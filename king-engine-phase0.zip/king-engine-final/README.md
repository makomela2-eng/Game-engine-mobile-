# KING Engine

Custom Godot 4.6.1 game engine — mobile-first, ECS-driven, full editor integration.

**Docs:** `docs/README.md` · `docs/architecture.md` · `docs/usage.md`

## Run
1. Open in Godot 4.6.1  
2. Enable plugin: Project Settings → Plugins → KING Editor  
3. Press F5 (Boot scene)

## Test
Open `scenes/test/DebugScene.tscn` → F6
