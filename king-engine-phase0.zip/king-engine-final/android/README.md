# Android Export

## Requirements
- Android SDK (API 33+)
- Godot Android Build Template (installed via editor Export dialog)
- `debug.keystore` in this directory

## Generating a debug keystore
```bash
keytool -genkey -v \
  -keystore android/build/debug.keystore \
  -alias androiddebugkey \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass android -keypass android \
  -dname "CN=Android Debug,O=Android,C=US"
```

## Export steps
1. Project → Export → Android
2. Set keystore path to `android/build/debug.keystore`
3. Click Export Project
