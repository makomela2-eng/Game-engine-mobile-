## Migration script: save format 0.9.x → 1.0.0
## Run once on load when _version < "1.0.0"
extends RefCounted

static func migrate(data: Dictionary) -> Dictionary:
	# 0.9 used "hp" key; 1.0 uses "health"
	if data.has("player"):
		var p : Dictionary = data["player"]
		if p.has("hp") and not p.has("health"):
			p["health"] = p["hp"]
			p.erase("hp")
		if not p.has("max_health"):
			p["max_health"] = 100
	data["_version"] = "1.0.0"
	return data
