# KING Engine

**KING** is a custom game engine layer built on top of Godot 4.6.1, designed for
mobile-first 3D games with a full in-editor authoring workflow, ECS architecture,
streaming world support, and tiered device performance scaling.

---

## Quick Start

1. Open the project in **Godot 4.6.1** or later.
2. Enable the plugin: **Project → Project Settings → Plugins → KING Editor → Enable**.
3. Press **F5** to run the Boot scene (`scenes/boot/Boot.tscn`).
4. Open the custom editor via the **Dashboard** scene (`scenes/dashboard/Dashboard.tscn`).

---

## Project Layout

```
king/
├── addons/king_editor/        # Godot EditorPlugin + all dock panels
│   └── systems/               # KingToolbar, KingHierarchyPanel, KingInspectorDock, …
├── engine/editor/             # editor_root.gd — dock registration & state manager
├── src/
│   ├── core/                  # Log, Bus, Kernel, SaveLoadManager, Cfg, Version
│   ├── ecs/                   # EntityManager, Component, SystemBase, all components & systems
│   ├── gameplay/              # SceneSession, PrefabLibrary, KingUndoRedo, SceneValidator
│   ├── platform/              # DeviceCap, InputRouter, BatteryMonitor, ThermalMonitor, …
│   ├── rendering/             # LODManager, MaterialManager, ShaderManager, GraphicsScaler, …
│   ├── runtime/               # TaskScheduler, FrameBudget, MemoryBudget, Watchdog
│   ├── services/              # UIStack, StateMachine, LocalizationSystem, Registry, Pool, …
│   ├── streaming/             # WorldChunkManager, SceneStream, AssetStream
│   ├── diagnostics/           # LogCapture, PerfMonitor, CrashGuard, RuntimeValidator
│   └── tooling/               # DevUI, AnalyticsSystem
├── scenes/
│   ├── boot/                  # Boot.tscn — entry point
│   ├── dashboard/             # Dashboard.tscn — in-game editor UI
│   ├── editor/                # KingEditorScene.tscn
│   ├── gameplay/              # GameWorld.tscn, GameSession.tscn
│   ├── ui/                    # MainMenu.tscn, HUD.tscn
│   └── test/                  # TestLevel, BenchmarkScene, DebugScene
├── prefabs/
│   ├── player/                # Player.tscn + Player.gd
│   └── enemy/                 # Enemy.tscn + Enemy.gd
├── assets/
│   ├── textures/              # .png / .svg / .webp
│   ├── audio/                 # .wav / .ogg / .mp3
│   ├── fonts/                 # .ttf / .otf
│   ├── models/                # .glb / .gltf
│   ├── shaders/               # .gdshader
│   └── animations/            # .res animation resources
├── locales/                   # en.json, es.json, fr.json
├── tests/
│   ├── unit/                  # test_entity_manager, test_save_load, test_bus_events
│   └── integration/           # test_ecs_pipeline, test_scene_streaming
└── docs/                      # README.md, architecture.md, usage.md
```

---

## Running Tests

Open `scenes/test/DebugScene.tscn` and press **F6**. All unit tests execute
automatically and print results to the Godot Output panel.

---

## Export

See `export_presets.cfg` for Android and desktop targets.
Android requires a keystore at `android/build/debug.keystore`.
