# KING Engine — API Reference

## EntityManager (Autoload)

| Method | Returns | Description |
|--------|---------|-------------|
| `create_entity()` | `int` | Create a new entity, returns its id |
| `create_entity_with_id(id)` | `int` | Create at specific id (for save/restore) |
| `destroy_entity(id)` | `void` | Destroy entity and emit events |
| `entity_exists(id)` | `bool` | Check if entity is alive |
| `entity_count()` | `int` | Total live entities |
| `add_component(id, type, comp)` | `void` | Attach a component |
| `get_component(id, type)` | `Component` | Retrieve a component or null |
| `has_component(id, type)` | `bool` | Check for component presence |
| `remove_component(id, type)` | `void` | Detach a component |
| `get_entities_with(types[])` | `Array[int]` | Query by required components |
| `get_entities_without(types[])` | `Array[int]` | Exclude by component |
| `get_all_entities()` | `Array[int]` | All live entity ids |
| `add_tag(id, tag)` | `void` | Add a StringName tag |
| `remove_tag(id, tag)` | `void` | Remove a tag |
| `has_tag(id, tag)` | `bool` | Check tag presence |
| `get_entities_by_tag(tag)` | `Array[int]` | All entities with tag |
| `get_entity_id(node)` | `Variant` | node → entity id (or null) |
| `snapshot()` | `Dictionary` | Serialise all entities |
| `restore_snapshot(data)` | `void` | Restore from snapshot |
| `clear_all()` | `void` | Wipe all entities |
| `debug_dump()` | `void` | Print entity table to Log |

---

## SystemBase (base class)

Override these in every system:

```gdscript
func _on_start() -> void:   # Subscribe to Bus events
func _on_stop()  -> void:   # Unsubscribe (required — no leaks)
func tick(delta: float) -> void:  # Per-frame logic
```

Helpers available in every system:

```gdscript
listen(event, fn)            # Bus.on wrapper + auto-cleanup tracking
unlisten(event, fn)          # Bus.off wrapper
broadcast(event, entity, {}) # emit { entity, data } on Bus
query([&"Type", ...])        # EntityManager.get_entities_with shorthand
get_c(entity, &"Type")       # EntityManager.get_component shorthand
```

---

## QueryBuilder

```gdscript
QueryBuilder.new(EntityManager)
    .with(&"Transform")
    .with(&"Velocity")
    .without(&"Dead")
    .tag(&"enemy")
    .build()                  # → EntityQuery

query.results()               # Array[int]
query.for_each(fn)            # fn(entity_id)
query.for_each_with(&"T", fn) # fn(entity_id, component)
query.where(predicate)        # → new EntityQuery (filtered)
query.first()                 # first entity id or -1
query.count()                 # int
```

---

## CommandBuffer (Autoload: Commands)

```gdscript
Commands.spawn()
    .add(&"Transform", TransformComponent.new())
    .add(&"Velocity",  VelocityComponent.new())
    .tag(&"enemy")
    .commit()

Commands.destroy(entity_id)
Commands.add_component(id, &"Type", component)
Commands.remove_component(id, &"Type")
Commands.add_tag(id, &"tag")
Commands.remove_tag(id, &"tag")
Commands.flush()   # Called automatically by GameLoop
```

---

## Bus (Autoload)

```gdscript
Bus.on(&"event.name", callable)
Bus.off(&"event.name", callable)
Bus.emit(&"event.name", data)   # data: any Variant
```

All engine events use namespaced StringName constants — see `EventTypes`.

---

## SaveManager (Autoload)

```gdscript
SaveManager.save(slot)           # → bool
SaveManager.load_save(slot)      # → bool
SaveManager.save_exists(slot)    # → bool
SaveManager.delete_save(slot)
SaveManager.list_saves()         # → Array[int]
# Signals: save_completed, load_completed, save_failed, load_failed
```

---

## ResourceManager (Autoload)

```gdscript
ResourceManager.register(&"player_mesh", "res://assets/player.mesh", &"Mesh")
ResourceManager.get_resource(&"player_mesh")   # → Resource (sync)
ResourceManager.get_async(&"player_mesh")      # background load
ResourceManager.preload_group([&"a", &"b"])    # batch async
ResourceManager.is_ready(&"player_mesh")       # → bool
ResourceManager.stats()                        # → { registered, loaded, cached }
```

---

## AudioManager (Autoload)

```gdscript
AudioManager.play(&"sound_id", &"SFX", -6.0)
AudioManager.stop(&"sound_id")
AudioManager.stop_all()
AudioManager.set_bus_volume(&"Music", 0.8)
AudioManager.set_bus_muted(&"Music", true)

# Or via Bus:
Bus.emit(&"audio.play",  { id = &"explosion", bus = &"SFX" })
Bus.emit(&"audio.stop",  { id = &"music_loop" })
```

---

## PrefabInstance (Autoload)

```gdscript
var id := PrefabInstance.spawn(&"enemy_goblin", Vector3(10, 0, 5))
PrefabInstance.despawn(id)
```

Prefabs must be registered in `PrefabRegistry` (loaded by `PrefabLoader.load_all()`).

---

## DataRegistry (Autoload)

```gdscript
DataRegistry.load_table(&"items",  "res://data/items.json",  "id")
DataRegistry.load_table(&"quests", "res://data/quests.json", "id")

var sword := DataRegistry.get_entry(&"items", &"iron_sword")
var all   := DataRegistry.get_all(&"items")
DataRegistry.has_entry(&"items", &"iron_sword")   # bool
```

---

## CameraManager (Autoload)

```gdscript
CameraManager.register(&"main", $Camera3D)
CameraManager.activate(&"main")
CameraManager.activate(&"cutscene", 1.5)   # 1.5s blend
CameraManager.get_active()                 # → Camera3D
```

---

## InventorySystem (Autoload)

```gdscript
InventorySystem.init_inventory(entity, 20)
InventorySystem.add_item(entity, &"iron_sword", 1)   # → bool
InventorySystem.remove_item(entity, &"potion", 2)    # → bool
InventorySystem.has_item(entity, &"key")             # → bool
InventorySystem.get_item_count(entity, &"gold")      # → int
InventorySystem.get_inventory(entity)                # → Dictionary
```

---

## QuestSystem (Autoload)

```gdscript
QuestSystem.start_quest(&"main_001")
QuestSystem.advance_objective(&"main_001", &"kill_goblins", 1)
QuestSystem.get_state(&"main_001")       # QuestSystem.QuestState
QuestSystem.active_quests()              # Array[StringName]
```

---

## Profiler (Autoload)

```gdscript
Profiler.begin(&"my_system")
# ... work ...
Profiler.end(&"my_system")
var ms := Profiler.get_ms(&"my_system")
var avg := Profiler.get_avg_ms(&"my_system")
Profiler.dump()   # print all scopes to Log
```

---

## Console (Autoload)

```gdscript
Console.register(&"spawn", func(args): PrefabInstance.spawn(args[0], Vector3.ZERO), "Spawn a prefab")
Console.print_line("Hello from engine", "cyan")
# Toggle with backtick (`)
```

---

## NetworkManager (Autoload)

```gdscript
NetworkManager.host(7777, 16)
NetworkManager.join("192.168.1.10", 7777)
NetworkManager.is_server()        # bool
NetworkManager.get_peers()        # Array[int]
NetworkManager.disconnect_all()
# Signals: peer_connected, peer_disconnected, connection_failed, connected_to_server
```
