# KING Engine — Architecture

## Overview

KING is a custom engine layer built on top of Godot 4.6. Godot handles rendering, physics, input, and audio primitives. KING provides a data-driven ECS, lifecycle management, streaming, and editor tooling on top.

---

## Layer Map

```
┌─────────────────────────────────────────────────┐
│                  Game Code                      │  /scenes  /prefabs
├─────────────────────────────────────────────────┤
│               Gameplay Systems                  │  /src/gameplay
│  Combat · Health · Inventory · Quest · AI · Nav │
├─────────────────────────────────────────────────┤
│               Engine Services                   │  /src/services  /src/save
│  SaveManager · UISystem · AudioManager · Net    │
├─────────────────────────────────────────────────┤
│                   ECS Core                      │  /src/ecs
│  EntityManager · SystemScheduler · QuerySystem  │
│  ComponentStorage · ArchetypeStorage · Commands │
├─────────────────────────────────────────────────┤
│              Platform / Runtime                 │  /src/platform  /src/runtime
│  GameLoop · WorldManager · DeviceCap · Input    │
├─────────────────────────────────────────────────┤
│                  Godot 4.6                      │
│  Rendering · Physics · Audio · OS · Navigation  │
└─────────────────────────────────────────────────┘
```

---

## ECS

### Entities
Plain integer IDs. Created via `EntityManager.create_entity()`. Destroyed via `EntityManager.destroy_entity(id)`.

### Components
`RefCounted` subclasses of `Component`. Never store logic — data only.
All components override `component_type() -> StringName`.

### Systems
`Node` subclasses of `SystemBase`. Override `_on_start()`, `_on_stop()`, `tick(delta)`.
Registered in `SystemRegistry`. Driven by `SystemScheduler` in priority order.

### Query
```gdscript
# Simple
var entities := EntityManager.get_entities_with([&"Transform", &"Velocity"])

# Fluent
var q := QueryBuilder.new(EntityManager)\
    .with(&"Transform").without(&"Dead").tag(&"enemy").build()
q.for_each(func(e): ...)
```

### Commands (deferred mutations)
```gdscript
Commands.spawn().add(&"Transform", TransformComponent.new()).commit()
Commands.destroy(entity_id)
Commands.flush()  # Called by GameLoop each tick
```

---

## Game Loop

```
GameLoop._process(delta)
  ├── SystemScheduler.tick_all(delta)   ← all systems in priority order
  ├── Commands.flush()                  ← apply deferred ECS mutations
  └── EventBus.flush()                 ← dispatch deferred events
```

Priority convention:
- `10–99`   Input systems
- `100–999`  Gameplay systems
- `2000–2999` Combat / health
- `3000–3999` Inventory / interaction / quest
- `4000–4999` AI / navigation
- `5000–5999` Physics
- `6000–6999` Animation
- `7000–7999` Audio
- `8000–8999` Rendering / camera
- `9000+`    Sync (EntityToSceneSync runs last)

---

## Events

All events route through `Bus` (global event bus). Use `StringName` constants from `EventTypes`.

```gdscript
Bus.emit(&"gameplay.entity_damaged", { "entity": id, "data": { "amount": 10.0 } })
Bus.on(&"gameplay.entity_damaged", _on_damaged)
Bus.off(&"gameplay.entity_damaged", _on_damaged)
```

For deferred end-of-frame events: `EventBus.enqueue(...)` → flushed by `GameLoop`.

---

## Autoload Order (project.godot)

```
Log            → src/core/Log.gd
Bus            → src/core/Bus.gd
Kernel         → src/core/Kernel.gd
EntityManager  → src/ecs/entity_manager.gd
SystemRegistry → src/ecs/system_registry.gd
SystemScheduler→ src/ecs/system_scheduler.gd
QuerySystem    → src/ecs/query_system.gd
Commands       → src/ecs/commands/command_buffer.gd
EventBus       → src/ecs/events/event_bus.gd
GameLoop       → src/runtime/game_loop.gd
WorldManager   → src/runtime/world_manager.gd
...            → all other autoloads
```

---

## Directory Structure

```
res://
├── src/
│   ├── core/           Log, Bus, Kernel, Cfg, SaveDir, Version
│   ├── components/     All Component subclasses
│   ├── ecs/            EntityManager, SystemBase, Registry, Scheduler
│   │   ├── storage/    ComponentStorage, ArchetypeStorage, SparseSet
│   │   ├── query/      EntityQuery, QueryBuilder
│   │   ├── events/     EventBus, EventTypes
│   │   └── commands/   CommandBuffer
│   ├── runtime/        GameLoop, WorldManager, Bridges
│   ├── gameplay/       Combat, Health, Inventory, Quest, AI, Nav
│   ├── input/          InputManager, InputMap, InputBuffer, InputSystem
│   ├── rendering/      Pipeline, RenderSystem, CameraSystem
│   │   ├── material/   MaterialManager, MaterialInstance
│   │   └── shader/     ShaderManager, ShaderLibrary
│   ├── world/          WorldStreamer, ChunkManager, LevelLoader, LOD
│   ├── assets/         AssetRegistry, Loader, Cache, ResourceManager
│   ├── audio/          AudioManager, AudioSystem, SoundPlayer, AudioBus
│   ├── animation/      AnimationSystem, Animator, StateMachine, BlendTree
│   ├── physics/        PhysicsSystem, CollisionSystem, PhysicsWorld
│   ├── ai/             BehaviorTree, DecisionSystem, Pathfinding
│   ├── camera/         CameraManager, CameraController, CameraModes
│   ├── save/           SaveManager, Serializer, Deserializer, SaveFormat
│   ├── network/        NetworkManager, ReplicationSystem, RPC, Sync
│   ├── ui/             UISystem, Widget, LayoutSystem, StyleSystem
│   ├── data/           ConfigLoader, JSONLoader, DataRegistry
│   ├── jobs/           JobSystem, WorkerPool, TaskScheduler
│   ├── debug/          DebugOverlay, Console, Profiler, EntityInspector
│   ├── scripting/      ScriptRuntime, ScriptLoader, ScriptBinding
│   ├── services/       ServiceLocator, DependencyContainer, EventService
│   ├── platform/       PlatformManager, InputAdapter, DeviceManager
│   ├── plugins/        PluginManager, PluginLoader
│   ├── extensions/     ExtensionAPI, ModuleLoader
│   ├── prefab/         Prefab, PrefabRegistry, PrefabLoader, PrefabInstance
│   ├── tooling/        ToolManager, SelectionSystem, GizmoSystem, EditorBridge
│   └── testing/        TestRunner, UnitTest, IntegrationTest
├── addons/king_editor/ Editor plugin
├── assets/prefabs/     Prefab .tres files
├── scenes/             Boot, gameplay scenes
├── prefabs/            Scene-based prefabs
├── data/               JSON data tables
└── docs/               This file + api_reference.md
```
