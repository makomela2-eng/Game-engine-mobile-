# KING Engine — Usage Guide

## Editor Panels

| Panel | Dock Slot | Purpose |
|---|---|---|
| KING Hierarchy | Left Upper | Scene node tree, select / add / delete |
| KING Assets | Left Lower | res:// file browser, open scenes & scripts |
| KING Viewport | Left Upper | Gizmo mode, snap, camera speed |
| KING File | Left Lower | New/Open/Save scene dialogs |
| KING Systems | Right Upper | Live autoload status list |
| KING Scene | Right Upper | Entity/component authoring |
| KING Inspector | Right Lower | Live node property viewer |
| KING Logs | Left Lower | Colour-coded log viewer with search |
| KING System Graph | Right Upper | System dependency visualiser |
| KING Toolbar | Toolbar | Screen switcher (2D / 3D / Script / Game) |

---

## Creating an Entity

1. Open the **KING Scene** dock (right panel).
2. Click **+ Entity** — a new entity ID appears in the list.
3. Select the entity row, then click **+ Comp**.
4. Choose a component type from the popup.
5. The component appears in the lower list.

## Converting a Node to a Prefab

1. Select the entity in **KING Scene**.
2. Click **→ Prefab** — the scene is saved to `res://prefabs/<name>.tscn`.

## Running the Test Suite

Open `scenes/test/DebugScene.tscn` → **F6**.
Results appear in the Godot **Output** panel.

## Localization

`LocalizationSystem` reads from `res://locales/<lang>.json`.
Call `LocalizationSystem.tr("KEY")` anywhere in GDScript.
Add new languages by creating `locales/<code>.json` with matching keys.

## Device Tiers

`DeviceCap` detects hardware on startup and sets `DeviceCap.tier` (0/1/2).
Override for testing:
```gdscript
DeviceCap.force_tier(1)  # force mid-tier
```

## Save / Load

```gdscript
# Save
SaveLoadManager.save_data("user://save_slot_1.json", my_data_dict)

# Load
var data : Variant = SaveLoadManager.load_data("user://save_slot_1.json")
```
