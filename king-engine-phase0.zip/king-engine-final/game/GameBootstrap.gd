## GameBootstrap — the ONLY game-layer autoload.
##
## Listens for engine_ready. Then and only then:
##   1. Loads game data tables into DataRegistry.
##   2. Loads all prefabs via PrefabLoader.
##   3. Spawns game/GameSystems.tscn.
##   4. Emits game_ready so game scenes can start.
##
## Engine knows nothing about this file.
## Nothing in src/ may reference GameBootstrap.
extends Node

const GAME_SYSTEMS_SCENE := "res://game/GameSystems.tscn"

var _cb : Callable

func _ready() -> void:
	_cb = _on_engine_ready
	Bus.on(&"engine_ready", _cb)

func _exit_tree() -> void:
	Bus.off(&"engine_ready", _cb)

func _on_engine_ready(_data: Variant) -> void:
	Bus.off(&"engine_ready", _cb)
	## PHASE 0: Register all component types before any save/load can occur.
	## This must run before _load_data_tables and _spawn_game_systems so that
	## any restore_snapshot calls triggered during boot find the registry populated.
	ComponentRegistry.register_all_defaults()
	_load_data_tables()
	_load_prefabs()
	_spawn_game_systems()

func _load_data_tables() -> void:
	const TABLES : Array[Array] = [
		[&"items",     "res://data/items.json"],
		[&"enemies",   "res://data/enemies.json"],
		[&"abilities", "res://data/abilities.json"],
		[&"quests",    "res://data/quests.json"],
	]
	for entry : Array in TABLES:
		var tname : StringName = entry[0]
		var path  : String     = entry[1]
		if ResourceLoader.exists(path):
			DataRegistry.load_table(tname, path)
		else:
			Log.warn("[GameBootstrap] Missing data table: %s" % path)

func _load_prefabs() -> void:
	PrefabLoader.load_all()

func _spawn_game_systems() -> void:
	if not ResourceLoader.exists(GAME_SYSTEMS_SCENE):
		Log.warn("[GameBootstrap] No GameSystems scene — engine-only mode")
		Bus.emit(&"game_ready", null)
		return
	var packed := load(GAME_SYSTEMS_SCENE) as PackedScene
	if packed == null:
		Log.error("[GameBootstrap] Failed to load GameSystems scene")
		Bus.emit(&"game_ready", null)
		return
	var systems := packed.instantiate()
	get_tree().root.add_child(systems)
	Log.info("[GameBootstrap] GameSystems loaded (%d systems)" % systems.get_child_count())
	get_tree().process_frame.connect(
		func() -> void: Bus.emit(&"game_ready", null),
		CONNECT_ONE_SHOT
	)
