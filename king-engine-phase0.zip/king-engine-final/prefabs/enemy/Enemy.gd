## Enemy — ECS-wired enemy. No logic here — all in systems.
##
## AISystem assigns a BehaviorTree (sense→chase→attack).
## NavigationSystem / Pathfinding drives movement.
## PhysicsSystem calls move_and_slide (single authority).
## HealthSystem + DamageSystem handle hp and death.
extends CharacterBody3D

## Enemy type id — matches DataRegistry "enemies" table.
@export var enemy_type : StringName = &"default_enemy"

var entity_id : int = -1

func _ready() -> void:
	_register_entity()

func _register_entity() -> void:
	entity_id = EntityManager.create_entity()

	EntityManager.add_component(entity_id, &"SceneNode",
		SceneNodeComponent.new(self))

	var tc := TransformComponent.new(global_position, rotation_degrees, scale)
	EntityManager.add_component(entity_id, &"Transform", tc)

	var vel := VelocityComponent.new()
	## Pathfinding owns velocity for this enemy — PhysicsSystem won't overwrite.
	vel.owner = &"pathfinding"
	EntityManager.add_component(entity_id, &"Velocity", vel)

	## HP from DataRegistry if available, else default 50.
	var data   := DataRegistry.get_entry(&"enemies", enemy_type)
	var max_hp := float(data.get("hp", 50.0))
	EntityManager.add_component(entity_id, &"Health", HealthComponent.new(max_hp))

	EntityManager.add_component(entity_id, &"Audio", AudioComponent.new(&"SFX"))

	EntityManager.add_tag(entity_id, &"enemy")
	EntityManager.add_tag(entity_id, &"ai")
	EntityManager.add_tag(entity_id, &"team_enemy")
	if enemy_type != &"":
		EntityManager.add_tag(entity_id, enemy_type)

	## Register with pathfinding so NavigationAgent3D is auto-created.
	Pathfinding.register_entity(entity_id)

	Log.debug("[Enemy] e%d (%s) registered" % [entity_id, enemy_type])

func _exit_tree() -> void:
	if entity_id >= 0:
		EntityManager.destroy_entity(entity_id)
		entity_id = -1
