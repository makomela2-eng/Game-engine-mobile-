## Player — ECS-wired player controller.
##
## This node is the scene bridge. It registers itself as an ECS entity
## on _ready and lets KING Engine systems handle the actual logic:
##   InputManager  → reads hardware, writes InputComponent
##   TouchInput    → writes InputComponent.move_dir on mobile
##   PhysicsSystem → reads Velocity, calls move_and_slide (single authority)
##   HealthSystem  → tracks hp, drives death
##   CameraSystem  → activates Camera3D via CameraComponent
##
## This file contains NO move_and_slide, NO velocity math, NO health math.
## All gameplay logic lives in the ECS systems.
extends CharacterBody3D

## Entity id assigned on _ready. -1 until registered.
var entity_id : int = -1

func _ready() -> void:
	_register_entity()

func _register_entity() -> void:
	entity_id = EntityManager.create_entity()

	## SceneNode — links this CharacterBody3D to the entity.
	EntityManager.add_component(entity_id, &"SceneNode",
		SceneNodeComponent.new(self))

	## Transform — initialised from scene position.
	var tc := TransformComponent.new(global_position, rotation_degrees, scale)
	EntityManager.add_component(entity_id, &"Transform", tc)

	## Velocity — PhysicsSystem writes here.
	EntityManager.add_component(entity_id, &"Velocity", VelocityComponent.new())

	## Health — HealthSystem drives this.
	EntityManager.add_component(entity_id, &"Health",
		HealthComponent.new(100.0))

	## Input — InputManager / TouchInput write here.
	EntityManager.add_component(entity_id, &"Input",
		InputComponent.new(0))

	## Camera — CameraSystem activates the Camera3D.
	var cam_comp := CameraComponent.new(true)
	cam_comp.fov = 75.0
	EntityManager.add_component(entity_id, &"Camera", cam_comp)

	## Audio emitter.
	EntityManager.add_component(entity_id, &"Audio",
		AudioComponent.new(&"SFX"))

	## Tags.
	EntityManager.add_tag(entity_id, &"player")
	EntityManager.add_tag(entity_id, &"team_player")

	## Register with Pathfinding so NavAgent is available (player uses it
	## for click-to-move or similar; remove if pure WASD).
	## Pathfinding.register_entity(entity_id)

	Log.info("[Player] Entity %d registered at %s" % [entity_id, global_position])
	Bus.emit(&"player_spawned", {"entity": entity_id})

func _exit_tree() -> void:
	if entity_id >= 0:
		EntityManager.destroy_entity(entity_id)
		entity_id = -1
