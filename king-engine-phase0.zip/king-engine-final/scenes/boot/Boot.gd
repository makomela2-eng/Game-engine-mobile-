## Boot — engine startup only.
##
## Knows nothing about game content.
## Loads EngineSystems, emits engine_ready, transitions to Empty.
## The game layer listens on engine_ready and owns everything after that.
extends Node

func _ready() -> void:
	Log.info("KING Engine %s — %s" % [Version.as_string(), Kernel.platform])

	if Kernel.is_mobile:
		FrameBudget.set_budget(4.0)

	InputMapConfig.load_defaults()

	call_deferred("_add_engine_systems")

func _add_engine_systems() -> void:
	var packed := load("res://scenes/engine/EngineSystems.tscn") as PackedScene
	if packed:
		var systems := packed.instantiate()
		get_tree().root.add_child(systems)
		Log.info("[Boot] EngineSystems loaded (%d systems)" % systems.get_child_count())
	else:
		Log.error("[Boot] EngineSystems.tscn missing — engine cannot start")
		return

	get_tree().process_frame.connect(_on_systems_ready, CONNECT_ONE_SHOT)

func _on_systems_ready() -> void:
	Bus.emit(&"engine_ready", null)
	if Kernel.is_debug:
		get_tree().change_scene_to_file("res://scenes/dashboard/Dashboard.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/engine/Empty.tscn")
