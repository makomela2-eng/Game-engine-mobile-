## Dashboard — KING Engine v2.1 — Phase 1 Editor
## New in Phase 1:
##   • Undo / Redo  (Ctrl+Z / Ctrl+Y, history panel)
##   • Multi-select nodes  (tap to add/remove from selection)
##   • Scene search  (filter nodes by name)
##   • Inspector history  (back / forward buttons)
##   • Scene validation  (Validate button shows issues list)
##   • Right-click context menu  (long-press on node row)
##   • Inspector property search / filter
##   • Dock split persistence  (saved to Cfg)
##   • Toolbar: new Validate, History, Search buttons
extends Control

# ── Palette ───────────────────────────────────────────────────────────────────
const C_BG0    := Color(0.047, 0.047, 0.055)
const C_BG1    := Color(0.078, 0.078, 0.090)
const C_BG2    := Color(0.102, 0.102, 0.118)
const C_BORDER := Color(1.0, 1.0, 1.0, 0.06)
const C_ACCENT := Color(0.220, 0.510, 1.000)
const C_TEXT   := Color(0.910, 0.910, 0.930)
const C_DIM    := Color(0.490, 0.490, 0.530)
const C_OK     := Color(0.216, 0.761, 0.408)
const C_WARN   := Color(0.961, 0.714, 0.196)
const C_ERR    := Color(0.937, 0.271, 0.314)
const C_SEL    := Color(0.220, 0.510, 1.000, 0.25)
const C_ENTITY := Color(0.800, 0.600, 1.000)
const C_MULTI  := Color(1.000, 0.750, 0.200)   # multi-select accent

# ── Viewport ──────────────────────────────────────────────────────────────────
var _viewport_container : SubViewportContainer
var _viewport           : SubViewport
var _cam                : Camera3D
var _cam_pivot          : Node3D
var _cam_yaw            : float = 30.0
var _cam_pitch          : float = -25.0
var _cam_dist           : float = 12.0
var _scene_root         : Node3D

# ── Scene tree ────────────────────────────────────────────────────────────────
var _tree_list      : VBoxContainer
var _tree_search    : LineEdit
var _selected_nodes : Array[Node] = []        # multi-select
var _selected_node  : Node:                   # primary selection
	get: return _selected_nodes.back() if not _selected_nodes.is_empty() else null

# ── ECS ───────────────────────────────────────────────────────────────────────
var _entity_list    : VBoxContainer
var _selected_entity: int = -1
## System names highlighted because the selected entity is in their cache.
## Cleared when selection changes to a non-entity or a different entity.
var _entity_highlight_systems : Array[String] = []
## Entity IDs highlighted by a system-selection click in the Systems tab.
## Empty = no system filter active.
var _system_highlight_ids : Array[int] = []
var _system_highlight_name : String = ""

# ── Inspector + history ───────────────────────────────────────────────────────
var _insp_list      : VBoxContainer
var _insp_scroll    : ScrollContainer
var _insp_mode      : String = "node"
var _insp_search    : LineEdit
var _insp_history   : Array  = []    # Array of {mode, node, entity}
var _insp_hist_idx  : int    = -1
var _insp_back_btn  : Button
var _insp_fwd_btn   : Button

# ── Undo/Redo ─────────────────────────────────────────────────────────────────
var _undo_redo      : Node          # KingUndoRedo instance
var _undo_lbl       : Label

# ── Scene validator ───────────────────────────────────────────────────────────
var _validator      : Node          # SceneValidator instance
var _validation_list: VBoxContainer
var _validate_btn   : Button

# ── Stats bar ─────────────────────────────────────────────────────────────────
var _lbl_fps     : Label
var _lbl_mem     : Label
var _lbl_nodes   : Label
var _lbl_entities: Label

# ── Play controls ─────────────────────────────────────────────────────────────
var _btn_play  : Button
var _btn_pause : Button
var _btn_stop  : Button
var _playing   : bool = false
var _paused    : bool = false

# ── P2: Play-mode visual state ────────────────────────────────────────────────
## Toolbar StyleBoxFlat ref so we can tint its bg during play/pause/stop.
var _toolbar_style  : StyleBoxFlat = null
## Full-width banner that sits over the toolbar when playing.
var _play_banner    : PanelContainer = null
var _play_banner_lbl: Label = null

# ── Toast notification ────────────────────────────────────────────────────────
## Lightweight floating label that appears bottom-center of viewport,
## fades out after 1.8s. One at a time — new toast cancels previous.
var _toast_label  : Label = null
var _toast_tween  : Tween = null

# ── Gizmo ─────────────────────────────────────────────────────────────────────
var _gizmo_mode   : int = 0
var _gizmo_btns   : Array[Button] = []
var _snap_enabled : bool = false
const GRID_SNAP   := 0.5

# ── Axis-constrained drag state ───────────────────────────────────────────────
var _drag_axis          : int              = -1
var _axis_tips2d        : Array[Vector2]   = []
const AXIS_HIT_PX       := 28.0
var _drag_plane         : Plane            = Plane()
var _drag_start_hit     : Vector3          = Vector3.ZERO
var _drag_node_origins  : Array[Vector3]   = []
var _drag_active        : bool             = false
var _last_drag_hit      : Vector3          = Vector3.ZERO  ## hit cache for miss frames
var _hover_axis         : int              = -1             ## axis nearest finger (no touch)

# ── P0: Selection outline overlay ────────────────────────────────────────────
var _sel_overlay  : Control = null
## Drives selection-flash: counts down from 1.0→0.0 after a new selection.
## Used by _draw_selection_overlay to thicken the outline briefly on select.
var _sel_flash_t  : float   = 0.0

# ── P0: 3D gizmo arrows ───────────────────────────────────────────────────────
var _gizmo_mesh_inst : MeshInstance3D = null
var _gizmo_imm       : ImmediateMesh  = null
const GIZMO_LEN      := 1.2

# ── Scene objects ─────────────────────────────────────────────────────────────
var _spawned    : Array[Node] = []
var _grid_lines : MeshInstance3D = null
## Tracks MeshInstance3D markers created for pure ECS entities (＋E button).
## Key = entity id (int), Value = MeshInstance3D node in _scene_root.
var _entity_markers : Dictionary = {}

# ── Context menu ──────────────────────────────────────────────────────────────
var _ctx_menu      : PopupMenu = null
var _ctx_target    : Node = null

# ── Add Node popup ────────────────────────────────────────────────────────────
var _add_node_popup     : PopupMenu = null
var _add_node_parent    : Node = null   # where to attach — null = scene root
var _long_press_t  : float = 0.0
var _long_press_pos: Vector2 = Vector2.ZERO
var _long_pressing : bool = false
const LONG_PRESS_SEC := 0.55

# ── Asset browser ─────────────────────────────────────────────────────────────
var _asset_list        : HBoxContainer
var _asset_path        : String = "res://"
var _asset_search_edit : LineEdit = null
var _asset_history     : Array[String] = []
var _asset_path_lbl    : Label = null

# ── Inspector pin ─────────────────────────────────────────────────────────────
var _insp_pinned       : bool = false
var _insp_overlay_panel : Control = null

# ── Camera speed ──────────────────────────────────────────────────────────────
var _cam_speed_scale   : float = 1.0
var _runtime_tick : float = 0.0
var _session_info_lbl : Label = null
var _prefab_name_edit : LineEdit = null
var _prefab_status_lbl : Label = null
var _prefab_list : VBoxContainer = null
var _selected_prefab_name : String = ""
var _runtime_vbox     : VBoxContainer = null
var _runtime_info_lbl : Label         = null

# ── P3: Performance sparkline ─────────────────────────────────────────────────
const PERF_HISTORY_MAX  := 80          ## samples kept (1 per Bus perf_snap tick)
var _perf_fps_buf  : Array[float] = [] ## rolling FPS samples
var _perf_mem_buf  : Array[float] = [] ## rolling mem-MB samples
var _perf_graph    : Control      = null  ## the drawing Control

# ── Event log ─────────────────────────────────────────────────────────────────
var _event_list   : VBoxContainer
var _event_scroll : ScrollContainer
const EVENT_LOG_MAX := 80

# ── Split containers (for persistence) ────────────────────────────────────────
var _mid_split    : HSplitContainer
var _right_split  : HSplitContainer
var _vert_split   : VSplitContainer

# ══════════════════════════════════════════════════════════════════════════════
func _ready() -> void:
	set_process(true)
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_boot_subsystems()
	_build_ui()
	_spawn_editor_world()
	_build_context_menu()
	_build_add_node_popup()
	_restore_splits()
	Bus.on(&"perf_snap",             _on_perf)
	Bus.on(&"scene_validation_done", _on_validation_done)
	Bus.on(&"undo_history_changed",  _on_undo_changed)
	Bus.on(&"ecs.entity_created",    _on_ecs_entity_created)
	Bus.on(&"ecs.entity_destroyed",  _on_ecs_entity_destroyed)
	Bus.on(&"ecs.component_added",   _on_ecs_event)
	Bus.on(&"ecs.component_removed", _on_ecs_event)
	Bus.on(&"scene_loaded",          _on_scene_loaded)
	Bus.on(&"editor.system_selected", _on_system_selected)
	TaskScheduler.schedule(&"dash_tree_refresh", 2.0, _refresh_scene_tree)
	## Create markers for any entities that already existed before the dashboard opened
	call_deferred("_sync_existing_entity_markers")
	Log.info("[Dashboard] Phase 1 ready")

# ── Subsystems ────────────────────────────────────────────────────────────────

func _boot_subsystems() -> void:
	var ur_script := load("res://src/gameplay/KingUndoRedo.gd") as Script
	_undo_redo = Node.new()
	_undo_redo.set_script(ur_script)
	_undo_redo.name = "KingUndoRedo"
	add_child(_undo_redo)

	var val_script := load("res://src/gameplay/SceneValidator.gd") as Script
	_validator = Node.new()
	_validator.set_script(val_script)
	_validator.name = "SceneValidator"
	add_child(_validator)

## Creates viewport markers for any entities that existed before the dashboard
## opened (e.g. spawned by TestLevel). Runs deferred so _scene_root exists.
func _sync_existing_entity_markers() -> void:
	if not is_instance_valid(_scene_root): return
	var created := 0
	for id : int in EntityManager.get_all_entities():
		if _entity_markers.has(id): continue
		## Skip if already has a SceneNode — it has a real visual
		if EntityManager.has_component(id, &"SceneNode"): continue
		var tc := EntityManager.get_component(id, &"Transform") as TransformComponent
		if tc == null: continue
		var marker := MeshInstance3D.new()
		marker.name = "Entity_%d" % id
		var sm := SphereMesh.new()
		sm.radius = 0.18; sm.height = 0.36; sm.radial_segments = 6; sm.rings = 3
		marker.mesh = sm
		var mat := StandardMaterial3D.new()
		mat.albedo_color     = C_ENTITY
		mat.emission_enabled = true
		mat.emission         = C_ENTITY * 0.6
		mat.shading_mode     = BaseMaterial3D.SHADING_MODE_UNSHADED
		marker.set_surface_override_material(0, mat)
		marker.position = tc.position
		_scene_root.add_child(marker)
		_entity_markers[id] = marker
		created += 1
	if created > 0:
		_refresh_scene_tree()
		_toast("👁  %d entities mapped" % created, C_ENTITY)

# ── Top-level layout ──────────────────────────────────────────────────────────

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = C_BG0
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 0)
	add_child(root)

	root.add_child(_build_stats_bar())
	root.add_child(_build_toolbar())

	_mid_split = HSplitContainer.new()
	_mid_split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_mid_split.split_offset = 220

	_right_split = HSplitContainer.new()
	_right_split.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_right_split.split_offset = -230

	_mid_split.add_child(_build_left_panel())
	_mid_split.add_child(_right_split)

	## On mobile: viewport fills the right side, inspector floats as overlay
	_right_split.add_child(_build_viewport_panel())
	var insp_panel := _build_inspector_panel()
	if Kernel.is_mobile:
		## Hide inspector by default; it slides in when a node is selected
		insp_panel.visible = false
		insp_panel.custom_minimum_size.x = 0
	_right_split.add_child(insp_panel)
	## Store reference so selection can toggle visibility
	_insp_overlay_panel = insp_panel

	_vert_split = VSplitContainer.new()
	_vert_split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_vert_split.split_offset = -160
	_vert_split.add_child(_mid_split)
	_vert_split.add_child(_build_bottom_panel())
	root.add_child(_vert_split)

	# Save splits on drag
	_mid_split.dragged.connect(func(_o): _save_splits())
	_right_split.dragged.connect(func(_o): _save_splits())
	_vert_split.dragged.connect(func(_o): _save_splits())

# ── Stats bar ─────────────────────────────────────────────────────────────────

func _build_stats_bar() -> Control:
	var bar := PanelContainer.new()
	bar.custom_minimum_size.y = 28
	var style := StyleBoxFlat.new()
	style.bg_color = C_BG1
	style.border_width_bottom = 1
	style.border_color = C_BORDER
	bar.add_theme_stylebox_override("panel", style)
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 16)
	bar.add_child(hbox)
	hbox.add_child(_lbl("KING v" + Version.as_string(), 10, C_ACCENT))
	hbox.add_child(_sep())
	# Undo label
	_undo_lbl = _lbl("", 9, C_DIM)
	hbox.add_child(_undo_lbl)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hbox.add_child(spacer)
	_lbl_fps      = _lbl("-- fps",      11, C_OK)
	_lbl_mem      = _lbl("-- MB",       11, C_DIM)
	_lbl_nodes    = _lbl("-- nodes",    11, C_DIM)
	_lbl_entities = _lbl("-- entities", 11, C_ENTITY)
	for l: Label in [_lbl_fps, _lbl_mem, _lbl_nodes, _lbl_entities]:
		hbox.add_child(_sep()); hbox.add_child(l)
	return bar

# ── Toolbar ───────────────────────────────────────────────────────────────────

func _build_toolbar() -> Control:
	var bar := PanelContainer.new()
	bar.custom_minimum_size.y = 38
	var style := StyleBoxFlat.new()
	style.bg_color = C_BG1
	bar.add_theme_stylebox_override("panel", style)
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 4)
	bar.add_child(hbox)

	# Play
	_btn_play  = _tool_btn("▶",  C_OK,   func(): _do_play())
	_btn_pause = _tool_btn("⏸", C_WARN, func(): _do_pause())
	_btn_stop  = _tool_btn("⏹",  C_ERR,  func(): _do_stop())
	_btn_pause.disabled = true; _btn_stop.disabled = true
	hbox.add_child(_btn_play); hbox.add_child(_btn_pause); hbox.add_child(_btn_stop)
	hbox.add_child(_vsep())

	# Undo / Redo
	hbox.add_child(_tool_btn("↩", C_DIM, func(): _undo_redo.call("undo")))
	hbox.add_child(_tool_btn("↪", C_DIM, func(): _undo_redo.call("redo")))
	hbox.add_child(_vsep())

	# Gizmos
	for i in ["Q", "W", "E", "R"].size():
		var labels := ["Q", "W", "E", "R"]
		var btn := _tool_btn(labels[i], C_DIM, Callable())
		btn.pressed.connect(func(idx := i): _set_gizmo(idx))
		_gizmo_btns.append(btn); hbox.add_child(btn)
	_set_gizmo(0)
	hbox.add_child(_vsep())

	# Spawn
	for pair: Array in [
		["＋Cube", _spawn_cube], ["＋Sph", _spawn_sphere],
		["＋Cap",  _spawn_capsule], ["＋Lit", _spawn_light],
		["CLR",    _clear_spawned]]:
		hbox.add_child(_tool_btn(pair[0] as String, C_TEXT, pair[1] as Callable))
	hbox.add_child(_vsep())

	# ECS
	hbox.add_child(_tool_btn("＋E", C_ENTITY, _spawn_entity))
	hbox.add_child(_vsep())

	# Validate
	_validate_btn = _tool_btn("✔ VAL", C_OK, _run_validation)
	hbox.add_child(_validate_btn)
	hbox.add_child(_vsep())

	# Snap
	var snap_btn := _tool_btn("SNAP", C_DIM, Callable())
	snap_btn.pressed.connect(func(): _toggle_snap(snap_btn))
	hbox.add_child(snap_btn)

	# Focus selected
	var focus_tb_btn := _tool_btn("⊙F", C_DIM, _focus_selected)
	focus_tb_btn.tooltip_text = "Focus selected node"
	hbox.add_child(focus_tb_btn)

	# Debug shapes
	var dbg_btn := _tool_btn("COL", C_DIM, Callable())
	dbg_btn.tooltip_text = "Toggle collision shape visibility"
	dbg_btn.pressed.connect(func():
		_toggle_debug_shapes()
		dbg_btn.add_theme_color_override("font_color",
			C_WARN if _debug_shapes_visible else C_DIM))
	hbox.add_child(dbg_btn)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hbox.add_child(spacer)

	hbox.add_child(_tool_btn("↺CAM", C_DIM, _reset_camera))
	hbox.add_child(_vsep())
	hbox.add_child(_tool_btn("SAVE", C_OK,  func(): save_scene()))
	hbox.add_child(_tool_btn("LOAD", C_DIM, func(): load_scene()))

	## P2: Keep a reference to the toolbar style so _apply_play_style() can tint it.
	_toolbar_style = style

	## P2: Play banner — hidden until _do_play(). Sits anchored over the toolbar.
	_play_banner = PanelContainer.new()
	_play_banner.set_anchors_preset(Control.PRESET_FULL_RECT)
	_play_banner.visible = false
	_play_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var banner_style := StyleBoxFlat.new()
	banner_style.bg_color = Color(0.70, 0.10, 0.10, 0.82)
	_play_banner.add_theme_stylebox_override("panel", banner_style)
	_play_banner_lbl = Label.new()
	_play_banner_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_play_banner_lbl.vertical_alignment   = VERTICAL_ALIGNMENT_CENTER
	_play_banner_lbl.set_anchors_preset(Control.PRESET_FULL_RECT)
	_play_banner_lbl.add_theme_font_size_override("font_size", 11)
	_play_banner_lbl.add_theme_color_override("font_color", Color(1, 1, 1, 0.92))
	_play_banner.add_child(_play_banner_lbl)
	bar.add_child(_play_banner)

	return bar

# ── Left panel: Scene | Entities | Validate tabs ──────────────────────────────

func _build_left_panel() -> Control:
	var tabs := TabContainer.new()
	tabs.custom_minimum_size.x = 220
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tabs.add_theme_font_size_override("font_size", 10)
	tabs.add_child(_build_scene_tab())
	tabs.add_child(_build_entity_tab())
	tabs.add_child(_build_validate_tab())
	return tabs

# ── Scene tab (with search + multi-select) ────────────────────────────────────

func _build_scene_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Scene"
	panel.add_theme_constant_override("separation", 2)

	# ── + Add Node button ─────────────────────────────────────────────────────
	var add_row := HBoxContainer.new()
	add_row.add_theme_constant_override("separation", 2)
	var add_btn := Button.new()
	add_btn.text = "＋  Add Node"
	add_btn.flat = false
	add_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_btn.add_theme_font_size_override("font_size", 11)
	add_btn.add_theme_color_override("font_color", C_OK)
	var add_style := StyleBoxFlat.new()
	add_style.bg_color       = Color(C_OK.r, C_OK.g, C_OK.b, 0.12)
	add_style.border_color   = Color(C_OK.r, C_OK.g, C_OK.b, 0.4)
	add_style.border_width_bottom = 1; add_style.border_width_top    = 1
	add_style.border_width_left  = 1; add_style.border_width_right   = 1
	add_style.set_corner_radius_all(3)
	add_btn.add_theme_stylebox_override("normal", add_style)
	add_btn.pressed.connect(func():
		_add_node_parent = null
		_show_add_node_popup(add_btn.get_global_rect().end))
	add_row.add_child(add_btn)

	# Scene file actions — New / Save As
	var scene_row := HBoxContainer.new()
	scene_row.add_theme_constant_override("separation", 2)
	var new_btn := _tool_btn("New", C_DIM, _do_new_scene)
	new_btn.flat = false
	new_btn.add_theme_font_size_override("font_size", 10)
	scene_row.add_child(new_btn)
	var saveas_btn := _tool_btn("Save As", C_DIM, _do_save_scene_as)
	saveas_btn.flat = false
	saveas_btn.add_theme_font_size_override("font_size", 10)
	scene_row.add_child(saveas_btn)
	var focus_btn := _tool_btn("⊙ Focus", C_DIM, _focus_selected)
	focus_btn.flat = false
	focus_btn.add_theme_font_size_override("font_size", 10)
	focus_btn.tooltip_text = "Frame selected node in viewport"
	scene_row.add_child(focus_btn)
	panel.add_child(scene_row)

	panel.add_child(add_row)

	# Search bar
	_tree_search = LineEdit.new()
	_tree_search.placeholder_text = "🔍 search nodes…"
	_tree_search.add_theme_font_size_override("font_size", 10)
	_tree_search.text_changed.connect(func(_t: String): _refresh_scene_tree())
	panel.add_child(_tree_search)

	# Multi-select hint
	var hint := _lbl("Tap = select  •  Long-press = menu", 8, C_DIM)
	panel.add_child(hint)

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	_tree_list = VBoxContainer.new()
	_tree_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tree_list.add_theme_constant_override("separation", 1)
	scroll.add_child(_tree_list)
	return panel

func _refresh_scene_tree() -> void:
	if not is_instance_valid(_tree_list): return
	for c in _tree_list.get_children(): c.queue_free()
	if not is_instance_valid(_scene_root): return
	var filter : String = _tree_search.text.to_lower() if is_instance_valid(_tree_search) else ""
	_add_tree_node(_scene_root, 0, filter)

func _add_tree_node(node: Node, depth: int, filter: String) -> void:
	var name_str := str(node.name).to_lower()
	if not filter.is_empty() and not name_str.contains(filter):
		for child in node.get_children():
			_add_tree_node(child, depth, filter)
		return

	var is_selected := _selected_nodes.has(node)
	var is_primary  := node == _selected_node

	var row := HBoxContainer.new()
	row.custom_minimum_size.y = 24

	# Indent
	if depth > 0:
		var indent := Control.new()
		indent.custom_minimum_size.x = float(depth) * 12.0
		row.add_child(indent)

	# Node type icon
	var icon_lbl := _lbl(_node_icon(node), 11,
		C_ACCENT if is_primary else (C_MULTI if is_selected else C_DIM))
	icon_lbl.custom_minimum_size.x = 16
	row.add_child(icon_lbl)

	# Name button
	var btn := Button.new()
	btn.text = str(node.name)
	btn.flat = true
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	btn.add_theme_font_size_override("font_size", 11)
	btn.add_theme_color_override("font_color",
		C_ACCENT if is_primary else (C_MULTI if is_selected else C_TEXT))
	btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var n := node
	btn.pressed.connect(func(): _on_tree_tap(n))
	row.add_child(btn)

	# Inline + Add Child button (compact, always visible)
	var add_child_btn := Button.new()
	add_child_btn.text = "+"
	add_child_btn.flat = true
	add_child_btn.custom_minimum_size = Vector2(20, 22)
	add_child_btn.add_theme_font_size_override("font_size", 13)
	add_child_btn.add_theme_color_override("font_color", C_DIM)
	add_child_btn.tooltip_text = "Add child node"
	var captured_n := n
	add_child_btn.pressed.connect(func():
		_select_node_single(captured_n)
		_add_node_parent = captured_n
		_show_add_node_popup(add_child_btn.get_global_rect().end))
	row.add_child(add_child_btn)

	# Visibility toggle
	if node is Node3D:
		var vis_btn := _tool_btn("👁" if (node as Node3D).visible else "🚫", C_DIM, Callable())
		vis_btn.custom_minimum_size = Vector2(24, 24)
		vis_btn.pressed.connect(func():
			if is_instance_valid(n) and n is Node3D:
				(n as Node3D).visible = not (n as Node3D).visible
				_refresh_scene_tree())
		row.add_child(vis_btn)

	_tree_list.add_child(row)

	for child in node.get_children():
		_add_tree_node(child, depth + 1, filter)

func _on_tree_tap(node: Node) -> void:
	if _insp_pinned: return
	if _selected_nodes.has(node):
		_selected_nodes.erase(node)
		if Kernel.is_mobile and is_instance_valid(_insp_overlay_panel):
			_insp_overlay_panel.visible = not _selected_nodes.is_empty()
	else:
		_selected_nodes.append(node)
		_sel_flash_t = 1.0   ## pulse on tap-select
		if Kernel.is_mobile and is_instance_valid(_insp_overlay_panel):
			_insp_overlay_panel.visible = true
	_insp_mode = "node"
	_selected_entity = -1
	_refresh_scene_tree()
	_push_insp_history()
	_refresh_inspector()
	_rebuild_gizmo_mesh()
	if is_instance_valid(_sel_overlay): _sel_overlay.queue_redraw()

func _select_node_single(node: Node) -> void:
	_selected_nodes.clear()
	if is_instance_valid(node):
		_selected_nodes.append(node)
	_insp_mode = "node"
	_selected_entity = -1
	_sel_flash_t = 1.0   ## trigger outline pulse
	_refresh_scene_tree()
	_push_insp_history()
	_refresh_inspector()
	## Show inspector panel when something is selected
	if Kernel.is_mobile and is_instance_valid(_insp_overlay_panel):
		_insp_overlay_panel.visible = is_instance_valid(node)
	_rebuild_gizmo_mesh()
	if is_instance_valid(_sel_overlay): _sel_overlay.queue_redraw()

func _node_icon(node: Node) -> String:
	if node is Camera3D:            return "📷"
	if node is OmniLight3D:         return "💡"
	if node is SpotLight3D:         return "🔦"
	if node is DirectionalLight3D:  return "☀"
	if node is MeshInstance3D:      return "🧊"
	if node is CharacterBody3D:     return "🧍"
	if node is RigidBody3D:         return "🌀"
	if node is StaticBody3D:        return "🪨"
	if node is CollisionShape3D:    return "⬡"
	if node is Button:              return "🔲"
	if node is Label:               return "🔤"
	if node is VBoxContainer:       return "▤"
	if node is HBoxContainer:       return "▥"
	if node is PanelContainer:      return "▣"
	if node is Control:             return "⬜"
	if node is Node3D:              return "📦"
	return "●"

# ── Entity tab ────────────────────────────────────────────────────────────────

func _build_entity_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Entities"
	panel.add_theme_constant_override("separation", 0)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	_entity_list = VBoxContainer.new()
	_entity_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_entity_list.add_theme_constant_override("separation", 1)
	scroll.add_child(_entity_list)
	return panel

func _refresh_entity_list() -> void:
	if not is_instance_valid(_entity_list): return
	for c in _entity_list.get_children(): c.queue_free()
	var ids := EntityManager.get_all_entities()
	if ids.is_empty():
		_entity_list.add_child(_lbl("  No entities", 10, C_DIM))
		return
	for id: int in ids:
		_add_entity_row(id)
	if is_instance_valid(_lbl_entities):
		_lbl_entities.text = "%d entities" % ids.size()

func _add_entity_row(id: int) -> void:
	var row := HBoxContainer.new()
	row.custom_minimum_size.y = 24

	## Behavior color badge — left stripe shows idle behavior mode at a glance.
	var badge_color := _entity_behavior_color(id)
	var badge := ColorRect.new()
	badge.color         = badge_color
	badge.custom_minimum_size = Vector2(3, 0)
	badge.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_child(badge)

	var btn := Button.new()
	var comps := _get_component_names(id)
	var behavior_tag := _entity_behavior_tag(id)
	btn.text = " e%d  %s[%s]" % [id, behavior_tag, ", ".join(comps)]
	btn.flat = true
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	btn.add_theme_font_size_override("font_size", 10)

	## Highlight: accent if selected, highlight color if system-highlighted, dim otherwise.
	var is_sys_hl : bool = not _system_highlight_ids.is_empty() \
		and _system_highlight_ids.has(id)
	var font_color : Color
	if id == _selected_entity:
		font_color = C_ACCENT
	elif is_sys_hl:
		font_color = Color(1.0, 0.85, 0.3)   ## warm amber = "this system touches you"
	else:
		font_color = C_ENTITY

	btn.add_theme_color_override("font_color", font_color)
	btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn.pressed.connect(func(): _select_entity(id))
	row.add_child(btn)

	var del := _tool_btn("✕", C_ERR, Callable())
	del.custom_minimum_size = Vector2(20, 20)
	del.pressed.connect(func(): EntityManager.destroy_entity(id))
	row.add_child(del)
	_entity_list.add_child(row)

## Returns the idle behavior color for an entity's left badge, or transparent.
func _entity_behavior_color(id: int) -> Color:
	var ib := EntityManager.get_component(id, &"IdleBehavior") as IdleBehaviorComponent
	if ib == null: return Color(0, 0, 0, 0)
	match ib.mode:
		IdleBehaviorComponent.Mode.ORBIT:  return Color(0.3, 0.6, 1.0)   ## blue
		IdleBehaviorComponent.Mode.DRIFT:  return Color(1.0, 0.85, 0.2)  ## yellow
		IdleBehaviorComponent.Mode.BOB:    return Color(0.4, 0.9, 0.5)   ## green
		IdleBehaviorComponent.Mode.SPIN:   return Color(0.9, 0.4, 0.9)   ## magenta
		IdleBehaviorComponent.Mode.PATROL: return Color(1.0, 0.5, 0.2)   ## orange
	return Color(0, 0, 0, 0)

## Returns a short mode tag string, e.g. "⟳ " for orbit, or "" if none.
func _entity_behavior_tag(id: int) -> String:
	var ib := EntityManager.get_component(id, &"IdleBehavior") as IdleBehaviorComponent
	if ib == null: return ""
	match ib.mode:
		IdleBehaviorComponent.Mode.ORBIT:  return "⟳ "
		IdleBehaviorComponent.Mode.DRIFT:  return "~ "
		IdleBehaviorComponent.Mode.BOB:    return "↕ "
		IdleBehaviorComponent.Mode.SPIN:   return "↺ "
		IdleBehaviorComponent.Mode.PATROL: return "⇄ "
	return ""

func _get_component_names(id: int) -> Array[String]:
	var names : Array[String] = []
	for type: StringName in [&"Transform", &"Velocity", &"IdleBehavior", &"Relation",
			&"Animation", &"Audio", &"SceneNode", &"Health"]:
		if EntityManager.has_component(id, type):
			names.append(str(type))
	return names

func _select_entity(id: int) -> void:
	_selected_entity = id
	_selected_nodes.clear()
	_insp_mode = "entity"
	_sel_flash_t = 1.0   ## trigger outline pulse on entity marker if visible
	## Clear system-selection highlight — entity selection takes precedence.
	_system_highlight_ids.clear()
	_system_highlight_name = ""
	## Compute which systems are touching this entity.
	_entity_highlight_systems.clear()
	if is_instance_valid(SystemRegistry):
		for sys in SystemRegistry.all_systems():
			if not is_instance_valid(sys): continue
			if "_cache" in sys:
				var cache = sys.get("_cache")
				if cache is Array and (cache as Array).has(id):
					_entity_highlight_systems.append(str(sys.name))
	_refresh_entity_list()
	_refresh_systems_tab(_systems_list)   ## re-render with entity-driven highlights
	_push_insp_history()
	_refresh_inspector()

func _on_ecs_entity_created(_evt: Variant) -> void: _refresh_entity_list()
func _on_ecs_entity_destroyed(evt: Variant) -> void:
	if not evt is Dictionary: return
	var id : int = int((evt as Dictionary).get("entity", -1))
	## Remove marker if this entity had one
	if _entity_markers.has(id):
		var marker : Variant = _entity_markers[id]
		if (marker is Node) and is_instance_valid(marker as Node):
			(marker as Node).queue_free()
		_entity_markers.erase(id)
	if _selected_entity == id:
		_selected_entity = -1; _insp_mode = "node"; _refresh_inspector()
	_refresh_entity_list()
func _on_ecs_event(_evt: Variant) -> void: pass

## Called when a system row is clicked in the Systems tab.
## Highlights entities that the system is actively affecting.
func _on_system_selected(evt: Variant) -> void:
	if not evt is Dictionary: return
	var sys = (evt as Dictionary).get("system", null)
	var sys_name : String = str((evt as Dictionary).get("name", ""))

	## Toggle off if same system clicked again.
	if sys_name == _system_highlight_name and not _system_highlight_ids.is_empty():
		_system_highlight_ids.clear()
		_system_highlight_name = ""
		_refresh_entity_list()
		return

	_system_highlight_name = sys_name
	_system_highlight_ids.clear()

	## Ask the system for its current cache if it exposes one.
	## IdleBehaviorSystem and MovementSystem both expose _cache.
	if sys != null and "_cache" in sys:
		var cache = sys.get("_cache")
		if cache is Array:
			for id in cache:
				_system_highlight_ids.append(int(id))

	_refresh_entity_list()

	## Switch to Entities tab so the highlights are visible.
	## The left TabContainer is the first child of _mid_split.
	var left_tabs := _mid_split.get_child(0) if is_instance_valid(_mid_split) else null
	if left_tabs is TabContainer:
		(left_tabs as TabContainer).current_tab = 1  ## Entities tab

# ── Validate tab ──────────────────────────────────────────────────────────────

func _build_validate_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Validate"
	panel.add_theme_constant_override("separation", 2)
	var run_btn := _tool_btn("▶ Run Validation", C_OK, _run_validation)
	run_btn.flat = false
	panel.add_child(run_btn)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	_validation_list = VBoxContainer.new()
	_validation_list.add_theme_constant_override("separation", 2)
	_validation_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_validation_list)
	return panel

func _run_validation() -> void:
	if is_instance_valid(_validator):
		_validator.call("validate", _scene_root)

func _on_validation_done(data: Variant) -> void:
	if not is_instance_valid(_validation_list): return
	for c in _validation_list.get_children(): c.queue_free()
	if not data is Dictionary: return
	var issues : Array = (data as Dictionary).get("issues", [])
	if issues.is_empty():
		_validation_list.add_child(_lbl("  ✔ No issues found", 11, C_OK))
		return
	for issue: Object in issues:
		var sev  : int    = int(issue.get("severity"))
		var nname: String = str(issue.get("node_name"))
		var msg  : String = str(issue.get("message"))
		var col  : Color  = C_ERR if sev == 2 else (C_WARN if sev == 1 else C_DIM)
		var icon : String = "✖" if sev == 2 else ("⚠" if sev == 1 else "ℹ")
		var row := HBoxContainer.new()
		row.add_child(_lbl(icon, 12, col))
		var txt := _lbl(" [%s] %s" % [nname, msg], 10, col)
		txt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		txt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(txt)
		_validation_list.add_child(row)

# ── Inspector panel ───────────────────────────────────────────────────────────

func _build_inspector_panel() -> Control:
	var panel := _panel(C_BG1)
	panel.custom_minimum_size.x = 220
	var vbox := VBoxContainer.new()
	vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	vbox.add_theme_constant_override("separation", 0)
	panel.add_child(vbox)

	# Header with back/forward history + pin
	var hdr := HBoxContainer.new()
	hdr.add_theme_constant_override("separation", 2)
	_insp_back_btn = _tool_btn("←", C_DIM, _insp_go_back)
	_insp_back_btn.disabled = true
	_insp_fwd_btn  = _tool_btn("→", C_DIM, _insp_go_fwd)
	_insp_fwd_btn.disabled = true
	hdr.add_child(_insp_back_btn)
	hdr.add_child(_insp_fwd_btn)
	var hdr_lbl := _lbl("INSPECTOR", 10, C_ACCENT)
	hdr_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hdr.add_child(hdr_lbl)
	var pin_btn := Button.new()
	pin_btn.text = "📌"
	pin_btn.flat = true
	pin_btn.toggle_mode = true
	pin_btn.add_theme_font_size_override("font_size", 11)
	pin_btn.toggled.connect(func(on: bool) -> void:
		_insp_pinned = on
		pin_btn.add_theme_color_override("font_color", C_ACCENT if on else C_DIM))
	hdr.add_child(pin_btn)
	vbox.add_child(hdr)

	# Property search
	_insp_search = LineEdit.new()
	_insp_search.placeholder_text = "🔍 filter properties…"
	_insp_search.add_theme_font_size_override("font_size", 10)
	_insp_search.text_changed.connect(func(_t: String): _refresh_inspector())
	vbox.add_child(_insp_search)

	_insp_scroll = ScrollContainer.new()
	_insp_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_insp_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(_insp_scroll)
	_insp_list = VBoxContainer.new()
	_insp_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_insp_list.add_theme_constant_override("separation", 4)
	_insp_scroll.add_child(_insp_list)
	return panel

# ── Inspector history ─────────────────────────────────────────────────────────

func _push_insp_history() -> void:
	var entry := {
		"mode":   _insp_mode,
		"node":   _selected_node,
		"entity": _selected_entity
	}
	if _insp_hist_idx < _insp_history.size() - 1:
		_insp_history = _insp_history.slice(0, _insp_hist_idx + 1)
	_insp_history.append(entry)
	_insp_hist_idx = _insp_history.size() - 1
	_update_hist_btns()

func _insp_go_back() -> void:
	if _insp_hist_idx <= 0: return
	_insp_hist_idx -= 1
	_apply_insp_history()

func _insp_go_fwd() -> void:
	if _insp_hist_idx >= _insp_history.size() - 1: return
	_insp_hist_idx += 1
	_apply_insp_history()

func _apply_insp_history() -> void:
	if _insp_hist_idx < 0 or _insp_hist_idx >= _insp_history.size(): return
	var e : Dictionary = _insp_history[_insp_hist_idx]
	_insp_mode = str(e.get("mode", "node"))
	_selected_entity = int(e.get("entity", -1))
	var node : Variant = e.get("node")
	_selected_nodes.clear()
	if node is Node and is_instance_valid(node as Node):
		_selected_nodes.append(node as Node)
	_update_hist_btns()
	_refresh_scene_tree()
	_refresh_inspector()

func _update_hist_btns() -> void:
	if is_instance_valid(_insp_back_btn):
		_insp_back_btn.disabled = _insp_hist_idx <= 0
	if is_instance_valid(_insp_fwd_btn):
		_insp_fwd_btn.disabled = _insp_hist_idx >= _insp_history.size() - 1

func _refresh_inspector() -> void:
	if not is_instance_valid(_insp_list): return
	for c in _insp_list.get_children(): c.queue_free()
	var filter : String = _insp_search.text.to_lower() if is_instance_valid(_insp_search) else ""
	if _insp_mode == "entity":
		_build_entity_inspector(filter)
	else:
		_build_node_inspector(filter)

# ── Node inspector ────────────────────────────────────────────────────────────

func _build_node_inspector(filter: String = "") -> void:
	if _selected_nodes.size() > 1:
		_insp_list.add_child(_lbl("%d nodes selected" % _selected_nodes.size(), 12, C_MULTI))
		_insp_list.add_child(_hdiv())
		for n in _selected_nodes:
			if is_instance_valid(n):
				_insp_list.add_child(_lbl("  " + _node_icon(n) + " " + str(n.name), 10, C_TEXT))
		var del_all := _action_btn("Delete All Selected", C_ERR)
		del_all.pressed.connect(_delete_selected)
		_insp_list.add_child(del_all)
		return

	var node := _selected_node
	if not is_instance_valid(node):
		_insp_list.add_child(_lbl("Nothing selected", 10, C_DIM))
		return

	_insp_list.add_child(_lbl(_node_icon(node) + " " + str(node.name), 12, C_ACCENT))
	_insp_list.add_child(_lbl(node.get_class(), 10, C_DIM))
	## Show path relative to scene root, not the full internal UI path
	var display_path : String
	if is_instance_valid(_scene_root) and node.is_ancestor_of(_scene_root) == false and _scene_root.is_ancestor_of(node):
		display_path = str(_scene_root.get_path_to(node))
	elif node == _scene_root:
		display_path = "Scene"
	else:
		display_path = str(node.name)
	_insp_list.add_child(_lbl(display_path, 9, C_DIM))
	_insp_list.add_child(_hdiv())

	if node is Node3D:
		var n3 := node as Node3D
		var tf_content := VBoxContainer.new()
		tf_content.add_theme_constant_override("separation", 2)
		for pair: Array in [
				["Position",   "position"],
				["Rotation °", "rotation_degrees"],
				["Scale",      "scale"]]:
			if filter.is_empty() or (pair[0] as String).to_lower().contains(filter):
				tf_content.add_child(_lbl(pair[0] as String, 10, C_DIM))
				tf_content.add_child(_node3d_vec3_row(n3, pair[1] as String))
		if tf_content.get_child_count() > 0:
			_insp_list.add_child(_collapsible_header("Transform", C_OK, tf_content))
			_insp_list.add_child(tf_content)

	## Light controls — Omni, Directional, Spot all share Light3D base
	if node is Light3D:
		var light := node as Light3D
		var lt_content := VBoxContainer.new()
		lt_content.add_theme_constant_override("separation", 2)
		if filter.is_empty() or "energy".contains(filter) or "light".contains(filter):
			lt_content.add_child(_lbl("Energy", 10, C_DIM))
			var spin := _make_spinbox(light.light_energy, 0.0, 200.0, 0.1)
			spin.value_changed.connect(func(v: float): light.light_energy = v)
			lt_content.add_child(spin)
			lt_content.add_child(_lbl("Color", 10, C_DIM))
			var cpb := ColorPickerButton.new()
			cpb.color = light.light_color
			cpb.custom_minimum_size = Vector2(60, 24)
			cpb.color_changed.connect(func(c: Color): light.light_color = c)
			lt_content.add_child(cpb)
		if node is SpotLight3D and (filter.is_empty() or "spot".contains(filter) or "angle".contains(filter)):
			var spot := node as SpotLight3D
			lt_content.add_child(_lbl("Spot Angle", 10, C_DIM))
			var angle_spin := _make_spinbox(spot.spot_angle, 1.0, 90.0, 0.5)
			angle_spin.value_changed.connect(func(v: float): spot.spot_angle = v)
			lt_content.add_child(angle_spin)
			lt_content.add_child(_lbl("Spot Range", 10, C_DIM))
			var range_spin := _make_spinbox(spot.spot_range, 0.5, 200.0, 0.5)
			range_spin.value_changed.connect(func(v: float): spot.spot_range = v)
			lt_content.add_child(range_spin)
		if node is OmniLight3D and (filter.is_empty() or "range".contains(filter)):
			var omni := node as OmniLight3D
			lt_content.add_child(_lbl("Range", 10, C_DIM))
			var range_spin := _make_spinbox(omni.omni_range, 0.5, 200.0, 0.5)
			range_spin.value_changed.connect(func(v: float): omni.omni_range = v)
			lt_content.add_child(range_spin)
		if lt_content.get_child_count() > 0:
			_insp_list.add_child(_collapsible_header("Light", C_WARN, lt_content))
			_insp_list.add_child(lt_content)

	## MeshInstance3D — surface color picker for slot 0
	if node is MeshInstance3D and (filter.is_empty() or "color".contains(filter) or "material".contains(filter)):
		var mi := node as MeshInstance3D
		var mat := mi.get_surface_override_material(0) as StandardMaterial3D
		if mat:
			var mesh_content := VBoxContainer.new()
			mesh_content.add_theme_constant_override("separation", 2)
			mesh_content.add_child(_lbl("Surface Color", 10, C_DIM))
			var cpb := ColorPickerButton.new()
			cpb.color = mat.albedo_color
			cpb.custom_minimum_size = Vector2(60, 24)
			cpb.color_changed.connect(func(c: Color): mat.albedo_color = c)
			mesh_content.add_child(cpb)
			_insp_list.add_child(_collapsible_header("Mesh", C_DIM, mesh_content))
			_insp_list.add_child(mesh_content)

	## Script variables — editable by type
	var scr : Script = node.get_script() as Script
	if scr:
		var scr_content := VBoxContainer.new()
		scr_content.add_theme_constant_override("separation", 4)
		scr_content.add_child(_lbl(scr.resource_path.get_file(), 9, C_DIM))
		var props : Array = node.get_property_list()
		var shown : int = 0
		for p in props:
			if shown >= 24: break
			var usage : int = int(p.get("usage", 0))
			if not (usage & PROPERTY_USAGE_SCRIPT_VARIABLE): continue
			var pname : String = str(p.get("name", ""))
			if pname.begins_with("_"): continue
			if not filter.is_empty() and not pname.to_lower().contains(filter): continue
			var ptype : int    = int(p.get("type", TYPE_NIL))
			var phint : int    = int(p.get("hint", PROPERTY_HINT_NONE))
			var phint_str : String = str(p.get("hint_string", ""))
			var val   : Variant = node.get(pname)
			var editor := _build_prop_editor(node, pname, ptype, phint, phint_str, val)
			if editor != null:
				scr_content.add_child(editor)
				shown += 1
		if shown > 0:
			_insp_list.add_child(_collapsible_header("Script  (" + str(shown) + " vars)", C_ACCENT, scr_content))
			_insp_list.add_child(scr_content)

	## ECS components attached to this node
	var eid := _find_entity_for_node(node)
	if eid >= 0:
		_insp_list.add_child(_hdiv())
		_insp_list.add_child(_lbl("ECS Entity #%d" % eid, 10, C_ENTITY))
		for comp_type : StringName in [&"Transform", &"Velocity", &"Animation",
				&"Audio", &"SceneNode", &"Health", &"Camera", &"Input",
				&"Mesh", &"Light", &"Collider", &"RigidBody", &"Script", &"UI"]:
			if EntityManager.has_component(eid, comp_type):
				_insp_list.add_child(_lbl("  ● " + str(comp_type), 9, C_ENTITY))

	_insp_list.add_child(_hdiv())
	## Quick actions row
	var qa_row := HBoxContainer.new()
	qa_row.add_theme_constant_override("separation", 4)
	var dup_btn := _action_btn("⧉ Duplicate", C_DIM)
	dup_btn.pressed.connect(func():
		if is_instance_valid(node) and node is Node3D and is_instance_valid(_scene_root):
			var src := node as Node3D
			var copy := src.duplicate() as Node3D
			copy.position += Vector3(GRID_SNAP, 0, GRID_SNAP)
			_undo_redo.call("push", "Duplicate " + str(src.name),
				func(): _scene_root.add_child(copy); _spawned.append(copy); _select_node_single(copy); _refresh_scene_tree(); _focus_selected(); _toast("⧉  " + str(src.name) + " duplicated", C_DIM),
				func(): copy.queue_free(); _spawned.erase(copy)))
	qa_row.add_child(dup_btn)
	var foc_btn := _action_btn("⊙ Focus", C_DIM)
	foc_btn.pressed.connect(func(): _focus_selected())
	qa_row.add_child(foc_btn)
	_insp_list.add_child(qa_row)
	var del_btn := _action_btn("Delete Node", C_ERR)
	del_btn.pressed.connect(func() -> void:
		if is_instance_valid(node):
			_undo_redo.call("push", "Delete " + str(node.name),
				func(): node.queue_free(); _selected_nodes.clear(); _refresh_scene_tree(); _refresh_inspector(),
				func(): Log.warn("[Dashboard] Cannot undo node deletion")))
	_insp_list.add_child(del_btn)

## Returns an editable row Control for a single script property.
## Dispatches on GDScript TYPE_* constants for float, int, bool, Color,
## Vector2, Vector3, String, and enum (PROPERTY_HINT_ENUM).
## Falls back to a read-only label for unsupported types.
func _build_prop_editor(obj: Object, pname: String,
		ptype: int, phint: int, phint_str: String, val: Variant) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	var lbl := _lbl(pname, 9, C_DIM)
	lbl.custom_minimum_size.x = 76
	lbl.clip_text = true
	row.add_child(lbl)

	match ptype:
		TYPE_BOOL:
			var chk := CheckBox.new()
			chk.text = ""
			chk.button_pressed = bool(val)
			chk.add_theme_font_size_override("font_size", 10)
			chk.toggled.connect(func(on: bool) -> void:
				obj.set(pname, on))
			row.add_child(chk)

		TYPE_INT:
			if phint == PROPERTY_HINT_ENUM and not phint_str.is_empty():
				## Enum — OptionButton populated from hint_string "A,B,C"
				var opt := OptionButton.new()
				opt.add_theme_font_size_override("font_size", 9)
				opt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				var entries := phint_str.split(",")
				for i in entries.size():
					opt.add_item(entries[i].strip_edges(), i)
				opt.select(clampi(int(val), 0, entries.size()-1))
				opt.item_selected.connect(func(idx: int) -> void:
					obj.set(pname, idx))
				row.add_child(opt)
			else:
				## Plain integer spinbox
				var spin := _make_spinbox(float(int(val)), -99999.0, 99999.0, 1.0)
				spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				spin.value_changed.connect(func(v: float) -> void:
					obj.set(pname, int(v)))
				row.add_child(spin)

		TYPE_FLOAT:
			var spin := _make_spinbox(float(val), -99999.0, 99999.0, 0.01)
			spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			spin.value_changed.connect(func(v: float) -> void:
				obj.set(pname, v))
			row.add_child(spin)

		TYPE_STRING:
			var edit := LineEdit.new()
			edit.text = str(val)
			edit.add_theme_font_size_override("font_size", 10)
			edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			edit.text_submitted.connect(func(s: String) -> void:
				obj.set(pname, s))
			row.add_child(edit)

		TYPE_COLOR:
			var cpb := ColorPickerButton.new()
			cpb.color = val if val is Color else Color.WHITE
			cpb.custom_minimum_size = Vector2(48, 22)
			cpb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			cpb.color_changed.connect(func(c: Color) -> void:
				obj.set(pname, c))
			row.add_child(cpb)

		TYPE_VECTOR2:
			var v2 := val as Vector2 if val is Vector2 else Vector2.ZERO
			for i in 2:
				var ax_lbl := _lbl(["X","Y"][i], 9, [C_ERR, C_OK][i])
				ax_lbl.custom_minimum_size.x = 10
				row.add_child(ax_lbl)
				var spin := _make_spinbox(v2[i], -99999.0, 99999.0, 0.01)
				spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				var ax := i
				spin.value_changed.connect(func(v: float) -> void:
					var cur : Vector2 = obj.get(pname)
					cur[ax] = v; obj.set(pname, cur))
				row.add_child(spin)

		TYPE_VECTOR3:
			var v3 := val as Vector3 if val is Vector3 else Vector3.ZERO
			for i in 3:
				var ax_lbl := _lbl(["X","Y","Z"][i], 9, [C_ERR, C_OK, C_ACCENT][i])
				ax_lbl.custom_minimum_size.x = 10
				row.add_child(ax_lbl)
				var spin := _make_spinbox(v3[i], -99999.0, 99999.0, 0.01)
				spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				var ax := i
				spin.value_changed.connect(func(v: float) -> void:
					var cur : Vector3 = obj.get(pname)
					cur[ax] = v; obj.set(pname, cur))
				row.add_child(spin)

		_:
			## Unsupported type — show read-only formatted value
			var v_lbl := _lbl(_fmt_val(val), 9, C_DIM)
			v_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			v_lbl.clip_text = true
			row.add_child(v_lbl)

	return row

func _fmt_val(val: Variant) -> String:
	if val == null: return "null"
	if val is float:  return "%.3f" % val
	if val is Vector2: return "(%.1f, %.1f)" % [(val as Vector2).x, (val as Vector2).y]
	if val is Vector3: return "(%.1f, %.1f, %.1f)" % [(val as Vector3).x, (val as Vector3).y, (val as Vector3).z]
	if val is Color:   return "#" + (val as Color).to_html()
	if val is Array:   return "Array[%d]" % (val as Array).size()
	if val is Dictionary: return "Dict{%d}" % (val as Dictionary).size()
	return str(val).left(40)

func _find_entity_for_node(node: Node) -> int:
	for id : int in EntityManager.get_all_entities():
		var sn: Variant = EntityManager.get_component(id, &"SceneNode")
		if sn is SceneNodeComponent and is_instance_valid((sn as SceneNodeComponent).node):
			if (sn as SceneNodeComponent).node == node:
				return id
	return -1

func _delete_selected() -> void:
	for n in _selected_nodes.duplicate():
		if is_instance_valid(n):
			_spawned.erase(n)
			n.queue_free()
	_selected_nodes.clear()
	_refresh_scene_tree()
	_refresh_inspector()

func _node3d_vec3_row(node: Node3D, prop: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 2)
	var axes   := ["x","y","z"]
	var colors := [C_ERR, C_OK, C_ACCENT]
	for i in 3:
		var l := _lbl(axes[i].to_upper(), 9, colors[i])
		l.custom_minimum_size.x = 10
		row.add_child(l)
		var spin := _make_spinbox(float((node.get(prop) as Vector3)[i]), -9999.0, 9999.0, 0.1)
		spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var p := prop; var ax := i
		spin.value_changed.connect(func(v: float) -> void:
			if is_instance_valid(node):
				var old_val : Vector3 = node.get(p)
				var new_val : Vector3 = old_val
				new_val[ax] = v
				_undo_redo.call("push",
					"%s.%s[%d]" % [node.name, p, ax],
					func(): (node as Node3D).set(p, new_val),
					func(): (node as Node3D).set(p, old_val)))
		row.add_child(spin)
	# Reset to default button
	var default_val : Vector3
	match prop:
		"position":        default_val = Vector3.ZERO
		"rotation_degrees": default_val = Vector3.ZERO
		"scale":           default_val = Vector3.ONE
		_:                 default_val = Vector3.ZERO
	var rst := Button.new()
	rst.text = "↺"
	rst.flat = true
	rst.custom_minimum_size = Vector2(18, 22)
	rst.add_theme_font_size_override("font_size", 10)
	rst.add_theme_color_override("font_color", C_DIM)
	rst.tooltip_text = "Reset to default"
	var dv := default_val
	rst.pressed.connect(func():
		if is_instance_valid(node):
			var old_v : Vector3 = node.get(prop)
			_undo_redo.call("push", "Reset %s.%s" % [node.name, prop],
				func(): (node as Node3D).set(prop, dv),
				func(): (node as Node3D).set(prop, old_v)))
	row.add_child(rst)
	return row

# ── Entity inspector ──────────────────────────────────────────────────────────

func _build_entity_inspector(filter: String = "") -> void:
	var id := _selected_entity
	if not EntityManager.entity_exists(id):
		_insp_list.add_child(_lbl("Entity no longer exists", 10, C_DIM))
		return

	## ── Entity header ────────────────────────────────────────────────────────
	var hdr_row := HBoxContainer.new()
	var behavior_color := _entity_behavior_color(id)
	if behavior_color.a > 0.0:
		var stripe := ColorRect.new()
		stripe.color = behavior_color
		stripe.custom_minimum_size = Vector2(4, 0)
		stripe.size_flags_vertical = Control.SIZE_EXPAND_FILL
		hdr_row.add_child(stripe)
	var id_lbl := _lbl("  Entity %d" % id, 13, C_ENTITY)
	id_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hdr_row.add_child(id_lbl)
	_insp_list.add_child(hdr_row)

	## ── "Affected by" system list ─────────────────────────────────────────────
	## Walk registered systems; if they expose _cache and contain this entity,
	## show them as clickable chips so the user understands the cause chain.
	var affecting : Array[String] = []
	if is_instance_valid(SystemRegistry):
		for sys in SystemRegistry.all_systems():
			if not is_instance_valid(sys): continue
			if "_cache" in sys:
				var cache = sys.get("_cache")
				if cache is Array and (cache as Array).has(id):
					affecting.append(str(sys.name))
	if not affecting.is_empty():
		var aff_row := HBoxContainer.new()
		aff_row.add_theme_constant_override("separation", 3)
		aff_row.add_child(_lbl("  ⚡ ", 9, C_WARN))
		aff_row.add_child(_lbl("Affected by: " + ", ".join(affecting), 9, C_WARN))
		_insp_list.add_child(aff_row)

	_insp_list.add_child(_hdiv())

	## ── TransformComponent ───────────────────────────────────────────────────
	var tc := EntityManager.get_component(id, &"Transform") as TransformComponent
	if tc and (filter.is_empty() or "transform".contains(filter) or "position".contains(filter)):
		_insp_list.add_child(_comp_header_removable("Transform", C_OK, func():
			EntityManager.remove_component(id, &"Transform"); _refresh_inspector()))
		_insp_list.add_child(_vec3_editor("pos", tc, "position"))
		_insp_list.add_child(_vec3_editor("rot", tc, "rotation"))
		_insp_list.add_child(_vec3_editor("scl", tc, "scale"))

	## ── VelocityComponent — shows owner ──────────────────────────────────────
	var vel := EntityManager.get_component(id, &"Velocity") as VelocityComponent
	if vel and (filter.is_empty() or "velocity".contains(filter)):
		_insp_list.add_child(_comp_header_removable("Velocity", C_WARN, func():
			EntityManager.remove_component(id, &"Velocity"); _refresh_inspector()))
		_insp_list.add_child(_vec3_editor("lin", vel, "linear"))
		## Owner line — critical for diagnosing silent velocity conflicts.
		var owner_str : String = str(vel.owner) if vel.owner != &"" else "unclaimed"
		var owner_color : Color = C_DIM if vel.owner == &"" else C_ACCENT
		var ow_row := HBoxContainer.new()
		ow_row.add_child(_lbl("  owner:", 9, C_DIM))
		var ow_lbl := _lbl("  " + owner_str, 9, owner_color)
		ow_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		ow_row.add_child(ow_lbl)
		## Release button — hands control back if another system is stuck owning.
		if vel.owner != &"":
			var rel := _action_btn("release", C_DIM)
			rel.custom_minimum_size = Vector2(52, 18)
			rel.add_theme_font_size_override("font_size", 9)
			rel.pressed.connect(func(): vel.release_ownership(); _refresh_inspector())
			ow_row.add_child(rel)
		_insp_list.add_child(ow_row)

	## ── IdleBehaviorComponent — live controls ─────────────────────────────────
	var ib := EntityManager.get_component(id, &"IdleBehavior") as IdleBehaviorComponent
	if ib and (filter.is_empty() or "idle".contains(filter) or "behavior".contains(filter)):
		var mode_color := _entity_behavior_color(id)
		if mode_color.a < 0.1: mode_color = C_TEXT
		_insp_list.add_child(_comp_header_removable("IdleBehavior", mode_color, func():
			EntityManager.remove_component(id, &"IdleBehavior"); _refresh_inspector()))

		## Mode selector
		var mode_row := HBoxContainer.new()
		mode_row.add_child(_lbl("  mode:", 9, C_DIM))
		var mode_opt := OptionButton.new()
		mode_opt.add_theme_font_size_override("font_size", 9)
		mode_opt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		for m in IdleBehaviorComponent.Mode.values():
			mode_opt.add_item(IdleBehaviorComponent.Mode.keys()[m], m)
		mode_opt.select(int(ib.mode))
		mode_opt.item_selected.connect(func(idx: int) -> void:
			var from_mode := ib.mode
			ib.mode = idx as IdleBehaviorComponent.Mode
			## Apply smart defaults before refreshing — fills params from current
			## entity state and clamps ranges so nothing can be set to nonsense.
			if tc != null:
				ib.apply_smart_defaults(tc, from_mode)
			_refresh_inspector())
		mode_row.add_child(mode_opt)
		_insp_list.add_child(mode_row)

		## Mode-specific parameters
		match ib.mode:
			IdleBehaviorComponent.Mode.ORBIT:
				_insp_list.add_child(_float_editor("radius", ib, "orbit_radius", 0.1, 50.0))
				_insp_list.add_child(_float_editor("speed",  ib, "orbit_speed",  -10.0, 10.0))
				_insp_list.add_child(_vec3_editor("origin",  ib, "orbit_origin"))
			IdleBehaviorComponent.Mode.DRIFT:
				_insp_list.add_child(_float_editor("speed",    ib, "drift_speed",          0.0, 20.0))
				_insp_list.add_child(_float_editor("interval", ib, "drift_change_interval", 0.2, 10.0))
			IdleBehaviorComponent.Mode.BOB:
				_insp_list.add_child(_float_editor("amplitude", ib, "bob_amplitude", 0.0, 5.0))
				_insp_list.add_child(_float_editor("frequency", ib, "bob_frequency", 0.05, 5.0))
			IdleBehaviorComponent.Mode.SPIN:
				_insp_list.add_child(_float_editor("deg/sec", ib, "spin_speed", -720.0, 720.0))
			IdleBehaviorComponent.Mode.PATROL:
				_insp_list.add_child(_vec3_editor("point A",  ib, "patrol_a"))
				_insp_list.add_child(_vec3_editor("point B",  ib, "patrol_b"))
				_insp_list.add_child(_float_editor("speed",   ib, "patrol_speed", 0.1, 20.0))

	## ── RelationComponent — inter-entity forces ──────────────────────────────
	var rc := EntityManager.get_component(id, &"Relation") as RelationComponent
	if rc and (filter.is_empty() or "relation".contains(filter)):
		_insp_list.add_child(_comp_header_removable("Relation", Color(0.7, 0.5, 1.0), func():
			EntityManager.remove_component(id, &"Relation"); _refresh_inspector()))
		_insp_list.add_child(_float_editor("sep radius",   rc, "sep_radius",          0.0, 20.0))
		_insp_list.add_child(_float_editor("sep strength", rc, "sep_strength",        0.0, 20.0))
		_insp_list.add_child(_float_editor("align radius", rc, "align_radius",        0.0, 20.0))
		_insp_list.add_child(_float_editor("align str",    rc, "align_strength",      0.0,  1.0, 0.01))
		_insp_list.add_child(_float_editor("orb pull",     rc, "orbit_pull_strength", 0.0, 10.0))
		_insp_list.add_child(_float_editor("orb pull rad", rc, "orbit_pull_radius",   0.0, 30.0))

	## ── HealthComponent ───────────────────────────────────────────────────────
	var hc := EntityManager.get_component(id, &"Health") as HealthComponent
	if hc and (filter.is_empty() or "health".contains(filter)):
		_insp_list.add_child(_comp_header_removable("Health", C_ERR, func():
			EntityManager.remove_component(id, &"Health"); _refresh_inspector()))
		var hp_row := HBoxContainer.new()
		hp_row.add_child(_lbl("  hp:", 9, C_DIM))
		hp_row.add_child(_lbl("  %.0f / %.0f" % [hc.current, hc.maximum], 9, C_ERR))
		_insp_list.add_child(hp_row)

	_insp_list.add_child(_hdiv())
	_insp_list.add_child(_build_behavior_presets_row(id))
	_insp_list.add_child(_build_add_component_row(id))
	var del_btn := _action_btn("Destroy Entity", C_ERR)
	del_btn.pressed.connect(func(): EntityManager.destroy_entity(id))
	_insp_list.add_child(del_btn)

## Single-axis float editor with label — used for scalar component params.
func _float_editor(label: String, obj: Object, prop: String,
		min_v: float = -9999.0, max_v: float = 9999.0,
		step: float = 0.05) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 2)
	var l := _lbl("  " + label, 9, C_DIM)
	l.custom_minimum_size.x = 64
	row.add_child(l)
	var val := clampf(float(obj.get(prop)), min_v, max_v)
	var spin := _make_spinbox(val, min_v, max_v, step)
	spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spin.value_changed.connect(func(v: float) -> void:
		obj.set(prop, clampf(v, min_v, max_v)))
	row.add_child(spin)
	return row

func _comp_header(label: String, color: Color) -> Control:
	var row := ColorRect.new()
	row.color = C_BG2; row.custom_minimum_size.y = 20
	var l := _lbl("  " + label, 10, color)
	l.set_anchors_preset(Control.PRESET_FULL_RECT)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l); return row

## Like _comp_header but includes a ✕ remove button.
## on_remove is called when the button is pressed (caller handles EntityManager.remove_component).
func _comp_header_removable(label: String, color: Color, on_remove: Callable) -> Control:
	var row := ColorRect.new()
	row.color = C_BG2; row.custom_minimum_size.y = 20
	var hbox := HBoxContainer.new()
	hbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	hbox.add_theme_constant_override("separation", 0)
	var l := _lbl("  " + label, 10, color)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.vertical_alignment   = VERTICAL_ALIGNMENT_CENTER
	hbox.add_child(l)
	var rm := Button.new()
	rm.text = "✕"
	rm.flat = true
	rm.custom_minimum_size = Vector2(20, 20)
	rm.add_theme_font_size_override("font_size", 9)
	rm.add_theme_color_override("font_color", C_ERR)
	rm.tooltip_text = "Remove component"
	rm.pressed.connect(on_remove)
	hbox.add_child(rm)
	row.add_child(hbox)
	return row

## Returns a Button that acts as a collapsible section toggle.
## Pass the VBoxContainer that holds the section's content rows.
## The button shows ▾/▸ and hides/shows the content container on press.
func _collapsible_header(label: String, color: Color, content: VBoxContainer) -> Button:
	var btn := Button.new()
	btn.flat = true
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	btn.add_theme_font_size_override("font_size", 10)
	btn.add_theme_color_override("font_color", color)
	btn.custom_minimum_size.y = 20
	var style := StyleBoxFlat.new()
	style.bg_color = C_BG2; style.set_corner_radius_all(0)
	btn.add_theme_stylebox_override("normal", style)
	btn.add_theme_stylebox_override("hover",  style)
	var _sec_open := true
	btn.text = "  ▾ " + label
	btn.pressed.connect(func():
		_sec_open = not _sec_open
		content.visible = _sec_open
		btn.text = ("  ▾ " if _sec_open else "  ▸ ") + label)
	return btn

func _build_add_component_row(id: int) -> Control:
	var row := HBoxContainer.new()
	var opt := OptionButton.new()
	opt.add_item("+ Add Component", -1)
	const ALL_COMPS : Array[StringName] = [
		&"Transform", &"Velocity", &"Health", &"IdleBehavior", &"Relation",
		&"Animation", &"Audio", &"Camera", &"Input", &"Mesh",
		&"Light", &"Collider", &"RigidBody", &"Script", &"UI"
	]
	for i in ALL_COMPS.size():
		if not EntityManager.has_component(id, ALL_COMPS[i]):
			opt.add_item(str(ALL_COMPS[i]), i)
	opt.add_theme_font_size_override("font_size", 10)
	opt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	opt.item_selected.connect(func(idx: int) -> void:
		var comp_type := ALL_COMPS[opt.get_item_id(idx)]
		match comp_type:
			&"Transform":    EntityManager.add_component(id, &"Transform",    TransformComponent.new(Vector3.ZERO))
			&"Velocity":     EntityManager.add_component(id, &"Velocity",     VelocityComponent.new(Vector3.ZERO))
			&"Health":       EntityManager.add_component(id, &"Health",       HealthComponent.new())
			&"IdleBehavior": EntityManager.add_component(id, &"IdleBehavior", IdleBehaviorComponent.new())
			&"Relation":     EntityManager.add_component(id, &"Relation",     RelationComponent.new())
			_:
				## Generic: try to load from src/components/<type>Component.gd
				var path := "res://src/components/%sComponent.gd" % str(comp_type)
				if not FileAccess.file_exists(path):
					path = "res://src/ecs/%sComponent.gd" % str(comp_type)
				var scr := load(path) as Script
				if scr:
					var comp: Object = scr.new()
					EntityManager.add_component(id, comp_type, comp)
		_refresh_inspector())
	row.add_child(opt)
	return row

## ── Behavior Presets ─────────────────────────────────────────────────────────
## One-tap buttons that wire up standard component combinations.
## "Move"   → Transform + Velocity (random dir)
## "Orbit"  → Transform + Velocity + IdleBehavior(ORBIT)
## "Follow" → Transform + Velocity (placeholder owner "player")
## "Spin"   → Transform + IdleBehavior(SPIN)
func _build_behavior_presets_row(id: int) -> Control:
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 3)
	col.add_child(_lbl("  ⚡ Behavior Presets", 9, C_WARN))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)

	var presets : Array = [
		["Move",   func():
			if not EntityManager.has_component(id, &"Transform"):
				EntityManager.add_component(id, &"Transform", TransformComponent.new(Vector3.ZERO))
			if not EntityManager.has_component(id, &"Velocity"):
				EntityManager.add_component(id, &"Velocity",
					VelocityComponent.new(Vector3(randf_range(-2,2), 0, randf_range(-2,2))))
			_refresh_inspector()
			_toast("⚡ Move applied to e%d" % id, C_ENTITY)],
		["Orbit",  func():
			if not EntityManager.has_component(id, &"Transform"):
				EntityManager.add_component(id, &"Transform", TransformComponent.new(
					Vector3(randf_range(-4,4), 0, randf_range(-4,4))))
			if not EntityManager.has_component(id, &"Velocity"):
				EntityManager.add_component(id, &"Velocity", VelocityComponent.new(Vector3.ZERO))
			if not EntityManager.has_component(id, &"IdleBehavior"):
				var ib := IdleBehaviorComponent.new()
				ib.mode = IdleBehaviorComponent.Mode.ORBIT
				EntityManager.add_component(id, &"IdleBehavior", ib)
			_refresh_inspector()
			_toast("⟳ Orbit applied to e%d" % id, C_ENTITY)],
		["Spin",   func():
			if not EntityManager.has_component(id, &"Transform"):
				EntityManager.add_component(id, &"Transform", TransformComponent.new(Vector3.ZERO))
			if not EntityManager.has_component(id, &"IdleBehavior"):
				var ib := IdleBehaviorComponent.new()
				ib.mode = IdleBehaviorComponent.Mode.SPIN
				EntityManager.add_component(id, &"IdleBehavior", ib)
			_refresh_inspector()
			_toast("↺ Spin applied to e%d" % id, C_ENTITY)],
		["Follow", func():
			if not EntityManager.has_component(id, &"Transform"):
				EntityManager.add_component(id, &"Transform", TransformComponent.new(Vector3.ZERO))
			var vel := VelocityComponent.new(Vector3.ZERO)
			vel.claim_ownership(&"player")
			if not EntityManager.has_component(id, &"Velocity"):
				EntityManager.add_component(id, &"Velocity", vel)
			_refresh_inspector()
			_toast("→ Follow applied to e%d" % id, C_ENTITY)],
	]

	for pair in presets:
		var lbl_text : String = str(pair[0])
		var fn       : Callable = pair[1] as Callable
		var pb := Button.new()
		pb.text = lbl_text
		pb.flat = false
		pb.add_theme_font_size_override("font_size", 9)
		pb.add_theme_color_override("font_color", C_ENTITY)
		pb.pressed.connect(fn)
		row.add_child(pb)

	col.add_child(row)
	return col

func _vec3_editor(label: String, obj: Object, prop: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 2)
	row.add_child(_lbl("  " + label, 9, C_DIM))
	var axes   := ["x","y","z"]
	var colors := [C_ERR, C_OK, C_ACCENT]
	for i in 3:
		var l := _lbl(axes[i].to_upper(), 9, colors[i])
		l.custom_minimum_size.x = 10
		row.add_child(l)
		var spin := _make_spinbox(float((obj.get(prop) as Vector3)[i]), -9999.0, 9999.0, 0.1)
		spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var o := obj; var p := prop; var ax := i
		spin.value_changed.connect(func(v: float) -> void:
			var vec : Vector3 = o.get(p); vec[ax] = v; o.set(p, vec))
		row.add_child(spin)
	return row

# ── Undo changed ──────────────────────────────────────────────────────────────

func _on_undo_changed(data: Variant) -> void:
	if not is_instance_valid(_undo_lbl): return
	if not data is Dictionary: return
	var idx  : int = int((data as Dictionary).get("index", -1))
	var undo_size : int = int((data as Dictionary).get("size", 0))
	_undo_lbl.text = "↩ %d/%d" % [idx + 1, undo_size] if undo_size > 0 else ""

# ── Bottom panel ──────────────────────────────────────────────────────────────

func _build_bottom_panel() -> Control:
	var tabs := TabContainer.new()
	tabs.custom_minimum_size.y = 150
	tabs.add_theme_font_size_override("font_size", 10)
	tabs.add_child(_build_session_tab())
	tabs.add_child(_build_prefab_tab())
	tabs.add_child(_build_runtime_tab())
	tabs.add_child(_build_asset_tab())
	tabs.add_child(_build_event_tab())
	tabs.add_child(_build_history_tab())
	tabs.add_child(_build_systems_tab())
	tabs.add_child(_build_logs_tab())
	tabs.add_child(_build_graph_tab())
	return tabs

func _build_asset_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Assets"
	panel.add_theme_constant_override("separation", 2)

	# Header row: path + back + up
	var hdr := HBoxContainer.new()
	hdr.add_theme_constant_override("separation", 4)
	var back_btn := _tool_btn("←", C_DIM, Callable())
	back_btn.pressed.connect(func():
		if not _asset_history.is_empty():
			_asset_path = _asset_history.pop_back()
			_refresh_asset_tab())
	hdr.add_child(back_btn)
	var up_btn := _tool_btn("↑", C_DIM, Callable())
	up_btn.pressed.connect(func():
		var parent := _asset_path.get_base_dir()
		if not parent.ends_with("/"): parent += "/"
		if parent != _asset_path:
			_asset_history.append(_asset_path)
			_asset_path = parent
			_refresh_asset_tab())
	hdr.add_child(up_btn)
	_asset_path_lbl = _lbl("res://", 9, C_DIM)
	_asset_path_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_asset_path_lbl.clip_text = true
	hdr.add_child(_asset_path_lbl)
	panel.add_child(hdr)

	# Search bar
	_asset_search_edit = LineEdit.new()
	_asset_search_edit.placeholder_text = "🔍 filter assets…"
	_asset_search_edit.add_theme_font_size_override("font_size", 10)
	_asset_search_edit.text_changed.connect(func(_t: String): _refresh_asset_tab())
	panel.add_child(_asset_search_edit)

	# Vertical scrollable list
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	_asset_list = HBoxContainer.new()  # kept for compat but unused in new layout
	var asset_vbox := VBoxContainer.new()
	asset_vbox.name = "AssetVBox"
	asset_vbox.add_theme_constant_override("separation", 1)
	asset_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(asset_vbox)

	_refresh_asset_tab()
	return panel

func _refresh_asset_tab() -> void:
	# Find the vbox — it may be nested in the scroll
	var vbox := find_child("AssetVBox", true, false) as VBoxContainer
	if not is_instance_valid(vbox): return
	for c in vbox.get_children(): c.queue_free()
	if is_instance_valid(_asset_path_lbl):
		_asset_path_lbl.text = _asset_path

	var query : String = ""
	if is_instance_valid(_asset_search_edit):
		query = _asset_search_edit.text.to_lower()

	var dir := DirAccess.open(_asset_path)
	if not dir:
		vbox.add_child(_lbl("(cannot open)", 10, C_DIM))
		return
	dir.list_dir_begin()
	var entries : Array[String] = []
	var entry := dir.get_next()
	while entry != "":
		if not entry.begins_with("."):
			entries.append(entry)
		entry = dir.get_next()
	dir.list_dir_end()
	entries.sort()

	for e in entries:
		if not query.is_empty() and not e.to_lower().contains(query): continue
		var full := _asset_path.path_join(e)
		var is_dir := DirAccess.dir_exists_absolute(full)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 4)
		var icon_lbl := _lbl("📁" if is_dir else _file_icon(e), 11,
			C_ACCENT if is_dir else C_DIM)
		row.add_child(icon_lbl)
		var nm := _lbl(e, 10, C_ACCENT if is_dir else C_TEXT)
		nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nm.clip_text = true
		row.add_child(nm)
		var btn := Button.new()
		btn.flat = true; btn.text = ""
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var captured_full := full; var captured_is_dir := is_dir
		btn.pressed.connect(func():
			if captured_is_dir:
				_asset_history.append(_asset_path)
				_asset_path = captured_full + "/"
				_refresh_asset_tab()
			else:
				_on_asset_clicked(captured_full))
		row.add_child(btn)
		vbox.add_child(row)

func _build_event_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Events"
	panel.add_theme_constant_override("separation", 0)
	var hdr := HBoxContainer.new()
	hdr.add_child(_lbl("  BUS MONITOR", 9, C_ENTITY))
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hdr.add_child(spacer)
	hdr.add_child(_tool_btn("Clear", C_DIM, func():
		if is_instance_valid(_event_list):
			for c in _event_list.get_children(): c.queue_free()))
	panel.add_child(hdr)
	_event_scroll = ScrollContainer.new()
	_event_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_event_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(_event_scroll)
	_event_list = VBoxContainer.new()
	_event_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_event_list.add_theme_constant_override("separation", 0)
	_event_scroll.add_child(_event_list)
	return panel

func _build_history_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "History"
	panel.add_theme_constant_override("separation", 2)
	var hdr := HBoxContainer.new()
	hdr.add_child(_lbl("  UNDO HISTORY", 9, C_ACCENT))
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hdr.add_child(spacer)
	hdr.add_child(_tool_btn("Clear", C_DIM, func(): _undo_redo.call("clear")))
	panel.add_child(hdr)
	# History list updated via Bus event
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	var hist_list := VBoxContainer.new()
	hist_list.name = "HistoryList"
	hist_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(hist_list)
	Bus.on(&"undo_history_changed", func(data: Variant) -> void:
		if not is_instance_valid(hist_list): return
		for c in hist_list.get_children(): c.queue_free()
		if not data is Dictionary: return
		var labels : Array = _undo_redo.call("history_labels")
		var cur_idx : int  = int(_undo_redo.call("current_index"))
		for i in labels.size():
			var lbl_text : String = str(labels[i])
			var row_lbl := _lbl(("▶ " if i == cur_idx else "  ") + lbl_text, 10,
				C_ACCENT if i == cur_idx else C_DIM)
			hist_list.add_child(row_lbl))
	return panel

# ── Viewport ──────────────────────────────────────────────────────────────────

func _build_viewport_panel() -> Control:
	var panel := _panel(Color(0.03, 0.03, 0.04))
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	# Camera speed slider overlay
	var overlay := VBoxContainer.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	panel.add_child(overlay)

	_viewport_container = SubViewportContainer.new()
	_viewport_container.stretch = true
	_viewport_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_viewport_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	overlay.add_child(_viewport_container)
	_viewport = SubViewport.new()
	_viewport.transparent_bg = false
	_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_viewport_container.add_child(_viewport)
	_viewport_container.gui_input.connect(_on_viewport_input)

	# Bottom cam speed bar
	var cam_bar := HBoxContainer.new()
	cam_bar.add_theme_constant_override("separation", 6)
	cam_bar.add_child(_lbl("Cam Speed", 9, C_DIM))
	var spd_slider := HSlider.new()
	spd_slider.min_value = 0.1
	spd_slider.max_value = 5.0
	spd_slider.value     = 1.0
	spd_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spd_slider.value_changed.connect(func(v: float): _cam_speed_scale = v)
	cam_bar.add_child(spd_slider)
	var spd_lbl := _lbl("1.0×", 9, C_DIM)
	spd_slider.value_changed.connect(func(v: float):
		spd_lbl.text = "%.1f×" % v)
	cam_bar.add_child(spd_lbl)
	overlay.add_child(cam_bar)

	_sel_overlay = Control.new()
	_sel_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_sel_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_sel_overlay.draw.connect(_draw_selection_overlay)
	panel.add_child(_sel_overlay)

	## Toast label — sits bottom-center, invisible until _toast() is called.
	_toast_label = Label.new()
	_toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_label.add_theme_font_size_override("font_size", 12)
	_toast_label.add_theme_color_override("font_color", Color(1, 1, 1, 0.0))
	_toast_label.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	_toast_label.offset_bottom = -16
	_toast_label.offset_top    = -40
	var toast_bg := StyleBoxFlat.new()
	toast_bg.bg_color = Color(0.06, 0.06, 0.08, 0.82)
	toast_bg.set_corner_radius_all(4)
	toast_bg.content_margin_left  = 12; toast_bg.content_margin_right  = 12
	toast_bg.content_margin_top   = 4;  toast_bg.content_margin_bottom = 4
	_toast_label.add_theme_stylebox_override("normal", toast_bg)
	panel.add_child(_toast_label)

	return panel

func _spawn_editor_world() -> void:
	if not is_instance_valid(_viewport): return
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.08, 0.08, 0.10)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color  = Color(0.3, 0.3, 0.4)
	env.ambient_light_energy = 0.4
	env_node.environment = env
	_viewport.add_child(env_node)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, 30, 0)
	sun.light_energy = 1.2
	_viewport.add_child(sun)
	var grid_plane := MeshInstance3D.new()
	var plane := PlaneMesh.new(); plane.size = Vector2(40, 40)
	grid_plane.mesh = plane
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.10, 0.10, 0.14)
	mat.roughness = 1.0
	grid_plane.set_surface_override_material(0, mat)
	_viewport.add_child(grid_plane)
	_cam_pivot = Node3D.new(); _viewport.add_child(_cam_pivot)
	_cam = Camera3D.new(); _cam.position = Vector3(0, 0, _cam_dist)
	_cam_pivot.add_child(_cam)
	_cam_pivot.rotation_degrees = Vector3(_cam_pitch, _cam_yaw, 0)
	var imm := ImmediateMesh.new()
	_grid_lines = MeshInstance3D.new(); _grid_lines.mesh = imm
	var gmat := StandardMaterial3D.new()
	gmat.albedo_color = Color(0.28, 0.28, 0.36, 0.6)
	gmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	gmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_grid_lines.position.y = 0.002
	_build_grid_mesh(imm, 20, 1.0)
	_grid_lines.set_surface_override_material(0, gmat)
	_viewport.add_child(_grid_lines)
	_scene_root = Node3D.new(); _scene_root.name = "Scene"
	_viewport.add_child(_scene_root)
	Bus.emit(&"camera_changed", {"camera": _cam})

	_gizmo_imm       = ImmediateMesh.new()
	_gizmo_mesh_inst = MeshInstance3D.new()
	_gizmo_mesh_inst.mesh = _gizmo_imm
	_gizmo_mesh_inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_gizmo_mesh_inst.visible = false
	var gizmo_mat := StandardMaterial3D.new()
	gizmo_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	gizmo_mat.vertex_color_use_as_albedo = true
	gizmo_mat.flags_no_depth_test = true
	## ImmediateMesh has no surfaces yet — assign via material_override instead
	_gizmo_mesh_inst.material_override = gizmo_mat
	_viewport.add_child(_gizmo_mesh_inst)

func _on_viewport_input(event: InputEvent) -> void:
	## F key → focus selected node
	if event is InputEventKey:
		var ek := event as InputEventKey
		if ek.pressed and ek.keycode == KEY_F:
			_focus_selected()
			return
		if ek.pressed and ek.keycode == KEY_DELETE:
			_delete_selected()
			_toast("🗑  Deleted", C_ERR)
			return
		if ek.pressed and ek.keycode == KEY_D and ek.ctrl_pressed:
			## Ctrl+D duplicate selected
			if not _selected_nodes.is_empty() and is_instance_valid(_selected_node) \
					and _selected_node is Node3D and is_instance_valid(_scene_root):
				var src := _selected_node as Node3D
				var copy := src.duplicate() as Node3D
				copy.position += Vector3(GRID_SNAP, 0, GRID_SNAP)
				_undo_redo.call("push", "Duplicate " + str(src.name),
					func(): _scene_root.add_child(copy); _spawned.append(copy); _select_node_single(copy); _refresh_scene_tree(); _focus_selected(); _toast("⧉  " + str(src.name) + " duplicated", C_DIM),
					func(): copy.queue_free(); _spawned.erase(copy))
			return
	if event is InputEventScreenDrag:
		var e := event as InputEventScreenDrag
		if _gizmo_mode == 0 or _selected_nodes.is_empty():
			_cam_yaw  -= e.relative.x * 0.35 * _cam_speed_scale
			_cam_pitch = clampf(_cam_pitch - e.relative.y * 0.35 * _cam_speed_scale, -89.0, -5.0)
			if is_instance_valid(_cam_pivot):
				_cam_pivot.rotation_degrees = Vector3(_cam_pitch, _cam_yaw, 0)
			_hover_axis = -1
		elif _gizmo_mode == 1 and is_instance_valid(_cam):
			## Hover: if not yet locked, update hover highlight from finger position.
			if not _drag_active:
				var new_hover := _pick_gizmo_axis(e.position)
				if new_hover != _hover_axis:
					_hover_axis = new_hover
					if is_instance_valid(_sel_overlay): _sel_overlay.queue_redraw()
			_world_drag_translate(e.position)
		elif _gizmo_mode == 2:
			var spd := 0.5
			for n in _selected_nodes:
				if not (n is Node3D): continue
				var n3d := n as Node3D
				match _drag_axis:
					0:  n3d.rotation_degrees.x -= e.relative.y * spd
					1:  n3d.rotation_degrees.y -= e.relative.x * spd
					2:  n3d.rotation_degrees.z -= e.relative.x * spd
					_:
						n3d.rotation_degrees.y -= e.relative.x * spd
						n3d.rotation_degrees.x -= e.relative.y * spd
		elif _gizmo_mode == 3:
			var factor := 1.0 + e.relative.x * 0.01
			for n in _selected_nodes:
				if not (n is Node3D): continue
				var n3d := n as Node3D
				match _drag_axis:
					0:  n3d.scale.x = maxf(n3d.scale.x * factor, 0.001)
					1:  n3d.scale.y = maxf(n3d.scale.y * factor, 0.001)
					2:  n3d.scale.z = maxf(n3d.scale.z * factor, 0.001)
					_:  n3d.scale   = n3d.scale.max(Vector3(0.001,0.001,0.001)) * factor
	elif event is InputEventMagnifyGesture:
		_cam_dist = clampf(_cam_dist / (event as InputEventMagnifyGesture).factor, 1.5, 60.0)
		if is_instance_valid(_cam): _cam.position.z = _cam_dist
	elif event is InputEventScreenTouch:
		var e := event as InputEventScreenTouch
		if e.pressed:
			_long_pressing = true; _long_press_t = 0.0; _long_press_pos = e.position
			if _gizmo_mode == 0:
				_try_pick(e.position)
			elif not _selected_nodes.is_empty() and is_instance_valid(_selected_node) \
					and _selected_node is Node3D:
				_drag_axis = _pick_gizmo_axis(e.position)
				_begin_world_drag(e.position)
		else:
			_long_pressing = false
			_drag_axis = -1
			_drag_active = false
			_drag_node_origins.clear()

func _process(delta: float) -> void:
	if _long_pressing:
		_long_press_t += delta
		if _long_press_t >= LONG_PRESS_SEC:
			_long_pressing = false
			if not _selected_nodes.is_empty(): _show_context_menu(_long_press_pos)
	_runtime_tick += delta
	if _runtime_tick >= 1.0:
		_runtime_tick = 0.0
		_refresh_runtime_panel()
		_refresh_session_panel()

	## Decay selection flash — triggers a redraw each frame while active
	if _sel_flash_t > 0.0:
		_sel_flash_t = maxf(_sel_flash_t - delta * 2.5, 0.0)
		if is_instance_valid(_sel_overlay): _sel_overlay.queue_redraw()

	## Sync entity marker positions.
	## TC is always the source of truth — marker tracks it in both editor and play mode.
	for eid: int in _entity_markers.keys():
		var marker : Variant = _entity_markers.get(eid)
		## Guard: check the Variant itself before any cast — freed nodes return invalid
		if not (marker is Node) or not is_instance_valid(marker as Node):
			_entity_markers.erase(eid)
			continue
		var tc := EntityManager.get_component(eid, &"Transform") as TransformComponent
		if tc != null:
			(marker as MeshInstance3D).position = tc.position

	## Live inspector: sync Transform spinboxes with actual node position each frame.
	## Only when not dragging (dragging writes TO the node, not the reverse).
	if _insp_mode == "node" and is_instance_valid(_selected_node) and _selected_node is Node3D:
		var n3 := _selected_node as Node3D
		## Sync ECS Transform component so systems see the editor position.
		var eid := _find_entity_for_node(n3)
		if eid >= 0:
			var tc := EntityManager.get_component(eid, &"Transform") as TransformComponent
			if tc != null:
				tc.position = n3.global_position
				tc.rotation = n3.rotation_degrees
				tc.scale = n3.scale

	if not _selected_nodes.is_empty():
		if is_instance_valid(_sel_overlay): _sel_overlay.queue_redraw()
		if is_instance_valid(_gizmo_mesh_inst) and is_instance_valid(_selected_node) \
				and _selected_node is Node3D:
			_gizmo_mesh_inst.global_position = (_selected_node as Node3D).global_position
	else:
		if is_instance_valid(_gizmo_mesh_inst): _gizmo_mesh_inst.visible = false
		if is_instance_valid(_sel_overlay):     _sel_overlay.queue_redraw()


# ── P0.1  Selection outline ───────────────────────────────────────────────────
func _draw_selection_overlay() -> void:
	if not is_instance_valid(_sel_overlay): return
	if not is_instance_valid(_cam) or not is_instance_valid(_viewport_container): return
	if _selected_nodes.is_empty(): return
	var vp_rect := _viewport_container.get_global_rect()
	for node in _selected_nodes:
		if not (node is Node3D) or not is_instance_valid(node): continue
		var n3 := node as Node3D
		var aabb := _get_node_aabb(n3)
		if aabb.size == Vector3.ZERO:
			aabb = AABB(n3.global_position - Vector3(0.5, 0.5, 0.5), Vector3.ONE)
		var lp := aabb.position; var ls := aabb.size
		var corners : Array[Vector3] = [
			lp, lp + Vector3(ls.x,0,0), lp + Vector3(0,ls.y,0), lp + Vector3(0,0,ls.z),
			lp + Vector3(ls.x,ls.y,0), lp + Vector3(ls.x,0,ls.z),
			lp + Vector3(0,ls.y,ls.z), lp + ls,
		]
		var pts2d : Array[Vector2] = []
		var any_front := false
		for c in corners:
			pts2d.append(_cam.unproject_position(c) - vp_rect.position)
			if not _cam.is_position_behind(c): any_front = true
		if not any_front: continue
		var min_x := pts2d[0].x; var max_x := pts2d[0].x
		var min_y := pts2d[0].y; var max_y := pts2d[0].y
		for p in pts2d:
			if p.x < min_x: min_x = p.x
			if p.x > max_x: max_x = p.x
			if p.y < min_y: min_y = p.y
			if p.y > max_y: max_y = p.y
		var pad := 3.0
		var r := Rect2(min_x - pad, min_y - pad, max_x - min_x + pad*2.0, max_y - min_y + pad*2.0)
		r = r.intersection(Rect2(Vector2.ZERO, _sel_overlay.size))
		if r.size.x <= 0.0 or r.size.y <= 0.0: continue
		var col : Color = C_ACCENT if node == _selected_node else C_MULTI
		## Flash: thicker outline + stronger fill during the first 0.4s after selection
		var flash := _sel_flash_t if node == _selected_node else 0.0
		var fill_alpha := 0.18 + flash * 0.22
		var line_w     := 2.0  + flash * 2.5
		_sel_overlay.draw_rect(r, Color(col.r, col.g, col.b, fill_alpha))
		_sel_overlay.draw_rect(r, col, false, line_w)
		var tick := 8.0
		var corners2d : Array[Vector2] = [r.position, Vector2(r.end.x,r.position.y), r.end, Vector2(r.position.x,r.end.y)]
		var tx : Array[float] = [tick,-tick,-tick,tick]
		var ty : Array[float] = [tick,tick,-tick,-tick]
		for i in 4:
			var c2 := corners2d[i]
			_sel_overlay.draw_line(c2, c2+Vector2(tx[i],0.0), col, 3.0)
			_sel_overlay.draw_line(c2, c2+Vector2(0.0,ty[i]), col, 3.0)
		var font := ThemeDB.fallback_font
		if font:
			_sel_overlay.draw_string(font, Vector2(r.position.x+2.0, r.position.y-4.0),
				str(node.name), HORIZONTAL_ALIGNMENT_LEFT, -1, 9, col)
	if _gizmo_mode != 0 and not _selected_nodes.is_empty() and not _axis_tips2d.is_empty():
		var axis_cols_2d : Array[Color] = [Color(0.93,0.25,0.25),Color(0.25,0.85,0.25),Color(0.25,0.45,0.93)]
		for i in mini(_axis_tips2d.size(), 3):
			var tip2d : Vector2 = _axis_tips2d[i]
			if tip2d.x < -9000: continue
			var is_active := (_drag_axis == i)
			var is_hover  := (not is_active and _hover_axis == i)
			## Active = full colour + label. Hover = 70% alpha + slightly larger.
			## Neither = dim 35%.
			var ring_alpha : float = 1.0 if is_active else (0.70 if is_hover else 0.35)
			var ring_col   := Color(axis_cols_2d[i].r, axis_cols_2d[i].g, axis_cols_2d[i].b, ring_alpha)
			var ring_r     := 10.0 if is_active else (9.0 if is_hover else 7.0)
			_sel_overlay.draw_circle(tip2d, ring_r, ring_col)
			_sel_overlay.draw_circle(tip2d, ring_r-3.0, Color(0.05,0.05,0.05,0.7))
			if is_active or is_hover:
				var lbl_font := ThemeDB.fallback_font
				if lbl_font:
					var letters := ["X","Y","Z"]
					var lbl_col := Color.WHITE if is_active else Color(1,1,1,0.65)
					_sel_overlay.draw_string(lbl_font, tip2d-Vector2(4,-4),
						letters[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 9, lbl_col)

func _collect_mesh_instances(node: Node) -> Array[MeshInstance3D]:
	var out : Array[MeshInstance3D] = []
	if node is MeshInstance3D: out.append(node as MeshInstance3D)
	for c in node.get_children(): out.append_array(_collect_mesh_instances(c))
	return out

func _get_node_aabb(node: Node3D) -> AABB:
	var meshes := _collect_mesh_instances(node)
	if meshes.is_empty(): return AABB(node.global_position, Vector3.ZERO)
	var result := AABB(); var started := false
	for mi in meshes:
		var la : AABB = mi.get_aabb(); var xf : Transform3D = mi.global_transform
		var lp := la.position; var ls := la.size
		var wc : Array[Vector3] = [
			xf*lp, xf*(lp+Vector3(ls.x,0,0)), xf*(lp+Vector3(0,ls.y,0)), xf*(lp+Vector3(0,0,ls.z)),
			xf*(lp+Vector3(ls.x,ls.y,0)), xf*(lp+Vector3(ls.x,0,ls.z)),
			xf*(lp+Vector3(0,ls.y,ls.z)), xf*(lp+ls),
		]
		var wmin := wc[0]; var wmax := wc[0]
		for v in wc: wmin = wmin.min(v); wmax = wmax.max(v)
		var mesh_aabb := AABB(wmin, wmax-wmin)
		if not started: result = mesh_aabb; started = true
		else: result = result.merge(mesh_aabb)
	return result

# ── P0.2  Gizmo mesh ──────────────────────────────────────────────────────────
func _rebuild_gizmo_mesh() -> void:
	if not is_instance_valid(_gizmo_imm) or not is_instance_valid(_gizmo_mesh_inst): return
	_gizmo_imm.clear_surfaces()
	if _gizmo_mode == 0 or _selected_nodes.is_empty():
		_gizmo_mesh_inst.visible = false; return
	var node := _selected_node
	if not (node is Node3D) or not is_instance_valid(node):
		_gizmo_mesh_inst.visible = false; return
	var n3 := node as Node3D
	_gizmo_mesh_inst.global_position = n3.global_position
	_gizmo_mesh_inst.visible = true
	var cam_dist := _cam.global_position.distance_to(n3.global_position) if is_instance_valid(_cam) else 10.0
	_gizmo_mesh_inst.scale = Vector3.ONE * maxf(cam_dist * 0.12, 0.3)
	var axis_dirs : Array[Vector3] = [Vector3.RIGHT, Vector3.UP, Vector3.BACK]
	var axis_cols : Array[Color]   = [Color(0.93,0.25,0.25),Color(0.25,0.85,0.25),Color(0.25,0.45,0.93)]
	_gizmo_imm.surface_begin(Mesh.PRIMITIVE_LINES)
	match _gizmo_mode:
		1:
			for i in 3:
				var col := axis_cols[i]; var tip := axis_dirs[i] * GIZMO_LEN
				_gizmo_imm.surface_set_color(col); _gizmo_imm.surface_add_vertex(Vector3.ZERO)
				_gizmo_imm.surface_set_color(col); _gizmo_imm.surface_add_vertex(tip)
				var perp := axis_dirs[(i+1)%3]; var head := GIZMO_LEN*0.18
				for side in [-1.0,1.0]:
					_gizmo_imm.surface_set_color(col); _gizmo_imm.surface_add_vertex(tip)
					_gizmo_imm.surface_set_color(col)
					_gizmo_imm.surface_add_vertex(tip - axis_dirs[i]*head + perp*head*side)
		2:
			const SEGS := 24
			for i in 3:
				var col := axis_cols[i]
				var a1 := axis_dirs[(i+1)%3]; var a2 := axis_dirs[(i+2)%3]
				for s in SEGS:
					var ang0 := TAU*float(s)/float(SEGS); var ang1 := TAU*float(s+1)/float(SEGS)
					var p0 := (a1*cos(ang0)+a2*sin(ang0))*GIZMO_LEN
					var p1 := (a1*cos(ang1)+a2*sin(ang1))*GIZMO_LEN
					_gizmo_imm.surface_set_color(col); _gizmo_imm.surface_add_vertex(p0)
					_gizmo_imm.surface_set_color(col); _gizmo_imm.surface_add_vertex(p1)
		3:
			for i in 3:
				var col := axis_cols[i]; var tip := axis_dirs[i]*GIZMO_LEN
				_gizmo_imm.surface_set_color(col); _gizmo_imm.surface_add_vertex(Vector3.ZERO)
				_gizmo_imm.surface_set_color(col); _gizmo_imm.surface_add_vertex(tip)
				var b := GIZMO_LEN*0.10
				var perp1 := axis_dirs[(i+1)%3]; var perp2 := axis_dirs[(i+2)%3]
				for s1 in [-b,b]:
					for s2 in [-b,b]:
						_gizmo_imm.surface_set_color(col)
						_gizmo_imm.surface_add_vertex(tip+perp1*s1+perp2*b)
						_gizmo_imm.surface_set_color(col)
						_gizmo_imm.surface_add_vertex(tip+perp1*s1+perp2*(-b))
						_gizmo_imm.surface_set_color(col)
						_gizmo_imm.surface_add_vertex(tip+perp1*b+perp2*s2)
						_gizmo_imm.surface_set_color(col)
						_gizmo_imm.surface_add_vertex(tip+perp1*(-b)+perp2*s2)
	_gizmo_imm.surface_end()

# ── World-drag ─────────────────────────────────────────────────────────────────
func _begin_world_drag(screen_pos: Vector2) -> void:
	if not is_instance_valid(_cam): return
	## Capture each node's start position.
	_drag_node_origins.clear()
	for n in _selected_nodes:
		if n is Node3D: _drag_node_origins.append((n as Node3D).global_position)
		else:           _drag_node_origins.append(Vector3.ZERO)

	## Use group centroid as plane origin so multi-select drags evenly.
	var origin := Vector3.ZERO
	var node_count := 0
	for n in _selected_nodes:
		if n is Node3D:
			origin += (n as Node3D).global_position
			node_count += 1
	if node_count > 0: origin /= float(node_count)

	## Stable plane normal: project cam→origin direction off the axis.
	## cam_dir - axis*(cam_dir·axis) gives the component of cam_dir perpendicular
	## to the axis — always faces the camera, no cross-product degeneracy.
	var cam_dir : Vector3 = (_cam.global_position - origin).normalized()
	var plane_normal : Vector3
	if _drag_axis >= 0:
		var axis_dirs : Array[Vector3] = [Vector3.RIGHT, Vector3.UP, Vector3.BACK]
		var axis : Vector3 = axis_dirs[_drag_axis]
		var perp : Vector3 = cam_dir - axis * cam_dir.dot(axis)
		## Fallback: if camera is exactly along the axis, use cam forward
		plane_normal = perp.normalized() if perp.length_squared() > 0.001 else -_cam.global_transform.basis.z.normalized()
	else:
		plane_normal = cam_dir
	_drag_plane = Plane(plane_normal, origin)

	var from := _cam.project_ray_origin(screen_pos)
	var dir  := _cam.project_ray_normal(screen_pos)
	var hit  : Variant = _drag_plane.intersects_ray(from, dir)
	_last_drag_hit  = hit if hit is Vector3 else origin
	_drag_start_hit = _last_drag_hit
	_drag_active    = true

func _world_drag_translate(screen_pos: Vector2) -> void:
	if not _drag_active or not is_instance_valid(_cam): return
	var from := _cam.project_ray_origin(screen_pos)
	var dir  := _cam.project_ray_normal(screen_pos)
	var hit  : Variant = _drag_plane.intersects_ray(from, dir)
	## Cache last good hit — use it when ray misses (near-parallel approach).
	## Prevents the "sticky frame" stutter on mobile.
	if hit is Vector3:
		_last_drag_hit = hit as Vector3
	else:
		hit = _last_drag_hit
	var raw_delta : Vector3 = (_last_drag_hit) - _drag_start_hit
	var axis_dirs : Array[Vector3] = [Vector3.RIGHT, Vector3.UP, Vector3.BACK]
	var movement  : Vector3 = axis_dirs[_drag_axis] * raw_delta.dot(axis_dirs[_drag_axis]) \
		if _drag_axis >= 0 else raw_delta
	## Apply snap after projection — snap acts on the final world displacement.
	if _snap_enabled:
		movement = _snap(movement)
	for i in _selected_nodes.size():
		var n := _selected_nodes[i]
		if not (n is Node3D): continue
		var orig : Vector3 = _drag_node_origins[i] if i < _drag_node_origins.size() else Vector3.ZERO
		(n as Node3D).global_position = orig + movement

func _pick_gizmo_axis(screen_pos: Vector2) -> int:
	_axis_tips2d.clear()
	if not is_instance_valid(_cam) or not is_instance_valid(_gizmo_mesh_inst): return -1
	if not _gizmo_mesh_inst.visible: return -1
	var vp_rect := _viewport_container.get_global_rect() if is_instance_valid(_viewport_container) else Rect2()
	var origin  := _gizmo_mesh_inst.global_position
	var s := _gizmo_mesh_inst.scale.x
	var world_tips : Array[Vector3] = [
		origin + Vector3.RIGHT * GIZMO_LEN * s,
		origin + Vector3.UP    * GIZMO_LEN * s,
		origin + Vector3.BACK  * GIZMO_LEN * s,
	]
	var best_dist := AXIS_HIT_PX; var best_axis := -1
	for i in 3:
		if _cam.is_position_behind(world_tips[i]):
			_axis_tips2d.append(Vector2(-9999,-9999)); continue
		var tip2d := _cam.unproject_position(world_tips[i]) - vp_rect.position
		_axis_tips2d.append(tip2d)
		var d := screen_pos.distance_to(tip2d)
		if d < best_dist: best_dist = d; best_axis = i
	return best_axis

func _try_pick(screen_pos: Vector2) -> void:
	if not is_instance_valid(_cam) or not is_instance_valid(_viewport): return
	var world := _viewport.get_world_3d()
	if not world: return
	var space := world.direct_space_state
	if not space: return
	var from := _cam.project_ray_origin(screen_pos)
	var dir  := _cam.project_ray_normal(screen_pos)
	var hit  := space.intersect_ray(PhysicsRayQueryParameters3D.create(from, from + dir * 200.0))
	if hit.is_empty(): return
	var col : Variant = hit.get("collider")
	if col is Node:
		var node := col as Node
		while is_instance_valid(node) and node.get_parent() != _scene_root:
			node = node.get_parent()
		if is_instance_valid(node) and node.get_parent() == _scene_root:
			_on_tree_tap(node)

# ── Context menu ──────────────────────────────────────────────────────────────

func _build_context_menu() -> void:
	_ctx_menu = PopupMenu.new()
	_ctx_menu.add_item("Add Child Node", 6)  ## NEW — opens node picker with target as parent
	_ctx_menu.add_separator()
	_ctx_menu.add_item("Duplicate",  0)
	_ctx_menu.add_item("Focus Cam", 1)
	_ctx_menu.add_item("Rename",    2)
	_ctx_menu.add_separator()
	_ctx_menu.add_item("Save Prefab", 3)
	_ctx_menu.add_item("Spawn Prefab", 4)
	_ctx_menu.add_separator()
	_ctx_menu.add_item("Delete",    5)
	_ctx_menu.id_pressed.connect(_on_ctx_action)
	add_child(_ctx_menu)

func _show_context_menu(pos: Vector2) -> void:
	if not is_instance_valid(_ctx_menu): return
	_ctx_target = _selected_node
	_ctx_menu.position = Vector2i(int(pos.x), int(pos.y))
	_ctx_menu.popup()

func _on_ctx_action(id: int) -> void:
	if not is_instance_valid(_ctx_target): return
	match id:
		6:  # Add Child Node
			_add_node_parent = _ctx_target
			_show_add_node_popup(_ctx_menu.position)
		0:  # Duplicate
			if _ctx_target is Node3D and is_instance_valid(_scene_root):
				var src := _ctx_target as Node3D
				var copy := src.duplicate() as Node3D
				copy.position += Vector3(GRID_SNAP, 0, GRID_SNAP)
				_undo_redo.call("push", "Duplicate " + str(src.name),
					func(): _scene_root.add_child(copy); _spawned.append(copy); _select_node_single(copy); _refresh_scene_tree(),
					func(): copy.queue_free(); _spawned.erase(copy))
		1:  # Focus camera
			if _ctx_target is Node3D and is_instance_valid(_cam_pivot):
				_cam_pivot.position = (_ctx_target as Node3D).global_position
		2:  # Rename — simple dialog via LineEdit popup
			_show_rename_dialog(_ctx_target)
		3:  # Save as prefab
			_selected_nodes.clear(); _selected_nodes.append(_ctx_target)
			_save_selected_prefab()
		4:  # Spawn prefab
			_spawn_selected_prefab()
		5:  # Delete
			_undo_redo.call("push", "Delete " + str(_ctx_target.name),
				func(): _ctx_target.queue_free(); _selected_nodes.clear(); _refresh_scene_tree(); _refresh_inspector(),
				func(): Log.warn("[Dashboard] Cannot undo node deletion"))

func _show_rename_dialog(node: Node) -> void:
	var dlg := AcceptDialog.new()
	dlg.title = "Rename Node"
	var edit := LineEdit.new()
	edit.text = str(node.name)
	dlg.add_child(edit)
	dlg.confirmed.connect(func():
		if not edit.text.is_empty():
			var old_name := str(node.name)
			var new_name := edit.text
			_undo_redo.call("push", "Rename %s→%s" % [old_name, new_name],
				func(): node.name = new_name; _refresh_scene_tree(),
				func(): node.name = old_name; _refresh_scene_tree())
		dlg.queue_free())
	dlg.canceled.connect(func(): dlg.queue_free())
	add_child(dlg)
	dlg.popup_centered()
	edit.grab_focus()

# ── Add Node popup ─────────────────────────────────────────────────────────────
## Node type catalogue.  Each entry: [display_label, factory_callable]
## Organised by section: 3D Geometry / Lights / Camera / Physics / Control / Empty

const _NODE_CATALOGUE : Array = [
	# ── 3D Geometry ──────────────────────────────────────────────────────────
	["🧊 Cube (MeshInstance3D)",     "_antype_cube"],
	["⬤  Sphere (MeshInstance3D)",  "_antype_sphere"],
	["⬮  Capsule (MeshInstance3D)", "_antype_capsule"],
	["—  Plane (MeshInstance3D)",   "_antype_plane"],
	["⬡  Node3D (empty pivot)",     "_antype_node3d"],
	# ── Lights ───────────────────────────────────────────────────────────────
	["💡 OmniLight3D",              "_antype_omni"],
	["☀  DirectionalLight3D",      "_antype_sun"],
	["🔦 SpotLight3D",             "_antype_spot"],
	# ── Camera ───────────────────────────────────────────────────────────────
	["📷 Camera3D",                 "_antype_camera"],
	# ── Physics ──────────────────────────────────────────────────────────────
	["🧱 StaticBody3D",            "_antype_static"],
	["🎮 CharacterBody3D",         "_antype_character"],
	["🌀 RigidBody3D",             "_antype_rigid"],
	# ── UI / Control ─────────────────────────────────────────────────────────
	["⬜ Control (root panel)",     "_antype_control"],
	["▤  VBoxContainer",           "_antype_vbox"],
	["▥  HBoxContainer",           "_antype_hbox"],
	["🔤 Label",                   "_antype_label"],
	["🔲 Button",                  "_antype_button"],
]

func _build_add_node_popup() -> void:
	_add_node_popup = PopupMenu.new()
	_add_node_popup.add_theme_font_size_override("font_size", 11)
	for i in _NODE_CATALOGUE.size():
		_add_node_popup.add_item(str(_NODE_CATALOGUE[i][0]), i)
	_add_node_popup.id_pressed.connect(_on_add_node_selected)
	add_child(_add_node_popup)

func _show_add_node_popup(at_pos: Vector2) -> void:
	if not is_instance_valid(_add_node_popup): return
	_add_node_popup.position = Vector2i(int(at_pos.x), int(at_pos.y))
	_add_node_popup.popup()

func _on_add_node_selected(id: int) -> void:
	if id < 0 or id >= _NODE_CATALOGUE.size(): return
	var method : String = str(_NODE_CATALOGUE[id][1])
	if has_method(method):
		call(method)
	else:
		Log.warn("[Dashboard] Add Node: no factory for %s" % method)

## ── Node factories (each creates, registers undo, selects) ──────────────────

func _an_attach(node: Node, type_name: String) -> void:
	## Determine parent: explicit parent > selected node > scene root
	var parent : Node = _add_node_parent
	if not is_instance_valid(parent):
		parent = _selected_node if is_instance_valid(_selected_node) else _scene_root
	if not is_instance_valid(parent): parent = _scene_root
	_add_node_parent = null  # reset after use

	## Register undo BEFORE adding — capture parent ref
	var par := parent
	_undo_redo.call("push", "Add " + type_name,
		func():
			if is_instance_valid(par) and is_instance_valid(node):
				par.add_child(node)
				_spawned.append(node)
				_select_node_single(node)
				_refresh_scene_tree()
				## Auto-focus so user sees what was created immediately
				_focus_selected()
				_toast("✚  " + type_name + " added", C_OK),
		func():
			if is_instance_valid(node):
				node.queue_free()
				_spawned.erase(node)
				_selected_nodes.clear()
				_refresh_scene_tree()
				_refresh_inspector())

func _antype_node3d() -> void:
	var n := Node3D.new(); n.name = "Node3D"
	_an_attach(n, "Node3D")

func _antype_cube() -> void:
	var mi := MeshInstance3D.new(); mi.name = "Cube"
	mi.mesh = BoxMesh.new()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(randf_range(0.4,1.0), randf_range(0.4,1.0), randf_range(0.4,1.0))
	mi.set_surface_override_material(0, mat)
	var eid := EntityManager.create_entity()
	EntityManager.add_component(eid, &"SceneNode", SceneNodeComponent.new(mi))
	EntityManager.add_component(eid, &"Transform",
		TransformComponent.new(Vector3.ZERO, Vector3.ZERO, Vector3.ONE))
	EntityManager.add_tag(eid, &"editor_object")
	_an_attach(mi, "Cube")

func _antype_sphere() -> void:
	var mi := MeshInstance3D.new(); mi.name = "Sphere"
	mi.mesh = SphereMesh.new()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(randf_range(0.4,1.0), randf_range(0.4,1.0), randf_range(0.4,1.0))
	mi.set_surface_override_material(0, mat)
	var eid := EntityManager.create_entity()
	EntityManager.add_component(eid, &"SceneNode", SceneNodeComponent.new(mi))
	EntityManager.add_component(eid, &"Transform",
		TransformComponent.new(Vector3.ZERO, Vector3.ZERO, Vector3.ONE))
	EntityManager.add_tag(eid, &"editor_object")
	_an_attach(mi, "Sphere")

func _antype_capsule() -> void:
	var mi := MeshInstance3D.new(); mi.name = "Capsule"
	mi.mesh = CapsuleMesh.new()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(randf_range(0.4,1.0), randf_range(0.4,1.0), randf_range(0.4,1.0))
	mi.set_surface_override_material(0, mat)
	var eid := EntityManager.create_entity()
	EntityManager.add_component(eid, &"SceneNode", SceneNodeComponent.new(mi))
	EntityManager.add_component(eid, &"Transform",
		TransformComponent.new(Vector3.ZERO, Vector3.ZERO, Vector3.ONE))
	EntityManager.add_tag(eid, &"editor_object")
	_an_attach(mi, "Capsule")

func _antype_plane() -> void:
	var mi := MeshInstance3D.new(); mi.name = "Plane"
	var pm := PlaneMesh.new(); pm.size = Vector2(2, 2); mi.mesh = pm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.55, 0.55, 0.6)
	mi.set_surface_override_material(0, mat)
	_an_attach(mi, "Plane")

func _antype_omni() -> void:
	var l := OmniLight3D.new(); l.name = "OmniLight3D"
	l.omni_range = 8.0
	l.light_color = Color(1.0, 0.95, 0.85)
	_an_attach(l, "OmniLight3D")

func _antype_sun() -> void:
	var l := DirectionalLight3D.new(); l.name = "DirectionalLight3D"
	l.rotation_degrees = Vector3(-50, 30, 0)
	_an_attach(l, "DirectionalLight3D")

func _antype_spot() -> void:
	var l := SpotLight3D.new(); l.name = "SpotLight3D"
	l.spot_range = 10.0; l.spot_angle = 25.0
	_an_attach(l, "SpotLight3D")

func _antype_camera() -> void:
	var c := Camera3D.new(); c.name = "Camera3D"
	c.position = Vector3(0, 2, 5)
	_an_attach(c, "Camera3D")

func _antype_static() -> void:
	var body := StaticBody3D.new(); body.name = "StaticBody3D"
	var cshape := CollisionShape3D.new()
	cshape.shape = BoxShape3D.new()
	body.add_child(cshape)
	_an_attach(body, "StaticBody3D")

func _antype_character() -> void:
	var body := CharacterBody3D.new(); body.name = "CharacterBody3D"
	var cshape := CollisionShape3D.new()
	cshape.shape = CapsuleShape3D.new()
	body.add_child(cshape)
	_an_attach(body, "CharacterBody3D")

func _antype_rigid() -> void:
	var body := RigidBody3D.new(); body.name = "RigidBody3D"
	var cshape := CollisionShape3D.new()
	cshape.shape = SphereShape3D.new()
	body.add_child(cshape)
	_an_attach(body, "RigidBody3D")

func _antype_control() -> void:
	var c := Control.new(); c.name = "Control"
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	_an_attach(c, "Control")

func _antype_vbox() -> void:
	var c := VBoxContainer.new(); c.name = "VBoxContainer"
	_an_attach(c, "VBoxContainer")

func _antype_hbox() -> void:
	var c := HBoxContainer.new(); c.name = "HBoxContainer"
	_an_attach(c, "HBoxContainer")

func _antype_label() -> void:
	var l := Label.new(); l.name = "Label"; l.text = "Label"
	_an_attach(l, "Label")

func _antype_button() -> void:
	var b := Button.new(); b.name = "Button"; b.text = "Button"
	_an_attach(b, "Button")

# ── Play controls ─────────────────────────────────────────────────────────────

func _do_play() -> void:
	_playing = true; _paused = false
	if is_instance_valid(_btn_play):  _btn_play.disabled  = true
	if is_instance_valid(_btn_pause): _btn_pause.disabled = false
	if is_instance_valid(_btn_stop):  _btn_stop.disabled  = false
	get_tree().paused = false
	if SystemScheduler: SystemScheduler.resume()
	_apply_play_style(true, false)
	Bus.emit(&"engine_play", null)
	_toast("▶  Playing", C_OK)

func _do_pause() -> void:
	_paused = not _paused
	get_tree().paused = _paused
	if SystemScheduler:
		if _paused: SystemScheduler.pause()
		else:       SystemScheduler.resume()
	if is_instance_valid(_btn_pause):
		_btn_pause.text = "▶" if _paused else "⏸"
	_apply_play_style(true, _paused)
	Bus.emit(&"engine_pause", {"paused": _paused})
	_toast(("⏸  Paused" if _paused else "▶  Resumed"), C_WARN)

func _do_stop() -> void:
	_playing = false; _paused = false
	get_tree().paused = false
	if SystemScheduler: SystemScheduler.pause()   ## stop ECS tick in editor mode
	if is_instance_valid(_btn_play):  _btn_play.disabled  = false
	if is_instance_valid(_btn_pause): _btn_pause.disabled = true
	if is_instance_valid(_btn_stop):  _btn_stop.disabled  = true
	if is_instance_valid(_btn_pause): _btn_pause.text = "⏸"
	_apply_play_style(false, false)
	Bus.emit(&"engine_stop", null)
	_toast("⏹  Stopped", C_ERR)

## Drives all play-mode visual changes in one place.
## playing=false → editor mode (normal colours, banner hidden, editing enabled).
## playing=true, paused=false → PLAYING (red tint, red banner, editing locked).
## playing=true, paused=true  → PAUSED  (amber tint, amber banner, editing locked).
func _apply_play_style(playing: bool, paused: bool) -> void:
	## ── Toolbar tint ─────────────────────────────────────────────────────────
	if is_instance_valid(_toolbar_style):
		if not playing:
			_toolbar_style.bg_color = C_BG1
		elif paused:
			_toolbar_style.bg_color = Color(0.28, 0.20, 0.04, 1.0)   ## dark amber
		else:
			_toolbar_style.bg_color = Color(0.28, 0.04, 0.04, 1.0)   ## dark red

	## ── Play banner ──────────────────────────────────────────────────────────
	if is_instance_valid(_play_banner):
		_play_banner.visible = playing
		if playing:
			var banner_style := _play_banner.get_theme_stylebox("panel") as StyleBoxFlat
			if is_instance_valid(banner_style):
				banner_style.bg_color = Color(0.55, 0.30, 0.04, 0.82) if paused \
					else Color(0.55, 0.04, 0.04, 0.82)
		if is_instance_valid(_play_banner_lbl):
			if paused:
				_play_banner_lbl.text = "⏸  PAUSED  —  tap ▶ to resume  |  ⏹ to stop"
			else:
				_play_banner_lbl.text = "●  PLAYING  —  tap ⏸ to pause  |  ⏹ to stop"

	## ── Scene tree / gizmo interaction ──────────────────────────────────────
	## Disable gizmo transforms and tree taps during play so users can't
	## accidentally edit the live scene. Re-enable on stop.
	if playing:
		## Force orbit (Q) mode — no accidental moves during play
		_set_gizmo(0)
		for btn in _gizmo_btns:
			if is_instance_valid(btn): btn.disabled = true
		if is_instance_valid(_tree_search): _tree_search.editable = false
	else:
		for btn in _gizmo_btns:
			if is_instance_valid(btn): btn.disabled = false
		if is_instance_valid(_tree_search): _tree_search.editable = true

# ── Gizmo ─────────────────────────────────────────────────────────────────────

func _set_gizmo(mode: int) -> void:
	_gizmo_mode = mode
	for i in _gizmo_btns.size():
		if is_instance_valid(_gizmo_btns[i]):
			_gizmo_btns[i].add_theme_color_override("font_color",
				C_ACCENT if i == mode else C_DIM)
	_rebuild_gizmo_mesh()

# ── Spawn helpers (with undo) ─────────────────────────────────────────────────

func _spawn_mesh(mesh: Mesh, prefix: String, shape: Shape3D = null) -> void:
	var mi := MeshInstance3D.new()
	mi.name = "%s_%d" % [prefix, _spawned.size()]
	mi.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(randf_range(0.3,1.0), randf_range(0.3,1.0), randf_range(0.3,1.0))
	mi.set_surface_override_material(0, mat)
	if shape:
		var col := StaticBody3D.new()
		var csh := CollisionShape3D.new(); csh.shape = shape
		col.add_child(csh); mi.add_child(col)
	mi.position = _snap(Vector3(randf_range(-4.0, 4.0), 0.5, randf_range(-4.0, 4.0)))

	## Build the ECS entity fully BEFORE the undo push so it's never half-constructed.
	## Store the id so undo can cleanly destroy it.
	var eid := EntityManager.create_entity()
	EntityManager.add_component(eid, &"SceneNode",
		SceneNodeComponent.new(mi))
	EntityManager.add_component(eid, &"Transform",
		TransformComponent.new(mi.position, mi.rotation_degrees, mi.scale))
	EntityManager.add_tag(eid, &"editor_object")

	_undo_redo.call("push", "Spawn " + prefix,
		func():
			if is_instance_valid(_scene_root): _scene_root.add_child(mi)
			_spawned.append(mi)
			_select_node_single(mi); _refresh_scene_tree()
			_focus_selected()
			_toast("✚  " + prefix + " spawned", C_OK),
		func():
			EntityManager.destroy_entity(eid)
			mi.queue_free(); _spawned.erase(mi)
			_selected_nodes.clear(); _refresh_scene_tree(); _refresh_inspector())

func _spawn_cube()    -> void: _spawn_mesh(BoxMesh.new(),     "Cube",    BoxShape3D.new())
func _spawn_sphere()  -> void: _spawn_mesh(SphereMesh.new(),  "Sphere",  SphereShape3D.new())
func _spawn_capsule() -> void: _spawn_mesh(CapsuleMesh.new(), "Capsule", CapsuleShape3D.new())

func _spawn_light() -> void:
	var light := OmniLight3D.new()
	light.name = "Light_%d" % _spawned.size()
	light.position = Vector3(randf_range(-4.0,4.0), 3.0, randf_range(-4.0,4.0))
	light.light_color = Color(1, randf_range(0.7,1.0), randf_range(0.5,1.0))
	light.omni_range = 8.0
	_undo_redo.call("push", "Spawn Light",
		func():
			if is_instance_valid(_scene_root): _scene_root.add_child(light)
			_spawned.append(light); _select_node_single(light); _refresh_scene_tree()
			_focus_selected()
			_toast("💡  Light spawned", C_WARN),
		func():
			light.queue_free(); _spawned.erase(light)
			_selected_nodes.clear(); _refresh_scene_tree())

func _spawn_entity() -> void:
	var pos := Vector3(randf_range(-4.0, 4.0), 0.5, randf_range(-4.0, 4.0))
	var id := EntityManager.create_entity()
	EntityManager.add_component(id, &"Transform",
		TransformComponent.new(pos))
	EntityManager.add_component(id, &"Velocity",
		VelocityComponent.new(Vector3(randf_range(-2.0,2.0), 0.0, randf_range(-2.0,2.0))))

	## Visible marker — small octahedron-ish shape built from a scaled SphereMesh.
	## Acts as the entity's scene representation; synced to TransformComponent each frame.
	var marker := MeshInstance3D.new()
	marker.name = "Entity_%d" % id
	var sm := SphereMesh.new()
	sm.radius = 0.18; sm.height = 0.36; sm.radial_segments = 6; sm.rings = 3
	marker.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color    = C_ENTITY
	mat.emission_enabled = true
	mat.emission        = C_ENTITY * 0.6
	mat.shading_mode    = BaseMaterial3D.SHADING_MODE_UNSHADED
	marker.set_surface_override_material(0, mat)
	marker.position = pos

	## Register SceneNode so inspector linkage works
	EntityManager.add_component(id, &"SceneNode", SceneNodeComponent.new(marker))
	EntityManager.add_tag(id, &"editor_entity")

	if is_instance_valid(_scene_root):
		_scene_root.add_child(marker)
	_spawned.append(marker)
	_entity_markers[id] = marker

	_select_node_single(marker)   ## show in scene tree + inspector
	_refresh_scene_tree()
	_focus_selected()
	_toast("✚  Entity e%d spawned" % id, C_ENTITY)
	Log.info("[Dashboard] spawned entity %d with marker" % id)

func _clear_spawned() -> void:
	for n in _spawned:
		if is_instance_valid(n): n.queue_free()
	_spawned.clear()
	_selected_nodes.clear()
	## Also clear entity markers — their nodes were in _spawned
	_entity_markers.clear()
	_refresh_inspector(); _refresh_scene_tree()
	_toast("🗑  Scene cleared", C_DIM)

func _reset_camera() -> void:
	_cam_yaw = 30.0; _cam_pitch = -25.0; _cam_dist = 12.0
	if is_instance_valid(_cam_pivot):
		_cam_pivot.rotation_degrees = Vector3(_cam_pitch, _cam_yaw, 0)
	if is_instance_valid(_cam): _cam.position.z = _cam_dist

## Show a brief toast notification in the viewport.
## msg    — text to display
## color  — optional accent color for the label text (default white)
func _toast(msg: String, color: Color = Color(1, 1, 1, 1)) -> void:
	if not is_instance_valid(_toast_label): return
	## Kill any running tween so previous toast doesn't interfere.
	if is_instance_valid(_toast_tween) and _toast_tween.is_running():
		_toast_tween.kill()
	_toast_label.text = msg
	_toast_label.add_theme_color_override("font_color", Color(color.r, color.g, color.b, 0.0))

	_toast_tween = create_tween()
	## Fade in quickly
	_toast_tween.tween_property(_toast_label, "theme_override_colors/font_color",
		Color(color.r, color.g, color.b, 1.0), 0.12)
	## Hold
	_toast_tween.tween_interval(1.4)
	## Fade out
	_toast_tween.tween_property(_toast_label, "theme_override_colors/font_color",
		Color(color.r, color.g, color.b, 0.0), 0.35)

## Frame the selected node in the viewport — moves cam pivot to node position
## and pulls distance back to fit the node's AABB.
func _focus_selected() -> void:
	if not is_instance_valid(_cam_pivot) or not is_instance_valid(_cam): return
	var node := _selected_node
	if not is_instance_valid(node):
		## No node selected — if entity selected, try its SceneNode
		if _selected_entity >= 0:
			var sn: Variant = EntityManager.get_component(_selected_entity, &"SceneNode")
			if sn is SceneNodeComponent and is_instance_valid((sn as SceneNodeComponent).node):
				node = (sn as SceneNodeComponent).node
	if not is_instance_valid(node) or not (node is Node3D): return
	var n3 := node as Node3D
	var aabb := _get_node_aabb(n3)
	var center := aabb.get_center() if aabb.size != Vector3.ZERO else n3.global_position
	var radius := aabb.size.length() * 0.5 if aabb.size != Vector3.ZERO else 1.5
	_cam_pivot.position = center
	_cam_dist = clampf(radius * 2.5, 2.0, 60.0)
	_cam.position.z = _cam_dist

## Clear all scene root children with undo — "New Scene".
func _do_new_scene() -> void:
	if not is_instance_valid(_scene_root): return
	var old_children : Array[Node] = []
	for c in _scene_root.get_children(): old_children.append(c)
	_undo_redo.call("push", "New Scene",
		func():
			for c in old_children:
				if is_instance_valid(c): c.queue_free()
			_spawned.clear(); _selected_nodes.clear()
			## Seed with a starter cube so the scene is never empty
			var mi := MeshInstance3D.new(); mi.name = "Cube"
			mi.mesh = BoxMesh.new()
			var mat := StandardMaterial3D.new()
			mat.albedo_color = Color(0.55, 0.65, 0.80)
			mi.set_surface_override_material(0, mat)
			mi.position = Vector3(0, 0.5, 0)
			_scene_root.add_child(mi)
			_spawned.append(mi)
			## Seed a warm fill light
			var fill := OmniLight3D.new(); fill.name = "FillLight"
			fill.position = Vector3(3, 4, 3)
			fill.light_color = Color(1.0, 0.92, 0.80)
			fill.omni_range = 12.0
			fill.light_energy = 1.2
			_scene_root.add_child(fill)
			_spawned.append(fill)
			_select_node_single(mi)
			_refresh_scene_tree(); _refresh_inspector()
			_focus_selected()
			_toast("✦  New scene — Cube + Light ready", C_OK),
		func():
			for c in old_children:
				if is_instance_valid(c): _scene_root.add_child(c); _spawned.append(c)
			_refresh_scene_tree())

## Save scene with a user-chosen slot name via a simple dialog.
func _do_save_scene_as() -> void:
	var dlg := AcceptDialog.new()
	dlg.title = "Save Scene As"
	var vbox := VBoxContainer.new()
	vbox.add_child(_lbl("Slot (0–9):", 10, C_DIM))
	var edit := LineEdit.new()
	edit.text = "0"; edit.max_length = 1
	edit.add_theme_font_size_override("font_size", 12)
	vbox.add_child(edit)
	dlg.add_child(vbox)
	dlg.confirmed.connect(func():
		var slot := clampi(int(edit.text), 0, 9)
		save_scene(slot)
		dlg.queue_free())
	dlg.canceled.connect(func(): dlg.queue_free())
	add_child(dlg)
	dlg.popup_centered()
	edit.grab_focus(); edit.select_all()

## Toggle collision shape visibility across all physics bodies in the scene.
var _debug_shapes_visible : bool = false
func _toggle_debug_shapes() -> void:
	_debug_shapes_visible = not _debug_shapes_visible
	if is_instance_valid(_scene_root):
		_set_debug_shapes_recursive(_scene_root, _debug_shapes_visible)

func _set_debug_shapes_recursive(node: Node, visible: bool) -> void:
	if node is CollisionShape3D:
		(node as CollisionShape3D).disabled = not visible
		if visible:
			(node as CollisionShape3D).debug_color = Color(0.0, 1.0, 0.5, 0.35)
	for c in node.get_children():
		_set_debug_shapes_recursive(c, visible)

# ── Asset browser ─────────────────────────────────────────────────────────────

func _file_icon(f: String) -> String:
	match f.get_extension().to_lower():
		"tscn","scn": return "🎬"
		"png","jpg","webp","svg": return "🖼"
		"gd": return "📝"
		"wav","ogg","mp3": return "🔊"
		"glb","obj","fbx": return "🧊"
		_: return "📄"

func _on_asset_clicked(path: String) -> void:
	var ext := path.get_extension().to_lower()
	if ext in ["tscn","scn"]:
		SceneStream.go(path)
	elif ext in ["glb","obj"]:
		var res: Resource = load(path)
		if res is PackedScene:
			var inst := (res as PackedScene).instantiate()
			if is_instance_valid(_scene_root):
				_scene_root.add_child(inst); _spawned.append(inst); _select_node_single(inst)

# ── Performance ───────────────────────────────────────────────────────────────

## Draws the performance sparkline.
## Two series on the same canvas:
##   FPS  — green line, y-axis 0–120 (clamped), with 30/60 reference lines.
##   MEM  — blue line, y-axis auto-scaled to max observed value.
## Both are normalised to the graph height independently.
func _draw_perf_graph() -> void:
	if not is_instance_valid(_perf_graph): return
	var w := _perf_graph.size.x
	var h := _perf_graph.size.y
	if w < 4.0 or h < 4.0: return
	var n := _perf_fps_buf.size()

	## Background
	_perf_graph.draw_rect(Rect2(0, 0, w, h), Color(0.06, 0.06, 0.08))

	## Reference lines at 30 and 60 FPS
	var fps_max := 120.0
	for ref_fps in [30.0, 60.0]:
		var ry: float = h - (ref_fps / fps_max) * h
		var ref_col := Color(0.9, 0.5, 0.1, 0.25) if ref_fps == 30.0 else Color(0.2, 0.8, 0.2, 0.20)
		_perf_graph.draw_line(Vector2(0, ry), Vector2(w, ry), ref_col, 1.0)
		var font := ThemeDB.fallback_font
		if font:
			_perf_graph.draw_string(font, Vector2(2, ry - 2),
				"%.0f" % ref_fps, HORIZONTAL_ALIGNMENT_LEFT, -1, 8,
				Color(0.6, 0.6, 0.6, 0.5))

	if n < 2: return

	## ── FPS line ─────────────────────────────────────────────────────────────
	var prev_fps := Vector2.ZERO
	for i in n:
		var fx := (float(i) / float(n - 1)) * w
		var fy := h - clampf(_perf_fps_buf[i] / fps_max, 0.0, 1.0) * h
		var pt := Vector2(fx, fy)
		if i > 0:
			var fps_val : float = _perf_fps_buf[i]
			var line_col := C_OK if fps_val >= 50.0 else (C_WARN if fps_val >= 30.0 else C_ERR)
			_perf_graph.draw_line(prev_fps, pt, line_col, 1.5)
		prev_fps = pt

	## ── MEM line ─────────────────────────────────────────────────────────────
	if _perf_mem_buf.size() >= 2:
		var mem_max := 0.0
		for v in _perf_mem_buf: mem_max = maxf(mem_max, v)
		if mem_max < 1.0: mem_max = 1.0
		var mem_n := _perf_mem_buf.size()
		var prev_mem := Vector2.ZERO
		for i in mem_n:
			var mx := (float(i) / float(mem_n - 1)) * w
			var my := h - (_perf_mem_buf[i] / mem_max) * h
			var mpt := Vector2(mx, my)
			if i > 0:
				_perf_graph.draw_line(prev_mem, mpt, Color(0.55, 0.75, 1.0, 0.7), 1.0)
			prev_mem = mpt

	## Current-value labels at right edge
	var font2 := ThemeDB.fallback_font
	if font2 and n > 0:
		var cur_fps : float = _perf_fps_buf[n - 1]
		var cur_mem : float = _perf_mem_buf[n - 1] if _perf_mem_buf.size() > 0 else 0.0
		var fps_col := C_OK if cur_fps >= 50.0 else (C_WARN if cur_fps >= 30.0 else C_ERR)
		_perf_graph.draw_string(font2, Vector2(w - 36, 10),
			"%.0ffps" % cur_fps, HORIZONTAL_ALIGNMENT_LEFT, -1, 8, fps_col)
		_perf_graph.draw_string(font2, Vector2(w - 36, 20),
			"%.0fMB" % cur_mem, HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0.55, 0.75, 1.0))

func _on_perf(data: Variant) -> void:
	if not data is Dictionary: return
	if not is_instance_valid(_lbl_fps): return
	var d := data as Dictionary
	var fps : float = float(d.get("fps", 0.0))
	var mem : float = float(d.get("mem_mb", 0.0))
	_lbl_fps.text = "%.0f fps" % fps
	_lbl_fps.add_theme_color_override("font_color",
		C_OK if fps >= 50 else (C_WARN if fps >= 30 else C_ERR))
	_lbl_mem.text   = "%.0f MB"  % mem
	_lbl_nodes.text = "%d nodes" % int(d.get("nodes", 0))
	## P3: push to rolling history buffers
	_perf_fps_buf.append(fps)
	_perf_mem_buf.append(mem)
	if _perf_fps_buf.size() > PERF_HISTORY_MAX: _perf_fps_buf.pop_front()
	if _perf_mem_buf.size() > PERF_HISTORY_MAX: _perf_mem_buf.pop_front()
	if is_instance_valid(_perf_graph): _perf_graph.queue_redraw()

# ── Split persistence ──────────────────────────────────────────────────────────

func _save_splits() -> void:
	Cfg.set_val("dashboard", "mid_split",   _mid_split.split_offset)
	Cfg.set_val("dashboard", "right_split", _right_split.split_offset)
	Cfg.set_val("dashboard", "vert_split",  _vert_split.split_offset)

func _restore_splits() -> void:
	var ms : Variant = Cfg.get_val("dashboard", "mid_split",   null)
	var rs : Variant = Cfg.get_val("dashboard", "right_split", null)
	var vs : Variant = Cfg.get_val("dashboard", "vert_split",  null)
	if ms != null: _mid_split.split_offset   = int(ms)
	if rs != null: _right_split.split_offset = int(rs)
	if vs != null: _vert_split.split_offset  = int(vs)

# ── Snap / grid ───────────────────────────────────────────────────────────────

func _snap(v: Vector3) -> Vector3:
	if not _snap_enabled: return v
	return Vector3(
		round(v.x / GRID_SNAP) * GRID_SNAP,
		round(v.y / GRID_SNAP) * GRID_SNAP,
		round(v.z / GRID_SNAP) * GRID_SNAP)

func _toggle_snap(btn: Button) -> void:
	_snap_enabled = not _snap_enabled
	btn.add_theme_color_override("font_color", C_ACCENT if _snap_enabled else C_DIM)

func _build_grid_mesh(imm: ImmediateMesh, half: int, step: float) -> void:
	imm.clear_surfaces()
	imm.surface_begin(Mesh.PRIMITIVE_LINES)
	for i in range(-half, half + 1):
		var f := float(i) * step
		var col := Color(0.4,0.4,0.55,0.8) if (i % 5 == 0) else Color(0.22,0.22,0.30,0.5)
		imm.surface_set_color(col); imm.surface_add_vertex(Vector3(f, 0, -half * step))
		imm.surface_set_color(col); imm.surface_add_vertex(Vector3(f, 0,  half * step))
		imm.surface_set_color(col); imm.surface_add_vertex(Vector3(-half * step, 0, f))
		imm.surface_set_color(col); imm.surface_add_vertex(Vector3( half * step, 0, f))
	imm.surface_end()

# ── Session / runtime panels ──────────────────────────────────────────────────

func _build_session_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Session"
	panel.add_theme_constant_override("separation", 4)
	_session_info_lbl = _lbl("", 10, C_DIM)
	panel.add_child(_session_info_lbl)
	var save_row := HBoxContainer.new()
	save_row.add_theme_constant_override("separation", 4)
	for slot in range(3):
		var slot_id := slot
		save_row.add_child(_tool_btn("Save %d" % slot_id, C_OK, func(): save_scene(slot_id)))
	for slot in range(3):
		var slot_id := slot
		save_row.add_child(_tool_btn("Load %d" % slot_id, C_WARN, func(): load_scene(slot_id)))
	panel.add_child(save_row)
	var sync_row := HBoxContainer.new()
	sync_row.add_theme_constant_override("separation", 4)
	sync_row.add_child(_tool_btn("Refresh", C_ACCENT, _refresh_session_panel))
	sync_row.add_child(_tool_btn("Reset ECS", C_ERR, _reset_entities))
	panel.add_child(sync_row)
	_refresh_session_panel()
	return panel

func _build_prefab_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Prefabs"
	panel.add_theme_constant_override("separation", 4)
	var hdr := HBoxContainer.new()
	hdr.add_theme_constant_override("separation", 4)
	_prefab_name_edit = LineEdit.new()
	_prefab_name_edit.placeholder_text = "Prefab name"
	_prefab_name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hdr.add_child(_prefab_name_edit)
	hdr.add_child(_tool_btn("Save Sel", C_OK, _save_selected_prefab))
	hdr.add_child(_tool_btn("Spawn Sel", C_ACCENT, _spawn_selected_prefab))
	hdr.add_child(_tool_btn("Refresh", C_DIM, _refresh_prefab_panel))
	panel.add_child(hdr)
	_prefab_status_lbl = _lbl("Prefab library", 10, C_DIM)
	panel.add_child(_prefab_status_lbl)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	_prefab_list = VBoxContainer.new()
	_prefab_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_prefab_list.add_theme_constant_override("separation", 2)
	scroll.add_child(_prefab_list)
	_refresh_prefab_panel()
	return panel

func _build_runtime_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Runtime"
	panel.add_theme_constant_override("separation", 2)

	## ── P3: Sparkline graph ──────────────────────────────────────────────────
	_perf_graph = Control.new()
	_perf_graph.custom_minimum_size = Vector2(0, 56)
	_perf_graph.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_perf_graph.draw.connect(_draw_perf_graph)
	## Legend row
	var legend := HBoxContainer.new()
	legend.add_theme_constant_override("separation", 8)
	legend.add_child(_lbl("● FPS", 8, C_OK))
	legend.add_child(_lbl("● MEM MB", 8, Color(0.55, 0.75, 1.0)))
	var legend_spacer := Control.new()
	legend_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	legend.add_child(legend_spacer)
	var clr_btn := _tool_btn("CLR", C_DIM, func():
		_perf_fps_buf.clear(); _perf_mem_buf.clear()
		if is_instance_valid(_perf_graph): _perf_graph.queue_redraw())
	legend.add_child(clr_btn)
	panel.add_child(legend)
	panel.add_child(_perf_graph)
	panel.add_child(_hdiv())

	## ── Header + text section ────────────────────────────────────────────────
	var top := HBoxContainer.new()
	top.add_child(_tool_btn("Refresh", C_ACCENT, _refresh_runtime_panel))
	_runtime_info_lbl = _lbl("Task scheduler + budgets", 9, C_DIM)
	top.add_child(_runtime_info_lbl)
	panel.add_child(top)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	_runtime_vbox = VBoxContainer.new()
	_runtime_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_runtime_vbox.add_theme_constant_override("separation", 2)
	scroll.add_child(_runtime_vbox)
	_refresh_runtime_panel()
	return panel

func _refresh_prefab_panel() -> void:
	if not is_instance_valid(_prefab_list): return
	for c in _prefab_list.get_children(): c.queue_free()
	var prefabs : Array[String] = PrefabLibrary.list_prefabs()
	if is_instance_valid(_prefab_status_lbl):
		var src := _get_prefab_source_node()
		var source_note := ""
		if is_instance_valid(src):
			source_note = " | source: %s" % str(src.name)
		_prefab_status_lbl.text = "%d prefabs%s" % [prefabs.size(), source_note]
	if prefabs.is_empty():
		_prefab_list.add_child(_lbl("  No prefabs saved", 10, C_DIM))
		return
	for prefab_name in prefabs:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 4)
		var btn := Button.new()
		btn.text = prefab_name
		btn.flat = true
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		btn.add_theme_font_size_override("font_size", 10)
		btn.add_theme_color_override("font_color", C_ACCENT if prefab_name == _selected_prefab_name else C_TEXT)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.pressed.connect(func():
			_selected_prefab_name = prefab_name
			if is_instance_valid(_prefab_name_edit):
				_prefab_name_edit.text = prefab_name
			_refresh_prefab_panel())
		row.add_child(btn)
		row.add_child(_tool_btn("Spawn", C_OK, func(): _spawn_prefab_by_name(prefab_name)))
		_prefab_list.add_child(row)

func _save_selected_prefab() -> void:
	var src := _get_prefab_source_node()
	if not is_instance_valid(src):
		Log.warn("[Dashboard] no node selected for prefab capture")
		return
	var prefab_name := _prefab_name_edit.text.strip_edges() if is_instance_valid(_prefab_name_edit) else ""
	if prefab_name.is_empty():
		prefab_name = "%s_%d" % [str(src.name), int(Time.get_unix_time_from_system())]
	if PrefabLibrary.save_prefab_from_node(prefab_name, src):
		_selected_prefab_name = prefab_name
		if is_instance_valid(_prefab_name_edit):
			_prefab_name_edit.text = prefab_name
		_refresh_prefab_panel()
		_refresh_session_panel()

func _spawn_selected_prefab() -> void:
	var prefab_name := _selected_prefab_name
	if prefab_name.is_empty() and is_instance_valid(_prefab_name_edit):
		prefab_name = _prefab_name_edit.text.strip_edges()
	if prefab_name.is_empty() and PrefabLibrary:
		var list : Array[String] = PrefabLibrary.list_prefabs()
		if not list.is_empty():
			prefab_name = list[0]
	if not prefab_name.is_empty():
		_spawn_prefab_by_name(prefab_name)

func _spawn_prefab_by_name(prefab_name: String) -> void:
	if prefab_name.is_empty() or not is_instance_valid(_scene_root):
		return
	var node : Node = PrefabLibrary.spawn_prefab(prefab_name, _scene_root)
	if is_instance_valid(node):
		_spawned.append(node)
		_select_node_single(node)
		_refresh_scene_tree()
		_refresh_entity_list()
		_refresh_session_panel()
		_refresh_runtime_panel()
		_selected_prefab_name = prefab_name
		if is_instance_valid(_prefab_name_edit):
			_prefab_name_edit.text = prefab_name
		_refresh_prefab_panel()

func _get_prefab_source_node() -> Node:
	if is_instance_valid(_selected_node):
		return _selected_node
	if _selected_entity >= 0:
		var sn: Variant = EntityManager.get_component(_selected_entity, &"SceneNode")
		if sn is SceneNodeComponent:
			var linked := sn as SceneNodeComponent
			if is_instance_valid(linked.node):
				return linked.node
	return null

func _refresh_session_panel() -> void:
	if not is_instance_valid(_session_info_lbl):
		return
	var nodes := 0
	if is_instance_valid(_scene_root):
		nodes = _scene_root.get_child_count()
	_session_info_lbl.text = "Scene root children: %d | Entities: %d | Prefabs: %d | Saved slots: %s" % [
		nodes,
		EntityManager.entity_count(),
		PrefabLibrary.list_prefabs().size(),
		"0 1 2"
	]

func _refresh_runtime_panel() -> void:
	if not is_instance_valid(_runtime_vbox):
		return
	for c in _runtime_vbox.get_children():
		c.queue_free()
	var fps := float(Engine.get_frames_per_second())
	var mem := float(OS.get_static_memory_usage()) / 1_048_576.0
	var frame_rem := float(FrameBudget.remaining_ms()) if FrameBudget and FrameBudget.has_method("remaining_ms") else 0.0
	_runtime_vbox.add_child(_lbl("FPS: %.1f  Mem: %.1f MB  Entities: %d" % [fps, mem, EntityManager.entity_count()], 10, C_TEXT))
	_runtime_vbox.add_child(_lbl("Frame budget remaining: %.2f ms" % frame_rem, 10, C_DIM))
	_runtime_vbox.add_child(_hdiv())
	var tasks := TaskScheduler.get_tasks() if TaskScheduler.has_method("get_tasks") else []
	_runtime_vbox.add_child(_lbl("Scheduled tasks: %d" % tasks.size(), 10, C_ACCENT))
	for task in tasks:
		if not task is Dictionary:
			continue
		var d := task as Dictionary
		var row := _lbl("%s | every %.1fs | next %.1fs" % [str(d.get("id", "")), float(d.get("interval", 0.0)), float(d.get("remaining", 0.0))], 9, C_DIM)
		_runtime_vbox.add_child(row)
	var warn := ""
	if MemoryBudget and MemoryBudget.has_method("usage_mb"):
		warn = "Memory: %.1f / %.1f MB" % [MemoryBudget.usage_mb(), MemoryBudget.budget_mb]
	else:
		warn = "Memory budget unavailable"
	_runtime_vbox.add_child(_hdiv())
	_runtime_vbox.add_child(_lbl(warn, 10, C_WARN))
	if is_instance_valid(_runtime_info_lbl):
		_runtime_info_lbl.text = warn

func _reset_entities() -> void:
	## Remove marker nodes before clearing ECS so _on_ecs_entity_destroyed
	## doesn't race against the bulk clear.
	for eid: int in _entity_markers.keys():
		var m : Variant = _entity_markers[eid]
		if (m is Node) and is_instance_valid(m as Node): (m as Node).queue_free()
	_entity_markers.clear()
	EntityManager.clear_all()
	_refresh_entity_list()
	_refresh_inspector()
	_refresh_session_panel()
	_refresh_runtime_panel()
	_toast("⚡  ECS reset", C_WARN)

# ── Widget helpers ─────────────────────────────────────────────────────────────

func _lbl(text: String, sz: int = 12, color: Color = Color.WHITE) -> Label:
	var l := Label.new(); l.text = text
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", color)
	return l

func _make_spinbox(value: float, min_v: float, max_v: float, step: float) -> SpinBox:
	var s := SpinBox.new()
	s.min_value = min_v; s.max_value = max_v; s.step = step; s.value = value
	s.add_theme_font_size_override("font_size", 10)
	return s

func _panel(color: Color) -> PanelContainer:
	var p := PanelContainer.new()
	var s := StyleBoxFlat.new(); s.bg_color = color
	s.border_color = C_BORDER; s.set_border_width_all(1)
	p.add_theme_stylebox_override("panel", s); return p

func _tool_btn(text: String, color: Color, fn: Callable) -> Button:
	var b := Button.new(); b.text = text; b.flat = true
	b.add_theme_font_size_override("font_size", 13)
	b.add_theme_color_override("font_color", color)
	b.custom_minimum_size = Vector2(32, 30)
	if fn.is_valid(): b.pressed.connect(fn)
	return b

func _asset_btn(text: String, is_dir: bool) -> Button:
	var b := Button.new(); b.text = text; b.flat = false
	b.add_theme_font_size_override("font_size", 10)
	b.add_theme_color_override("font_color", C_ACCENT if is_dir else C_TEXT)
	b.custom_minimum_size = Vector2(80, 64); return b

func _action_btn(text: String, color: Color) -> Button:
	var b := Button.new(); b.text = text
	b.add_theme_font_size_override("font_size", 11)
	b.add_theme_color_override("font_color", color); return b

func _sep() -> Control:
	var s := VSeparator.new()
	s.add_theme_color_override("separator_color", C_BORDER); return s

func _vsep() -> Control:
	var s := VSeparator.new(); s.custom_minimum_size.x = 1
	s.add_theme_color_override("separator_color", C_BORDER); return s

func _hdiv() -> HSeparator:
	var s := HSeparator.new()
	s.add_theme_color_override("separator_color", C_BORDER); return s

func _comp_header_plain(label: String) -> Control:
	return _comp_header(label, C_DIM)

# ── KING Systems tab ──────────────────────────────────────────────────────────

var _systems_list   : VBoxContainer = null
var _sys_tick_phase : float = 0.0

func _build_systems_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Systems"
	panel.add_theme_constant_override("separation", 2)

	var hdr := HBoxContainer.new()
	var hdr_lbl := _lbl("ACTIVE SYSTEMS", 10, C_ACCENT)
	hdr_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hdr.add_child(hdr_lbl)
	var entity_count := EntityManager.get_all_entities().size()
	hdr.add_child(_lbl("%d entities total" % entity_count, 9, C_ENTITY))
	panel.add_child(hdr)
	panel.add_child(_hdiv())

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	_systems_list = VBoxContainer.new()
	_systems_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_systems_list.add_theme_constant_override("separation", 1)
	scroll.add_child(_systems_list)

	_refresh_systems_tab(_systems_list)
	## Auto-refresh every second
	TaskScheduler.schedule(&"dash_systems_refresh", 1.0, func():
		if is_instance_valid(_systems_list): _refresh_systems_tab(_systems_list))
	return panel

func _refresh_systems_tab(sys_list: VBoxContainer) -> void:
	for c in sys_list.get_children(): c.queue_free()
	if not is_instance_valid(SystemRegistry): return

	var systems : Array = SystemRegistry.all_systems()
	if systems.is_empty():
		sys_list.add_child(_lbl("  No systems registered", 10, C_DIM))
		return

	var global_entity_count := EntityManager.get_all_entities().size()
	for sys in systems:
		if not is_instance_valid(sys): continue
		var row := HBoxContainer.new()
		row.custom_minimum_size.y = 22

		## Tick pulse — alternates color to show system is running.
		_sys_tick_phase = fmod(_sys_tick_phase + 0.5, 1.0)
		var pulse_color := C_OK.lerp(Color(0.1, 0.6, 0.3), absf(sin(_sys_tick_phase * PI)))
		var dot := _lbl("●", 10, pulse_color if sys.get("enabled") != false else C_DIM)
		dot.custom_minimum_size.x = 14
		row.add_child(dot)

		## System name — clicking selects/highlights the system in the tab.
		var sys_name : String = str(sys.name) if sys.has_method("get") else sys.get_class()
		## Highlight: accent if this system touches the selected entity.
		var is_entity_hl : bool = not _entity_highlight_systems.is_empty() \
			and _entity_highlight_systems.has(sys_name)
		var name_color : Color
		if is_entity_hl:
			name_color = Color(1.0, 0.85, 0.3)   ## amber = "touching selected entity"
		elif sys.get("enabled") != false:
			name_color = C_TEXT
		else:
			name_color = C_DIM
		var name_lbl := _lbl(sys_name, 10, name_color)
		name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_lbl.mouse_filter = Control.MOUSE_FILTER_STOP
		## Emit an event so the viewport can flash affected entities.
		var captured_sys = sys
		name_lbl.gui_input.connect(func(event: InputEvent) -> void:
			if event is InputEventMouseButton \
					and (event as InputEventMouseButton).pressed \
					and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
				Bus.emit(&"editor.system_selected",
					{"system": captured_sys, "name": sys_name}))
		row.add_child(name_lbl)

		## Per-system entity count:
		##   If the system exposes _affected_count (e.g. IdleBehaviorSystem,
		##   MovementSystem), show that real value.
		##   Otherwise fall back to the global entity count.
		var priority : int = int(sys.get("priority") if "priority" in sys else 0)
		var affected : int = global_entity_count
		if "_affected_count" in sys:
			affected = int(sys.get("_affected_count"))
		## Colour the count: green if > 0, dim if zero (system doing nothing).
		var count_color : Color = C_ENTITY if affected > 0 else C_DIM
		var count_lbl := _lbl("%d  p%d" % [affected, priority], 9, count_color)
		count_lbl.custom_minimum_size.x = 52
		row.add_child(count_lbl)

		sys_list.add_child(row)

# ── KING Logs tab ─────────────────────────────────────────────────────────────

func _build_logs_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Logs"
	panel.add_theme_constant_override("separation", 2)

	# Filter bar
	var filter_row := HBoxContainer.new()
	filter_row.add_theme_constant_override("separation", 3)
	var log_vbox := VBoxContainer.new()
	log_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	log_vbox.add_theme_constant_override("separation", 1)
	var log_scroll := ScrollContainer.new()

	var search_edit := LineEdit.new()
	search_edit.placeholder_text = "🔍 filter…"
	search_edit.add_theme_font_size_override("font_size", 10)

	const LEVEL_LABELS : Array[String] = ["D", "I", "W", "E"]
	const LEVEL_COLORS : Array[Color]  = [
		Color(0.50, 0.75, 1.00),
		Color(0.85, 0.85, 0.85),
		Color(1.00, 0.75, 0.20),
		Color(0.90, 0.28, 0.28)
	]
	var show_level : Array[bool] = [true, true, true, true]

	var rebuild := func():
		for c in log_vbox.get_children(): c.queue_free()
		var capture : Node = get_tree().root.get_node_or_null("LogCapture")
		if not capture: return
		var search : String = search_edit.text.to_lower()
		for entry in capture.all():
			var lvl : int    = clampi(int(entry.get("level", 1)), 0, 3)
			var msg : String = str(entry.get("msg", ""))
			var ts  : float  = float(entry.get("time", 0.0))
			if not show_level[lvl]: continue
			if not search.is_empty() and not msg.to_lower().contains(search): continue
			var row := HBoxContainer.new()
			row.add_theme_constant_override("separation", 4)
			var ts_lbl := _lbl("%6.1fs" % ts, 9, C_DIM)
			ts_lbl.custom_minimum_size.x = 44
			row.add_child(ts_lbl)
			var lvl_lbl := _lbl(LEVEL_LABELS[lvl], 9, LEVEL_COLORS[lvl])
			lvl_lbl.custom_minimum_size.x = 10
			row.add_child(lvl_lbl)
			var msg_lbl := _lbl(msg, 10, LEVEL_COLORS[lvl])
			msg_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			msg_lbl.clip_text = true
			row.add_child(msg_lbl)
			log_vbox.add_child(row)

	for i in 4:
		var btn := Button.new()
		btn.text = LEVEL_LABELS[i]
		btn.flat = false
		btn.toggle_mode = true
		btn.button_pressed = true
		btn.add_theme_font_size_override("font_size", 10)
		btn.add_theme_color_override("font_color", LEVEL_COLORS[i])
		var idx := i
		btn.toggled.connect(func(on: bool) -> void:
			show_level[idx] = on
			rebuild.call())
		filter_row.add_child(btn)

	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	filter_row.add_child(sp)
	var clear_btn := _tool_btn("✕", C_DIM, Callable())
	clear_btn.pressed.connect(func():
		var capture : Node = get_tree().root.get_node_or_null("LogCapture")
		if capture: capture.clear()
		rebuild.call())
	filter_row.add_child(clear_btn)

	panel.add_child(filter_row)
	search_edit.text_changed.connect(func(_t: String): rebuild.call())
	panel.add_child(search_edit)

	log_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	log_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(log_scroll)
	log_scroll.add_child(log_vbox)

	# Poll for new entries every 1.5s via a timer
	var timer := Timer.new()
	timer.wait_time = 1.5
	timer.autostart = true
	timer.timeout.connect(rebuild)
	panel.add_child(timer)

	rebuild.call()
	return panel

# ── KING System Graph tab ─────────────────────────────────────────────────────

func _build_graph_tab() -> Control:
	var panel := VBoxContainer.new()
	panel.name = "Graph"
	panel.add_theme_constant_override("separation", 2)

	const GROUPS : Array = [
		["Core",        Color(0.28, 0.52, 0.90),
			["Log","Bus","Kernel","Cfg","Version","SaveDir","SaveLoadManager"]],
		["Runtime",     Color(0.44, 0.80, 0.44),
			["TaskScheduler","FrameBudget","MemoryBudget","Watchdog","Clock"]],
		["Services",    Color(0.75, 0.55, 0.90),
			["Pool","Registry","Jobs","StateMachine","UIStack","EntityManager",
			 "AudioDSPSystem","MultiplayerSystem","LocalizationSystem","IAPSystem",
			 "NetworkState"]],
		["Platform",    Color(0.90, 0.65, 0.28),
			["DeviceCap","InputRouter","AppLifecycle","AccessibilitySystem",
			 "ThermalMonitor","BatteryMonitor","NotchHandler"]],
		["Streaming",   Color(0.28, 0.75, 0.75),
			["AssetStream","SceneStream","WorldChunkManager"]],
		["Rendering",   Color(0.90, 0.40, 0.40),
			["MaterialManager","ShaderManager","GraphicsScaler","LODManager",
			 "PostProcessManager","ParticleSystem"]],
		["Diagnostics", Color(0.90, 0.80, 0.28),
			["PerfMonitor","LogCapture","CrashGuard","RuntimeValidator",
			 "ReplayRecorder","DevUI"]],
		["ECS",         Color(0.60, 0.80, 0.60),
			["EntityManager","MovementSystem","AnimationSystem","AudioSystem",
			 "DamageSystem","DebugSystem"]],
	]

	# Legend row
	var legend := HBoxContainer.new()
	legend.add_theme_constant_override("separation", 6)
	for g in GROUPS:
		var ga := g as Array
		var dot := _lbl("● " + str(ga[0]), 8, ga[1] as Color)
		legend.add_child(dot)
	var lscroll := ScrollContainer.new()
	lscroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	lscroll.vertical_scroll_mode   = ScrollContainer.SCROLL_MODE_DISABLED
	lscroll.custom_minimum_size.y  = 18
	lscroll.add_child(legend)
	panel.add_child(lscroll)

	# Draw area
	var outer_scroll := ScrollContainer.new()
	outer_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(outer_scroll)

	var draw_area := Control.new()
	const BOX_W := 90; const BOX_H := 22
	const PAD_X := 14; const PAD_Y := 8
	const COL_W := BOX_W + PAD_X * 2
	const ROW_H := BOX_H + PAD_Y
	var cols := GROUPS.size()
	var max_rows := 0
	for g in GROUPS:
		max_rows = maxi(max_rows, (g as Array)[2].size())
	draw_area.custom_minimum_size = Vector2(cols * COL_W + 20, (max_rows + 2) * ROW_H + 40)

	draw_area.draw.connect(func():
		var dc := draw_area
		dc.draw_rect(Rect2(Vector2.ZERO, dc.size), Color(0.08, 0.08, 0.10))
		var font := ThemeDB.fallback_font
		if not font: return
		var ox := 8; var oy := 8
		for gi in GROUPS.size():
			var ga : Array = GROUPS[gi] as Array
			var gcol : Color = ga[1] as Color
			var gsys : Array = ga[2] as Array
			var cx := ox + gi * COL_W
			var col_rect := Rect2(cx, oy, COL_W, (gsys.size() + 1) * ROW_H + PAD_Y)
			dc.draw_rect(col_rect, Color(gcol.r, gcol.g, gcol.b, 0.07))
			dc.draw_rect(col_rect, Color(gcol.r, gcol.g, gcol.b, 0.25), false, 1.0)
			dc.draw_string(font, Vector2(cx + 4, oy + 13), str(ga[0]),
				HORIZONTAL_ALIGNMENT_LEFT, -1, 9, gcol)
			for si in gsys.size():
				var sname : String = str(gsys[si])
				var bx := cx + PAD_X
				var by := oy + (si + 1) * ROW_H + 4
				var box := Rect2(bx, by, BOX_W, BOX_H)
				dc.draw_rect(box, Color(gcol.r * 0.3, gcol.g * 0.3, gcol.b * 0.3, 0.85))
				dc.draw_rect(box, gcol, false, 1.0)
				dc.draw_string(font, Vector2(bx + 4, by + int(BOX_H * 0.65)),
					sname, HORIZONTAL_ALIGNMENT_LEFT, BOX_W - 6, 9, Color(0.9, 0.9, 0.9))
	)
	outer_scroll.add_child(draw_area)
	return panel

func save_scene(slot: int = 0) -> void:
	SceneSession.save_slot(slot, _scene_root)
	_refresh_session_panel()
	_refresh_runtime_panel()
	_toast("💾  Saved to slot %d" % slot, C_OK)

func load_scene(slot: int = 0) -> void:
	if not is_instance_valid(_scene_root):
		return
	if not SceneSession.restore_slot(slot, _scene_root):
		return
	Log.info("[Dashboard] requested load slot %d" % slot)
	_toast("📂  Loaded slot %d" % slot, C_WARN)

func _on_scene_loaded(_payload: Variant) -> void:
	if not is_instance_valid(_scene_root):
		return
	_spawned.clear()
	for child: Node in _scene_root.get_children():
		if child != null:
			_spawned.append(child)
	_refresh_scene_tree()
	_refresh_inspector()
	_refresh_session_panel()
	_refresh_runtime_panel()
