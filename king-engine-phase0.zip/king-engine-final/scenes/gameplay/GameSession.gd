## GameSession — wires world load, player spawn, HUD, and pause.
extends Node

@export var world_path  : String = "res://scenes/gameplay/GameWorld.tscn"
@export var player_prefab_path : String = "res://prefabs/player/Player.tscn"

var _player_entity : int = -1

func _ready() -> void:
	Bus.on(&"input.action",  _on_input_action)
	Bus.on(&"scene_loaded",  _on_world_ready)
	Bus.on(&"player_spawned", _on_player_spawned)
	WorldManager.load_world_async(world_path)
	Log.info("[GameSession] Loading world: %s" % world_path)

func _exit_tree() -> void:
	Bus.off(&"input.action",  _on_input_action)
	Bus.off(&"scene_loaded",  _on_world_ready)
	Bus.off(&"player_spawned", _on_player_spawned)

func _on_world_ready(_data: Variant) -> void:
	Bus.off(&"scene_loaded", _on_world_ready)
	Log.info("[GameSession] World ready — spawning player")
	_spawn_player()

func _spawn_player() -> void:
	## Find spawn point from the loaded world.
	var spawn_pos := Vector3(0.0, 0.5, 0.0)
	var spawn_node := _find_spawn_marker()
	if spawn_node:
		spawn_pos = spawn_node.global_position

	## Load Player scene and add to world.
	if not ResourceLoader.exists(player_prefab_path):
		Log.warn("[GameSession] Player scene not found: %s" % player_prefab_path)
		return

	var packed := load(player_prefab_path) as PackedScene
	if packed == null:
		Log.error("[GameSession] Failed to load player scene")
		return

	var player_node := packed.instantiate() as Node3D
	if player_node == null:
		Log.error("[GameSession] Player scene root is not Node3D")
		return

	player_node.global_position = spawn_pos

	## Add to the world scene root.
	var parent : Node = WorldManager.scene_root
	if not is_instance_valid(parent):
		parent = get_tree().current_scene
	if is_instance_valid(parent):
		parent.add_child(player_node)
	else:
		add_child(player_node)

func _on_player_spawned(data: Variant) -> void:
	if not data is Dictionary: return
	_player_entity = int((data as Dictionary).get("entity", -1))
	## Now the player exists — sync HUD.
	UISystem._sync_initial_state()
	Log.info("[GameSession] Player entity: %d" % _player_entity)

func _find_spawn_marker() -> Marker3D:
	if not is_instance_valid(WorldManager.scene_root): return null
	## Try to find PlayerSpawn marker in the world.
	var node := WorldManager.scene_root.find_child("PlayerSpawn", true, false)
	if node is Marker3D:
		return node as Marker3D
	return null

func _on_input_action(data: Variant) -> void:
	if not data is Dictionary: return
	if StringName(str((data as Dictionary).get("action", ""))) == &"pause":
		_toggle_pause()

func _toggle_pause() -> void:
	if GameLoop.paused:
		GameLoop.resume()
	else:
		GameLoop.pause()
