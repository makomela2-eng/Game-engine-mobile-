## DebugScene — test runner for KING Engine.
## Runs unit tests immediately, then integration tests after one frame
## (integration tests need autoloads fully ready + first _process to have run).
extends Node

const UNIT_TESTS : Array[String] = [
	"res://tests/unit/test_entity_manager.gd",
	"res://tests/unit/test_save_load.gd",
	"res://tests/unit/test_bus_events.gd",
]

const INTEGRATION_TESTS : Array[String] = [
	"res://tests/integration/test_ecs_pipeline.gd",
]

func _ready() -> void:
	print("=== KING ENGINE TEST RUNNER ===")
	_run_unit_tests()
	## Integration tests need the first frame to complete (systems registered via _ready).
	## Defer by one frame so SystemScheduler has ticked at least once.
	get_tree().process_frame.connect(_run_integration_tests, CONNECT_ONE_SHOT)
	($Label as Label).text = "Tests running — see output panel"

func _run_unit_tests() -> void:
	print("--- Unit Tests ---")
	for path in UNIT_TESTS:
		var scr : Script = load(path)
		if not scr:
			push_error("Test not found: " + path)
			continue
		var t : Node = scr.new()
		t.name = path.get_file().get_basename()
		add_child(t)

func _run_integration_tests() -> void:
	print("--- Integration Tests ---")
	for path in INTEGRATION_TESTS:
		var scr : Script = load(path)
		if not scr:
			push_error("Integration test not found: " + path)
			continue
		var t : Node = scr.new()
		t.name = path.get_file().get_basename()
		add_child(t)
