## TestLevel — ECS integration smoke test + live demo sandbox.
##
## At boot this spawns a small set of demonstration entities, each with a
## distinct IdleBehaviorComponent mode, so the engine introduces itself
## without requiring any manual input.
##
## Demo layout (spawned in _spawn_demo):
##   • 4 ORBIT entities  — circle the origin at staggered start angles
##   • 2 DRIFT entities  — slow random-walk in the XZ plane
##   • 1 BOB entity      — vertical sine oscillation at centre
##   • 1 SPIN entity     — slow Y-rotation at a fixed position
##   • 2 PATROL entities — walk between opposite pairs of waypoints
##
## The enemy stress-test (spawn_enemies) is kept but opt-in via @export.
##
## Run integration tests via Dashboard → Console: "test run"
## or TestRunner.run_all()
extends Node3D

@export var enemy_count  : int   = 0        ## 0 = skip stress-test enemies
@export var spawn_radius : float = 8.0
@export var run_demo     : bool  = true     ## false = pure stress-test mode

var _spawned_entities : Array[int] = []

func _ready() -> void:
	_register_tests()
	call_deferred("_boot_spawn")

# ── Boot spawn ────────────────────────────────────────────────────────────────

func _boot_spawn() -> void:
	if run_demo:
		_spawn_demo()
	if enemy_count > 0:
		_spawn_enemies()

# ── Demo sandbox ───────────────────────────────────────────────────────────────
## Spawns entities that are already doing something.
## Each entity gets a TransformComponent + IdleBehaviorComponent.
## Entities that need movement also get a VelocityComponent.

func _spawn_demo() -> void:
	# ── 4 ORBIT entities — with separation + orbit-pull so they cluster ──
	for i in 4:
		var start_angle := float(i) / 4.0 * TAU
		var id := _make_entity(
			Vector3(cos(start_angle) * 3.0, 0.0, sin(start_angle) * 3.0))
		EntityManager.add_component(id, &"Velocity",     VelocityComponent.new())
		EntityManager.add_component(id, &"IdleBehavior",
			IdleBehaviorComponent.make_orbit(Vector3.ZERO, 3.0, 0.9 + randf() * 0.4,
			start_angle))
		## Relation: orbit pull draws their centres together over time.
		EntityManager.add_component(id, &"Relation",
			RelationComponent.make_repulse(1.5, 2.5))
		_spawned_entities.append(id)

	# ── 2 DRIFT entities — full flocking so they move as a loose pair ──
	for i in 2:
		var id := _make_entity(Vector3(randf_range(-2.0, 2.0), 0.0,
				randf_range(-2.0, 2.0)))
		EntityManager.add_component(id, &"Velocity",     VelocityComponent.new())
		EntityManager.add_component(id, &"IdleBehavior",
			IdleBehaviorComponent.make_drift(1.0 + randf() * 0.6, 1.8 + randf() * 1.5))
		EntityManager.add_component(id, &"Relation",
			RelationComponent.make_flock(1.8, 5.0))
		_spawned_entities.append(id)

	# ── 1 BOB entity — no relation (solo) ──
	var bob_id := _make_entity(Vector3(0.0, 0.0, 0.0))
	EntityManager.add_component(bob_id, &"IdleBehavior",
		IdleBehaviorComponent.make_bob(0.5, 0.7))
	_spawned_entities.append(bob_id)

	# ── 1 SPIN entity — no relation ──
	var spin_id := _make_entity(Vector3(5.0, 0.0, 0.0))
	EntityManager.add_component(spin_id, &"IdleBehavior",
		IdleBehaviorComponent.make_spin(60.0))
	_spawned_entities.append(spin_id)

	# ── 2 PATROL entities — separation so they don't stack at waypoints ──
	var p1 := _patrol(-5.0,  5.0, 0.0)
	var p2 := _patrol( 0.0,  0.0, 5.0)
	EntityManager.add_component(p1, &"Velocity",  VelocityComponent.new())
	EntityManager.add_component(p2, &"Velocity",  VelocityComponent.new())
	EntityManager.add_component(p1, &"Relation",  RelationComponent.make_repulse(2.0, 3.0))
	EntityManager.add_component(p2, &"Relation",  RelationComponent.make_repulse(2.0, 3.0))

	Log.info("[TestLevel] Demo: %d entities spawned and moving" % _spawned_entities.size())

func _patrol(ax: float, bx: float, z_offset: float) -> int:
	var id := _make_entity(Vector3(ax, 0.0, z_offset))
	EntityManager.add_component(id, &"IdleBehavior",
		IdleBehaviorComponent.make_patrol(
			Vector3(ax, 0.0, z_offset),
			Vector3(bx, 0.0, z_offset),
			2.0))
	_spawned_entities.append(id)
	return id

func _make_entity(pos: Vector3) -> int:
	var id := EntityManager.create_entity()
	EntityManager.add_component(id, &"Transform", TransformComponent.new(pos))
	return id

# ── Enemy stress-test (unchanged) ─────────────────────────────────────────────

func _spawn_enemies() -> void:
	for i in enemy_count:
		var angle := float(i) / float(enemy_count) * TAU
		var pos   := Vector3(cos(angle) * spawn_radius, 0.0, sin(angle) * spawn_radius)
		var id    := PrefabInstance.spawn(&"default_enemy", pos)
		if id >= 0:
			_spawned_entities.append(id)
	Log.info("[TestLevel] Spawned %d enemies" % enemy_count)

func _exit_tree() -> void:
	for id : int in _spawned_entities:
		if EntityManager.entity_exists(id):
			EntityManager.destroy_entity(id)
	_spawned_entities.clear()

# ── Tests (unchanged) ──────────────────────────────────────────────────────────

func _register_tests() -> void:
	TestRunner.register(&"TestLevel::entity_create_destroy", _test_entity_lifecycle)
	TestRunner.register(&"TestLevel::component_add_remove",  _test_components)
	TestRunner.register(&"TestLevel::damage_pipeline",       _test_damage)
	TestRunner.register(&"TestLevel::query_cache",           _test_query_cache)
	TestRunner.register(&"TestLevel::idle_behavior_orbit",   _test_idle_orbit)

func _test_entity_lifecycle() -> String:
	var id := EntityManager.create_entity()
	if not EntityManager.entity_exists(id):
		return "entity_exists failed after create"
	EntityManager.destroy_entity(id)
	if EntityManager.entity_exists(id):
		return "entity_exists still true after destroy"
	return ""

func _test_components() -> String:
	var id := EntityManager.create_entity()
	var tc := TransformComponent.new(Vector3(1, 2, 3))
	EntityManager.add_component(id, &"Transform", tc)
	if not EntityManager.has_component(id, &"Transform"):
		EntityManager.destroy_entity(id)
		return "has_component returned false after add"
	var got := EntityManager.get_component(id, &"Transform") as TransformComponent
	if got == null or not got.position.is_equal_approx(Vector3(1, 2, 3)):
		EntityManager.destroy_entity(id)
		return "component data mismatch"
	EntityManager.remove_component(id, &"Transform")
	if EntityManager.has_component(id, &"Transform"):
		EntityManager.destroy_entity(id)
		return "has_component still true after remove"
	EntityManager.destroy_entity(id)
	return ""

func _test_damage() -> String:
	var id := EntityManager.create_entity()
	EntityManager.add_component(id, &"Health", HealthComponent.new(100.0))
	Bus.emit(&"ecs.damage", {"entity": id, "amount": 30.0, "source": -1})
	var hc := EntityManager.get_component(id, &"Health") as HealthComponent
	EntityManager.destroy_entity(id)
	if hc == null:
		return "HealthComponent missing after damage emit"
	return ""

func _test_query_cache() -> String:
	var id := EntityManager.create_entity()
	EntityManager.add_component(id, &"Transform", TransformComponent.new())
	EntityManager.add_component(id, &"Velocity",  VelocityComponent.new())
	var result := QuerySystem.query([&"Transform", &"Velocity"])
	if not result.has(id):
		EntityManager.destroy_entity(id)
		return "QuerySystem missed new entity"
	EntityManager.destroy_entity(id)
	var after := QuerySystem.query([&"Transform", &"Velocity"])
	if after.has(id):
		return "QuerySystem still contains destroyed entity"
	return ""

func _test_idle_orbit() -> String:
	var id := EntityManager.create_entity()
	EntityManager.add_component(id, &"Transform",    TransformComponent.new(Vector3(3, 0, 0)))
	EntityManager.add_component(id, &"Velocity",     VelocityComponent.new())
	EntityManager.add_component(id, &"IdleBehavior",
		IdleBehaviorComponent.make_orbit(Vector3.ZERO, 3.0, 1.0, 0.0))
	var ib := EntityManager.get_component(id, &"IdleBehavior") as IdleBehaviorComponent
	if ib == null:
		EntityManager.destroy_entity(id)
		return "IdleBehaviorComponent missing after add"
	if ib.mode != IdleBehaviorComponent.Mode.ORBIT:
		EntityManager.destroy_entity(id)
		return "mode mismatch — expected ORBIT"
	EntityManager.destroy_entity(id)
	return ""
