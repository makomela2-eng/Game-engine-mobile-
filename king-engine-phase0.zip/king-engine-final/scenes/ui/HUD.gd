## HUD — reacts to Bus events. No polling, no _process.
## Nodes are optional — HUD works even without the scene tree children
## (gracefully degrades if HealthBar/FPSLabel/QuestLabel aren't in the tscn).
extends CanvasLayer

## These are set if the tscn has the children wired; otherwise null.
@onready var _health_bar  : ProgressBar = get_node_or_null("HealthBar")
@onready var _fps_label   : Label       = get_node_or_null("FPSLabel")
@onready var _quest_label : Label       = get_node_or_null("QuestLabel")

func _ready() -> void:
	Bus.on(&"hud.health_updated",    _on_health)
	Bus.on(&"hud.quest_updated",     _on_quest)
	Bus.on(&"hud.inventory_changed", _on_inventory)
	## FPS at 4 Hz via TaskScheduler — no _process.
	TaskScheduler.schedule(&"hud_fps", 0.25, func() -> void:
		if is_instance_valid(_fps_label):
			_fps_label.text = "FPS %d" % Engine.get_frames_per_second())

func _exit_tree() -> void:
	Bus.off(&"hud.health_updated",    _on_health)
	Bus.off(&"hud.quest_updated",     _on_quest)
	Bus.off(&"hud.inventory_changed", _on_inventory)
	TaskScheduler.unschedule(&"hud_fps")

func _on_health(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	if is_instance_valid(_health_bar):
		_health_bar.value = float(d.get("fraction", 1.0)) * 100.0

func _on_quest(data: Variant) -> void:
	if not data is Dictionary or not is_instance_valid(_quest_label): return
	var d      := data as Dictionary
	var quest  := str(d.get("quest", ""))
	var state  := int(d.get("state", 0))
	var states : Array[String] = ["Available", "Active", "Completed", "Failed"]
	_quest_label.text = "%s [%s]" % [quest, states[clampi(state, 0, 3)]]

func _on_inventory(_data: Variant) -> void:
	pass
