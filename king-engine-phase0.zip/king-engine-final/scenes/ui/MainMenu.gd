## MainMenu — wired to Bus and UIStack.
extends CanvasLayer

func _ready() -> void:
	Bus.on(&"ui.button_pressed", _on_button)

func _exit_tree() -> void:
	Bus.off(&"ui.button_pressed", _on_button)

func _on_button(data: Variant) -> void:
	if not data is Dictionary: return
	match StringName(str((data as Dictionary).get("button", ""))):
		&"play":
			get_tree().change_scene_to_file("res://scenes/gameplay/GameSession.tscn")
		&"settings":
			UISystem.show_screen(&"settings")
		&"quit":
			Bus.emit(&"app_quit", null)

## Called by Button.pressed signals in the scene.
func _on_play_pressed()     -> void: UIEventSystem.button_pressed(&"play")
func _on_settings_pressed() -> void: UIEventSystem.button_pressed(&"settings")
func _on_quit_pressed()     -> void: UIEventSystem.button_pressed(&"quit")
