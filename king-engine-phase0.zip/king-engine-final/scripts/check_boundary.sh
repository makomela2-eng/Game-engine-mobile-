#!/usr/bin/env bash
## scripts/check_boundary.sh — enforce the engine/game boundary.
## Exit 0 = clean. Exit 1 = violations.

FAIL=0

echo "1. src/ (minus src/gameplay, src/ai) must not call game systems by name ..."
# Only check engine-layer dirs. src/gameplay and src/ai ARE the game layer — fine to self-reference.
ENGINE_DIRS="src/core src/ecs src/runtime src/rendering src/input src/audio src/camera src/ui src/data src/save src/platform src/physics src/animation src/world src/streaming src/debug src/components src/extensions src/services src/jobs src/diagnostics src/scripting src/tooling src/network src/prefab src/assets src/testing"
HITS=""
for dir in $ENGINE_DIRS; do
  [ ! -d "$dir" ] && continue
  # Flag direct method calls to game systems (word boundary, followed by . and a method or newline)
  FOUND=$(grep -rEn "\b(QuestSystem|CombatSystem|InventorySystem|AbilitySystem|InteractionSystem|NavigationSystem)\s*\." "$dir/" 2>/dev/null || true)
  [ -n "$FOUND" ] && HITS="$HITS$FOUND\n"
done
[ -n "$HITS" ] && echo "VIOLATION:" && printf "$HITS" && FAIL=1

echo "2. Boot.gd must not reference gameplay/ or res://game/ ..."
HITS=$(grep -En "res://scenes/gameplay|res://game/" scenes/boot/Boot.gd 2>/dev/null || true)
[ -n "$HITS" ] && echo "VIOLATION:" && echo "$HITS" && FAIL=1

echo "3. EngineSystems.tscn must not load gameplay/ scripts ..."
HITS=$(grep -n "path.*gameplay/" scenes/engine/EngineSystems.tscn 2>/dev/null || true)
[ -n "$HITS" ] && echo "VIOLATION:" && echo "$HITS" && FAIL=1

echo "4. Engine dirs must not call DataRegistry with game table names ..."
HITS=""
for dir in $ENGINE_DIRS; do
  [ ! -d "$dir" ] && continue
  FOUND=$(grep -rEn 'DataRegistry\.(load_table|get_entry).*&"(items|enemies|quests|abilities)"' "$dir/" 2>/dev/null || true)
  [ -n "$FOUND" ] && HITS="$HITS$FOUND\n"
done
[ -n "$HITS" ] && echo "VIOLATION:" && printf "$HITS" && FAIL=1

echo "5. src/ must not reference res://game/ ..."
HITS=$(grep -rn "res://game/" src/ 2>/dev/null || true)
[ -n "$HITS" ] && echo "VIOLATION:" && echo "$HITS" && FAIL=1

echo ""
if [ "$FAIL" -eq 0 ]; then
  echo "✅  Boundary clean."
else
  echo "❌  Fix violations before committing."
  exit 1
fi
