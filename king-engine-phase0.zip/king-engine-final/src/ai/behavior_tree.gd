## BehaviorTree — production-grade behavior tree for AI entities.
##
## Nodes return SUCCESS, FAILURE, or RUNNING.
## Build trees in code or via AISystem._build_tree():
##
##   var tree := BehaviorTree.new(entity_id, blackboard)
##   tree.root = BehaviorTree.Selector.new([
##       BehaviorTree.Sequence.new([
##           BehaviorTree.ConditionNode.new(func(bb): return bb.has(&"target")),
##           BehaviorTree.ChaseNode.new(),
##       ]),
##       BehaviorTree.PatrolNode.new(waypoints),
##   ])
##
## Blackboard:
##   Shared Dictionary passed into every node tick.
##   Keys are StringName. Write from sensors, read from actions.
##   BehaviorTree.Blackboard wraps it with typed helpers.
class_name BehaviorTree
extends RefCounted

enum Status { SUCCESS, FAILURE, RUNNING }

var entity     : int
var blackboard : Blackboard
var root       : BTNode = null

func _init(e: int, bb: Blackboard = null) -> void:
	entity     = e
	blackboard = bb if bb != null else Blackboard.new()

func tick(delta: float) -> Status:
	if root == null:
		return Status.FAILURE
	return root.tick(entity, blackboard, delta) as Status

func reset() -> void:
	if root != null:
		root.reset()

# ── Blackboard ─────────────────────────────────────────────────────────────────

class Blackboard extends RefCounted:
	var _data : Dictionary = {}

	func set_val(key: StringName, value: Variant) -> void:
		_data[key] = value

	func get_val(key: StringName, default: Variant = null) -> Variant:
		return _data.get(key, default)

	func has(key: StringName) -> bool:
		return _data.has(key)

	func erase(key: StringName) -> void:
		_data.erase(key)

	func clear() -> void:
		_data.clear()

	## Typed helpers
	func get_int(key: StringName, default: int = 0) -> int:
		return int(_data.get(key, default))

	func get_float(key: StringName, default: float = 0.0) -> float:
		return float(_data.get(key, default))

	func get_vec3(key: StringName, default: Vector3 = Vector3.ZERO) -> Vector3:
		var v : Variant = _data.get(key, default)
		return v as Vector3 if v is Vector3 else default

	func get_entity(key: StringName) -> int:
		return int(_data.get(key, -1))

	func set_entity(key: StringName, id: int) -> void:
		_data[key] = id

# ── Node base ──────────────────────────────────────────────────────────────────

class BTNode extends RefCounted:
	func tick(_entity: int, _bb: Blackboard, _delta: float) -> int:
		return BehaviorTree.Status.FAILURE
	func reset() -> void:
		pass

# ── Composites ─────────────────────────────────────────────────────────────────

## Runs children left-to-right. Fails on first FAILURE. Succeeds when all succeed.
class Sequence extends BTNode:
	var children     : Array[BTNode]
	var _running_idx : int = 0
	func _init(c: Array[BTNode]) -> void: children = c
	func reset() -> void:
		_running_idx = 0
		for child in children: child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		for i in range(_running_idx, children.size()):
			var r : int = children[i].tick(entity, bb, delta)
			if r == BehaviorTree.Status.RUNNING:
				_running_idx = i
				return r
			if r == BehaviorTree.Status.FAILURE:
				_running_idx = 0
				return r
		_running_idx = 0
		return BehaviorTree.Status.SUCCESS

## Runs children left-to-right. Succeeds on first SUCCESS.
class Selector extends BTNode:
	var children     : Array[BTNode]
	var _running_idx : int = 0
	func _init(c: Array[BTNode]) -> void: children = c
	func reset() -> void:
		_running_idx = 0
		for child in children: child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		for i in range(_running_idx, children.size()):
			var r : int = children[i].tick(entity, bb, delta)
			if r == BehaviorTree.Status.RUNNING:
				_running_idx = i
				return r
			if r == BehaviorTree.Status.SUCCESS:
				_running_idx = 0
				return r
		_running_idx = 0
		return BehaviorTree.Status.FAILURE

## Ticks all children every frame. Policy: ALL_SUCCESS or ANY_SUCCESS.
class Parallel extends BTNode:
	var children    : Array[BTNode]
	var require_all : bool = true
	func _init(c: Array[BTNode], all: bool = true) -> void:
		children = c; require_all = all
	func reset() -> void:
		for child in children: child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		var successes := 0
		var failures  := 0
		for child in children:
			var r : int = child.tick(entity, bb, delta)
			if r == BehaviorTree.Status.SUCCESS: successes += 1
			elif r == BehaviorTree.Status.FAILURE: failures += 1
		if require_all:
			if failures > 0:            return BehaviorTree.Status.FAILURE
			if successes == children.size(): return BehaviorTree.Status.SUCCESS
			return BehaviorTree.Status.RUNNING
		else:
			if successes > 0: return BehaviorTree.Status.SUCCESS
			if failures == children.size(): return BehaviorTree.Status.FAILURE
			return BehaviorTree.Status.RUNNING

## Random-priority selector — shuffles children order each activation.
class RandomSelector extends BTNode:
	var children : Array[BTNode]
	var _order   : Array[int] = []
	func _init(c: Array[BTNode]) -> void: children = c
	func reset() -> void:
		_order.clear()
		for child in children: child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		if _order.is_empty():
			for i in children.size(): _order.append(i)
			_order.shuffle()
		for idx in _order:
			var r : int = children[idx].tick(entity, bb, delta)
			if r != BehaviorTree.Status.FAILURE:
				return r
		_order.clear()
		return BehaviorTree.Status.FAILURE

# ── Decorators ─────────────────────────────────────────────────────────────────

class Inverter extends BTNode:
	var child : BTNode
	func _init(c: BTNode) -> void: child = c
	func reset() -> void: child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		var r : int = child.tick(entity, bb, delta)
		if r == BehaviorTree.Status.SUCCESS: return BehaviorTree.Status.FAILURE
		if r == BehaviorTree.Status.FAILURE: return BehaviorTree.Status.SUCCESS
		return r

class Succeeder extends BTNode:
	var child : BTNode
	func _init(c: BTNode) -> void: child = c
	func reset() -> void: child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		child.tick(entity, bb, delta)
		return BehaviorTree.Status.SUCCESS

class Failer extends BTNode:
	var child : BTNode
	func _init(c: BTNode) -> void: child = c
	func reset() -> void: child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		child.tick(entity, bb, delta)
		return BehaviorTree.Status.FAILURE

## Runs child until it returns SUCCESS n times (or infinitely if n < 0).
class Repeater extends BTNode:
	var child  : BTNode
	var times  : int = -1
	var _count : int = 0
	func _init(c: BTNode, n: int = -1) -> void: child = c; times = n
	func reset() -> void: _count = 0; child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		if times >= 0 and _count >= times: return BehaviorTree.Status.SUCCESS
		var r : int = child.tick(entity, bb, delta)
		if r == BehaviorTree.Status.SUCCESS: _count += 1
		return BehaviorTree.Status.RUNNING

## Cooldown — child can only run once per interval_sec.
class Cooldown extends BTNode:
	var child        : BTNode
	var interval_sec : float
	var _elapsed     : float = 0.0
	var _ready_flag  : bool  = true
	func _init(c: BTNode, interval: float) -> void: child = c; interval_sec = interval
	func reset() -> void: _elapsed = 0.0; _ready_flag = true; child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		if not _ready_flag:
			_elapsed += delta
			if _elapsed >= interval_sec:
				_elapsed    = 0.0
				_ready_flag = true
			else:
				return BehaviorTree.Status.FAILURE
		var r : int = child.tick(entity, bb, delta)
		if r == BehaviorTree.Status.SUCCESS:
			_ready_flag = false
		return r

## Timeout — returns FAILURE if child takes longer than max_sec.
class Timeout extends BTNode:
	var child    : BTNode
	var max_sec  : float
	var _elapsed : float = 0.0
	func _init(c: BTNode, t: float) -> void: child = c; max_sec = t
	func reset() -> void: _elapsed = 0.0; child.reset()
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		_elapsed += delta
		if _elapsed > max_sec:
			_elapsed = 0.0
			child.reset()
			return BehaviorTree.Status.FAILURE
		var r : int = child.tick(entity, bb, delta)
		if r != BehaviorTree.Status.RUNNING: _elapsed = 0.0
		return r

# ── Leaf helpers ───────────────────────────────────────────────────────────────

## Wrap any callable: func(entity, blackboard, delta) -> BehaviorTree.Status
class ActionNode extends BTNode:
	var fn : Callable
	func _init(callable: Callable) -> void: fn = callable
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		return int(fn.call(entity, bb, delta))

## Wrap any condition: func(entity, blackboard) -> bool
class ConditionNode extends BTNode:
	var fn : Callable
	func _init(callable: Callable) -> void: fn = callable
	func tick(entity: int, bb: Blackboard, _delta: float) -> int:
		return BehaviorTree.Status.SUCCESS if fn.call(entity, bb) \
			else BehaviorTree.Status.FAILURE

## Wait for duration_sec then succeed.
class WaitNode extends BTNode:
	var duration : float
	var _elapsed : float = 0.0
	func _init(d: float) -> void: duration = d
	func reset() -> void: _elapsed = 0.0
	func tick(_entity: int, _bb: Blackboard, delta: float) -> int:
		_elapsed += delta
		if _elapsed >= duration:
			_elapsed = 0.0
			return BehaviorTree.Status.SUCCESS
		return BehaviorTree.Status.RUNNING

## Write a value into the blackboard, then succeed immediately.
class SetBlackboard extends BTNode:
	var key   : StringName
	var value : Variant
	func _init(k: StringName, v: Variant) -> void: key = k; value = v
	func tick(_entity: int, bb: Blackboard, _delta: float) -> int:
		bb.set_val(key, value)
		return BehaviorTree.Status.SUCCESS

## Emit a Bus event, then succeed.
class EmitNode extends BTNode:
	var event   : StringName
	var payload : Variant
	func _init(e: StringName, p: Variant = null) -> void: event = e; payload = p
	func tick(entity: int, _bb: Blackboard, _delta: float) -> int:
		Bus.emit(event, payload if payload != null else {"entity": entity, "data": {}})
		return BehaviorTree.Status.SUCCESS

# ── Built-in AI action nodes ───────────────────────────────────────────────────

## Move entity toward blackboard[&"target_pos"] using Pathfinding.
class MoveToTarget extends BTNode:
	var arrive_radius : float = 1.2
	var speed         : float = 4.0
	func _init(spd: float = 4.0, radius: float = 1.2) -> void:
		speed = spd; arrive_radius = radius
	func tick(entity: int, bb: Blackboard, _delta: float) -> int:
		var target : Vector3 = bb.get_vec3(&"target_pos")
		if target == Vector3.ZERO:
			return BehaviorTree.Status.FAILURE
		var t := EntityManager.get_component(entity, &"Transform") as TransformComponent
		if t == null:
			return BehaviorTree.Status.FAILURE
		if t.position.distance_to(target) <= arrive_radius:
			return BehaviorTree.Status.SUCCESS
		Pathfinding.set_target(entity, target)
		var desired := Pathfinding.get_desired_velocity(entity) * speed
		var vel := EntityManager.get_component(entity, &"Velocity") as VelocityComponent
		if vel != null:
			vel.linear = desired
		return BehaviorTree.Status.RUNNING

## Face the entity toward blackboard[&"target_entity"] or [&"target_pos"].
class FaceTarget extends BTNode:
	var turn_speed : float = 6.0
	func _init(spd: float = 6.0) -> void: turn_speed = spd
	func tick(entity: int, bb: Blackboard, delta: float) -> int:
		var t := EntityManager.get_component(entity, &"Transform") as TransformComponent
		if t == null: return BehaviorTree.Status.FAILURE
		var target_pos := Vector3.ZERO
		var target_id  := bb.get_entity(&"target_entity")
		if target_id >= 0:
			var tt := EntityManager.get_component(target_id, &"Transform") as TransformComponent
			if tt: target_pos = tt.position
		else:
			target_pos = bb.get_vec3(&"target_pos")
		if target_pos == Vector3.ZERO:
			return BehaviorTree.Status.FAILURE
		var dir       := (target_pos - t.position).normalized()
		var target_y  := atan2(dir.x, dir.z)
		t.rotation.y  = lerp_angle(t.rotation.y, target_y, turn_speed * delta)
		return BehaviorTree.Status.SUCCESS

## Check if target entity is within sense_range. Writes &"target_entity" to BB on success.
class SenseTarget extends BTNode:
	var sense_range : float = 12.0
	var target_tag  : StringName = &"player"
	func _init(range_val: float = 12.0, tag: StringName = &"player") -> void:
		sense_range = range_val; target_tag = tag
	func tick(entity: int, bb: Blackboard, _delta: float) -> int:
		var my_t := EntityManager.get_component(entity, &"Transform") as TransformComponent
		if my_t == null: return BehaviorTree.Status.FAILURE
		for target_id in EntityManager.get_entities_by_tag(target_tag):
			if target_id == entity: continue
			if EntityManager.has_tag(target_id, &"dead"): continue
			var tt := EntityManager.get_component(target_id, &"Transform") as TransformComponent
			if tt == null: continue
			if my_t.position.distance_to(tt.position) <= sense_range:
				bb.set_entity(&"target_entity", target_id)
				bb.set_val(&"target_pos", tt.position)
				return BehaviorTree.Status.SUCCESS
		return BehaviorTree.Status.FAILURE

## Flee: move away from blackboard[&"target_entity"].
class Flee extends BTNode:
	var flee_speed  : float = 5.0
	var safe_range  : float = 15.0
	func _init(spd: float = 5.0, safe: float = 15.0) -> void:
		flee_speed = spd; safe_range = safe
	func tick(entity: int, bb: Blackboard, _delta: float) -> int:
		var target_id := bb.get_entity(&"target_entity")
		if target_id < 0: return BehaviorTree.Status.FAILURE
		var my_t := EntityManager.get_component(entity,    &"Transform") as TransformComponent
		var tg_t := EntityManager.get_component(target_id, &"Transform") as TransformComponent
		if my_t == null or tg_t == null: return BehaviorTree.Status.FAILURE
		var dist := my_t.position.distance_to(tg_t.position)
		if dist >= safe_range: return BehaviorTree.Status.SUCCESS
		var away := (my_t.position - tg_t.position).normalized() * flee_speed
		var vel  := EntityManager.get_component(entity, &"Velocity") as VelocityComponent
		if vel: vel.linear = away
		return BehaviorTree.Status.RUNNING

## Patrol between waypoints stored in blackboard[&"waypoints"] (Array[Vector3]).
class Patrol extends BTNode:
	var speed        : float = 3.0
	var arrive_dist  : float = 1.5
	var _wp_index    : int   = 0
	func _init(spd: float = 3.0) -> void: speed = spd
	func reset() -> void: _wp_index = 0
	func tick(entity: int, bb: Blackboard, _delta: float) -> int:
		var wps_var : Variant = bb.get_val(&"waypoints")
		if not wps_var is Array: return BehaviorTree.Status.FAILURE
		var wps := wps_var as Array
		if wps.is_empty(): return BehaviorTree.Status.FAILURE
		_wp_index = _wp_index % wps.size()
		var wp    := wps[_wp_index] as Vector3
		var t     := EntityManager.get_component(entity, &"Transform") as TransformComponent
		if t == null: return BehaviorTree.Status.FAILURE
		if t.position.distance_to(wp) < arrive_dist:
			_wp_index = (_wp_index + 1) % wps.size()
			return BehaviorTree.Status.RUNNING
		Pathfinding.set_target(entity, wp)
		var desired := Pathfinding.get_desired_velocity(entity) * speed
		var vel := EntityManager.get_component(entity, &"Velocity") as VelocityComponent
		if vel: vel.linear = desired
		return BehaviorTree.Status.RUNNING
