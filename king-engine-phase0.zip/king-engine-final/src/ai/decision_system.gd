## DecisionSystem — ticks BehaviorTrees for all AI-tagged entities.
## Respects FrameBudget: stops ticking when frame time is exhausted,
## continues from where it left off next frame (round-robin fairness).
extends SystemBase

var _trees        : Dictionary = {}   ## entity_id → BehaviorTree
var _tick_order   : Array[int] = []   ## round-robin cursor list
var _cursor       : int        = 0    ## next index to tick
var _budget_ms    : float      = 3.0  ## max ms to spend on AI per frame

func _on_start() -> void:
	priority = 4000
	listen(&"ecs.entity_destroyed", _on_entity_destroyed)
	listen(&"ecs.entity_created",   _on_entity_created)

func _on_stop() -> void:
	unlisten(&"ecs.entity_destroyed", _on_entity_destroyed)
	unlisten(&"ecs.entity_created",   _on_entity_created)

# ── Tree registration ──────────────────────────────────────────────────────────

func register_tree(entity: int, tree: BehaviorTree) -> void:
	_trees[entity] = tree
	if entity not in _tick_order:
		_tick_order.append(entity)

func unregister(entity: int) -> void:
	_trees.erase(entity)
	_tick_order.erase(entity)
	if _cursor >= _tick_order.size():
		_cursor = 0

func get_behavior_tree(entity: int) -> BehaviorTree:
	return _trees.get(entity, null)

func get_blackboard(entity: int) -> BehaviorTree.Blackboard:
	var tree := _trees.get(entity, null) as BehaviorTree
	return tree.blackboard if tree != null else null

## Write directly into an entity's blackboard without holding a tree reference.
func set_bb(entity: int, key: StringName, value: Variant) -> void:
	var bb := get_blackboard(entity)
	if bb: bb.set_val(key, value)

func get_bb(entity: int, key: StringName, default: Variant = null) -> Variant:
	var bb := get_blackboard(entity)
	return bb.get_val(key, default) if bb else default

# ── Tick ───────────────────────────────────────────────────────────────────────

func tick(delta: float) -> void:
	if _tick_order.is_empty():
		return
	var start_us  : int   = Time.get_ticks_usec()
	var budget_us : float = _budget_ms * 1000.0
	var ticked    : int   = 0
	var count     : int   = _tick_order.size()

	## Round-robin: start from _cursor so no entity starves.
	while ticked < count:
		if _cursor >= _tick_order.size():
			_cursor = 0
		var id : int = _tick_order[_cursor]
		_cursor += 1
		ticked  += 1

		if not _trees.has(id):
			continue
		if EntityManager.has_tag(id, &"dead"):
			continue
		(_trees[id] as BehaviorTree).tick(delta)

		## Budget check every 4 entities to amortize the timer call.
		if ticked % 4 == 0:
			var elapsed_us := float(Time.get_ticks_usec() - start_us)
			if elapsed_us >= budget_us:
				break

func set_budget_ms(ms: float) -> void:
	_budget_ms = maxf(ms, 0.5)

func active_count() -> int:
	return _trees.size()

# ── Auto-register on entity creation ──────────────────────────────────────────

func _on_entity_created(data: Variant) -> void:
	if not data is Dictionary: return
	var id := int((data as Dictionary).get("entity", -1))
	if id >= 0 and EntityManager.has_tag(id, &"ai") and not _trees.has(id):
		## AISystem._init_ai will call register_tree; nothing to do here
		## unless the entity already has a tag but skipped AISystem.
		pass

func _on_entity_destroyed(data: Variant) -> void:
	if data is Dictionary:
		unregister(int((data as Dictionary).get("entity", -1)))
