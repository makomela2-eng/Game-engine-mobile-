## Pathfinding — NavigationServer3D wrapper for entity pathfinding.
##
## Each AI entity gets one NavigationAgent3D (auto-created if absent).
## Provides desired velocity, arrival detection, obstacle avoidance radius,
## and path debug drawing in debug builds.
extends Node

## Default agent properties applied on registration.
var default_speed          : float = 4.0
var default_radius         : float = 0.5
var default_height         : float = 1.8
var default_avoidance      : bool  = true
var default_max_neighbors  : int   = 8

## entity_id → { agent: NavigationAgent3D, speed: float }
var _agents : Dictionary = {}

func _ready() -> void:
	Bus.on(&"ecs.entity_destroyed", _on_entity_destroyed)

func _exit_tree() -> void:
	Bus.off(&"ecs.entity_destroyed", _on_entity_destroyed)

# ── Registration ───────────────────────────────────────────────────────────────

## Register entity for pathfinding. Auto-creates NavigationAgent3D if missing.
## Returns true on success.
func register_entity(entity: int, speed: float = -1.0) -> bool:
	if _agents.has(entity):
		return true
	var sn := EntityManager.get_component(entity, &"SceneNode") as SceneNodeComponent
	if sn == null or not is_instance_valid(sn.node):
		return false
	var agent := sn.node.get_node_or_null("NavigationAgent3D") as NavigationAgent3D
	if agent == null:
		agent = NavigationAgent3D.new()
		agent.name = "NavigationAgent3D"
		sn.node.add_child(agent)
	_configure_agent(agent)
	var effective_speed := speed if speed > 0.0 else default_speed
	_agents[entity] = {"agent": agent, "speed": effective_speed}
	## Wire velocity_computed so CharacterBody3D entities move automatically.
	if sn.node is CharacterBody3D:
		var body := sn.node as CharacterBody3D
		if not agent.velocity_computed.is_connected(_make_velocity_cb(entity, body)):
			agent.velocity_computed.connect(_make_velocity_cb(entity, body))
	return true

func _configure_agent(agent: NavigationAgent3D) -> void:
	agent.radius                   = default_radius
	agent.height                   = default_height
	agent.max_speed                = default_speed
	agent.avoidance_enabled        = default_avoidance
	agent.max_neighbors            = default_max_neighbors
	agent.path_desired_distance    = 0.5
	agent.target_desired_distance  = 0.8

func _make_velocity_cb(entity: int, body: CharacterBody3D) -> Callable:
	return func(safe_vel: Vector3) -> void:
		body.velocity = safe_vel
		body.move_and_slide()
		## Write back into VelocityComponent so ECS stays in sync.
		var vel := EntityManager.get_component(entity, &"Velocity") as VelocityComponent
		if vel: vel.linear = body.velocity

func unregister(entity: int) -> void:
	if _agents.has(entity):
		var entry := _agents[entity] as Dictionary
		var agent := entry.get("agent") as NavigationAgent3D
		if agent and is_instance_valid(agent):
			agent.queue_free()
	_agents.erase(entity)

# ── Navigation API ─────────────────────────────────────────────────────────────

func set_target(entity: int, target: Vector3) -> void:
	var agent := _get_agent(entity)
	if agent:
		agent.target_position = target

func get_next_position(entity: int) -> Vector3:
	var agent := _get_agent(entity)
	return agent.get_next_path_position() if agent else Vector3.ZERO

## Normalised desired-velocity vector (not scaled by speed — caller multiplies).
func get_desired_velocity(entity: int) -> Vector3:
	var agent := _get_agent(entity)
	if agent == null: return Vector3.ZERO
	if agent.is_navigation_finished(): return Vector3.ZERO
	var t := EntityManager.get_component(entity, &"Transform") as TransformComponent
	if t == null: return Vector3.ZERO
	var next := agent.get_next_path_position()
	var dir  := (next - t.position)
	dir.y    = 0.0
	return dir.normalized() if dir.length_squared() > 0.0001 else Vector3.ZERO

func is_navigation_finished(entity: int) -> bool:
	var agent := _get_agent(entity)
	return agent == null or agent.is_navigation_finished()

func get_distance_to_target(entity: int) -> float:
	var agent := _get_agent(entity)
	if agent == null: return INF
	var t := EntityManager.get_component(entity, &"Transform") as TransformComponent
	if t == null: return INF
	return t.position.distance_to(agent.target_position)

func set_speed(entity: int, speed: float) -> void:
	if _agents.has(entity):
		(_agents[entity] as Dictionary)["speed"] = speed
		var agent := (_agents[entity] as Dictionary).get("agent") as NavigationAgent3D
		if agent: agent.max_speed = speed

func set_avoidance(entity: int, enabled: bool) -> void:
	var agent := _get_agent(entity)
	if agent: agent.avoidance_enabled = enabled

func set_radius(entity: int, radius: float) -> void:
	var agent := _get_agent(entity)
	if agent: agent.radius = radius

## Push avoidance velocity manually (for non-CharacterBody3D entities).
func push_avoidance_velocity(entity: int) -> void:
	var agent := _get_agent(entity)
	if agent == null: return
	var vel := EntityManager.get_component(entity, &"Velocity") as VelocityComponent
	if vel == null: return
	agent.set_velocity(vel.linear)

func registered_count() -> int:
	return _agents.size()

func is_registered(entity: int) -> bool:
	return _agents.has(entity)

# ── Internal ───────────────────────────────────────────────────────────────────

func _get_agent(entity: int) -> NavigationAgent3D:
	if not _agents.has(entity): return null
	var a : Variant = (_agents[entity] as Dictionary).get("agent")
	if a is NavigationAgent3D and is_instance_valid(a as NavigationAgent3D):
		return a as NavigationAgent3D
	return null

func _on_entity_destroyed(data: Variant) -> void:
	if data is Dictionary:
		unregister(int((data as Dictionary).get("entity", -1)))
