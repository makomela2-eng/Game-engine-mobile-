## AnimationSystem — drives AnimationComponent via AnimationPlayer or AnimationTree.
##
## Prefers AnimationTree when present (richer blending, state machines).
## Falls back to AnimationPlayer for simple entities.
## Forwards animation_finished signal as ecs.animation_finished on Bus.
## Respects loop / one-shot distinction from AnimationComponent.playing.
extends SystemBase

## entity_id → Callable — stored finish callbacks to avoid signal leak.
var _finish_cbs : Dictionary = {}

func _on_start() -> void:
	priority = 6000
	listen(&"ecs.entity_destroyed", _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"ecs.entity_destroyed", _on_entity_destroyed)
	_finish_cbs.clear()

func tick(_delta: float) -> void:
	var entities := query([&"Animation", &"SceneNode"])
	for id : int in entities:
		var ac := get_c(id, &"Animation") as AnimationComponent
		var sn := get_c(id, &"SceneNode") as SceneNodeComponent
		if ac == null or sn == null or not is_instance_valid(sn.node):
			continue
		## Prefer AnimationTree if present.
		var tree := sn.node.get_node_or_null("AnimationTree") as AnimationTree
		if tree and tree.active:
			_apply_tree(id, ac, tree)
		else:
			var player := sn.node.get_node_or_null("AnimationPlayer") as AnimationPlayer
			if player:
				_apply_player(id, ac, player)

# ── AnimationPlayer path ───────────────────────────────────────────────────────

func _apply_player(entity: int, ac: AnimationComponent, player: AnimationPlayer) -> void:
	player.speed_scale = ac.speed

	## Wire finish signal once per player.
	if not _finish_cbs.has(entity):
		var cb := func(anim_name: StringName) -> void:
			ac.playing = false
			ac.elapsed = 0.0
			broadcast(&"ecs.animation_finished", entity, {"anim": anim_name})
		player.animation_finished.connect(cb)
		_finish_cbs[entity] = cb

	## Transition request.
	if ac.next_anim != &"" and ac.next_anim != ac.current_anim:
		if player.has_animation(ac.next_anim):
			if ac.blend_time > 0.0:
				player.play(ac.next_anim, ac.blend_time)
			else:
				player.play(ac.next_anim)
			ac.current_anim = ac.next_anim
			ac.next_anim    = &""
			ac.playing      = true
			broadcast(&"ecs.animation_changed", entity, {"anim": ac.current_anim})
		else:
			Log.warn("[AnimationSystem] Missing anim '%s' on e%d" % [ac.next_anim, entity])
			ac.next_anim = &""
		return

	## Start initial or restart stopped animation.
	if not player.is_playing() and ac.current_anim != &"" and ac.playing:
		if player.has_animation(ac.current_anim):
			player.play(ac.current_anim)

	## Handle loop setting.
	if player.is_playing() and player.has_animation(ac.current_anim):
		var lib := player.get_animation_library(&"")
		if lib and lib.has_animation(ac.current_anim):
			var anim_res := lib.get_animation(ac.current_anim)
			if anim_res:
				anim_res.loop_mode = Animation.LOOP_LINEAR if ac.loop else Animation.LOOP_NONE

# ── AnimationTree path ─────────────────────────────────────────────────────────

func _apply_tree(entity: int, ac: AnimationComponent, tree: AnimationTree) -> void:
	## Apply blend parameters from AnimationComponent.parameters.
	BlendTree.apply_params(entity, tree)
	## Set travel target in AnimationNodeStateMachine if present.
	if ac.next_anim != &"" and ac.next_anim != ac.current_anim:
		var playback : Variant = tree.get("parameters/playback")
		if playback is AnimationNodeStateMachinePlayback:
			var pb := playback as AnimationNodeStateMachinePlayback
			if pb.get_travel_path().is_empty() or pb.get_current_node() != ac.next_anim:
				pb.travel(ac.next_anim)
		ac.current_anim = ac.next_anim
		ac.next_anim    = &""
		broadcast(&"ecs.animation_changed", entity, {"anim": ac.current_anim})

# ── Cleanup ────────────────────────────────────────────────────────────────────

func _on_entity_destroyed(data: Variant) -> void:
	if not data is Dictionary: return
	var id := int((data as Dictionary).get("entity", -1))
	_finish_cbs.erase(id)
