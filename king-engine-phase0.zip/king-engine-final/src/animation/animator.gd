## Animator — high-level API for triggering animations on entities.
## Wraps AnimationComponent so systems don't touch it directly.
extends Node

func play(entity: int, anim: StringName, blend: float = 0.15) -> void:
	var ac := EntityManager.get_component(entity, &"Animation") as AnimationComponent
	if ac:
		ac.play(anim, blend)

func stop(entity: int) -> void:
	var ac := EntityManager.get_component(entity, &"Animation") as AnimationComponent
	if ac:
		ac.playing = false

func set_speed(entity: int, speed: float) -> void:
	var ac := EntityManager.get_component(entity, &"Animation") as AnimationComponent
	if ac:
		ac.speed = speed

func set_param(entity: int, key: StringName, value: Variant) -> void:
	var ac := EntityManager.get_component(entity, &"Animation") as AnimationComponent
	if ac:
		ac.set_param(key, value)

func current_anim(entity: int) -> StringName:
	var ac := EntityManager.get_component(entity, &"Animation") as AnimationComponent
	return ac.current_anim if ac else &""

func is_playing(entity: int) -> bool:
	var ac := EntityManager.get_component(entity, &"Animation") as AnimationComponent
	return ac.playing if ac else false
