## BlendTree — runtime blend weight manager for AnimationTree nodes.
##
## apply_params() reads AnimationComponent.parameters and maps them
## to the correct AnimationTree parameter paths using Godot 4's
## "parameters/<NodeName>/blend_amount" (1D) or
## "parameters/<NodeName>/blend_position" (2D) convention.
extends Node

## Apply all parameters from an AnimationComponent to an AnimationTree.
func apply_params(entity: int, tree: AnimationTree) -> void:
	var ac := EntityManager.get_component(entity, &"Animation") as AnimationComponent
	if ac == null or ac.parameters.is_empty():
		return
	for key in ac.parameters.keys():
		var sname  := StringName(str(key))
		var value  : Variant = ac.parameters[key]
		_apply_single(tree, sname, value)

## Set a 1D blend weight by node name.
func set_blend(tree: AnimationTree, node_name: StringName, weight: float) -> void:
	var candidates : Array[String] = [
		"parameters/%s/blend_amount" % node_name,
		"parameters/%s/add_amount"   % node_name,
	]
	for path in candidates:
		if tree.has_parameter(path):
			tree.set(path, weight)
			return
	## Direct set as fallback (e.g. TimeScale nodes).
	var direct := "parameters/%s" % node_name
	if tree.has_parameter(direct):
		tree.set(direct, weight)

## Set a 2D blend position (BlendSpace2D).
func set_blend_position(tree: AnimationTree, node_name: StringName, pos: Vector2) -> void:
	var path := "parameters/%s/blend_position" % node_name
	if tree.has_parameter(path):
		tree.set(path, pos)

## Set a 1D blend position (BlendSpace1D).
func set_blend_position_1d(tree: AnimationTree, node_name: StringName, val: float) -> void:
	var path := "parameters/%s/blend_position" % node_name
	if tree.has_parameter(path):
		tree.set(path, val)

## Trigger a OneShot node.
func trigger_oneshot(tree: AnimationTree, node_name: StringName) -> void:
	var path := "parameters/%s/request" % node_name
	if tree.has_parameter(path):
		tree.set(path, AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)

## Abort a OneShot node.
func abort_oneshot(tree: AnimationTree, node_name: StringName) -> void:
	var path := "parameters/%s/request" % node_name
	if tree.has_parameter(path):
		tree.set(path, AnimationNodeOneShot.ONE_SHOT_REQUEST_ABORT)

## Set time scale on a TimeScale node.
func set_timescale(tree: AnimationTree, node_name: StringName, scale: float) -> void:
	var path := "parameters/%s/scale" % node_name
	if tree.has_parameter(path):
		tree.set(path, scale)

## Travel to a state in a StateMachine node (defaults to root playback).
func travel(tree: AnimationTree, state_name: StringName,
		sm_node: StringName = &"StateMachine") -> void:
	var path : String = "parameters/playback" if sm_node == &"StateMachine" \
		else "parameters/%s/playback" % sm_node
	var playback : Variant = tree.get(path)
	if playback is AnimationNodeStateMachinePlayback:
		(playback as AnimationNodeStateMachinePlayback).travel(state_name)

# ── Internal dispatch ──────────────────────────────────────────────────────────

func _apply_single(tree: AnimationTree, key: StringName, value: Variant) -> void:
	if value is Vector2:
		set_blend_position(tree, key, value as Vector2)
	elif value is float or value is int:
		## Try blend_amount first, then blend_position (1D), then direct.
		var fv := float(value)
		set_blend(tree, key, fv)
	elif value is bool:
		## Some nodes use bool conditions.
		var path := "parameters/%s/condition" % key
		if tree.has_parameter(path):
			tree.set(path, value as bool)
	elif value is StringName:
		## Travel request for state machine nodes.
		travel(tree, value as StringName, key)
