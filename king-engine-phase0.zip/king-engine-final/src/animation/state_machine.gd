## AnimationStateMachine — data-driven anim state graph for an entity.
## Define states and transitions; tick() evaluates conditions each frame.
##
## Usage:
##   var sm := AnimationStateMachine.new(entity_id)
##   sm.add_state(&"idle",  &"idle")
##   sm.add_state(&"run",   &"run")
##   sm.add_transition(&"idle", &"run",  func(): return speed > 0.1)
##   sm.add_transition(&"run",  &"idle", func(): return speed <= 0.1)
##   sm.start(&"idle")
class_name AnimationStateMachine
extends RefCounted

var entity       : int
var _states      : Dictionary = {}   ## StringName → { anim: StringName }
var _transitions : Array[Dictionary] = []  ## [{ from, to, condition }]
var _current     : StringName = &""

func _init(e: int) -> void:
	entity = e

func add_state(state: StringName, anim: StringName) -> void:
	_states[state] = {"anim": anim}

func add_transition(from: StringName, to: StringName, condition: Callable) -> void:
	_transitions.append({"from": from, "to": to, "condition": condition})

func start(initial: StringName) -> void:
	_current = initial
	_enter(initial)

func tick() -> void:
	if _current == &"":
		return
	for t : Dictionary in _transitions:
		if t.from == _current and (t.condition as Callable).call():
			_transition(t.to)
			return

func _transition(to: StringName) -> void:
	_current = to
	_enter(to)

func _enter(state: StringName) -> void:
	var s := _states.get(state, {}) as Dictionary
	if s.is_empty():
		return
	var anim := StringName(str(s.get("anim", "")))
	if anim != &"":
		Animator.play(entity, anim)

func current_state() -> StringName:
	return _current
