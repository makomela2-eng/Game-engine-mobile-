## AssetCache — LRU cache with byte-budget eviction and ref-counting.
##
## Evicts by BYTES consumed, not entry count. On mobile, one 4K texture
## can be 64 MB — evicting 32 tiny assets while keeping one giant one
## leaves you right back where you started.
##
## Byte tracking: entries call store() with their estimated byte size.
## If unknown, size defaults to 128 KB (safe conservative estimate).
extends Node

const DEFAULT_ENTRY_BYTES : int = 128 * 1024   ## 128 KB fallback

var max_bytes            : int   = 256 * 1024 * 1024   ## 256 MB default
var memory_evict_pct     : float = 0.80                ## evict when above this
var evict_target_pct     : float = 0.65                ## evict down to this

var _cache      : Dictionary = {}   ## StringName → { res, bytes }
var _order      : Array[StringName] = []
var _refs       : Dictionary = {}   ## StringName → int
var _groups     : Dictionary = {}   ## StringName group → Array[StringName]
var _total_bytes: int        = 0

func _ready() -> void:
	Bus.on(&"memory_warning", _on_memory_warning)
	## Auto-configure max_bytes from device tier.
	match DeviceCap.gpu_tier:
		2: max_bytes = 512 * 1024 * 1024   ## High: 512 MB
		1: max_bytes = 256 * 1024 * 1024   ## Mid:  256 MB
		_: max_bytes = 128 * 1024 * 1024   ## Low:  128 MB
	Bus.on(&"device.quality_tier_set", _on_tier_changed)

func _exit_tree() -> void:
	Bus.off(&"memory_warning",          _on_memory_warning)
	Bus.off(&"device.quality_tier_set", _on_tier_changed)

# ── Store / retrieve ───────────────────────────────────────────────────────────

func store(id: StringName, res: Resource,
		group: StringName = &"",
		byte_size: int = -1) -> void:
	var bytes : int = byte_size if byte_size >= 0 else _estimate_bytes(res)
	if _cache.has(id):
		var old_bytes : int = int((_cache[id] as Dictionary).get("bytes", 0))
		_total_bytes -= old_bytes
		_order.erase(id)
	_cache[id]    = {"res": res, "bytes": bytes}
	_total_bytes += bytes
	_order.append(id)
	if not _refs.has(id):
		_refs[id] = 0
	if group != &"":
		if not _groups.has(group): _groups[group] = []
		var g := _groups[group] as Array
		if not g.has(id): g.append(id)
	_maybe_evict()

func get_resource(id: StringName) -> Resource:
	if not _cache.has(id): return null
	_order.erase(id)
	_order.append(id)
	return (_cache[id] as Dictionary).get("res") as Resource

func has(id: StringName) -> bool:
	return _cache.has(id)

# ── Ref-counting / pinning ─────────────────────────────────────────────────────

func retain(id: StringName) -> void:
	_refs[id] = int(_refs.get(id, 0)) + 1

func release(id: StringName) -> void:
	var count := int(_refs.get(id, 0)) - 1
	if count <= 0:
		_refs.erase(id)
		## Schedule eviction when ref reaches zero.
		if _cache.has(id):
			_evict_one(id)
	else:
		_refs[id] = count

func is_pinned(id: StringName) -> bool:
	return int(_refs.get(id, 0)) > 0

func evict(id: StringName) -> void:
	if is_pinned(id): return
	_evict_one(id)

# ── Group operations ───────────────────────────────────────────────────────────

func evict_group(group: StringName) -> void:
	if not _groups.has(group): return
	for id : StringName in (_groups[group] as Array).duplicate():
		evict(id)
	_groups.erase(group)

func retain_group(group: StringName) -> void:
	if not _groups.has(group): return
	for id : StringName in (_groups[group] as Array): retain(id)

func release_group(group: StringName) -> void:
	if not _groups.has(group): return
	for id : StringName in (_groups[group] as Array): release(id)

# ── Eviction ───────────────────────────────────────────────────────────────────

func _maybe_evict() -> void:
	var limit := int(float(max_bytes) * memory_evict_pct)
	if _total_bytes <= limit: return
	var target := int(float(max_bytes) * evict_target_pct)
	_evict_until_bytes(target)

func _evict_until_bytes(target_bytes: int) -> void:
	var i := 0
	while _total_bytes > target_bytes and i < _order.size():
		var id : StringName = _order[i]
		if not is_pinned(id):
			_evict_one(id)
		else:
			i += 1

func _evict_one(id: StringName) -> void:
	if not _cache.has(id): return
	var bytes : int = int((_cache[id] as Dictionary).get("bytes", 0))
	_total_bytes -= bytes
	_cache.erase(id)
	_order.erase(id)
	_refs.erase(id)

func _on_memory_warning(_data: Variant) -> void:
	var target := int(float(max_bytes) * evict_target_pct)
	var before := _total_bytes
	_evict_until_bytes(target)
	Log.info("[AssetCache] Memory pressure eviction: %.1f MB → %.1f MB" \
		% [float(before) / 1048576.0, float(_total_bytes) / 1048576.0])

func _on_tier_changed(data: Variant) -> void:
	if not data is Dictionary: return
	match int((data as Dictionary).get("tier", 1)):
		2: max_bytes = 512 * 1024 * 1024
		1: max_bytes = 256 * 1024 * 1024
		_: max_bytes = 128 * 1024 * 1024

# ── Byte estimation ────────────────────────────────────────────────────────────

func _estimate_bytes(res: Resource) -> int:
	if res is Texture2D:
		var t := res as Texture2D
		var w := t.get_width()
		var h := t.get_height()
		## 4 bytes per pixel (RGBA8) × mip factor ~1.33.
		return int(w * h * 4 * 1.33)
	if res is AudioStream:
		## Rough: compressed audio ~128 KB, PCM ~4 MB. Use conservative mid.
		return 512 * 1024
	if res is PackedScene:
		return 256 * 1024
	if res is Mesh:
		return 1 * 1024 * 1024
	return DEFAULT_ENTRY_BYTES

# ── Stats ──────────────────────────────────────────────────────────────────────

func clear() -> void:
	_cache.clear(); _order.clear(); _refs.clear()
	_groups.clear(); _total_bytes = 0

func size() -> int: return _cache.size()
func used_bytes() -> int: return _total_bytes
func used_mb() -> float: return float(_total_bytes) / 1048576.0
func pinned_count() -> int: return _refs.size()

func stats() -> Dictionary:
	return {
		"entries":    _cache.size(),
		"used_mb":    used_mb(),
		"max_mb":     float(max_bytes) / 1048576.0,
		"usage_pct":  float(_total_bytes) / float(max_bytes),
		"pinned":     _refs.size(),
		"groups":     _groups.size(),
	}
