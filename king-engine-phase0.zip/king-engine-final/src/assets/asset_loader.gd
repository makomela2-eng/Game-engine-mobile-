## AssetLoader — async and sync asset loading with budget, batching, and callbacks.
##
## Async loading respects a per-frame time budget so it never spikes the main thread.
## Callbacks: load_async(id, callback) calls callback(id, resource) on completion.
## Batch: load_batch(ids, on_all_done) calls on_all_done when every id is ready.
extends Node

signal asset_loaded(id: StringName, resource: Resource)
signal asset_failed(id: StringName, path: String)
signal batch_complete(group: StringName)

var poll_budget_ms : float = 1.0   ## max ms spent polling per frame

## path → { ids: Array[StringName], callbacks: Array[Callable] }
var _pending   : Dictionary = {}
## batch_group → { remaining: int, callback: Callable }
var _batches   : Dictionary = {}

func _ready() -> void:
	set_process(false)

# ── Sync load ──────────────────────────────────────────────────────────────────

func load_sync(id: StringName) -> Resource:
	var path := AssetRegistry.get_asset_path(id)
	if path.is_empty():
		Log.warn("[AssetLoader] Unknown id: %s" % id)
		return null
	if AssetCache.has(id):
		return AssetCache.get_resource(id)
	if AssetRegistry.is_loaded(id):
		var res := AssetRegistry.get_resource(id)
		if res: return res
	var res : Resource = load(path)
	if res == null:
		Log.error("[AssetLoader] sync load failed: %s" % path)
		asset_failed.emit(id, path)
		return null
	_finish_load(id, path, res)
	return res

# ── Async load ─────────────────────────────────────────────────────────────────

func load_async(id: StringName, callback: Callable = Callable()) -> void:
	var path := AssetRegistry.get_asset_path(id)
	if path.is_empty():
		Log.warn("[AssetLoader] Unknown id for async: %s" % id)
		return
	if AssetCache.has(id) or AssetRegistry.is_loaded(id):
		## Already cached — fire callback immediately.
		var res := AssetCache.get_resource(id)
		if res == null: res = AssetRegistry.get_resource(id)
		if callback.is_valid(): callback.call(id, res)
		asset_loaded.emit(id, res)
		return
	if _pending.has(path):
		var entry := _pending[path] as Dictionary
		if not (entry.ids as Array).has(id):
			(entry.ids as Array).append(id)
		if callback.is_valid():
			(entry.callbacks as Array).append({"id": id, "fn": callback})
		return
	_pending[path] = {"ids": [id], "callbacks": ([] if not callback.is_valid() \
		else [{"id": id, "fn": callback}])}
	var err := ResourceLoader.load_threaded_request(path)
	if err != OK:
		Log.error("[AssetLoader] threaded request failed: %s (%s)" % [path, error_string(err)])
		_pending.erase(path)
		asset_failed.emit(id, path)
		return
	set_process(true)

# ── Batch load ─────────────────────────────────────────────────────────────────

## Load a group of assets; on_all_done called when every id is ready.
func load_batch(ids: Array[StringName], on_all_done: Callable = Callable(),
		group: StringName = &"") -> void:
	if ids.is_empty():
		if on_all_done.is_valid(): on_all_done.call()
		return
	var batch_key := group if group != &"" \
		else StringName("batch_%d" % Time.get_ticks_msec())
	var remaining := ids.size()
	_batches[batch_key] = {"remaining": remaining, "callback": on_all_done}
	for id : StringName in ids:
		load_async(id, func(loaded_id: StringName, _res: Resource) -> void:
			_on_batch_item_done(batch_key, loaded_id))

func _on_batch_item_done(batch_key: StringName, _id: StringName) -> void:
	if not _batches.has(batch_key):
		return
	var b := _batches[batch_key] as Dictionary
	b.remaining = int(b.remaining) - 1
	if int(b.remaining) <= 0:
		var cb := b.get("callback") as Callable
		_batches.erase(batch_key)
		if cb.is_valid(): cb.call()
		batch_complete.emit(batch_key)

func cancel(id: StringName) -> bool:
	for path in _pending.keys():
		var entry := _pending[path] as Dictionary
		var ids   := entry.ids as Array
		if ids.has(id):
			ids.erase(id)
			## Remove callbacks for this id.
			var cbs := entry.callbacks as Array
			for i in range(cbs.size() - 1, -1, -1):
				if (cbs[i] as Dictionary).get("id") == id:
					cbs.remove_at(i)
			if ids.is_empty():
				_pending.erase(path)
			return true
	return false

func cancel_all() -> void:
	_pending.clear()
	_batches.clear()
	set_process(false)

# ── Poll ───────────────────────────────────────────────────────────────────────

func _process(_delta: float) -> void:
	if _pending.is_empty():
		set_process(false)
		return
	var start    := Time.get_ticks_usec()
	var budget   := poll_budget_ms * 1000.0
	var done     : Array[String] = []
	for path : String in _pending.keys():
		if float(Time.get_ticks_usec() - start) >= budget:
			break
		var status := ResourceLoader.load_threaded_get_status(path)
		match status:
			ResourceLoader.THREAD_LOAD_LOADED:
				var res := ResourceLoader.load_threaded_get(path)
				var entry := _pending[path] as Dictionary
				for id : StringName in (entry.ids as Array):
					_finish_load(id, path, res)
				for cb_entry in (entry.callbacks as Array):
					var fn := (cb_entry as Dictionary).get("fn") as Callable
					var cb_id := (cb_entry as Dictionary).get("id") as StringName
					if fn.is_valid(): fn.call(cb_id, res)
				done.append(path)
			ResourceLoader.THREAD_LOAD_FAILED, ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
				var entry := _pending[path] as Dictionary
				for id : StringName in (entry.ids as Array):
					Log.error("[AssetLoader] async failed: %s" % path)
					asset_failed.emit(id, path)
				done.append(path)
	for path : String in done:
		_pending.erase(path)

func _finish_load(id: StringName, _path: String, res: Resource) -> void:
	AssetRegistry.mark_loaded(id, res)
	AssetCache.store(id, res)
	asset_loaded.emit(id, res)

func pending_count() -> int:
	return _pending.size()

func is_pending(id: StringName) -> bool:
	for path in _pending.keys():
		if (_pending[path] as Dictionary).ids.has(id):
			return true
	return false
