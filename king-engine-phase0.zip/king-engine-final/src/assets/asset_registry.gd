## AssetRegistry — central index of all known engine assets.
## Tracks registration, load state, resource reference, and group membership.
extends Node

## id → { path, type, loaded, resource, group }
var _registry : Dictionary = {}
## group → Array[StringName] ids
var _groups   : Dictionary = {}

func register(id: StringName, path: String, type: StringName = &"Resource",
		group: StringName = &"") -> void:
	_registry[id] = {
		"path":     path,
		"type":     type,
		"loaded":   false,
		"resource": null,
		"group":    group,
	}
	if group != &"":
		if not _groups.has(group):
			_groups[group] = []
		var g := _groups[group] as Array
		if not g.has(id):
			g.append(id)

func is_registered(id: StringName) -> bool:
	return _registry.has(id)

func get_asset_path(id: StringName) -> String:
	return str((_registry.get(id, {}) as Dictionary).get("path", ""))

func get_asset_type(id: StringName) -> StringName:
	return StringName(str((_registry.get(id, {}) as Dictionary).get("type", "")))

func get_resource(id: StringName) -> Resource:
	var r : Variant = (_registry.get(id, {}) as Dictionary).get("resource", null)
	return r as Resource if r is Resource else null

func mark_loaded(id: StringName, resource: Resource) -> void:
	if not _registry.has(id): return
	var entry := _registry[id] as Dictionary
	entry["loaded"]   = true
	entry["resource"] = resource

func is_loaded(id: StringName) -> bool:
	return bool((_registry.get(id, {}) as Dictionary).get("loaded", false))

func unload(id: StringName) -> void:
	if not _registry.has(id): return
	var entry := _registry[id] as Dictionary
	entry["loaded"]   = false
	entry["resource"] = null

func get_group_ids(group: StringName) -> Array[StringName]:
	var result : Array[StringName] = []
	if not _groups.has(group): return result
	for id in (_groups[group] as Array):
		result.append(id as StringName)
	return result

func all_ids() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _registry.keys(): result.append(k)
	return result

func ids_by_type(type: StringName) -> Array[StringName]:
	var result : Array[StringName] = []
	for id in _registry.keys():
		if StringName(str((_registry[id] as Dictionary).get("type", ""))) == type:
			result.append(id)
	return result

func count() -> int:
	return _registry.size()

func loaded_count() -> int:
	var n := 0
	for id in _registry:
		if (_registry[id] as Dictionary).loaded: n += 1
	return n

func clear() -> void:
	_registry.clear()
	_groups.clear()
