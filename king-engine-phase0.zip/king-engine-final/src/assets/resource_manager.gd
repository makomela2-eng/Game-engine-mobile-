## ResourceManager — high-level API for all asset operations.
## Single entry point: register, get, preload, release, group management.
##
## Never call load() directly in game code — always go through here.
##
## Usage:
##   ResourceManager.register(&"player_mesh", "res://assets/player.mesh", &"Mesh")
##   var mesh = ResourceManager.get_resource(&"player_mesh")
##   ResourceManager.preload_group([&"player_mesh", &"player_mat"], func(): _on_ready())
extends Node

func _ready() -> void:
	## Forward AssetLoader signals on Bus for Dashboard visibility.
	AssetLoader.asset_loaded.connect(func(id: StringName, _r: Resource) -> void:
		Bus.emit(&"asset.loaded", {"id": id}))
	AssetLoader.asset_failed.connect(func(id: StringName, path: String) -> void:
		Bus.emit(&"asset.failed", {"id": id, "path": path}))
	AssetLoader.batch_complete.connect(func(group: StringName) -> void:
		Bus.emit(&"asset.batch_complete", {"group": group}))

# ── Registration ───────────────────────────────────────────────────────────────

func register(id: StringName, path: String,
		type: StringName = &"Resource",
		group: StringName = &"") -> void:
	AssetRegistry.register(id, path, type, group)

## Register a whole table at once: { id → path }
func register_table(table: Dictionary, type: StringName = &"Resource",
		group: StringName = &"") -> void:
	for id in table.keys():
		AssetRegistry.register(StringName(str(id)), str(table[id]), type, group)

# ── Retrieval ──────────────────────────────────────────────────────────────────

func get_resource(id: StringName) -> Resource:
	if AssetCache.has(id):
		return AssetCache.get_resource(id)
	if AssetRegistry.is_loaded(id):
		var res := AssetRegistry.get_resource(id)
		if res: return res
	return AssetLoader.load_sync(id)

func get_async(id: StringName, callback: Callable = Callable()) -> void:
	AssetLoader.load_async(id, callback)

## Typed convenience helpers.
func get_texture(id: StringName) -> Texture2D:
	var r := get_resource(id)
	return r as Texture2D if r is Texture2D else null

func get_audio(id: StringName) -> AudioStream:
	var r := get_resource(id)
	return r as AudioStream if r is AudioStream else null

func get_scene(id: StringName) -> PackedScene:
	var r := get_resource(id)
	return r as PackedScene if r is PackedScene else null

func get_mesh(id: StringName) -> Mesh:
	var r := get_resource(id)
	return r as Mesh if r is Mesh else null

func get_material(id: StringName) -> Material:
	var r := get_resource(id)
	return r as Material if r is Material else null

# ── Preloading ─────────────────────────────────────────────────────────────────

## Async-preload a list of ids. on_complete called when all finish.
func preload_group(ids: Array[StringName], on_complete: Callable = Callable(),
		group: StringName = &"") -> void:
	AssetLoader.load_batch(ids, on_complete, group)

## Preload all assets registered under a group tag.
func preload_registered_group(group: StringName,
		on_complete: Callable = Callable()) -> void:
	var ids := AssetRegistry.get_group_ids(group)
	if ids.is_empty():
		if on_complete.is_valid(): on_complete.call()
		return
	AssetLoader.load_batch(ids, on_complete, group)

# ── Release ────────────────────────────────────────────────────────────────────

func release(id: StringName) -> void:
	AssetCache.release(id)
	AssetCache.evict(id)

func release_group(group: StringName) -> void:
	AssetCache.release_group(group)
	AssetCache.evict_group(group)

func pin(id: StringName) -> void:
	AssetCache.retain(id)

func unpin(id: StringName) -> void:
	AssetCache.release(id)

# ── Queries ────────────────────────────────────────────────────────────────────

func is_ready(id: StringName) -> bool:
	return AssetRegistry.is_loaded(id) or AssetCache.has(id)

func is_pending(id: StringName) -> bool:
	return AssetLoader.is_pending(id)

func stats() -> Dictionary:
	return {
		"registered": AssetRegistry.count(),
		"loaded":     AssetRegistry.loaded_count(),
		"cached":     AssetCache.size(),
		"pending":    AssetLoader.pending_count(),
		"pinned":     AssetCache.pinned_count(),
	}
