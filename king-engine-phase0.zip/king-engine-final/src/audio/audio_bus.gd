## AudioBus — runtime control of Godot AudioServer buses.
## Register buses by name, set volume/effects/mute at runtime.
extends Node

const BUS_MASTER := &"Master"
const BUS_MUSIC  := &"Music"
const BUS_SFX    := &"SFX"
const BUS_UI     := &"UI"
const BUS_VOICE  := &"Voice"
const BUS_AMB    := &"Ambient"

var _volumes : Dictionary = {}  ## StringName → float (linear 0–1)

func _ready() -> void:
	for i in range(AudioServer.get_bus_count()):
		var bus_id := StringName(AudioServer.get_bus_name(i))
		_volumes[bus_id] = db_to_linear(AudioServer.get_bus_volume_db(i))

func set_volume(bus: StringName, linear: float) -> void:
	var idx := _bus_idx(bus)
	if idx < 0:
		return
	linear = clampf(linear, 0.0, 1.0)
	_volumes[bus] = linear
	AudioServer.set_bus_volume_db(idx, linear_to_db(linear))

func get_volume(bus: StringName) -> float:
	return _volumes.get(bus, 1.0)

func mute(bus: StringName, muted: bool) -> void:
	var idx := _bus_idx(bus)
	if idx >= 0:
		AudioServer.set_bus_mute(idx, muted)

func is_muted(bus: StringName) -> bool:
	var idx := _bus_idx(bus)
	return idx >= 0 and AudioServer.is_bus_mute(idx)

func solo(bus: StringName, soloed: bool) -> void:
	var idx := _bus_idx(bus)
	if idx >= 0:
		AudioServer.set_bus_solo(idx, soloed)

func fade_to(bus: StringName, target: float, duration: float) -> void:
	var tree := get_tree()
	if tree == null:
		set_volume(bus, clampf(target, 0.0, 1.0))
		return
	var tween : Tween = tree.create_tween()
	tween.tween_method(func(v: float): set_volume(bus, v),
		get_volume(bus), clampf(target, 0.0, 1.0), duration)

func _bus_idx(bus: StringName) -> int:
	return AudioServer.get_bus_index(str(bus))
