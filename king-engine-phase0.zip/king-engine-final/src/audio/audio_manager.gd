## AudioManager — central audio router.
##
## Routing:
##   audio.play        → 2D player by ID (looping music, persistent ambience)
##   audio.play_once   → fire-and-forget 2D (pooled)
##   audio.play_3d     → spatial one-shot via SoundPlayer
##   audio.stop        → stop named player
##   audio.stop_all    → stop everything
##   audio.duck        → lower bus volume for a duration then restore
##
## Pitch randomization: pass "pitch_rand" in payload to vary ±range.
## Volume randomization: pass "vol_rand" in payload.
##
## Gameplay hooks: entity_died, entity_damaged, ui_pushed wired to default cues
## (empty StringName = no cue; set via set_cue() at boot).
extends Node

# ── Cue table — set these at boot in your game's AudioBootstrap ───────────────
var _cues : Dictionary = {
	&"entity_died":    &"",
	&"entity_damaged": &"",
	&"ui_push":        &"",
	&"ui_pop":         &"",
}

var _players  : Dictionary = {}   ## StringName → AudioStreamPlayer (named/looping)
var _pool     : Array[AudioStreamPlayer] = []
var _pool_size : int = 16
var _ducked   : Dictionary = {}   ## bus StringName → original_volume

func _ready() -> void:
	_build_pool()
	Bus.on(&"audio.play",              _on_play)
	Bus.on(&"audio.play_once",         _on_play_once)
	Bus.on(&"audio.play_3d",           _on_play_3d)
	Bus.on(&"audio.stop",              _on_stop)
	Bus.on(&"audio.stop_all",          _on_stop_all)
	Bus.on(&"audio.duck",              _on_duck)
	Bus.on(&"audio.set_cue",           _on_set_cue)
	Bus.on(&"gameplay.entity_died",    _on_entity_died)
	Bus.on(&"gameplay.entity_damaged", _on_entity_damaged)
	Bus.on(&"ui_pushed",               _on_ui_pushed)
	Bus.on(&"ui_popped",               _on_ui_popped)
	Bus.on(&"app_background",          _on_background)
	Bus.on(&"app_foreground",          _on_foreground)

func _exit_tree() -> void:
	Bus.off(&"audio.play",              _on_play)
	Bus.off(&"audio.play_once",         _on_play_once)
	Bus.off(&"audio.play_3d",           _on_play_3d)
	Bus.off(&"audio.stop",              _on_stop)
	Bus.off(&"audio.stop_all",          _on_stop_all)
	Bus.off(&"audio.duck",              _on_duck)
	Bus.off(&"audio.set_cue",           _on_set_cue)
	Bus.off(&"gameplay.entity_died",    _on_entity_died)
	Bus.off(&"gameplay.entity_damaged", _on_entity_damaged)
	Bus.off(&"ui_pushed",               _on_ui_pushed)
	Bus.off(&"ui_popped",               _on_ui_popped)
	Bus.off(&"app_background",          _on_background)
	Bus.off(&"app_foreground",          _on_foreground)
	stop_all()
	for p : AudioStreamPlayer in _pool:
		if is_instance_valid(p): p.queue_free()
	for p in _players.values():
		if is_instance_valid(p as AudioStreamPlayer): (p as AudioStreamPlayer).queue_free()

# ── Pool ───────────────────────────────────────────────────────────────────────

func _build_pool() -> void:
	for i in range(_pool_size):
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool.append(p)

func _get_pool_player() -> AudioStreamPlayer:
	for p : AudioStreamPlayer in _pool:
		if not p.playing:
			return p
	## All busy — steal oldest (lowest index is longest-running in pool).
	return _pool[0]

# ── Named player (looping / music) ────────────────────────────────────────────

func play(sound_id: StringName, bus: StringName = &"SFX",
		volume_db: float = 0.0, pitch_scale: float = 1.0,
		loop: bool = false) -> void:
	if sound_id == &"": return
	var player := _get_or_create_player(sound_id)
	var res    := _load_stream(sound_id)
	if res == null: return
	player.stream      = res
	player.bus         = str(bus)
	player.volume_db   = volume_db
	player.pitch_scale = pitch_scale
	if res is AudioStreamWAV:
		(res as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD if loop \
			else AudioStreamWAV.LOOP_DISABLED
	player.play()

## Fire-and-forget from pool. Supports pitch/volume randomization.
func play_once(sound_id: StringName, bus: StringName = &"SFX",
		volume_db: float = 0.0, pitch_scale: float = 1.0,
		pitch_rand: float = 0.0, vol_rand: float = 0.0) -> void:
	if sound_id == &"": return
	var res := _load_stream(sound_id)
	if res == null: return
	var p := _get_pool_player()
	p.stream      = res
	p.bus         = str(bus)
	p.volume_db   = volume_db + randf_range(-vol_rand, vol_rand)
	p.pitch_scale = pitch_scale + randf_range(-pitch_rand, pitch_rand)
	p.play()

func stop(sound_id: StringName) -> void:
	if _players.has(sound_id):
		(_players[sound_id] as AudioStreamPlayer).stop()

func stop_all() -> void:
	for p : AudioStreamPlayer in _players.values():
		if is_instance_valid(p): p.stop()
	for p : AudioStreamPlayer in _pool:
		if is_instance_valid(p): p.stop()

## Duck a bus to `target_volume_db` for `duration` seconds then restore.
func duck(bus: StringName, target_volume_db: float, duration: float) -> void:
	var idx := AudioServer.get_bus_index(str(bus))
	if idx < 0: return
	var original := AudioServer.get_bus_volume_db(idx)
	_ducked[bus] = original
	var tree := get_tree()
	if tree == null: return
	var t : Tween = tree.create_tween()
	t.tween_method(
		func(v: float) -> void: AudioServer.set_bus_volume_db(idx, v),
		original, target_volume_db, 0.05)
	t.tween_interval(duration)
	t.tween_method(
		func(v: float) -> void: AudioServer.set_bus_volume_db(idx, v),
		target_volume_db, original, 0.3)

func set_cue(event: StringName, sound_id: StringName) -> void:
	_cues[event] = sound_id

func get_cue(event: StringName) -> StringName:
	return _cues.get(event, &"")

# ── Bus listeners ──────────────────────────────────────────────────────────────

func _on_play(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	play(StringName(str(d.get("id", ""))),
		StringName(str(d.get("bus", "SFX"))),
		float(d.get("volume_db", 0.0)),
		float(d.get("pitch_scale", 1.0)),
		bool(d.get("loop", false)))

func _on_play_once(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	play_once(
		StringName(str(d.get("id", ""))),
		StringName(str(d.get("bus", "SFX"))),
		float(d.get("volume_db", 0.0)),
		float(d.get("pitch_scale", 1.0)),
		float(d.get("pitch_rand", 0.0)),
		float(d.get("vol_rand",   0.0)))

func _on_play_3d(data: Variant) -> void:
	if not data is Dictionary: return
	var d   := data as Dictionary
	var cue := StringName(str(d.get("cue", d.get("id", ""))))
	if cue == &"": return
	var pos : Variant = d.get("position", null)
	if pos is Vector3:
		SoundPlayer.play_at(pos as Vector3, cue,
			float(d.get("volume_db", 0.0)),
			StringName(str(d.get("bus", "SFX"))))

func _on_stop(data: Variant) -> void:
	if not data is Dictionary: return
	stop(StringName(str((data as Dictionary).get("id", ""))))

func _on_stop_all(_data: Variant) -> void: stop_all()

func _on_duck(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	duck(StringName(str(d.get("bus", "Master"))),
		float(d.get("target_db", -12.0)),
		float(d.get("duration",  1.5)))

func _on_set_cue(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	set_cue(StringName(str(d.get("event", ""))), StringName(str(d.get("id", ""))))

func _on_entity_died(_data: Variant) -> void:
	var cue := get_cue(&"entity_died")
	if cue != &"": play_once(cue)

func _on_entity_damaged(_data: Variant) -> void:
	var cue := get_cue(&"entity_damaged")
	if cue != &"": play_once(cue, &"SFX", 0.0, 1.0, 0.08)

func _on_ui_pushed(_data: Variant) -> void:
	var cue := get_cue(&"ui_push")
	if cue != &"": play_once(cue, &"UI")

func _on_ui_popped(_data: Variant) -> void:
	var cue := get_cue(&"ui_pop")
	if cue != &"": play_once(cue, &"UI")

func _on_background(_data: Variant) -> void:
	## Reduce music on background; SFX pool keeps state.
	AudioBus.fade_to(&"Music", 0.1, 0.4)

func _on_foreground(_data: Variant) -> void:
	AudioBus.fade_to(&"Music", 1.0, 0.4)

# ── Internal ───────────────────────────────────────────────────────────────────

func _get_or_create_player(id: StringName) -> AudioStreamPlayer:
	if not _players.has(id):
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players[id] = p
	return _players[id] as AudioStreamPlayer

func _load_stream(sound_id: StringName) -> AudioStream:
	if not ResourceManager.has_method("get_resource"): return null
	var res : Variant = ResourceManager.get_resource(sound_id)
	if res is AudioStream: return res as AudioStream
	return null
