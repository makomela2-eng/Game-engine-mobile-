## SoundPlayer — fire-and-forget spatial audio for world-positioned one-shots.
## Use when you have a position but no entity: explosions, ambient events, etc.
##
## Attenuation model follows Godot's AudioStreamPlayer3D defaults but each
## call can override unit_size and max_db for fine control.
extends Node

var _pool      : Array[AudioStreamPlayer3D] = []
var _pool_size : int = 24   ## Larger than v12 — mobile SFX can be dense

## Default 3D audio parameters.
var default_unit_size   : float = 10.0
var default_max_distance: float = 80.0
var default_attenuation : int   = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE

func _ready() -> void:
	for i in range(_pool_size):
		var p             := AudioStreamPlayer3D.new()
		p.bus             = "SFX"
		p.unit_size       = default_unit_size
		p.max_distance    = default_max_distance
		p.attenuation_model = default_attenuation
		add_child(p)
		_pool.append(p)
	Bus.on(&"audio.play_at", _on_play_at)

func _exit_tree() -> void:
	Bus.off(&"audio.play_at", _on_play_at)

# ── API ────────────────────────────────────────────────────────────────────────

func play_at(
		position   : Vector3,
		sound_id   : StringName,
		volume_db  : float      = 0.0,
		bus        : StringName = &"SFX",
		pitch_scale: float      = 1.0,
		pitch_rand : float      = 0.0,
		unit_size  : float      = -1.0) -> void:
	var res := _load_stream(sound_id)
	if res == null: return
	var p := _get_free()
	if p == null:
		## Steal the slot that has been playing longest (index 0 in scan order).
		p = _pool[0]
		p.stop()
	p.stream          = res
	p.global_position = position
	p.volume_db       = volume_db
	p.bus             = str(bus)
	p.pitch_scale     = pitch_scale + randf_range(-pitch_rand, pitch_rand)
	if unit_size > 0.0:
		p.unit_size = unit_size
	p.play()

func play_at_node(
		node       : Node3D,
		sound_id   : StringName,
		volume_db  : float      = 0.0,
		bus        : StringName = &"SFX",
		pitch_rand : float      = 0.0) -> void:
	if not is_instance_valid(node): return
	play_at(node.global_position, sound_id, volume_db, bus, 1.0, pitch_rand)

func play_at_entity(
		entity     : int,
		sound_id   : StringName,
		volume_db  : float      = 0.0,
		bus        : StringName = &"SFX",
		pitch_rand : float      = 0.0) -> void:
	var sn := EntityManager.get_component(entity, &"SceneNode") as SceneNodeComponent
	if sn and is_instance_valid(sn.node):
		play_at(sn.node.global_position, sound_id, volume_db, bus, 1.0, pitch_rand)
	else:
		## Fallback: play without position.
		AudioManager.play_once(sound_id, bus, volume_db, 1.0, pitch_rand)

func active_count() -> int:
	var n := 0
	for p : AudioStreamPlayer3D in _pool:
		if p.playing: n += 1
	return n

# ── Bus listener ───────────────────────────────────────────────────────────────

func _on_play_at(data: Variant) -> void:
	if not data is Dictionary: return
	var d   := data as Dictionary
	var pos_var : Variant = d.get("position", null)
	var pos := pos_var as Vector3 if pos_var is Vector3 else Vector3.ZERO
	play_at(
		pos,
		StringName(str(d.get("id", ""))),
		float(d.get("volume_db",  0.0)),
		StringName(str(d.get("bus", "SFX"))),
		float(d.get("pitch_scale", 1.0)),
		float(d.get("pitch_rand",  0.0)),
		float(d.get("unit_size",  -1.0)))

# ── Internal ───────────────────────────────────────────────────────────────────

func _get_free() -> AudioStreamPlayer3D:
	for p : AudioStreamPlayer3D in _pool:
		if not p.playing: return p
	return null

func _load_stream(sound_id: StringName) -> AudioStream:
	if not ResourceManager.has_method("get_resource"): return null
	var res : Variant = ResourceManager.get_resource(sound_id)
	if res is AudioStream: return res as AudioStream
	return null
