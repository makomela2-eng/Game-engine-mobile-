## CameraController — moves and rotates the active camera based on input.
## Handles keyboard/mouse/gamepad look AND touch swipe (input.look_delta).
## Attach to any entity with a CameraComponent + InputComponent.
extends SystemBase

var mouse_sensitivity : float = 0.002
var pad_sensitivity   : float = 2.0
var _yaw   : float = 0.0
var _pitch : float = 0.0
var _pitch_min : float = -80.0
var _pitch_max : float = 80.0

## Accumulated touch-swipe delta — applied once per tick then cleared.
var _touch_yaw_acc   : float = 0.0
var _touch_pitch_acc : float = 0.0

func _on_start() -> void:
	priority = 8060
	listen(&"camera.set_sensitivity", _on_set_sensitivity)
	## input.look_delta: emitted by TouchInput on every swipe drag frame.
	## delta.x/delta.y are already in radians.
	listen(&"input.look_delta", _on_look_delta)
	## input.pinch_zoom: emitted by TouchInput on two-finger pinch.
	listen(&"input.pinch_zoom", _on_pinch_zoom)

func _on_stop() -> void:
	unlisten(&"camera.set_sensitivity", _on_set_sensitivity)
	unlisten(&"input.look_delta",       _on_look_delta)
	unlisten(&"input.pinch_zoom",       _on_pinch_zoom)

func tick(delta: float) -> void:
	var entities := query([&"Camera", &"Transform", &"Input"])
	for id : int in entities:
		var cc := get_c(id, &"Camera") as CameraComponent
		var t  := get_c(id, &"Transform") as TransformComponent
		var ic := get_c(id, &"Input") as InputComponent
		if cc == null or t == null or ic == null or not cc.is_active:
			continue
		_apply_look(t, ic, delta)
	## Clear accumulated touch delta after applying.
	_touch_yaw_acc   = 0.0
	_touch_pitch_acc = 0.0

func _apply_look(t: TransformComponent, ic: InputComponent, delta: float) -> void:
	## Gamepad / keyboard look (only non-zero on desktop or connected pad).
	_yaw   -= ic.look_dir.x * pad_sensitivity * delta
	_pitch -= ic.look_dir.y * pad_sensitivity * delta
	## Touch swipe look (accumulated from input.look_delta events this frame).
	_yaw   -= _touch_yaw_acc
	_pitch -= _touch_pitch_acc
	_pitch  = clampf(_pitch, _pitch_min, _pitch_max)
	t.rotation.y = _yaw
	t.rotation.x = _pitch

## Called from _unhandled_input for mouse look on desktop.
func apply_mouse_motion(relative: Vector2) -> void:
	_yaw   -= relative.x * mouse_sensitivity
	_pitch -= relative.y * mouse_sensitivity
	_pitch  = clampf(_pitch, _pitch_min, _pitch_max)

## input.look_delta from TouchInput — delta is in radians already.
func _on_look_delta(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	var delta_var : Variant = d.get("delta", null)
	if not delta_var is Vector2: return
	var dv := delta_var as Vector2
	_touch_yaw_acc   += dv.x
	_touch_pitch_acc += dv.y

## input.pinch_zoom from TouchInput — delta is a signed float (positive = zoom in).
func _on_pinch_zoom(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	var zoom_delta := float(d.get("delta", 0.0))
	## Relay as a camera zoom event for CameraSystem / CameraModes to handle.
	Bus.emit(&"camera.zoom", {"delta": zoom_delta})

func _on_set_sensitivity(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	mouse_sensitivity = float(d.get("mouse", mouse_sensitivity))
	pad_sensitivity   = float(d.get("pad",   pad_sensitivity))
