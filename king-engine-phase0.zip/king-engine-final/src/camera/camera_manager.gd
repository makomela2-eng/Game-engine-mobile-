## CameraManager — owns the active Camera3D and manages camera transitions.
##
## Features:
##   • Named camera registry.
##   • Smooth positional blend between cameras (interpolated over blend_time).
##   • Spring-arm follow: attach to entity tag for smooth lag following.
##   • Shake system: trauma-based screen shake with decay.
##   • Zoom control: lerps Camera3D.fov or OrthogonalSize.
extends Node

var _cameras     : Dictionary  = {}   ## StringName → Camera3D
var _active_name : StringName  = &""
var _blend_tween : Tween       = null

## Follow state
var _follow_entity  : int     = -1
var _follow_offset  : Vector3 = Vector3(0, 3, 6)
var _follow_lag     : float   = 6.0   ## higher = snappier

## Shake state
var _trauma         : float   = 0.0
var _shake_max_pos  : float   = 0.08
var _shake_max_rot  : float   = 0.025
var _trauma_decay   : float   = 1.2

## Zoom
var _target_fov     : float   = 75.0
var _fov_lerp_speed : float   = 5.0

signal camera_changed(name: StringName)

func _ready() -> void:
	set_process(true)
	Bus.on(&"camera.activate",  _on_activate)
	Bus.on(&"camera.shake",     _on_shake)
	Bus.on(&"camera.zoom",      _on_zoom)
	Bus.on(&"camera.follow",    _on_follow)

func _exit_tree() -> void:
	Bus.off(&"camera.activate", _on_activate)
	Bus.off(&"camera.shake",    _on_shake)
	Bus.off(&"camera.zoom",     _on_zoom)
	Bus.off(&"camera.follow",   _on_follow)

func _process(delta: float) -> void:
	_apply_follow(delta)
	_apply_shake(delta)
	_apply_zoom(delta)

# ── Registry ───────────────────────────────────────────────────────────────────

func register(name: StringName, camera: Camera3D) -> void:
	_cameras[name] = camera
	Log.info("[CameraManager] Registered camera: %s" % name)

func unregister(name: StringName) -> void:
	_cameras.erase(name)
	if _active_name == name: _active_name = &""

func activate(name: StringName, blend_time: float = 0.0) -> void:
	if not _cameras.has(name):
		Log.warn("[CameraManager] Unknown camera: %s" % name)
		return
	var target := _cameras[name] as Camera3D
	if blend_time > 0.0 and _active_name != &"" and _cameras.has(_active_name):
		_smooth_blend(target, blend_time)
	else:
		target.make_current()
	_active_name = name
	_target_fov  = target.fov
	Bus.emit(&"camera.changed", {"name": name})
	camera_changed.emit(name)
	Log.info("[CameraManager] Active: %s" % name)

func get_active() -> Camera3D:
	return _cameras.get(_active_name, null) as Camera3D

func get_camera(name: StringName) -> Camera3D:
	return _cameras.get(name, null) as Camera3D

func all_cameras() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _cameras.keys(): result.append(k)
	return result

# ── Smooth blend ───────────────────────────────────────────────────────────────

func _smooth_blend(target: Camera3D, duration: float) -> void:
	var source := get_active()
	if source == null or not is_instance_valid(source):
		target.make_current()
		return
	if _blend_tween: _blend_tween.kill()
	_blend_tween = get_tree().create_tween()
	## Interpolate position/rotation in world space, then make_current at midpoint.
	var src_pos := source.global_position
	var src_rot := source.global_rotation
	var tgt_pos := target.global_position
	var tgt_rot := target.global_rotation
	_blend_tween.tween_method(
		func(t: float) -> void:
			source.global_position = src_pos.lerp(tgt_pos, t)
			source.global_rotation = Vector3(
				lerp_angle(src_rot.x, tgt_rot.x, t),
				lerp_angle(src_rot.y, tgt_rot.y, t),
				lerp_angle(src_rot.z, tgt_rot.z, t)),
		0.0, 1.0, duration)
	_blend_tween.tween_callback(target.make_current)

# ── Follow ─────────────────────────────────────────────────────────────────────

func follow_entity(entity: int, offset: Vector3 = Vector3(0, 3, 6), lag: float = 6.0) -> void:
	_follow_entity = entity
	_follow_offset = offset
	_follow_lag    = lag

func stop_follow() -> void:
	_follow_entity = -1

func _apply_follow(delta: float) -> void:
	if _follow_entity < 0: return
	var cam := get_active()
	if cam == null: return
	var t := EntityManager.get_component(_follow_entity, &"Transform") as TransformComponent
	if t == null: return
	var desired := t.position + _follow_offset
	cam.global_position = cam.global_position.lerp(desired, _follow_lag * delta)
	## Emit for WorldChunkManager focal point update.
	Bus.emit(&"camera_changed", {"position": cam.global_position})

# ── Shake ──────────────────────────────────────────────────────────────────────

## Add trauma (0–1). Shake intensity = trauma^2.
func add_trauma(amount: float) -> void:
	_trauma = minf(_trauma + amount, 1.0)

func _apply_shake(delta: float) -> void:
	if _trauma <= 0.0: return
	var cam := get_active()
	if cam == null:
		_trauma = 0.0
		return
	var intensity := _trauma * _trauma
	## Noise-based offset using Time as seed approximation.
	var t := Time.get_ticks_msec() * 0.001
	cam.position += Vector3(
		sin(t * 37.0) * _shake_max_pos * intensity,
		sin(t * 53.0) * _shake_max_pos * intensity,
		0.0)
	cam.rotation += Vector3(
		sin(t * 41.0) * _shake_max_rot * intensity,
		sin(t * 29.0) * _shake_max_rot * intensity,
		0.0)
	_trauma = maxf(_trauma - _trauma_decay * delta, 0.0)

# ── Zoom ───────────────────────────────────────────────────────────────────────

func set_fov(fov: float, immediate: bool = false) -> void:
	_target_fov = clampf(fov, 10.0, 150.0)
	if immediate:
		var cam := get_active()
		if cam: cam.fov = _target_fov

func zoom_by(delta: float) -> void:
	set_fov(_target_fov - delta * 30.0)

func _apply_zoom(delta: float) -> void:
	var cam := get_active()
	if cam == null or cam.projection != Camera3D.PROJECTION_PERSPECTIVE: return
	if absf(cam.fov - _target_fov) < 0.01: return
	cam.fov = lerp(cam.fov, _target_fov, _fov_lerp_speed * delta)

# ── Bus listeners ──────────────────────────────────────────────────────────────

func _on_activate(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	activate(StringName(str(d.get("name", ""))), float(d.get("blend", 0.0)))

func _on_shake(data: Variant) -> void:
	var amount : float = 0.3
	if data is Dictionary:
		amount = float((data as Dictionary).get("amount", 0.3))
	elif data is float:
		amount = data as float
	add_trauma(amount)

func _on_zoom(data: Variant) -> void:
	if not data is Dictionary: return
	zoom_by(float((data as Dictionary).get("delta", 0.0)))

func _on_follow(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	if entity < 0:
		stop_follow()
	else:
		var offset_var : Variant = d.get("offset", Vector3(0, 3, 6))
		var offset := offset_var as Vector3 if offset_var is Vector3 else Vector3(0, 3, 6)
		follow_entity(entity, offset, float(d.get("lag", 6.0)))
