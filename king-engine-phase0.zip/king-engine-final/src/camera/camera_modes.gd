## CameraModes — preset camera behaviours applied to a Camera3D via CameraManager.
##
## Each mode configures the active camera's FOV, position offset, follow params,
## and spring-arm length. Activate via:
##   CameraModes.apply(Mode.THIRD_PERSON, {"entity": player_id})
##   CameraModes.apply(Mode.ORBIT, {"entity": target_id, "distance": 8.0})
extends Node

enum Mode {
	FIRST_PERSON,
	THIRD_PERSON,
	ORBIT,
	FIXED,
	CINEMATIC,
	TOP_DOWN,
	ISOMETRIC,
	OVER_SHOULDER,
}

## Active mode and its params for runtime query.
var current_mode   : Mode       = Mode.THIRD_PERSON
var current_params : Dictionary = {}

func apply(mode: Mode, params: Dictionary = {}) -> void:
	current_mode   = mode
	current_params = params
	var entity     := int(params.get("entity", -1))
	match mode:
		Mode.FIRST_PERSON:    _first_person(entity,  params)
		Mode.THIRD_PERSON:    _third_person(entity,  params)
		Mode.ORBIT:           _orbit(entity,         params)
		Mode.FIXED:           _fixed(params)
		Mode.CINEMATIC:       _cinematic(params)
		Mode.TOP_DOWN:        _top_down(entity,      params)
		Mode.ISOMETRIC:       _isometric(entity,     params)
		Mode.OVER_SHOULDER:   _over_shoulder(entity, params)
	Bus.emit(&"camera.mode_changed", {"mode": mode, "entity": entity})

# ── Mode implementations ───────────────────────────────────────────────────────

func _first_person(entity: int, params: Dictionary) -> void:
	CameraManager.set_fov(float(params.get("fov", 85.0)), true)
	var eye_height := float(params.get("eye_height", 1.65))
	if entity >= 0:
		CameraManager.follow_entity(entity,
			Vector3(0, eye_height, 0), float(params.get("lag", 30.0)))

func _third_person(entity: int, params: Dictionary) -> void:
	CameraManager.set_fov(float(params.get("fov", 70.0)), true)
	var dist := float(params.get("distance", 5.5))
	var h    := float(params.get("height",   2.2))
	if entity >= 0:
		CameraManager.follow_entity(entity,
			Vector3(0, h, dist), float(params.get("lag", 7.0)))

func _over_shoulder(entity: int, params: Dictionary) -> void:
	CameraManager.set_fov(float(params.get("fov", 65.0)), true)
	var dist := float(params.get("distance", 3.0))
	var h    := float(params.get("height",   1.6))
	var side := float(params.get("side",     0.5))   ## positive = right shoulder
	if entity >= 0:
		CameraManager.follow_entity(entity,
			Vector3(side, h, dist), float(params.get("lag", 10.0)))

func _orbit(entity: int, params: Dictionary) -> void:
	CameraManager.set_fov(float(params.get("fov", 60.0)), true)
	var dist := float(params.get("distance", 8.0))
	if entity >= 0:
		CameraManager.follow_entity(entity,
			Vector3(0, dist * 0.4, dist), float(params.get("lag", 5.0)))

func _top_down(entity: int, params: Dictionary) -> void:
	CameraManager.set_fov(float(params.get("fov", 50.0)), true)
	var h := float(params.get("height", 22.0))
	if entity >= 0:
		CameraManager.follow_entity(entity,
			Vector3(0, h, 0.1), float(params.get("lag", 8.0)))
	var cam := CameraManager.get_active()
	if cam:
		cam.rotation_degrees = Vector3(-89.0, 0, 0)

func _isometric(entity: int, params: Dictionary) -> void:
	var cam := CameraManager.get_active()
	if cam:
		cam.projection = Camera3D.PROJECTION_ORTHOGONAL
		cam.size       = float(params.get("ortho_size", 14.0))
		cam.rotation_degrees = Vector3(-35.264, 45.0, 0)
	if entity >= 0:
		CameraManager.follow_entity(entity,
			Vector3(12, 12, 12), float(params.get("lag", 8.0)))

func _fixed(params: Dictionary) -> void:
	CameraManager.stop_follow()
	var cam := CameraManager.get_active()
	if cam == null: return
	var pos_var : Variant = params.get("position", null)
	var rot_var : Variant = params.get("rotation", null)
	if pos_var is Vector3: cam.global_position = pos_var as Vector3
	if rot_var is Vector3: cam.rotation_degrees = rot_var as Vector3
	CameraManager.set_fov(float(params.get("fov", 75.0)), true)

func _cinematic(params: Dictionary) -> void:
	CameraManager.stop_follow()
	CameraManager.set_fov(float(params.get("fov", 35.0)), false)
	var cam := CameraManager.get_active()
	if cam == null: return
	## Optional dolly path — if start/end provided, tween position.
	var start_var : Variant = params.get("start", null)
	var end_var   : Variant = params.get("end",   null)
	var dur       := float(params.get("duration", 4.0))
	if start_var is Vector3 and end_var is Vector3:
		cam.global_position = start_var as Vector3
		var tree := get_tree()
		if tree:
			var t : Tween = tree.create_tween()
			t.tween_property(cam, "global_position", end_var as Vector3, dur)

# ── Query ──────────────────────────────────────────────────────────────────────

func is_mode(mode: Mode) -> bool:
	return current_mode == mode

func get_mode_name() -> String:
	return Mode.keys()[current_mode]
