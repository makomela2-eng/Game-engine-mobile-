## AnimationComponent — animation state for an entity.
class_name AnimationComponent
extends Component

var current_anim  : StringName = &""
var next_anim     : StringName = &""
var speed         : float      = 1.0
var loop          : bool       = true
var playing       : bool       = false
var elapsed       : float      = 0.0
var blend_time    : float      = 0.15
var parameters    : Dictionary = {}  ## Blend tree parameters

func _init(anim: StringName = &"idle") -> void:
	current_anim = anim

func component_type() -> StringName:
	return &"Animation"

func play(anim: StringName, blend: float = 0.15) -> void:
	next_anim  = anim
	blend_time = blend
	playing    = true

func set_param(key: StringName, value: Variant) -> void:
	parameters[key] = value
