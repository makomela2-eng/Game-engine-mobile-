## AudioComponent — spatial audio emitter attached to an entity.
class_name AudioComponent
extends Component

var bus          : StringName = &"Master"
var volume_db    : float      = 0.0
var pitch        : float      = 1.0
var max_distance : float      = 40.0
var attenuation  : float      = 1.0
var autoplay     : StringName = &""
var playing      : StringName = &""
var queue        : Array[StringName] = []

func _init(b: StringName = &"Master") -> void:
	bus = b

func component_type() -> StringName:
	return &"Audio"

func play(sound: StringName) -> void:
	playing = sound

func enqueue(sound: StringName) -> void:
	queue.append(sound)

func stop() -> void:
	playing = &""
	queue.clear()
