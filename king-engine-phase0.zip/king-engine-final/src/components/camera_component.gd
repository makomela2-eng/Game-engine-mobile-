## CameraComponent — marks entity as owning a camera.
class_name CameraComponent
extends Component

var fov        : float = 75.0
var near_clip  : float = 0.05
var far_clip   : float = 4000.0
var is_active  : bool  = false
var projection : int   = 0  # 0=perspective 1=orthogonal

func _init(active: bool = false) -> void:
	is_active = active

func component_type() -> StringName:
	return &"Camera"
