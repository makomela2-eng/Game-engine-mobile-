## ColliderComponent — collision shape descriptor.
class_name ColliderComponent
extends Component

enum ShapeType { BOX, SPHERE, CAPSULE, MESH }

var shape_type   : ShapeType = ShapeType.BOX
var size         : Vector3   = Vector3.ONE  # box extents or (radius, height, 0)
var offset       : Vector3   = Vector3.ZERO
var is_trigger   : bool      = false
var layer        : int       = 1
var mask         : int       = 1

func _init(shape: ShapeType = ShapeType.BOX, s: Vector3 = Vector3.ONE) -> void:
	shape_type = shape
	size       = s

func component_type() -> StringName:
	return &"Collider"
