## IdleBehaviorComponent — autonomous motion declaration for an entity.
##
## IdleBehaviorSystem reads this each tick and writes into VelocityComponent
## and/or TransformComponent directly, claiming velocity ownership as &"idle".
##
## Modes:
##   NONE    — no autonomous motion (default, system skips entity)
##   ORBIT   — circles a world-space origin point at a given radius and speed
##   DRIFT   — slow random-walk in the XZ plane; occasionally changes direction
##   BOB     — vertical sine oscillation in place (no horizontal movement)
##   SPIN    — rotates in place around the Y axis
##   PATROL  — walks between two waypoints, turning on arrival
##
## Intent / velocity ownership:
##   This component claims VelocityComponent ownership as &"idle".
##   If another system (pathfinding, AI, script) already owns the velocity,
##   IdleBehaviorSystem skips the entity that frame — it never force-overwrites.
##   Call release_ownership() on VelocityComponent to hand control back.
class_name IdleBehaviorComponent
extends Component

enum Mode { NONE, ORBIT, DRIFT, BOB, SPIN, PATROL }

## Which autonomous behaviour to run.
var mode : Mode = Mode.NONE

# ── ORBIT ──────────────────────────────────────────────────────────────────────
## World-space centre of the orbit circle.
var orbit_origin : Vector3 = Vector3.ZERO
## Distance from origin to maintain.
var orbit_radius : float   = 3.0
## Radians per second (positive = counter-clockwise from above).
var orbit_speed  : float   = 1.0
## Current angle in radians — written by the system each tick.
var orbit_angle  : float   = 0.0

# ── DRIFT ──────────────────────────────────────────────────────────────────────
## Max speed while drifting.
var drift_speed      : float = 1.2
## Seconds before the drift direction changes.
var drift_change_interval : float = 2.5
## Internal countdown — written by the system.
var _drift_timer     : float = 0.0
## Current drift direction in XZ — written by system on direction change.
var _drift_dir       : Vector2 = Vector2.ZERO

# ── BOB ────────────────────────────────────────────────────────────────────────
## Amplitude of the vertical sine wave (metres).
var bob_amplitude : float = 0.4
## Complete oscillations per second.
var bob_frequency : float = 0.8
## Phase accumulator — written by system.
var _bob_phase    : float = 0.0
## Y position at the time the component was added — set by system on first tick.
var _bob_base_y   : float = 0.0
var _bob_init     : bool  = false

# ── SPIN ───────────────────────────────────────────────────────────────────────
## Degrees per second (positive = counter-clockwise from above).
var spin_speed : float = 45.0

# ── PATROL ─────────────────────────────────────────────────────────────────────
var patrol_a     : Vector3 = Vector3(-4.0, 0.0,  0.0)
var patrol_b     : Vector3 = Vector3( 4.0, 0.0,  0.0)
## Speed in metres per second while patrolling.
var patrol_speed : float   = 2.0
## Which waypoint we're heading toward (0 = A, 1 = B) — written by system.
var _patrol_target : int   = 1

# ── Interface ──────────────────────────────────────────────────────────────────

func component_type() -> StringName:
	return &"IdleBehavior"

## Convenience constructors ────────────────────────────────────────────────────

static func make_orbit(origin: Vector3, radius: float = 3.0,
		speed: float = 1.0, start_angle: float = 0.0) -> IdleBehaviorComponent:
	var c := IdleBehaviorComponent.new()
	c.mode         = Mode.ORBIT
	c.orbit_origin = origin
	c.orbit_radius = radius
	c.orbit_speed  = speed
	c.orbit_angle  = start_angle
	return c

static func make_drift(speed: float = 1.2,
		change_interval: float = 2.5) -> IdleBehaviorComponent:
	var c := IdleBehaviorComponent.new()
	c.mode                 = Mode.DRIFT
	c.drift_speed          = speed
	c.drift_change_interval = change_interval
	return c

static func make_bob(amplitude: float = 0.4,
		frequency: float = 0.8) -> IdleBehaviorComponent:
	var c := IdleBehaviorComponent.new()
	c.mode          = Mode.BOB
	c.bob_amplitude = amplitude
	c.bob_frequency = frequency
	return c

static func make_spin(degrees_per_second: float = 45.0) -> IdleBehaviorComponent:
	var c := IdleBehaviorComponent.new()
	c.mode       = Mode.SPIN
	c.spin_speed = degrees_per_second
	return c

static func make_patrol(a: Vector3, b: Vector3,
		speed: float = 2.0) -> IdleBehaviorComponent:
	var c := IdleBehaviorComponent.new()
	c.mode         = Mode.PATROL
	c.patrol_a     = a
	c.patrol_b     = b
	c.patrol_speed = speed
	return c

## Called by the Dashboard (and anything else) when switching modes at runtime.
## Fills in sensible defaults derived from the entity's current TransformComponent
## so the transition feels intentional rather than jarring.
##
## tc  — the entity's TransformComponent at the moment of the switch.
## from_mode — the mode being left (used to preserve continuity where possible).
func apply_smart_defaults(tc: TransformComponent,
		from_mode: Mode = Mode.NONE) -> void:
	match mode:
		Mode.ORBIT:
			## Default orbit around the entity's current XZ position as origin,
			## at a radius that keeps it near where it already is.
			if orbit_origin == Vector3.ZERO and tc != null:
				orbit_origin = Vector3(tc.position.x, 0.0, tc.position.z)
			orbit_radius  = clampf(orbit_radius, 0.5, 30.0)
			orbit_speed   = clampf(orbit_speed,  -8.0, 8.0)
			## Start angle so the entity begins at its current position — no pop.
			if tc != null:
				var offset := tc.position - orbit_origin
				orbit_angle = atan2(offset.z, offset.x)
		Mode.DRIFT:
			drift_speed          = clampf(drift_speed, 0.1, 15.0)
			drift_change_interval = clampf(drift_change_interval, 0.3, 8.0)
			_drift_timer = 0.0   ## force direction pick on next tick
		Mode.BOB:
			bob_amplitude = clampf(bob_amplitude, 0.05, 4.0)
			bob_frequency = clampf(bob_frequency, 0.05, 4.0)
			_bob_init = false    ## re-capture baseline Y from current position
		Mode.SPIN:
			spin_speed = clampf(spin_speed, -360.0, 360.0)
		Mode.PATROL:
			patrol_speed = clampf(patrol_speed, 0.1, 15.0)
			## Auto-place patrol points symmetrically around current position
			## if they were never set (both at default ±4 x).
			if tc != null:
				var default_a := Vector3(-4.0, 0.0, 0.0)
				var default_b := Vector3( 4.0, 0.0, 0.0)
				if patrol_a.is_equal_approx(default_a) and patrol_b.is_equal_approx(default_b):
					var forward := Vector3(4.0, 0.0, 0.0)
					patrol_a = tc.position - forward
					patrol_b = tc.position + forward
					patrol_a.y = 0.0
					patrol_b.y = 0.0
			_patrol_target = 1   ## always start heading toward B

	## Clamp patrol points to sane Y (ground level ±10).
	if mode == Mode.PATROL:
		patrol_a.y = clampf(patrol_a.y, -10.0, 10.0)
		patrol_b.y = clampf(patrol_b.y, -10.0, 10.0)

	## Suppress unused-parameter warning — from_mode available for future
	## transition logic (e.g. carry forward angular momentum from SPIN → ORBIT).
	var _unused := from_mode

func serialize() -> Dictionary:
	return {
		"mode":         int(mode),
		"orbit_origin": {"x": orbit_origin.x, "y": orbit_origin.y, "z": orbit_origin.z},
		"orbit_radius": orbit_radius,
		"orbit_speed":  orbit_speed,
		"orbit_angle":  orbit_angle,
		"drift_speed":  drift_speed,
		"drift_change": drift_change_interval,
		"bob_amplitude": bob_amplitude,
		"bob_frequency": bob_frequency,
		"spin_speed":   spin_speed,
		"patrol_a":     {"x": patrol_a.x, "y": patrol_a.y, "z": patrol_a.z},
		"patrol_b":     {"x": patrol_b.x, "y": patrol_b.y, "z": patrol_b.z},
		"patrol_speed": patrol_speed,
	}

func serialize_delta() -> Variant:
	if mode == Mode.NONE:
		return null
	return serialize()

func deserialize(data: Dictionary) -> void:
	mode = Mode.values()[clampi(int(data.get("mode", 0)), 0, Mode.size() - 1)]
	var o : Dictionary = data.get("orbit_origin", {})
	orbit_origin  = Vector3(float(o.get("x", 0)), float(o.get("y", 0)), float(o.get("z", 0)))
	orbit_radius  = float(data.get("orbit_radius", 3.0))
	orbit_speed   = float(data.get("orbit_speed",  1.0))
	orbit_angle   = float(data.get("orbit_angle",  0.0))
	drift_speed   = float(data.get("drift_speed",  1.2))
	drift_change_interval = float(data.get("drift_change", 2.5))
	bob_amplitude = float(data.get("bob_amplitude", 0.4))
	bob_frequency = float(data.get("bob_frequency", 0.8))
	spin_speed    = float(data.get("spin_speed", 45.0))
	var a : Dictionary = data.get("patrol_a", {})
	var b : Dictionary = data.get("patrol_b", {})
	patrol_a     = Vector3(float(a.get("x",-4)), float(a.get("y",0)), float(a.get("z",0)))
	patrol_b     = Vector3(float(b.get("x", 4)), float(b.get("y",0)), float(b.get("z",0)))
	patrol_speed = float(data.get("patrol_speed", 2.0))
