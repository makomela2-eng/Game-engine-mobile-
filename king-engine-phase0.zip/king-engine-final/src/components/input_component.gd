## InputComponent — marks entity as player-controlled and stores input state.
class_name InputComponent
extends Component

var player_index  : int  = 0
var enabled       : bool = true

## Per-frame input snapshot — written by InputSystem, read by movement/ability systems.
var move_dir      : Vector2 = Vector2.ZERO
var look_dir      : Vector2 = Vector2.ZERO
var actions       : Dictionary = {}  # StringName → bool (pressed this frame)
var held          : Dictionary = {}  # StringName → float (seconds held)

func _init(idx: int = 0) -> void:
	player_index = idx

func component_type() -> StringName:
	return &"Input"

func action_pressed(action: StringName) -> bool:
	return actions.get(action, false)

func action_held(action: StringName, min_time: float = 0.0) -> bool:
	return held.get(action, 0.0) >= min_time
