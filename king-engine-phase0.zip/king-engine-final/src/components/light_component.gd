## LightComponent — point, spot, or directional light data.
class_name LightComponent
extends Component

enum LightType { POINT, SPOT, DIRECTIONAL }

var light_type  : LightType = LightType.POINT
var color       : Color     = Color.WHITE
var energy      : float     = 1.0
var range       : float     = 10.0
var spot_angle  : float     = 45.0
var cast_shadow : bool      = true
var enabled     : bool      = true

func _init(type: LightType = LightType.POINT, e: float = 1.0) -> void:
	light_type = type
	energy     = e

func component_type() -> StringName:
	return &"Light"
