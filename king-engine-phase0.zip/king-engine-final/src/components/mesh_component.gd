## MeshComponent — links an entity to a MeshInstance3D resource.
class_name MeshComponent
extends Component

var mesh_path     : String = ""
var mesh          : Mesh   = null
var material_override : Material = null
var lod_bias      : float  = 1.0

func _init(path: String = "") -> void:
	mesh_path = path

func component_type() -> StringName:
	return &"Mesh"

func is_loaded() -> bool:
	return mesh != null
