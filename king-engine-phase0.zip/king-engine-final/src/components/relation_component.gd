## RelationComponent — opts an entity into the inter-entity emergence pass.
##
## RelationSystem reads this each tick and applies secondary forces on top of
## whatever IdleBehaviorSystem already wrote into VelocityComponent.linear.
## Forces are purely additive — RelationSystem never claims velocity ownership
## and never zeroes existing velocity. It only pushes.
##
## Three independent forces, all tunable to zero:
##
##   SEPARATION   — gentle repulsion from nearby entities within sep_radius.
##                  Prevents overlapping. Scale sep_strength to taste.
##
##   ALIGNMENT    — drift entities gradually steer toward the average velocity
##                  of neighbours within align_radius. Creates flocking feel.
##                  Only meaningful when entities have Velocity components.
##
##   ORBIT PULL   — orbit entities exert a weak gravitational pull on each
##                  other's orbit origin, so clusters of orbiters drift toward
##                  a shared centre over time. Set orbit_pull_strength = 0
##                  to disable.
##
## Interaction budget:
##   Full N² neighbour scan is O(n²). RelationSystem caps neighbour checks at
##   MAX_NEIGHBOURS_PER_ENTITY per entity per tick to stay bounded. Default 12.
##   For 50 entities that's 600 comparisons/tick — negligible.
##
## To enable: add RelationComponent to any entity that has IdleBehavior.
## Entities without RelationComponent are invisible to RelationSystem.
class_name RelationComponent
extends Component

## ── Separation ────────────────────────────────────────────────────────────────
## Radius within which other relation-enabled entities repel this one.
var sep_radius   : float = 2.0
## Force magnitude of repulsion at zero distance. Falls off linearly to zero
## at sep_radius.
var sep_strength : float = 3.0

## ── Alignment ─────────────────────────────────────────────────────────────────
## Radius within which neighbours contribute to velocity alignment.
## Set to 0.0 to disable alignment entirely for this entity.
var align_radius   : float = 4.0
## How strongly this entity steers toward neighbours' average velocity.
## 0 = ignore, 1 = snap to average immediately (too strong; use ~0.05–0.2).
var align_strength : float = 0.08

## ── Orbit pull ────────────────────────────────────────────────────────────────
## How strongly nearby orbit entities pull this entity's orbit_origin toward
## theirs. 0 = no gravitational clustering.
var orbit_pull_strength : float = 0.4
## Radius within which orbit origins attract each other.
var orbit_pull_radius   : float = 8.0

## ── Budget cap ────────────────────────────────────────────────────────────────
## Max neighbours checked per tick. Prevents cost explosion at high entity counts.
var max_neighbours : int = 12

func component_type() -> StringName:
	return &"Relation"

## Convenience constructor — standard social settings.
static func make_default() -> RelationComponent:
	return RelationComponent.new()

## Convenience — separation only (no flocking, no orbit pull).
static func make_repulse(radius: float = 2.0,
		strength: float = 3.0) -> RelationComponent:
	var c := RelationComponent.new()
	c.sep_radius      = radius
	c.sep_strength    = strength
	c.align_strength  = 0.0
	c.orbit_pull_strength = 0.0
	return c

## Convenience — full flocking preset.
static func make_flock(sep_r: float = 1.8, align_r: float = 5.0) -> RelationComponent:
	var c := RelationComponent.new()
	c.sep_radius          = sep_r
	c.sep_strength        = 4.0
	c.align_radius        = align_r
	c.align_strength      = 0.12
	c.orbit_pull_strength = 0.0
	return c

func serialize() -> Dictionary:
	return {
		"sep_radius":           sep_radius,
		"sep_strength":         sep_strength,
		"align_radius":         align_radius,
		"align_strength":       align_strength,
		"orbit_pull_strength":  orbit_pull_strength,
		"orbit_pull_radius":    orbit_pull_radius,
		"max_neighbours":       max_neighbours,
	}

func serialize_delta() -> Variant:
	return serialize()

func deserialize(data: Dictionary) -> void:
	sep_radius          = float(data.get("sep_radius",          2.0))
	sep_strength        = float(data.get("sep_strength",        3.0))
	align_radius        = float(data.get("align_radius",        4.0))
	align_strength      = float(data.get("align_strength",      0.08))
	orbit_pull_strength = float(data.get("orbit_pull_strength", 0.4))
	orbit_pull_radius   = float(data.get("orbit_pull_radius",   8.0))
	max_neighbours      = int(data.get("max_neighbours",        12))
