## RenderComponent — controls visibility and render layer.
class_name RenderComponent
extends Component

var visible       : bool  = true
var layer_mask    : int   = 1
var cast_shadow   : bool  = true
var z_index       : int   = 0

func _init(vis: bool = true) -> void:
	visible = vis

func component_type() -> StringName:
	return &"Render"
