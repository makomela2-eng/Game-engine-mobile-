## RigidbodyComponent — physics body settings.
class_name RigidbodyComponent
extends Component

enum BodyMode { DYNAMIC, STATIC, KINEMATIC }

var mode          : BodyMode = BodyMode.DYNAMIC
var mass          : float    = 1.0
var gravity_scale : float    = 1.0
var linear_damp   : float    = 0.0
var angular_damp  : float    = 0.0
var freeze_rot_x  : bool     = false
var freeze_rot_y  : bool     = false
var freeze_rot_z  : bool     = false
var continuous_cd  : bool    = false  # continuous collision detection

func _init(m: BodyMode = BodyMode.DYNAMIC, mass_val: float = 1.0) -> void:
	mode = m
	mass = mass_val

func component_type() -> StringName:
	return &"Rigidbody"
