## ScriptComponent — attaches a runtime script resource to an entity.
class_name ScriptComponent
extends Component

var script_path   : String   = ""
var script_res    : Script   = null
var properties    : Dictionary = {}  ## Exported values passed to the script instance
var instance      : Object   = null  ## Live instance, managed by ScriptRuntime

func _init(path: String = "") -> void:
	script_path = path

func component_type() -> StringName:
	return &"Script"

func is_loaded() -> bool:
	return script_res != null

func set_property(key: StringName, value: Variant) -> void:
	properties[key] = value

func get_property(key: StringName, default: Variant = null) -> Variant:
	return properties.get(key, default)
