## TransformComponent — position, rotation, scale in 3D space.
class_name TransformComponent
extends Component

var position : Vector3 = Vector3.ZERO
var rotation : Vector3 = Vector3.ZERO  ## Euler degrees
var scale    : Vector3 = Vector3.ONE
var basis    : Basis   = Basis.IDENTITY

func _init(p: Vector3 = Vector3.ZERO,
		r: Vector3 = Vector3.ZERO,
		s: Vector3 = Vector3.ONE) -> void:
	position = p
	rotation = r
	scale    = s

func component_type() -> StringName:
	return &"Transform"

func get_transform3d() -> Transform3D:
	return Transform3D(
		Basis.from_euler(rotation * (PI / 180.0)) * Basis.from_scale(scale),
		position)

func set_from_node(node: Node3D) -> void:
	position = node.global_position
	rotation = node.rotation_degrees
	scale    = node.scale

func apply_to_node(node: Node3D) -> void:
	node.global_position  = position
	node.rotation_degrees = rotation
	node.scale            = scale

## Full serialization — used by EntityManager snapshot and SaveManager.
func serialize() -> Dictionary:
	return {
		"px": position.x, "py": position.y, "pz": position.z,
		"rx": rotation.x, "ry": rotation.y, "rz": rotation.z,
		"sx": scale.x,    "sy": scale.y,    "sz": scale.z,
	}

## Delta serialization — returns null if position is zero (default).
func serialize_delta() -> Variant:
	if position.is_zero_approx() and rotation.is_zero_approx() \
			and scale.is_equal_approx(Vector3.ONE):
		return null
	return serialize()

func deserialize(data: Dictionary) -> void:
	position = Vector3(float(data.get("px", 0.0)),
		float(data.get("py", 0.0)), float(data.get("pz", 0.0)))
	rotation = Vector3(float(data.get("rx", 0.0)),
		float(data.get("ry", 0.0)), float(data.get("rz", 0.0)))
	scale    = Vector3(float(data.get("sx", 1.0)),
		float(data.get("sy", 1.0)), float(data.get("sz", 1.0)))
