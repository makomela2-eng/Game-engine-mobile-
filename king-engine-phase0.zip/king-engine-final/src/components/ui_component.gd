## UIComponent — links an entity to a UI widget/screen.
class_name UIComponent
extends Component

var widget_path   : String   = ""
var widget_scene  : PackedScene = null
var widget_node   : Control  = null
var screen_space  : bool     = true   # true=HUD, false=world-space billboard
var offset        : Vector2  = Vector2.ZERO
var visible       : bool     = true
var data          : Dictionary = {}   ## Reactive data bound to the widget

func _init(path: String = "") -> void:
	widget_path = path

func component_type() -> StringName:
	return &"UI"

func set_data(key: StringName, value: Variant) -> void:
	data[key] = value
	Bus.emit(&"ui.data_changed", {"widget": widget_node, "key": key, "value": value})

func get_data(key: StringName, default: Variant = null) -> Variant:
	return data.get(key, default)
