## VelocityComponent — linear and angular velocity with explicit ownership.
##
## PHASE 0 FIX: Ownership model hardened.
##
## Changes from old version:
##   - frame_acquired: int tracks the frame ownership was claimed.
##   - claim() now records frame_acquired via SystemScheduler.frame_index.
##   - release_ownership() is clearly documented as MANDATORY on mode/state change.
##   - Debug-only stale-ownership warning: if ownership is held for more than
##     MAX_OWN_FRAMES consecutive frames, a push_warning fires. This is NOT
##     an auto-eviction — it is a debuggability aid only. The system that
##     claimed ownership remains in control until it explicitly releases.
##
## Mutation model:
##   Value writes (linear, angular) → direct, enforced by claim().
##   Structural changes (add/remove component) → CommandBuffer.
##
## Valid owner tokens (convention):
##   &"physics"      PhysicsSystem
##   &"pathfinding"  Pathfinding / NavigationAgent
##   &"ai"           DecisionSystem / BehaviorTree
##   &"idle"         IdleBehaviorSystem
##   &"script"       game-specific script
##   &""             unclaimed — any system may take it
class_name VelocityComponent
extends Component

var linear  : Vector3    = Vector3.ZERO
var angular : Vector3    = Vector3.ZERO
var damping : float      = 0.0

## Current owner. &"" = unclaimed.
var owner          : StringName = &""
## Frame on which ownership was last claimed. -1 = never claimed this session.
var frame_acquired : int        = -1

## Debug-only: warn if ownership is held longer than this many frames.
## NOT an eviction threshold. Set 0 to disable the warning.
const MAX_OWN_FRAMES : int = 300   ## ~5 sec at 60fps

func _init(lin: Vector3 = Vector3.ZERO,
		ang: Vector3 = Vector3.ZERO) -> void:
	linear  = lin
	angular = ang

func component_type() -> StringName:
	return &"Velocity"

# ── Ownership API ──────────────────────────────────────────────────────────────

## Attempt to claim velocity ownership for this frame.
## Returns true if claim succeeded (either unclaimed, or already owned by caller).
## Returns false if a DIFFERENT system owns it — caller must skip this entity.
##
## current_frame: pass SystemScheduler.frame_index.
func claim(new_owner: StringName, current_frame: int = -1) -> bool:
	if owner != &"" and owner != new_owner:
		return false
	owner          = new_owner
	frame_acquired = current_frame if current_frame >= 0 else frame_acquired
	## Debug stale-ownership check.
	if OS.is_debug_build() and MAX_OWN_FRAMES > 0 and frame_acquired >= 0 \
			and current_frame >= 0 \
			and (current_frame - frame_acquired) > MAX_OWN_FRAMES:
		push_warning(
			"[VelocityComponent] Ownership held by '%s' for %d frames " \
			% [str(owner), current_frame - frame_acquired] +
			"(threshold %d). Did you forget release_ownership()?" % MAX_OWN_FRAMES
		)
	return true

## Release ownership. MUST be called by the owning system when it relinquishes
## control — on mode change, on entity state transition, or when the system
## stops driving this entity. Failing to call this will silently block other
## systems from writing velocity.
func release_ownership() -> void:
	owner          = &""
	frame_acquired = -1

func is_owned_by(system: StringName) -> bool:
	return owner == system

func is_claimed() -> bool:
	return owner != &""

# ── Velocity helpers ───────────────────────────────────────────────────────────

func speed() -> float:
	return linear.length()

func is_moving() -> bool:
	return linear.length_squared() > 0.0001

func apply_impulse(impulse: Vector3) -> void:
	linear += impulse

# ── Serialization ──────────────────────────────────────────────────────────────

func serialize() -> Dictionary:
	return {
		"lx": linear.x,  "ly": linear.y,  "lz": linear.z,
		"ax": angular.x, "ay": angular.y, "az": angular.z,
		"damping": damping,
		"owner":   str(owner),
	}

## Skip replication when at rest — saves bandwidth.
func serialize_delta() -> Variant:
	if linear.is_zero_approx() and angular.is_zero_approx():
		return null
	return serialize()

func deserialize(data: Dictionary) -> void:
	linear  = Vector3(float(data.get("lx", 0.0)),
		float(data.get("ly", 0.0)), float(data.get("lz", 0.0)))
	angular = Vector3(float(data.get("ax", 0.0)),
		float(data.get("ay", 0.0)), float(data.get("az", 0.0)))
	damping = float(data.get("damping", 0.0))
	## Do NOT restore owner on deserialize — ownership is a runtime contract,
	## not a persistent state. Restored entities start unclaimed.
	owner          = &""
	frame_acquired = -1
