## Bus — decoupled event bus. Zero deps.
## Debug mode: set KING_BUS_DEBUG=true in project settings (or via Cfg) to
## get a push_warning whenever an event fires with no registered listeners.
## This catches silent-failure cases where a system emits before its listener
## subscribed, or where an unlistened event name is a typo.
extends Node

var _listeners : Dictionary = {}

## Set true to warn on unlistened emit. Enable in your boot/debug cfg.
var debug_warn_no_listeners : bool = false

func _ready() -> void:
	debug_warn_no_listeners = ProjectSettings.get_setting(
		"king/bus/warn_no_listeners", false)

func on(event: StringName, fn: Callable) -> void:
	if not fn.is_valid():
		return
	if not _listeners.has(event):
		_listeners[event] = []
	var arr: Array = _listeners[event]
	if not arr.has(fn):
		arr.append(fn)
		_listeners[event] = arr

func off(event: StringName, fn: Callable) -> void:
	if _listeners.has(event):
		(_listeners[event] as Array).erase(fn)

func emit(event: StringName, data: Variant = null) -> void:
	if not _listeners.has(event) or (_listeners[event] as Array).is_empty():
		if debug_warn_no_listeners:
			push_warning("[Bus] emit '%s' — no listeners registered" % event)
		return
	for fn : Callable in (_listeners[event] as Array).duplicate():
		if fn.is_valid():
			fn.call(data)

func emit_deferred(event: StringName, data: Variant = null) -> void:
	call_deferred("emit", event, data)

func clear(event: StringName = &"") -> void:
	if event == &"":
		_listeners.clear()
	else:
		_listeners.erase(event)

func has_listeners(event: StringName) -> bool:
	return _listeners.has(event) and not (_listeners[event] as Array).is_empty()

## How many callables are listening to this event right now.
## Useful in unit tests: assert Bus.listener_count(&"ui.open") > 0
func listener_count(event: StringName) -> int:
	if not _listeners.has(event):
		return 0
	return (_listeners[event] as Array).size()
