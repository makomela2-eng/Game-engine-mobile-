## BusEvents — typed payload classes for every engine Bus event.
##
## Pattern: emit typed objects, receive with `is` + `as`.
## Dictionary payloads fail silently on typos; typed classes fail loudly at cast.
##
## Adding new events:
##   1. Add class below in the relevant section.
##   2. Replace Dictionary emit sites with the typed class.
##   3. Update receivers to cast.
class_name BusEvents

# ── ECS ────────────────────────────────────────────────────────────────────────

class EntityMoved:
	var entity   : int;  var position : Vector3;  var delta : float
	func _init(e: int, p: Vector3, d: float) -> void:
		entity = e; position = p; delta = d

class EntityStopped:
	var entity : int
	func _init(e: int) -> void: entity = e

class EntityDestroyed:
	var entity : int
	func _init(e: int) -> void: entity = e

class EntityTagged:
	var entity : int;  var tag : StringName;  var added : bool
	func _init(e: int, t: StringName, a: bool) -> void:
		entity = e; tag = t; added = a

class ComponentChanged:
	var entity : int;  var component : StringName
	func _init(e: int, c: StringName) -> void: entity = e; component = c

class DamageDealt:
	var entity : int;  var amount : float;  var source : int
	func _init(e: int, amt: float, src: int = -1) -> void:
		entity = e; amount = amt; source = src

class EntityDied:
	var entity : int;  var source : int
	func _init(e: int, src: int = -1) -> void: entity = e; source = src

class EntityHealed:
	var entity : int;  var amount : float;  var hp : float;  var max_hp : float
	func _init(e: int, amt: float, h: float, mh: float) -> void:
		entity = e; amount = amt; hp = h; max_hp = mh

class AnimationChanged:
	var entity : int;  var anim : StringName
	func _init(e: int, a: StringName) -> void: entity = e; anim = a

class AnimationFinished:
	var entity : int;  var anim : StringName
	func _init(e: int, a: StringName) -> void: entity = e; anim = a

class CollisionEntered:
	var entity_a : int;  var entity_b : int
	func _init(a: int, b: int) -> void: entity_a = a; entity_b = b

class CollisionExited:
	var entity_a : int;  var entity_b : int
	func _init(a: int, b: int) -> void: entity_a = a; entity_b = b

# ── Network ────────────────────────────────────────────────────────────────────

class NetworkQuality:
	var quality : int;  var ping_ms : int
	func _init(q: int, p: int) -> void: quality = q; ping_ms = p

class NetworkReconnectAttempt:
	var attempt : int;  var session_id : int
	func _init(a: int, s: int) -> void: attempt = a; session_id = s

class PeerConnected:
	var peer_id : int
	func _init(p: int) -> void: peer_id = p

class PeerDisconnected:
	var peer_id : int
	func _init(p: int) -> void: peer_id = p

# ── UI ─────────────────────────────────────────────────────────────────────────

class UIPushed:
	var id : StringName
	func _init(i: StringName) -> void: id = i

class UIPopped:
	var id : StringName
	func _init(i: StringName) -> void: id = i

# ── Rendering ──────────────────────────────────────────────────────────────────

class RenderScaleChanged:
	var scale : float
	func _init(s: float) -> void: scale = s

class QualityTierChanged:
	var tier : int;  var fps : int
	func _init(t: int, f: int) -> void: tier = t; fps = f

# ── Audio ──────────────────────────────────────────────────────────────────────

class MusicStateChanged:
	var state : StringName
	func _init(s: StringName) -> void: state = s

class AudioDucked:
	var bus : StringName;  var target_db : float;  var duration : float
	func _init(b: StringName, t: float, d: float) -> void:
		bus = b; target_db = t; duration = d

# ── Camera ─────────────────────────────────────────────────────────────────────

class CameraShake:
	var amount : float
	func _init(a: float) -> void: amount = a

class CameraZoom:
	var delta : float
	func _init(d: float) -> void: delta = d

class CameraModeChanged:
	var mode : int;  var entity : int
	func _init(m: int, e: int = -1) -> void: mode = m; entity = e

# ── AI ─────────────────────────────────────────────────────────────────────────

class AITargetAcquired:
	var entity : int;  var target : int
	func _init(e: int, t: int) -> void: entity = e; target = t

class AITargetLost:
	var entity : int
	func _init(e: int) -> void: entity = e

# ── Physics ────────────────────────────────────────────────────────────────────

class GravityChanged:
	var gravity : Vector3
	func _init(g: Vector3) -> void: gravity = g

# ── Scene / Save ───────────────────────────────────────────────────────────────

class SceneSaved:
	var slot : int;  var path : String;  var version : int
	func _init(sl: int, p: String, v: int) -> void:
		slot = sl; path = p; version = v

class SceneLoaded:
	var version : int
	func _init(v: int) -> void: version = v

class GameSaved:
	var slot : int
	func _init(s: int) -> void: slot = s

class GameLoaded:
	var slot : int
	func _init(s: int) -> void: slot = s

# ── Platform ───────────────────────────────────────────────────────────────────

class ThermalStateChanged:
	var state : int   ## 0=normal 1=warm 2=hot 3=critical
	func _init(s: int) -> void: state = s

class BatteryLow:
	var pct : int
	func _init(p: int) -> void: pct = p

class SafeAreaUpdated:
	var top : float;  var bottom : float;  var left : float;  var right : float
	func _init(t: float, b: float, l: float, r: float) -> void:
		top = t; bottom = b; left = l; right = r

# ── Asset ──────────────────────────────────────────────────────────────────────

class AssetLoaded:
	var id : StringName
	func _init(i: StringName) -> void: id = i

class AssetBatchComplete:
	var group : StringName
	func _init(g: StringName) -> void: group = g

# ── Editor ─────────────────────────────────────────────────────────────────────

class UndoHistoryChanged:
	var index : int;  var size : int
	func _init(i: int, s: int) -> void: index = i; size = s

class EditorAction:
	var label : String
	func _init(l: String) -> void: label = l

# ── Prefab ─────────────────────────────────────────────────────────────────────

class PrefabSaved:
	var prefab_name : String;  var path : String
	func _init(n: String, p: String) -> void: prefab_name = n; path = p

class PrefabSpawned:
	var prefab_name : String
	func _init(n: String) -> void: prefab_name = n

class PrefabDeleted:
	var prefab_name : String
	func _init(n: String) -> void: prefab_name = n

# ── Validation ─────────────────────────────────────────────────────────────────

class SceneValidated:
	var issues : Array;  var errors : int;  var warnings : int
	func _init(iss: Array, err: int, wrn: int) -> void:
		issues = iss; errors = err; warnings = wrn
