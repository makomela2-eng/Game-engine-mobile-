## Cfg — persistent typed config store.
##
## Sections and keys map to a nested Dictionary saved as ConfigFile.
## Typed getters prevent silent type coercion bugs across config consumers.
## export_all() / import_all() used by SaveLoadManager for save-slot embedding.
## Migration hooks: register_migration(from_version, fn) runs on load when the
## saved version is lower than CURRENT_VERSION.
extends Node

const SAVE_PATH      := "user://king_cfg.cfg"
const CURRENT_VERSION := 1

var _data     : Dictionary = {}
var _dirty    : bool       = false
var _version  : int        = 0
var _migrations : Array[Dictionary] = []  ## { version: int, fn: Callable }

func _ready() -> void:
	_load()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_EXIT_TREE:
		_save()

# ── Typed getters ──────────────────────────────────────────────────────────────

func get_val(section: String, key: String, default: Variant = null) -> Variant:
	var sec : Variant = _data.get(section)
	if sec is Dictionary:
		return (sec as Dictionary).get(key, default)
	return default

func get_string(section: String, key: String, default: String = "") -> String:
	return str(get_val(section, key, default))

func get_int(section: String, key: String, default: int = 0) -> int:
	return int(get_val(section, key, default))

func get_float(section: String, key: String, default: float = 0.0) -> float:
	return float(get_val(section, key, default))

func get_bool(section: String, key: String, default: bool = false) -> bool:
	var v : Variant = get_val(section, key, default)
	if v is bool: return v as bool
	if v is int:  return int(v) != 0
	return default

func get_vec2(section: String, key: String, default: Vector2 = Vector2.ZERO) -> Vector2:
	var v : Variant = get_val(section, key, null)
	if v is Vector2: return v as Vector2
	return default

# ── Setters ────────────────────────────────────────────────────────────────────

func set_val(section: String, key: String, value: Variant) -> void:
	if not _data.has(section):
		_data[section] = {}
	(_data[section] as Dictionary)[key] = value
	_dirty = true

func has(section: String, key: String = "") -> bool:
	if not _data.has(section): return false
	if key.is_empty(): return true
	return (_data[section] as Dictionary).has(key)

func erase(section: String, key: String = "") -> void:
	if not _data.has(section): return
	if key.is_empty():
		_data.erase(section)
	else:
		(_data[section] as Dictionary).erase(key)
	_dirty = true

# ── Migration ──────────────────────────────────────────────────────────────────

## Register a migration function to run when loading a file at `from_version`.
## fn receives the raw _data Dictionary and should return the mutated version.
func register_migration(from_version: int, fn: Callable) -> void:
	_migrations.append({"version": from_version, "fn": fn})

func _run_migrations() -> void:
	for m : Dictionary in _migrations:
		if int(m.get("version", -1)) == _version:
			var fn := m.get("fn") as Callable
			if fn.is_valid():
				fn.call(_data)
			_version += 1
			_dirty = true

# ── Export / import ────────────────────────────────────────────────────────────

func export_all() -> Dictionary:
	var result : Dictionary = {"_version": _version}
	for sec in _data.keys():
		result[str(sec)] = (_data[sec] as Dictionary).duplicate(true)
	return result

func import_all(data: Dictionary) -> void:
	for key in data.keys():
		if str(key).begins_with("_"): continue
		_data[str(key)] = (data[key] as Dictionary).duplicate(true)
	_dirty = true

# ── Persistence ────────────────────────────────────────────────────────────────

func _load() -> void:
	if not FileAccess.file_exists(SAVE_PATH): return
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK: return
	_version = int(cfg.get_value("_meta", "version", 0))
	for sec in cfg.get_sections():
		if sec == "_meta": continue
		_data[sec] = {}
		for key in cfg.get_section_keys(sec):
			(_data[sec] as Dictionary)[key] = cfg.get_value(sec, key)
	_run_migrations()
	Log.info("[Cfg] loaded (version %d)" % _version)

func _save() -> void:
	if not _dirty: return
	var cfg := ConfigFile.new()
	cfg.set_value("_meta", "version", CURRENT_VERSION)
	for sec in _data.keys():
		for key in (_data[sec] as Dictionary).keys():
			cfg.set_value(str(sec), str(key), (_data[sec] as Dictionary)[key])
	if cfg.save(SAVE_PATH) == OK:
		_dirty = false
	else:
		Log.warn("[Cfg] failed to save")

## Force immediate save (e.g. before app_quit).
func force_save() -> void:
	_dirty = true
	_save()
