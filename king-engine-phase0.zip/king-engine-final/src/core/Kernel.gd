## Kernel — device/platform info. Zero deps.
extends Node

var platform  : String = ""
var is_mobile : bool   = false
var is_debug  : bool   = false

func _ready() -> void:
	platform  = OS.get_name()
	is_mobile = platform in ["Android", "iOS"]
	is_debug  = OS.is_debug_build()
	Log.info("KING Kernel — platform: %s  mobile: %s  debug: %s" % [platform, is_mobile, is_debug])
