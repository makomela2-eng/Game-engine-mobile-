## Log — structured logger with rate-limiting, file output, and context fields.
##
## Always the first autoload — zero deps.
##
## Rate-limiting: identical messages within rate_limit_window_sec are collapsed
## and counted rather than spamming output. Useful for per-frame warnings.
##
## File logging: set log_to_file = true before _ready() via project settings,
## or call Log.enable_file_log(path) at runtime.
##
## Context fields: Log.push_context({"system": "MovementSystem"}) adds fields
## to all subsequent messages from that scope. pop_context() removes them.
extends Node

enum Level { DEBUG = 0, INFO = 1, WARN = 2, ERROR = 3 }

var min_level           : Level  = Level.INFO
var log_to_file         : bool   = false
var rate_limit_window_sec : float = 1.0   ## collapse identical msgs within window
var max_log_size_kb     : int    = 4096   ## rotate file at this size

## Internal
var _file          : FileAccess  = null
var _file_path     : String      = ""
var _rate_table    : Dictionary  = {}   ## msg_hash → { count, last_time }
var _context_stack : Array[Dictionary] = []

func _ready() -> void:
	min_level   = Level.DEBUG if OS.is_debug_build() else Level.INFO
	log_to_file = ProjectSettings.get_setting("king/log/to_file", false)
	if log_to_file:
		var path : String = str(ProjectSettings.get_setting(
			"king/log/file_path", "user://king_log.txt"))
		enable_file_log(path)
	Bus.on(&"app_quit", func(_d: Variant) -> void: _close_file())

func _exit_tree() -> void:
	_close_file()

# ── Public API ─────────────────────────────────────────────────────────────────

func debug(msg: String, ctx: Dictionary = {}) -> void: _emit(Level.DEBUG, msg, ctx)
func info (msg: String, ctx: Dictionary = {}) -> void: _emit(Level.INFO,  msg, ctx)
func warn (msg: String, ctx: Dictionary = {}) -> void: _emit(Level.WARN,  msg, ctx)
func error(msg: String, ctx: Dictionary = {}) -> void: _emit(Level.ERROR, msg, ctx)

## Push a context dict onto the stack. All subsequent Log calls inherit these fields.
func push_context(ctx: Dictionary) -> void:
	_context_stack.append(ctx)

## Pop the most recent context.
func pop_context() -> void:
	if not _context_stack.is_empty():
		_context_stack.pop_back()

## Enable or rotate file log.
func enable_file_log(path: String) -> void:
	_close_file()
	_file_path = path
	_file = FileAccess.open(path, FileAccess.WRITE)
	if _file == null:
		push_warning("[Log] Cannot open log file: %s" % path)
	else:
		_file.store_line("=== KING Engine Log — %s ===" \
			% Time.get_datetime_string_from_system())

func set_level(level: Level) -> void:
	min_level = level

# ── Internal ───────────────────────────────────────────────────────────────────

func _emit(lvl: Level, msg: String, extra_ctx: Dictionary) -> void:
	if lvl < min_level:
		return

	## Rate-limit: collapse duplicate messages within the window.
	var key  := "%d|%s" % [lvl, msg]
	var hash_key := key.hash()
	var now  := Time.get_ticks_msec() * 0.001
	if _rate_table.has(hash_key):
		var entry := _rate_table[hash_key] as Dictionary
		if float(entry.get("last_time", 0.0)) + rate_limit_window_sec > now:
			entry["count"] = int(entry.get("count", 1)) + 1
			return
		else:
			var count := int(entry.get("count", 1))
			if count > 1:
				_write(lvl, "%s [×%d]" % [msg, count], extra_ctx)
			_rate_table.erase(hash_key)
	_rate_table[hash_key] = {"last_time": now, "count": 1}

	_write(lvl, msg, extra_ctx)

func _write(lvl: Level, msg: String, extra_ctx: Dictionary) -> void:
	var prefixes : Array[String] = ["[DBG]", "[INF]", "[WRN]", "[ERR]"]
	var prefix   : String = prefixes[lvl]

	## Build context suffix from stack + call-site ctx.
	var ctx : Dictionary = {}
	for frame in _context_stack:
		for k in (frame as Dictionary).keys():
			ctx[k] = (frame as Dictionary)[k]
	for k in extra_ctx.keys():
		ctx[k] = extra_ctx[k]
	var ctx_str : String = ""
	if not ctx.is_empty():
		var parts : Array[String] = []
		for k in ctx.keys():
			parts.append("%s=%s" % [k, str(ctx[k])])
		ctx_str = "  {%s}" % ", ".join(parts)

	var line : String = "%s %s%s" % [prefix, msg, ctx_str]
	print(line)

	if _file != null:
		_file.store_line("[%s] %s" % [Time.get_time_string_from_system(), line])
		## Rotate if over size limit.
		if _file.get_position() > max_log_size_kb * 1024:
			_rotate_file()

	if is_instance_valid(Bus):
		Bus.emit(&"log_entry", {"level": lvl, "msg": msg, "ctx": ctx})

func _rotate_file() -> void:
	_close_file()
	## Rename old file.
	var backup := _file_path.replace(".txt", "_prev.txt")
	if FileAccess.file_exists(backup):
		DirAccess.remove_absolute(backup)
	DirAccess.rename_absolute(_file_path, backup)
	_file = FileAccess.open(_file_path, FileAccess.WRITE)

func _close_file() -> void:
	if _file != null:
		_file.close()
		_file = null
