## SaveDir — ensures save directory exists, provides safe paths.
extends Node
const BASE := "user://save/"
func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(BASE)
func path(filename: String) -> String: return BASE + filename
func exists(filename: String) -> bool: return FileAccess.file_exists(path(filename))
func delete(filename: String) -> void:
	if exists(filename): DirAccess.remove_absolute(path(filename))
