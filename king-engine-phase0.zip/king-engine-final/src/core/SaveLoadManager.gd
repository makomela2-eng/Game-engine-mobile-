## SaveLoadManager — unified save/load for both data dicts and scene snapshots.
##
## Data API (used by tests and game logic):
##   save(slot, data)       → writes dict to user://saves/slot_N.json
##   load_slot(slot)        → returns dict or {}
##   slot_exists(slot)      → bool
##   slot_info(slot)        → { slot, empty, timestamp, version }
##   delete_slot(slot)      → removes file
##
## Scene API (used by Dashboard / WorldManager):
##   save_scene(slot)       → snapshots scene via SceneSession
##   load_scene(slot)       → restores scene via SceneSession
##
## Bus API:
##   listens: save.requested, save.load_requested, app_background, app_quit
##   emits:   game_saved, game_loaded, save_deleted, autosave_triggered
extends Node

const SAVE_VERSION      := 1
const AUTOSAVE_INTERVAL := 300.0

func _ready() -> void:
	Bus.on(&"save.requested",      _on_save_requested)
	Bus.on(&"save.load_requested", _on_load_requested)
	Bus.on(&"app_background",      _on_background)
	Bus.on(&"app_quit",            _on_quit)
	TaskScheduler.schedule(&"autosave", AUTOSAVE_INTERVAL, _autosave)

func _exit_tree() -> void:
	Bus.off(&"save.requested",      _on_save_requested)
	Bus.off(&"save.load_requested", _on_load_requested)
	Bus.off(&"app_background",      _on_background)
	Bus.off(&"app_quit",            _on_quit)
	TaskScheduler.unschedule(&"autosave")

# ── Data API ──────────────────────────────────────────────────────────────────

func save(slot: int, data: Dictionary = {}) -> bool:
	var path := _slot_path(slot)
	var payload : Dictionary = data.duplicate()
	payload["_version"]   = SAVE_VERSION
	payload["_timestamp"] = Time.get_datetime_string_from_system()
	var f := FileAccess.open(path, FileAccess.WRITE)
	if not f:
		Log.error("[SaveLoadManager] cannot write slot %d" % slot)
		return false
	f.store_string(JSON.stringify(payload, "\t"))
	f.close()
	Bus.emit(&"game_saved", {"slot": slot})
	Log.info("[SaveLoadManager] saved slot %d" % slot)
	return true

func load_slot(slot: int) -> Dictionary:
	var path := _slot_path(slot)
	if not FileAccess.file_exists(path):
		return {}
	var text := FileAccess.get_file_as_string(path)
	if text.is_empty():
		return {}
	var parsed : Variant = JSON.parse_string(text)
	if not parsed is Dictionary:
		return {}
	return parsed as Dictionary

func slot_exists(slot: int) -> bool:
	return FileAccess.file_exists(_slot_path(slot))

func slot_info(slot: int) -> Dictionary:
	if not slot_exists(slot):
		return {"slot": slot, "empty": true}
	var data := load_slot(slot)
	return {
		"slot":      slot,
		"empty":     false,
		"timestamp": str(data.get("_timestamp", "")),
		"version":   int(data.get("_version",   0)),
	}

func delete_slot(slot: int) -> void:
	var path := _slot_path(slot)
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)
		Bus.emit(&"save_deleted", {"slot": slot})

# ── Scene API ─────────────────────────────────────────────────────────────────

func save_scene(slot: int = 0) -> bool:
	var root := _scene_root()
	if root == null:
		Log.warn("[SaveLoadManager] no scene root for save_scene")
		return false
	var ok := SceneSession.save_slot(slot, root)
	if ok:
		Bus.emit(&"game_saved", {"slot": slot, "type": "scene"})
	return ok

func load_scene(slot: int = 0) -> bool:
	var root := _scene_root()
	if root == null:
		Log.warn("[SaveLoadManager] no scene root for load_scene")
		return false
	var ok := SceneSession.restore_slot(slot, root)
	if ok:
		Bus.emit(&"game_loaded", {"slot": slot, "type": "scene"})
	return ok

# ── Bus handlers ──────────────────────────────────────────────────────────────

func _autosave() -> void:
	save_scene(0)
	Bus.emit(&"autosave_triggered", {})

func _on_save_requested(data: Variant) -> void:
	var slot := int((data as Dictionary).get("slot", 0)) if data is Dictionary else 0
	save_scene(slot)

func _on_load_requested(data: Variant) -> void:
	var slot := int((data as Dictionary).get("slot", 0)) if data is Dictionary else 0
	load_scene(slot)

func _on_background(_d: Variant) -> void:
	save_scene(0)

func _on_quit(_d: Variant) -> void:
	save_scene(0)

# ── Helpers ───────────────────────────────────────────────────────────────────

func _slot_path(slot: int) -> String:
	return SaveDir.path("save_slot_%d.json" % slot)

func _scene_root() -> Node:
	if is_instance_valid(WorldManager) and WorldManager.scene_root != null:
		return WorldManager.scene_root
	var tree := get_tree()
	return tree.current_scene if tree else null
