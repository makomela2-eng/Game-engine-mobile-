## Version — engine version constants.
extends Node
const MAJOR := 2; const MINOR := 0; const PATCH := 0; const LABEL := "alpha"
func as_string() -> String:
	return "%d.%d.%d-%s" % [MAJOR, MINOR, PATCH, LABEL]
