## ConfigLoader — loads .cfg and project settings into Cfg autoload.
extends Node

const USER_CFG := "user://king_config.cfg"

var _config : ConfigFile = ConfigFile.new()

func _ready() -> void:
	load_config()

func load_config() -> void:
	var err := _config.load(USER_CFG)
	if err != OK:
		Log.info("[ConfigLoader] No user config found — using defaults")

func save_config() -> void:
	var err := _config.save(USER_CFG)
	if err != OK:
		Log.error("[ConfigLoader] Failed to save config")

func get_value(section: String, key: String, default: Variant = null) -> Variant:
	return _config.get_value(section, key, default)

func set_value(section: String, key: String, value: Variant) -> void:
	_config.set_value(section, key, value)

func has_key(section: String, key: String) -> bool:
	return _config.has_section_key(section, key)

func export_all() -> Dictionary:
	var result : Dictionary = {}
	for section in _config.get_sections():
		result[section] = {}
		for key in _config.get_section_keys(section):
			(result[section] as Dictionary)[key] = _config.get_value(section, key)
	return result

func import_all(data: Dictionary) -> void:
	for section in data.keys():
		for key in (data[section] as Dictionary).keys():
			_config.set_value(section, key, (data[section] as Dictionary)[key])
	save_config()
