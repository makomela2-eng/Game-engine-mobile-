## DataRegistry — typed runtime data tables loaded from JSON or registered inline.
##
## Features:
##   load_table()      — parse JSON array, index by a key field
##   merge_table()     — add entries to an existing table without replacing it
##   register_entry()  — add a single entry programmatically
##   get_entry()       — returns Dictionary or {} (never null)
##   get_all()         — all entries in a table as Array[Dictionary]
##   filter()          — query with a callable predicate
##   hot_reload()      — re-read JSON from disk and replace table in-place
##   validate_entry()  — check required fields are present
##   Bus event:        data.table_loaded when a table finishes loading
extends Node

## table_name → Dictionary[StringName → Dictionary]
var _tables   : Dictionary = {}
## table_name → source path (for hot-reload)
var _sources  : Dictionary = {}

func _ready() -> void:
	Bus.on(&"data.reload_table", _on_reload_table)

func _exit_tree() -> void:
	Bus.off(&"data.reload_table", _on_reload_table)

# ── Loading ────────────────────────────────────────────────────────────────────

func load_table(name: StringName, path: String,
		key_field: String = "id",
		required_fields: Array[String] = []) -> int:
	var data := JSONLoader.load_array(path)
	if data.is_empty():
		Log.warn("[DataRegistry] Empty or missing table: %s (%s)" % [name, path])
		return 0
	var table  : Dictionary = {}
	var errors : int        = 0
	for entry in data:
		if not entry is Dictionary: continue
		var d := entry as Dictionary
		if not required_fields.is_empty():
			var missing := validate_entry(d, required_fields)
			if not missing.is_empty():
				Log.warn("[DataRegistry] Entry in '%s' missing fields: %s" % [name, missing])
				errors += 1
				continue
		var k := StringName(str(d.get(key_field, "")))
		if k != &"":
			table[k] = d
	_tables[name]  = table
	_sources[name] = path
	Log.info("[DataRegistry] Loaded '%s': %d entries (%d errors)" \
		% [name, table.size(), errors])
	Bus.emit(&"data.table_loaded", {"table": name, "count": table.size()})
	return table.size()

## Merge entries from a JSON file into an existing table (additive).
func merge_table(name: StringName, path: String, key_field: String = "id") -> void:
	var data := JSONLoader.load_array(path)
	if not _tables.has(name):
		_tables[name] = {}
	var table := _tables[name] as Dictionary
	for entry in data:
		if not entry is Dictionary: continue
		var d := entry as Dictionary
		var k := StringName(str(d.get(key_field, "")))
		if k != &"": table[k] = d
	Log.info("[DataRegistry] Merged %d entries into '%s'" % [data.size(), name])

## Register a single entry in code.
func register_entry(table: StringName, id: StringName, data: Dictionary) -> void:
	if not _tables.has(table): _tables[table] = {}
	(_tables[table] as Dictionary)[id] = data

## Re-read the source file for a table and replace it.
func hot_reload(name: StringName) -> bool:
	if not _sources.has(name):
		Log.warn("[DataRegistry] No source path for hot-reload: %s" % name)
		return false
	JSONLoader.release(str(_sources[name]))
	load_table(name, str(_sources[name]))
	return true

# ── Queries ────────────────────────────────────────────────────────────────────

func get_entry(table: StringName, id: StringName) -> Dictionary:
	if not _tables.has(table): return {}
	return (_tables[table] as Dictionary).get(id, {})

func has_entry(table: StringName, id: StringName) -> bool:
	return _tables.has(table) and (_tables[table] as Dictionary).has(id)

func get_all(table: StringName) -> Array[Dictionary]:
	var result : Array[Dictionary] = []
	if not _tables.has(table): return result
	for entry in (_tables[table] as Dictionary).values():
		result.append(entry as Dictionary)
	return result

## Filter entries by a predicate: fn(entry: Dictionary) -> bool
func filter(table: StringName, fn: Callable) -> Array[Dictionary]:
	var result : Array[Dictionary] = []
	for entry in get_all(table):
		if fn.call(entry): result.append(entry)
	return result

func get_ids(table: StringName) -> Array[StringName]:
	var result : Array[StringName] = []
	if not _tables.has(table): return result
	for k in (_tables[table] as Dictionary).keys():
		result.append(k)
	return result

func table_names() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _tables.keys(): result.append(k)
	return result

func entry_count(table: StringName) -> int:
	if not _tables.has(table): return 0
	return (_tables[table] as Dictionary).size()

# ── Validation ─────────────────────────────────────────────────────────────────

## Returns array of missing field names. Empty = valid.
func validate_entry(entry: Dictionary, required: Array[String]) -> Array[String]:
	var missing : Array[String] = []
	for field in required:
		if not entry.has(field): missing.append(field)
	return missing

# ── Bus handlers ───────────────────────────────────────────────────────────────

func _on_reload_table(data: Variant) -> void:
	if not data is Dictionary: return
	hot_reload(StringName(str((data as Dictionary).get("table", ""))))
