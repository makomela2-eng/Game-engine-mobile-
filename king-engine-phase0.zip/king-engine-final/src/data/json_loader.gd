## JSONLoader — loads and caches JSON data files.
extends Node

var _cache : Dictionary = {}  ## path → Variant

func load_file(path: String, force_reload: bool = false) -> Variant:
	if not force_reload and _cache.has(path):
		return _cache[path]
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		Log.error("[JSONLoader] Cannot open: %s" % path)
		return null
	var text   := file.get_as_text()
	file.close()
	var parsed : Variant = JSON.parse_string(text)
	if parsed == null:
		Log.error("[JSONLoader] Invalid JSON: %s" % path)
		return null
	_cache[path] = parsed
	return parsed

func load_array(path: String) -> Array:
	var data: Variant = load_file(path)
	if data is Array:
		return data as Array
	return []

func load_dict(path: String) -> Dictionary:
	var data: Variant = load_file(path)
	if data is Dictionary:
		return data as Dictionary
	return {}

func save_file(path: String, data: Variant) -> bool:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		Log.error("[JSONLoader] Cannot write: %s" % path)
		return false
	f.store_string(JSON.stringify(data, "	"))
	f.close()
	_cache[path] = data
	return true

func has_cache(path: String) -> bool:
	return _cache.has(path)

func release(path: String) -> void:
	_cache.erase(path)

func clear_cache() -> void:
	_cache.clear()
