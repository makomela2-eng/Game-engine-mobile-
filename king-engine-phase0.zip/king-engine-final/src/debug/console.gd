## Console — in-game developer command console.
##
## Desktop: toggle with backtick (`).
## Mobile: toggle via Bus.emit(&"console_toggle") or DevUI button.
## Commands: register() / unregister(). Built-ins: help, clear, quit, fps,
##   ents, pause, set, get, log, tags, sys, time, mem, bb.
## CVar system: set_cvar() / get_cvar() for runtime numeric/bool tuning.
## Tab completion: TAB cycles through matching command names.
## History: UP/DOWN arrows cycle through submitted commands.
extends CanvasLayer

var _panel       : PanelContainer
var _output      : RichTextLabel
var _input_field : LineEdit
var _history     : Array[String] = []
var _hist_idx    : int = -1
var _completions : Array[String] = []
var _comp_idx    : int = -1
var _open        : bool = false
var _commands    : Dictionary = {}   ## StringName → { fn, help }
var _cvars       : Dictionary = {}   ## StringName → Variant

func _ready() -> void:
	layer = 200
	_build_ui()
	visible = false
	_register_builtins()
	Bus.on(&"console_toggle", func(_d: Variant) -> void: toggle())
	Bus.on(&"console_print",  func(d: Variant) -> void:
		if d is String: print_line(d as String)
		elif d is Dictionary:
			var dd := d as Dictionary
			print_line(str(dd.get("msg", "")), str(dd.get("color", "white"))))

func _exit_tree() -> void:
	Bus.off(&"console_toggle", func(_d: Variant) -> void: toggle())
	Bus.off(&"console_print",  func(_d: Variant) -> void: pass)

# ── UI ─────────────────────────────────────────────────────────────────────────

func _build_ui() -> void:
	_panel = PanelContainer.new()
	_panel.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_panel.custom_minimum_size = Vector2(0, 340)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.05, 0.05, 0.92)
	style.border_color = Color(0.3, 0.5, 1.0, 0.6)
	style.set_border_width_all(1)
	_panel.add_theme_stylebox_override("panel", style)
	add_child(_panel)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 2)
	_panel.add_child(vbox)

	var header := Label.new()
	header.text = "  KING Console"
	header.add_theme_color_override("font_color", Color(0.4, 0.7, 1.0))
	vbox.add_child(header)

	_output = RichTextLabel.new()
	_output.bbcode_enabled      = true
	_output.scroll_following    = true
	_output.custom_minimum_size = Vector2(0, 285)
	_output.add_theme_font_size_override("normal_font_size", 12)
	vbox.add_child(_output)

	_input_field = LineEdit.new()
	_input_field.placeholder_text = "> enter command (TAB to complete, ↑↓ for history)"
	_input_field.text_submitted.connect(_on_submit)
	_input_field.gui_input.connect(_on_input_field_gui_input)
	vbox.add_child(_input_field)

func _input(event: InputEvent) -> void:
	if not event is InputEventKey: return
	var k := event as InputEventKey
	if not k.pressed: return
	match k.keycode:
		KEY_QUOTELEFT:
			toggle()
			get_viewport().set_input_as_handled()
		KEY_UP:
			if _open: _history_up(); get_viewport().set_input_as_handled()
		KEY_DOWN:
			if _open: _history_down(); get_viewport().set_input_as_handled()

func _on_input_field_gui_input(event: InputEvent) -> void:
	if not event is InputEventKey: return
	var k := event as InputEventKey
	if k.pressed and k.keycode == KEY_TAB:
		_tab_complete()
		get_viewport().set_input_as_handled()

# ── Toggle ─────────────────────────────────────────────────────────────────────

func toggle() -> void:
	_open   = not _open
	visible = _open
	if _open:
		_input_field.grab_focus()

func open()  -> void: if not _open: toggle()
func close() -> void: if _open:     toggle()

# ── Command registration ───────────────────────────────────────────────────────

func register(name: StringName, fn: Callable, help: String = "") -> void:
	_commands[name] = {"fn": fn, "help": help}

func unregister(name: StringName) -> void:
	_commands.erase(name)

# ── CVar system ────────────────────────────────────────────────────────────────

func set_cvar(name: StringName, value: Variant) -> void:
	_cvars[name] = value
	Bus.emit(&"cvar_changed", {"name": name, "value": value})

func get_cvar(name: StringName, default: Variant = null) -> Variant:
	return _cvars.get(name, default)

# ── Output ─────────────────────────────────────────────────────────────────────

func print_line(text: String, color: String = "white") -> void:
	_output.append_text("[color=%s]%s[/color]\n" % [color, text])

func print_table(headers: Array[String], rows: Array) -> void:
	var widths : Array[int] = []
	for h in headers: widths.append(h.length())
	for row in rows:
		for i in range(mini((row as Array).size(), widths.size())):
			widths[i] = maxi(widths[i], str((row as Array)[i]).length())
	var header_line := ""
	for i in range(headers.size()):
		header_line += headers[i].rpad(widths[i] + 2)
	print_line(header_line, "cyan")
	for row in rows:
		var line := ""
		for i in range(mini((row as Array).size(), widths.size())):
			line += str((row as Array)[i]).rpad(widths[i] + 2)
		print_line(line)

# ── Execution ──────────────────────────────────────────────────────────────────

func _on_submit(text: String) -> void:
	var trimmed := text.strip_edges()
	if trimmed.is_empty(): return
	_history.append(trimmed)
	_hist_idx = -1
	_comp_idx = -1
	_completions.clear()
	print_line("> " + trimmed, "cyan")
	_execute(trimmed)
	_input_field.clear()

func _execute(line: String) -> void:
	var parts := line.split(" ", false)
	if parts.is_empty(): return
	var cmd  := StringName(parts[0])
	var args := parts.slice(1)
	if _commands.has(cmd):
		(_commands[cmd] as Dictionary).fn.call(args)
	else:
		print_line("Unknown: '%s'  (type 'help')" % cmd, "red")

# ── Tab completion ─────────────────────────────────────────────────────────────

func _tab_complete() -> void:
	var prefix := _input_field.text.strip_edges()
	if prefix.is_empty(): return
	if _completions.is_empty() or _comp_idx < 0:
		_completions.clear()
		for key in _commands.keys():
			if str(key).begins_with(prefix):
				_completions.append(str(key))
		_completions.sort()
		_comp_idx = 0
	if _completions.is_empty(): return
	_comp_idx = _comp_idx % _completions.size()
	_input_field.text = _completions[_comp_idx]
	_input_field.caret_column = _input_field.text.length()
	_comp_idx += 1

# ── History ────────────────────────────────────────────────────────────────────

func _history_up() -> void:
	if _history.is_empty(): return
	_hist_idx = clampi(_hist_idx + 1, 0, _history.size() - 1)
	_input_field.text = _history[_history.size() - 1 - _hist_idx]
	_input_field.caret_column = _input_field.text.length()

func _history_down() -> void:
	_hist_idx = maxi(_hist_idx - 1, -1)
	_input_field.text = "" if _hist_idx < 0 else _history[_history.size() - 1 - _hist_idx]
	_input_field.caret_column = _input_field.text.length()

# ── Built-in commands ──────────────────────────────────────────────────────────

func _register_builtins() -> void:
	register(&"help",    _cmd_help,    "List commands. help <cmd> for detail")
	register(&"clear",   _cmd_clear,   "Clear output")
	register(&"quit",    _cmd_quit,    "Quit game")
	register(&"fps",     _cmd_fps,     "Show FPS and frame time")
	register(&"mem",     _cmd_mem,     "Show memory usage")
	register(&"ents",    _cmd_ents,    "Show entity count. ents <tag> to filter")
	register(&"tags",    _cmd_tags,    "tags <entity_id> — show entity tags")
	register(&"inspect", _cmd_inspect, "inspect <entity_id> — dump components")
	register(&"pause",   _cmd_pause,   "Toggle GameLoop pause")
	register(&"set",     _cmd_set,     "set <cvar> <value> — set a cvar")
	register(&"get",     _cmd_get,     "get <cvar> — read a cvar")
	register(&"log",     _cmd_log,     "log <level> — set log level (0-3)")
	register(&"sys",     _cmd_sys,     "sys — list active systems and priorities")
	register(&"time",    _cmd_time,    "Show elapsed game time")
	register(&"bus",     _cmd_bus,     "bus <event> — show listener count for event")

func _cmd_help(args: Array) -> void:
	if not args.is_empty():
		var cmd := StringName(str(args[0]))
		if _commands.has(cmd):
			print_line("%s — %s" % [cmd, (_commands[cmd] as Dictionary).get("help", "")], "cyan")
			return
	print_line("Commands:", "cyan")
	var sorted := _commands.keys().duplicate()
	sorted.sort()
	for key in sorted:
		print_line("  %-14s %s" % [key, (_commands[key] as Dictionary).get("help", "")])

func _cmd_clear(_a: Array) -> void: _output.clear()
func _cmd_quit(_a: Array)  -> void: get_tree().quit()

func _cmd_fps(_a: Array) -> void:
	var fps := Engine.get_frames_per_second()
	print_line("FPS: [color=yellow]%d[/color]  frame: %.2f ms" % [fps, 1000.0 / maxf(fps, 1.0)])

func _cmd_mem(_a: Array) -> void:
	print_line("Static: %.1f MB  VRAM: %.1f MB" % [
		Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0,
		RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_VIDEO_MEM_USED) / 1048576.0])

func _cmd_ents(args: Array) -> void:
	if args.is_empty():
		print_line("Entities: %d" % EntityManager.entity_count())
	else:
		var tag := StringName(str(args[0]))
		var ids := EntityManager.get_entities_by_tag(tag)
		print_line("Entities tagged '%s': %d  ids=%s" % [tag, ids.size(), str(ids.slice(0, 10))])

func _cmd_tags(args: Array) -> void:
	if args.is_empty(): print_line("Usage: tags <id>", "red"); return
	var id := int(str(args[0]))
	print_line("e%d tags: %s" % [id, EntityManager.get_tags(id)])

func _cmd_inspect(args: Array) -> void:
	if args.is_empty(): print_line("Usage: inspect <id>", "red"); return
	EntityInspector.print_entity(int(str(args[0])))

func _cmd_pause(_a: Array) -> void:
	GameLoop.paused = not GameLoop.paused
	print_line("GameLoop paused: %s" % GameLoop.paused)

func _cmd_set(args: Array) -> void:
	if args.size() < 2: print_line("Usage: set <cvar> <value>", "red"); return
	set_cvar(StringName(str(args[0])), str(args[1]))
	print_line("Set %s = %s" % [args[0], args[1]])

func _cmd_get(args: Array) -> void:
	if args.is_empty(): print_line("Usage: get <cvar>", "red"); return
	print_line("%s = %s" % [args[0], str(get_cvar(StringName(str(args[0]))))])

func _cmd_log(args: Array) -> void:
	if args.is_empty():
		print_line("Current level: %d" % Log.min_level); return
	Log.min_level = clampi(int(str(args[0])), 0, 3)
	print_line("Log level set to %d" % Log.min_level)

func _cmd_sys(_a: Array) -> void:
	var systems := SystemRegistry.sorted_systems()
	print_line("Systems (%d):" % systems.size(), "cyan")
	for s : SystemBase in systems:
		if is_instance_valid(s):
			print_line("  %-40s p=%-6d %s" % [
				s.name, s.priority, "ON" if s.enabled else "[color=red]OFF[/color]"])

func _cmd_time(_a: Array) -> void:
	print_line("Elapsed: %.1fs  Ticks: %d" % [GameLoop.elapsed_time, GameLoop.tick_count])

func _cmd_bus(args: Array) -> void:
	if args.is_empty(): print_line("Usage: bus <event>", "red"); return
	var event := StringName(str(args[0]))
	print_line("'%s' listeners: %d" % [event, Bus.listener_count(event)])
