## DebugOverlay — on-screen stats panel for desktop and mobile.
##
## Desktop: toggle F3. Mobile: Bus.emit(&"debug_overlay_toggle").
## Respects safe-area insets so content stays visible on notched phones.
## Shows: FPS graph (15-sample rolling), ECS, memory, draw calls, system ticks,
## active AI agents, physics bodies, network state, and Profiler scope times.
extends CanvasLayer

const HISTORY_LEN   := 15
const UPDATE_HZ     := 0.1   ## seconds between refreshes

var _label       : RichTextLabel
var _fps_history : Array[float] = []
var _timer       : float = 0.0
var _visible_flag: bool  = false
var _safe_top    : float = 0.0

func _ready() -> void:
	layer = 100
	_build_ui()
	visible = false
	set_process(true)
	Bus.on(&"debug_overlay_toggle", func(_d: Variant) -> void: toggle())
	Bus.on(&"safe_area_updated",    _on_safe_area)

func _exit_tree() -> void:
	Bus.off(&"debug_overlay_toggle", func(_d: Variant) -> void: toggle())
	Bus.off(&"safe_area_updated",    _on_safe_area)

func _build_ui() -> void:
	_label = RichTextLabel.new()
	_label.bbcode_enabled      = true
	_label.fit_content         = true
	_label.mouse_filter        = Control.MOUSE_FILTER_IGNORE
	_label.position            = Vector2(8, 8 + _safe_top)
	_label.custom_minimum_size = Vector2(420, 0)
	_label.add_theme_font_size_override("normal_font_size", 11)
	add_child(_label)

func _on_safe_area(data: Variant) -> void:
	if not data is Dictionary: return
	_safe_top = float((data as Dictionary).get("top", 0.0))
	_label.position.y = 8.0 + _safe_top

func _input(event: InputEvent) -> void:
	if not event is InputEventKey: return
	var k := event as InputEventKey
	if k.pressed and k.keycode == KEY_F3:
		toggle()

func _process(delta: float) -> void:
	if not _visible_flag: return
	_timer += delta
	if _timer < UPDATE_HZ: return
	_timer = 0.0
	_refresh()

# ── Toggle ─────────────────────────────────────────────────────────────────────

func toggle() -> void:
	_visible_flag = not _visible_flag
	visible = _visible_flag

func show_overlay() -> void:  _visible_flag = true;  visible = true
func hide_overlay() -> void:  _visible_flag = false; visible = false

# ── Refresh ────────────────────────────────────────────────────────────────────

func _refresh() -> void:
	var fps := Engine.get_frames_per_second()
	_fps_history.append(fps)
	if _fps_history.size() > HISTORY_LEN:
		_fps_history.remove_at(0)

	var lines : Array[String] = []
	lines.append("[b][color=cyan]▶ KING Debug[/color][/b]  %s" \
		% Time.get_time_string_from_system())

	## FPS + mini sparkline
	var spark := _spark(_fps_history)
	var fps_color := "green" if fps >= 55 else ("yellow" if fps >= 30 else "red")
	lines.append("FPS [color=%s]%d[/color]  %s  frame %.2fms" \
		% [fps_color, fps, spark, 1000.0 / maxf(fps, 1.0)])

	## Memory
	var mem_mb := Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0
	var vram   := RenderingServer.get_rendering_info(
		RenderingServer.RENDERING_INFO_VIDEO_MEM_USED) / 1048576.0
	lines.append("Mem [color=yellow]%.0f[/color] MB  VRAM [color=yellow]%.0f[/color] MB" \
		% [mem_mb, vram])

	## ECS
	var ent_count := EntityManager.entity_count() \
		if EntityManager.has_method("entity_count") else 0
	## DecisionSystem is game-layer — query via Bus if present, else 0.
	var ai_count  := 0
	lines.append("Entities [color=yellow]%d[/color]  AI [color=yellow]%d[/color]" \
		% [ent_count, ai_count])

	## Rendering
	var dc := RenderingServer.get_rendering_info(
		RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
	var nodes := int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	lines.append("DrawCalls [color=yellow]%d[/color]  Nodes [color=yellow]%d[/color]" \
		% [dc, nodes])

	## Systems (top 5 by tick ms from Profiler)
	var scopes := Profiler.all_scopes()
	if not scopes.is_empty():
		var scope_times : Array[Dictionary] = []
		for s in scopes:
			scope_times.append({"name": str(s), "ms": Profiler.get_avg_ms(s)})
		scope_times.sort_custom(func(a, b): return float(a.ms) > float(b.ms))
		lines.append("[color=dim_gray]── Systems (avg ms) ──[/color]")
		for i in range(mini(5, scope_times.size())):
			var e := scope_times[i] as Dictionary
			lines.append("  %-32s %.2fms" % [e.name, e.ms])

	## Network
	if NetworkState.has_method("is_online"):
		var online := NetworkState.is_online()
		var net_color := "green" if online else "dim_gray"
		lines.append("Net [color=%s]%s[/color]  ping %dms" \
			% [net_color, "online" if online else "offline", NetworkState.ping_ms])

	## Tasks
	lines.append("Tasks [color=yellow]%d[/color]  Budget %.1fms" \
		% [TaskScheduler.task_count(), FrameBudget.budget_ms])

	_label.text = "\n".join(lines)

func _spark(history: Array[float]) -> String:
	if history.is_empty(): return ""
	var bars : Array[String] = ["▁","▂","▃","▄","▅","▆","▇","█"]
	var max_v := 0.0
	for v in history: max_v = maxf(max_v, v)
	if max_v < 1.0: return ""
	var result := ""
	for v in history:
		var idx := int(clampf(v / max_v * (bars.size() - 1), 0, bars.size() - 1))
		result += bars[idx]
	return result
