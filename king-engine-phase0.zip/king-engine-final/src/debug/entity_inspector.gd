## EntityInspector — runtime inspection of any entity's components.
## Used by king_editor and Console ("inspect <id>") commands.
extends Node

var _watching : int = -1

func inspect(entity: int) -> Dictionary:
	if not EntityManager.entity_exists(entity):
		return {}
	var result : Dictionary = {
		"id":         entity,
		"tags":       EntityManager.get_tags(entity),
		"components": {}
	}
	for type : StringName in EntityManager.get_component_types(entity):
		var comp: Variant = EntityManager.get_component(entity, type)
		result.components[str(type)] = _dump_component(comp)
	return result

func watch(entity: int) -> void:
	_watching = entity

func unwatch() -> void:
	_watching = -1

func _process(_delta: float) -> void:
	if _watching >= 0 and Engine.get_frames_drawn() % 30 == 0:
		var data := inspect(_watching)
		Bus.emit(&"inspector.update", {"entity": _watching, "data": data})

func _dump_component(comp: Component) -> Dictionary:
	if comp == null:
		return {}
	var result : Dictionary = {"class": comp.get_class()}
	# Reflect exported properties
	for prop in comp.get_property_list():
		var pname : String = prop.name
		if pname.begins_with("_") or pname in ["script", "RefCounted"]:
			continue
		var val: Variant = comp.get(pname)
		if val != null:
			result[pname] = str(val)
	return result

func print_entity(entity: int) -> void:
	var data := inspect(entity)
	if data.is_empty():
		Log.warn("[EntityInspector] Entity %d not found" % entity)
		return
	Log.info("[EntityInspector] Entity %d  tags=%s" % [entity, data.tags])
	for type in (data.components as Dictionary).keys():
		Log.info("  [%s] %s" % [type, (data.components as Dictionary)[type]])
