## PerformanceMonitor — samples Godot Performance monitors each frame.
## Accessible via DebugOverlay and Console.
extends Node

var sample_rate : float = 0.25   ## Seconds between samples
var _timer      : float = 0.0
var _samples    : Dictionary = {}

const MONITORS : Array = [
	Performance.TIME_FPS,
	Performance.TIME_PROCESS,
	Performance.TIME_PHYSICS_PROCESS,
	Performance.MEMORY_STATIC,
	Performance.OBJECT_COUNT,
	Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME,
	Performance.RENDER_VIDEO_MEM_USED,
]

func _ready() -> void:
	set_process(true)

func _process(delta: float) -> void:
	_timer += delta
	if _timer < sample_rate:
		return
	_timer = 0.0
	for monitor in MONITORS:
		_samples[monitor] = Performance.get_monitor(monitor)
	Bus.emit(&"perf.sampled", {"samples": _samples.duplicate()})

func get_sample(monitor: int) -> float:
	return float(_samples.get(monitor, 0.0))

func fps() -> float:
	return get_sample(Performance.TIME_FPS)

func frame_ms() -> float:
	return get_sample(Performance.TIME_PROCESS) * 1000.0

func static_mem_mb() -> float:
	return get_sample(Performance.MEMORY_STATIC) / 1048576.0

func draw_calls() -> int:
	return int(get_sample(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME))

func vram_mb() -> float:
	return get_sample(Performance.RENDER_VIDEO_MEM_USED) / 1048576.0
