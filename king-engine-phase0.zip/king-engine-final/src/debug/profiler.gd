## Profiler — manual scope-based CPU profiler.
## Usage:
##   Profiler.begin("my_system")
##   # ... work ...
##   Profiler.end("my_system")
##   var ms := Profiler.get_ms("my_system")
extends Node

var _starts  : Dictionary = {}   ## StringName → start usec
var _results : Dictionary = {}   ## StringName → { last_ms, avg_ms, samples }
var _max_samples : int = 60

func begin(scope: StringName) -> void:
	_starts[scope] = Time.get_ticks_usec()

func end(scope: StringName) -> void:
	if not _starts.has(scope):
		return
	var elapsed_ms : float = (Time.get_ticks_usec() - _starts[scope]) / 1000.0
	_starts.erase(scope)
	if not _results.has(scope):
		_results[scope] = {"last_ms": 0.0, "avg_ms": 0.0, "samples": []}
	var r := _results[scope] as Dictionary
	r.last_ms = elapsed_ms
	(r.samples as Array).append(elapsed_ms)
	if (r.samples as Array).size() > _max_samples:
		(r.samples as Array).remove_at(0)
	var total := 0.0
	for s in (r.samples as Array):
		total += float(s)
	r.avg_ms = total / float((r.samples as Array).size())

func get_ms(scope: StringName) -> float:
	return (_results.get(scope, {}) as Dictionary).get("last_ms", 0.0)

func get_avg_ms(scope: StringName) -> float:
	return (_results.get(scope, {}) as Dictionary).get("avg_ms", 0.0)

func dump() -> void:
	Log.info("[Profiler] === Scope times ===")
	for scope in _results.keys():
		var r := _results[scope] as Dictionary
		Log.info("  %s: last=%.2fms avg=%.2fms" % [scope, r.last_ms, r.avg_ms])

func all_scopes() -> Array:
	return _results.keys()

func reset() -> void:
	_results.clear()
	_starts.clear()
