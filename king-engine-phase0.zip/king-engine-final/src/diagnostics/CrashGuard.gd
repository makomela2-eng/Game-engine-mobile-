## CrashGuard — error counting, deduplication, recovery actions, and report writing.
##
## Recovery levels (triggered by increasing error counts):
##   WARN    (5)  → emit crash_guard_threshold on Bus
##   RECOVER (15) → attempt scene reload (with cooldown — prevents infinite loops)
##   FATAL   (30) → write crash report and quit
##
## dev_mode: in debug builds, recovery is disabled so bugs surface as crashes,
## not silently-swallowed restarts. Set dev_mode = false for QA/release builds
## where recovery protects end users.
##
## Recovery cooldown: minimum 10 seconds between recover attempts to prevent
## an infinite reload loop if the bug that caused 15 errors persists.
extends Node

enum RecoveryLevel { OK, WARN, RECOVER, FATAL }

const THRESHOLD_WARN    := 5
const THRESHOLD_RECOVER := 15
const THRESHOLD_FATAL   := 30
const REPORT_PATH       := "user://crash_report.txt"
const RECOVER_COOLDOWN_SEC := 10.0

## In dev/debug mode: skip RECOVER and go straight to FATAL so bugs are visible.
var dev_mode        : bool           = false
var dedup_window_sec: float          = 2.0

var _error_count    : int            = 0
var _recovery_level : RecoveryLevel  = RecoveryLevel.OK
var _dedup_table    : Dictionary     = {}   ## msg_hash → last_time
var _stall_count    : int            = 0
var _last_recover_time : float       = -999.0   ## wall time of last recovery

signal threshold_reached(level: RecoveryLevel, count: int)

func _ready() -> void:
	dev_mode = OS.is_debug_build()
	get_tree().node_removed.connect(_on_node_removed)
	Bus.on(&"log_entry",   _on_log_entry)
	Bus.on(&"frame_stall", _on_frame_stall)
	Bus.on(&"app_quit",    _on_app_quit)

func _exit_tree() -> void:
	Bus.off(&"log_entry",   _on_log_entry)
	Bus.off(&"frame_stall", _on_frame_stall)
	Bus.off(&"app_quit",    _on_app_quit)

# ── Error tracking ─────────────────────────────────────────────────────────────

func _on_log_entry(entry: Variant) -> void:
	if not entry is Dictionary: return
	if int((entry as Dictionary).get("level", 0)) < 3: return
	var msg   : String = str((entry as Dictionary).get("msg", ""))
	var hash  : int    = msg.hash()
	var now   : float  = Time.get_ticks_msec() * 0.001
	if float(_dedup_table.get(hash, 0.0)) + dedup_window_sec > now:
		return
	_dedup_table[hash] = now
	_error_count += 1
	_check_thresholds()

func _on_frame_stall(data: Variant) -> void:
	if not data is Dictionary: return
	var ms := float((data as Dictionary).get("ms", 0.0))
	if ms < 500.0: return
	_stall_count += 1
	if ms > 3000.0:
		_error_count += 5
		_check_thresholds()

func _check_thresholds() -> void:
	if _error_count >= THRESHOLD_FATAL and _recovery_level < RecoveryLevel.FATAL:
		_recovery_level = RecoveryLevel.FATAL
		threshold_reached.emit(RecoveryLevel.FATAL, _error_count)
		Bus.emit(&"crash_guard_threshold", {"level": RecoveryLevel.FATAL, "count": _error_count})
		_handle_fatal()
	elif _error_count >= THRESHOLD_RECOVER and _recovery_level < RecoveryLevel.RECOVER:
		_recovery_level = RecoveryLevel.RECOVER
		threshold_reached.emit(RecoveryLevel.RECOVER, _error_count)
		Bus.emit(&"crash_guard_threshold", {"level": RecoveryLevel.RECOVER, "count": _error_count})
		if not dev_mode:
			_handle_recover()
		else:
			Log.error("[CrashGuard] dev_mode: skipping RECOVER, errors=%d" % _error_count)
	elif _error_count >= THRESHOLD_WARN and _recovery_level < RecoveryLevel.WARN:
		_recovery_level = RecoveryLevel.WARN
		threshold_reached.emit(RecoveryLevel.WARN, _error_count)
		Bus.emit(&"crash_guard_threshold", {"level": RecoveryLevel.WARN, "count": _error_count})
		Log.warn("[CrashGuard] %d errors — possible instability" % _error_count)

func _handle_recover() -> void:
	var now := Time.get_ticks_msec() * 0.001
	if now - _last_recover_time < RECOVER_COOLDOWN_SEC:
		Log.warn("[CrashGuard] Recovery cooldown active (%.0fs remaining) — skipping" \
			% (RECOVER_COOLDOWN_SEC - (now - _last_recover_time)))
		return
	_last_recover_time = now
	Log.warn("[CrashGuard] Attempting scene recovery (%d errors)" % _error_count)
	Cfg.force_save()
	get_tree().reload_current_scene()
	_error_count    = THRESHOLD_WARN
	_recovery_level = RecoveryLevel.WARN

func _handle_fatal() -> void:
	Log.error("[CrashGuard] FATAL: %d errors — writing report and quitting" % _error_count)
	_write_report()
	Cfg.force_save()
	get_tree().quit(1)

func _on_node_removed(node: Node) -> void:
	for name in ["Log", "Bus", "Kernel", "TaskScheduler", "EntityManager"]:
		if node.name == name:
			printerr("[CrashGuard] CRITICAL autoload removed: " + node.name)

func _write_report() -> void:
	var f := FileAccess.open(REPORT_PATH, FileAccess.WRITE)
	if f == null: return
	f.store_line("KING Engine Crash Report")
	f.store_line("Time:     " + Time.get_datetime_string_from_system())
	f.store_line("Platform: " + OS.get_name())
	f.store_line("Version:  " + Version.as_string())
	f.store_line("Errors:   %d  Stalls: %d" % [_error_count, _stall_count])
	f.store_line("dev_mode: %s" % dev_mode)
	f.store_line("")
	f.store_line("Recent log:")
	for entry : Dictionary in LogCapture.recent(40):
		f.store_line("  [%d] %s" % [int(entry.get("level", 0)), str(entry.get("msg", ""))])
	f.close()
	Bus.emit(&"crash_report_written", {"path": REPORT_PATH})

func _on_app_quit(_d: Variant) -> void:
	Cfg.force_save()

func reset() -> void:
	_error_count = 0; _recovery_level = RecoveryLevel.OK
	_dedup_table.clear(); _stall_count = 0; _last_recover_time = -999.0

func error_count()  -> int:           return _error_count
func stall_count()  -> int:           return _stall_count
func level()        -> RecoveryLevel: return _recovery_level
func in_dev_mode()  -> bool:          return dev_mode
