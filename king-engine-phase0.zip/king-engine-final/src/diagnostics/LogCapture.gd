## LogCapture — ring buffer for log entries with level filtering, search, and export.
##
## Stores up to MAX_ENTRIES recent log entries.
## Provides: recent(), search(), entries_by_level(), export_to_file().
## Used by CrashGuard (recent error replay), DebugOverlay, Dashboard logs tab.
extends Node

const MAX_ENTRIES := 500

var _entries : Array[Dictionary] = []

## Entry format: { level: int, msg: String, time_ms: int, ctx: Dictionary }

func _ready() -> void:
	Bus.on(&"log_entry", _on_entry)

func _exit_tree() -> void:
	Bus.off(&"log_entry", _on_entry)

func _on_entry(data: Variant) -> void:
	if not data is Dictionary: return
	var entry := (data as Dictionary).duplicate()
	entry["time_ms"] = Time.get_ticks_msec()
	_entries.append(entry)
	if _entries.size() > MAX_ENTRIES:
		_entries.pop_front()

# ── Queries ────────────────────────────────────────────────────────────────────

func recent(count: int = 20) -> Array[Dictionary]:
	var start := maxi(0, _entries.size() - count)
	var result : Array[Dictionary] = []
	for i in range(start, _entries.size()):
		result.append(_entries[i])
	return result

func all() -> Array[Dictionary]:
	return _entries.duplicate()

## Return entries at or above min_level (0=DEBUG 1=INFO 2=WARN 3=ERROR).
func entries_by_level(min_level: int, count: int = 100) -> Array[Dictionary]:
	var result : Array[Dictionary] = []
	for i in range(_entries.size() - 1, -1, -1):
		var e : Dictionary = _entries[i]
		if int(e.get("level", 0)) >= min_level:
			result.push_front(e)
		if result.size() >= count:
			break
	return result

## Case-insensitive substring search in message text.
func search(query: String, max_results: int = 50) -> Array[Dictionary]:
	var q      := query.to_lower()
	var result : Array[Dictionary] = []
	for i in range(_entries.size() - 1, -1, -1):
		if result.size() >= max_results: break
		if str(_entries[i].get("msg", "")).to_lower().contains(q):
			result.push_front(_entries[i])
	return result

func error_count() -> int:
	var n := 0
	for e : Dictionary in _entries:
		if int(e.get("level", 0)) >= 3: n += 1
	return n

func warn_count() -> int:
	var n := 0
	for e : Dictionary in _entries:
		if int(e.get("level", 0)) == 2: n += 1
	return n

# ── Export ─────────────────────────────────────────────────────────────────────

func export_to_file(path: String = "user://king_log_export.txt") -> bool:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		Log.warn("[LogCapture] Cannot write to: %s" % path)
		return false
	var prefixes : Array[String] = ["[DBG]", "[INF]", "[WRN]", "[ERR]"]
	for e : Dictionary in _entries:
		var lvl  := clampi(int(e.get("level", 0)), 0, 3)
		var ms   := int(e.get("time_ms", 0))
		var msg  := str(e.get("msg", ""))
		f.store_line("[%d.%03ds] %s %s" % [ms / 1000, ms % 1000, prefixes[lvl], msg])
	f.close()
	Log.info("[LogCapture] exported %d entries to %s" % [_entries.size(), path])
	return true

func clear() -> void:
	_entries.clear()
