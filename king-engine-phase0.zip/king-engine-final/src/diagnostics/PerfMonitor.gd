## PerfMonitor — samples FPS/memory/draw calls every 2s.
## Emits perf_snap (listened by Dashboard, DevUI, KingProfilerDock).
extends Node

signal snapshot(data: Dictionary)

func _ready() -> void:
	TaskScheduler.schedule(&"perf_sample", 2.0, _sample)

func _sample() -> void:
	var data := {
		"fps"       : Engine.get_frames_per_second(),
		"mem_mb"    : OS.get_static_memory_usage() / 1_048_576.0,
		"draw_calls": int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)),
		"nodes"     : int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)),
		"tasks"     : TaskScheduler.task_count(),
		"entities"  : EntityManager.entity_count() if EntityManager.has_method("entity_count") else 0,
	}
	snapshot.emit(data)
	Bus.emit(&"perf_snap", data)
