## ReplayRecorder — records input frames for replay/ghost/spectator.
##
## Schema versioning (FIX):
##   Saved replay files now carry a "schema" integer field at the top level.
##   load_replay() rejects files whose schema version is higher than
##   SCHEMA_VERSION, and logs a warning for older schemas so future migration
##   code has a clear hook point. This prevents silent data corruption when
##   the frame format changes across engine versions.
##
## Typing notes:
##   * _frames is Array[Dictionary] — no bare Array.
##   * JSON load result validated as Array before assignment; elements
##     cast to Dictionary individually in get_frame_at to stay safe.
##   * get_frame_at return type is Dictionary (empty dict = end of playback).
##   * All index/time accesses use explicit float() / int() coercions on
##     Dictionary values since JSON deserialises everything as Variant.
extends Node

signal recording_started
signal recording_stopped(frame_count: int)
signal playback_started
signal playback_finished

const MAX_FRAMES   := 18000  # 5 min at 60 fps
## Increment this whenever the per-frame Dictionary layout changes.
## Saved files store this value so loaders can detect and reject/migrate them.
const SCHEMA_VERSION := 1

var _recording  : bool  = false
var _playing    : bool  = false
var _frames     : Array[Dictionary] = []
var _play_idx   : int   = 0
var _play_t     : float = 0.0
var _start_time : float = 0.0

func start_recording() -> void:
	if _recording: return
	_frames.clear()
	_recording  = true
	_start_time = Clock.elapsed
	recording_started.emit()
	Log.info("[Replay] recording started")

func stop_recording() -> void:
	if not _recording: return
	_recording = false
	recording_stopped.emit(_frames.size())
	Log.info("[Replay] recorded %d frames" % _frames.size())

func record_frame(inputs: Dictionary) -> void:
	if not _recording or _frames.size() >= MAX_FRAMES: return
	_frames.append({"t": Clock.elapsed - _start_time, "inputs": inputs.duplicate()})

func start_playback(from_time: float = 0.0) -> void:
	if _frames.is_empty(): return
	_playing  = true
	_play_t   = from_time
	_play_idx = 0
	while _play_idx < _frames.size() and \
			float(_frames[_play_idx].get("t", 0.0)) < from_time:
		_play_idx += 1
	playback_started.emit()

func stop_playback() -> void:
	_playing = false

## Returns the inputs Dictionary for the frame at or after time_sec.
## Returns an empty Dictionary and stops playback when past the end.
func get_frame_at(time_sec: float) -> Dictionary:
	for i: int in range(_play_idx, _frames.size()):
		if float(_frames[i].get("t", 0.0)) >= time_sec:
			_play_idx = i
			var inputs_var: Variant = _frames[i].get("inputs", {})
			return inputs_var as Dictionary if inputs_var is Dictionary else {}
	_playing = false
	playback_finished.emit()
	return {}

func advance_playback(delta: float) -> Dictionary:
	if not _playing: return {}
	_play_t += delta
	return get_frame_at(_play_t)

## FIX: writes "schema" version alongside frames so loaders can detect
## incompatible or outdated replay files without guessing from the data shape.
func save_replay(path: String) -> void:
	var f: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if not f: return
	f.store_string(JSON.stringify({
		"schema": SCHEMA_VERSION,
		"frames": _frames
	}))
	f.close()

## FIX: reads and validates "schema" before attempting to parse frames.
## Returns false and logs a clear error for version mismatches rather than
## silently loading garbage data.
func load_replay(path: String) -> bool:
	if not FileAccess.file_exists(path): return false
	var result: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not result is Dictionary: return false
	var root: Dictionary = result as Dictionary

	# Schema check — allow equal or older; reject newer (forward-incompatible).
	var file_schema: int = int(root.get("schema", 0))
	if file_schema > SCHEMA_VERSION:
		Log.error("[Replay] cannot load replay: schema %d > current %d" % [
			file_schema, SCHEMA_VERSION])
		return false
	if file_schema < SCHEMA_VERSION:
		Log.warn("[Replay] replay schema %d is older than current %d — data may be incomplete" % [
			file_schema, SCHEMA_VERSION])

	var frames_var: Variant = root.get("frames", [])
	if not frames_var is Array: return false
	# Rebuild as typed Array[Dictionary], skipping any malformed entries.
	_frames.clear()
	for entry: Variant in (frames_var as Array):
		if entry is Dictionary:
			_frames.append(entry as Dictionary)
	return true

func frame_count() -> int:  return _frames.size()
func is_recording() -> bool: return _recording
func is_playing() -> bool:   return _playing

func duration() -> float:
	if _frames.is_empty(): return 0.0
	return float(_frames.back().get("t", 0.0))
