## RuntimeValidator — validates engine wiring on startup and after scene loads.
##
## Checks:
##   - All critical autoloads present in scene tree
##   - SystemScheduler has at least one system registered
##   - TaskScheduler has tasks scheduled
##   - EntityManager is accessible
##   - No duplicate class_name collisions (checks known pairs)
##   - Required Bus event handlers registered for core events
##   - Platform-specific checks (touch input on mobile)
##
## Emits validation_issue on Bus per issue found.
## Emits validation_passed when clean.
extends Node

const CRITICAL_AUTOLOADS : Array[String] = [
	"Bus", "Log", "Kernel", "Cfg", "TaskScheduler",
	"EntityManager", "SystemScheduler", "SystemRegistry",
	"GameLoop", "WorldManager",
]

const RECOMMENDED_AUTOLOADS : Array[String] = [
	"AudioManager", "UIStack", "SaveLoadManager",
	"DeviceCap", "AppLifecycle",
]

func _ready() -> void:
	Bus.on(&"engine_ready", _on_engine_ready)
	Bus.on(&"scene_loaded", _on_scene_loaded)

func _exit_tree() -> void:
	Bus.off(&"engine_ready", _on_engine_ready)
	Bus.off(&"scene_loaded", _on_scene_loaded)

func _on_engine_ready(_data: Variant) -> void:
	call_deferred("run")

func _on_scene_loaded(_data: Variant) -> void:
	call_deferred("run")

func run() -> void:
	var issues : Array[Dictionary] = []
	_check_autoloads(issues)
	_check_systems(issues)
	_check_tasks(issues)
	_check_bus_wiring(issues)
	_check_platform(issues)

	var errors   := issues.filter(func(i): return i.get("level", "") == "error").size()
	var warnings : int = issues.filter(func(i): return i.get("level", "") == "warn").size()

	for issue : Dictionary in issues:
		var lvl : String = str(issue.get("level", "warn"))
		var msg : String = str(issue.get("message", ""))
		if lvl == "error":
			Log.error("[RuntimeValidator] " + msg)
		else:
			Log.warn("[RuntimeValidator] " + msg)
		Bus.emit(&"validation_issue", issue)

	if issues.is_empty():
		Log.info("[RuntimeValidator] All checks passed")
		Bus.emit(&"validation_passed", {})
	else:
		Log.warn("[RuntimeValidator] %d errors, %d warnings" % [errors, warnings])

func _check_autoloads(issues: Array[Dictionary]) -> void:
	var root : Window = get_tree().root
	for name in CRITICAL_AUTOLOADS:
		if not root.has_node(name):
			issues.append({"level": "error",
				"message": "Missing critical autoload: %s" % name,
				"code": "missing_autoload"})
	for name in RECOMMENDED_AUTOLOADS:
		if not root.has_node(name):
			issues.append({"level": "warn",
				"message": "Missing recommended autoload: %s" % name,
				"code": "missing_recommended"})

func _check_systems(issues: Array[Dictionary]) -> void:
	if not get_tree().root.has_node("SystemRegistry"): return
	var systems := SystemRegistry.sorted_systems()
	if systems.is_empty():
		issues.append({"level": "warn",
			"message": "SystemRegistry has no registered systems",
			"code": "no_systems"})
	## Check for disabled critical systems.
	for s : SystemBase in systems:
		if not is_instance_valid(s): continue
		if not s.enabled:
			issues.append({"level": "warn",
				"message": "System disabled at startup: %s" % s.name,
				"code": "system_disabled"})

func _check_tasks(issues: Array[Dictionary]) -> void:
	if not get_tree().root.has_node("TaskScheduler"): return
	if TaskScheduler.task_count() == 0:
		issues.append({"level": "warn",
			"message": "TaskScheduler has no scheduled tasks",
			"code": "no_tasks"})

func _check_bus_wiring(issues: Array[Dictionary]) -> void:
	## These events should always have at least one listener by the time the
	## engine is ready. Missing listeners = a system failed to subscribe.
	var required_listeners : Array[StringName] = [
		&"log_entry", &"app_background", &"app_foreground",
	]
	for event : StringName in required_listeners:
		if Bus.listener_count(event) == 0:
			issues.append({"level": "warn",
				"message": "No listeners for required Bus event: %s" % event,
				"code": "missing_listener"})

func _check_platform(issues: Array[Dictionary]) -> void:
	if not Kernel.is_mobile: return
	## TouchInput should be registered.
	if not get_tree().root.has_node("TouchInput"):
		issues.append({"level": "warn",
			"message": "Mobile detected but TouchInput autoload is missing",
			"code": "missing_touch_input"})
	## NotchHandler should be active.
	if not get_tree().root.has_node("NotchHandler"):
		issues.append({"level": "warn",
			"message": "Mobile detected but NotchHandler is missing",
			"code": "missing_notch_handler"})
