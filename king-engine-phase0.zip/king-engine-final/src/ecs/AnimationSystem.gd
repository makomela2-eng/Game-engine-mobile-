## AnimationSystem — reacts to MovementSystem events and drives AnimationComponent.
##
## Guards:
##   has_parameter(): checks path exists before setting it — silent failures
##   in AnimationTree are the #1 source of hard-to-debug animation bugs.
##
##   Current-state tracking: only calls travel() when the target state
##   actually changes, not every frame. Prevents transition spam and
##   AnimationTree stuttering.
extends SystemBase

var _cache        : Array[int] = []
## entity_id → last requested animation StringName (dedup guard)
var _last_anim    : Dictionary = {}

func _on_start() -> void:
	priority = 2000
	listen(&"ecs.component_added",   _on_component_changed)
	listen(&"ecs.component_removed", _on_component_changed)
	listen(&"ecs.entity_destroyed",  _on_entity_destroyed)
	listen(&"ecs.entity_moved",      _on_entity_moved)
	listen(&"ecs.entity_stopped",    _on_entity_stopped)

func _on_stop() -> void:
	unlisten(&"ecs.component_added",   _on_component_changed)
	unlisten(&"ecs.component_removed", _on_component_changed)
	unlisten(&"ecs.entity_destroyed",  _on_entity_destroyed)
	unlisten(&"ecs.entity_moved",      _on_entity_moved)
	unlisten(&"ecs.entity_stopped",    _on_entity_stopped)

func _on_component_changed(evt: Variant) -> void:
	if not evt is Dictionary: return
	_revalidate(int((evt as Dictionary).get("entity", -1)))

func _on_entity_destroyed(evt: Variant) -> void:
	if not evt is Dictionary: return
	var id := int((evt as Dictionary).get("entity", -1))
	_cache.erase(id)
	_last_anim.erase(id)

func _revalidate(id: int) -> void:
	var qualifies := EntityManager.has_component(id, &"Animation")
	var in_cache  := _cache.has(id)
	if qualifies and not in_cache:
		_cache.append(id)
	elif not qualifies and in_cache:
		_cache.erase(id)
		_last_anim.erase(id)

func _on_entity_moved(evt: Variant) -> void:
	if evt is BusEvents.EntityMoved:
		_set_anim((evt as BusEvents.EntityMoved).entity, &"walk")

func _on_entity_stopped(evt: Variant) -> void:
	if evt is BusEvents.EntityStopped:
		_set_anim((evt as BusEvents.EntityStopped).entity, &"idle")

func _set_anim(id: int, anim: StringName) -> void:
	if not _cache.has(id): return
	## Dedup: don't travel if already in this state.
	if _last_anim.get(id) == anim: return
	var ac := EntityManager.get_component(id, &"Animation") as AnimationComponent
	if ac == null: return
	if ac.current_anim == anim: return
	ac.play(anim)
	_last_anim[id] = anim
	broadcast(&"ecs.animation_changed", id, {"animation": anim})

## Safe parameter setter with has_parameter guard.
## Call this from any system that writes AnimationTree parameters directly.
static func safe_set_param(tree: AnimationTree,
		path: StringName, value: Variant) -> bool:
	if not is_instance_valid(tree): return false
	## Godot 4: check the parameter exists before writing.
	var params : Array = tree.get_parameter_list()
	for p : Dictionary in params:
		if str(p.get("name", "")) == str(path):
			tree.set(str(path), value)
			return true
	return false
