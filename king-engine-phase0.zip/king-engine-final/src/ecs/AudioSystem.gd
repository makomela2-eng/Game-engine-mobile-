## AudioSystem — reacts to animation state changes from AnimationSystem.
##
## Composition chain:
##   AnimationSystem emits ecs.animation_changed
##   AudioSystem listens → updates AudioComponent.playing, emits audio.play_3d
##
## FIX: migrated to src/components/AudioComponent (data-only model).
##   No longer holds AudioStreamPlayer3D reference — sets ac.playing and emits
##   audio.play_3d for AudioDSPSystem to handle actual mixing.
extends SystemBase


var _cache: Array[int] = []

func _on_start() -> void:
	priority = 7000
	listen(&"ecs.component_added",   _on_component_changed)
	listen(&"ecs.component_removed", _on_component_changed)
	listen(&"ecs.entity_destroyed",  _on_entity_destroyed)
	listen(&"ecs.animation_changed", _on_animation_changed)

func _on_stop() -> void:
	unlisten(&"ecs.component_added",   _on_component_changed)
	unlisten(&"ecs.component_removed", _on_component_changed)
	unlisten(&"ecs.entity_destroyed",  _on_entity_destroyed)
	unlisten(&"ecs.animation_changed", _on_animation_changed)

# ── Cache ──────────────────────────────────────────────────────────────────────

func _on_component_changed(evt: Variant) -> void:
	if not evt is Dictionary: return
	_revalidate((evt as Dictionary).get("entity", -1))

func _on_entity_destroyed(evt: Variant) -> void:
	if not evt is Dictionary: return
	_cache.erase((evt as Dictionary).get("entity", -1))

func _revalidate(id: int) -> void:
	var qualifies := EntityManager.has_component(id, &"Audio")
	var in_cache  := _cache.has(id)
	if qualifies and not in_cache:
		_cache.append(id)
	elif not qualifies and in_cache:
		_cache.erase(id)

# ── Reactions ──────────────────────────────────────────────────────────────────

func _on_animation_changed(evt: Variant) -> void:
	if not evt is Dictionary: return
	var id: int   = (evt as Dictionary).get("entity", -1)
	if not _cache.has(id): return

	var ac := EntityManager.get_component(id, &"Audio") as AudioComponent
	if ac == null: return

	var anim: StringName = ((evt as Dictionary).get("data", {}) as Dictionary).get("animation", &"")
	var sound: StringName = &""
	if anim == &"walk":
		sound = ac.autoplay  ## Use autoplay cue for movement — extend as needed
	elif anim == &"idle":
		sound = &""          ## No sound on idle by default

	if sound != &"" and ac.playing != sound:
		ac.play(sound)
		Bus.emit(&"audio.play_3d", {
			"entity":  id,
			"cue":     sound,
			"bus":     ac.bus,
			"volume":  ac.volume_db,
			"pitch":   ac.pitch
		})
