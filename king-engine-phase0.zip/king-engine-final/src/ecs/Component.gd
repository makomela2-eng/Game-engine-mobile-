## Component — base class for all ECS components.
## Subclass this; never store raw Dictionaries as components.
##
## Write guard:
##   Call _debug_write_guard(SystemScheduler.frame_index) at the top of any
##   value mutation in a system. Zero cost in release builds. In debug builds,
##   asserts that no other system has already written this component this frame.
##
## Mutation model:
##   Structural mutations (add/remove component, spawn/destroy entity) →
##     CommandBuffer ONLY, applied at end-of-frame sync point.
##   Value mutations (writing fields on an existing component) →
##     Direct, but ONLY ONE system may write a given component type per frame.
##     Ownership enforced by _debug_write_guard in debug builds.
class_name Component
extends RefCounted

## Override in subclasses to return a stable type string.
## Used by EntityManager queries and debug tooling.
func component_type() -> StringName:
	return &""

## Frame on which this component was last written.
## -1 = never written this session.
var _last_writer_frame : int        = -1
var _last_writer_name  : StringName = &""

## Call this at the start of any direct value mutation from a system.
## frame — pass SystemScheduler.frame_index.
## writer — pass StringName(name) of the calling system (for error messages).
## In release builds this is a no-op. In debug builds it asserts single-writer
## invariant: only one system may mutate a given component instance per frame.
func _debug_write_guard(frame: int, writer: StringName = &"unknown") -> void:
	if not OS.is_debug_build():
		return
	if _last_writer_frame == frame and _last_writer_name != writer:
		push_error(
			"[Component] Multiple writers detected on '%s' in frame %d: " \
			% [str(component_type()), frame] +
			"'%s' already wrote, now '%s' is writing. " \
			% [str(_last_writer_name), str(writer)] +
			"Only ONE system may write a component type per frame."
		)
	_last_writer_frame = frame
	_last_writer_name  = writer
