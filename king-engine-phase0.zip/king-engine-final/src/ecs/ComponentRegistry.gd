## ComponentRegistry — maps component type StringNames to factory callables.
##
## PHASE 0 FIX: Replaces the hardcoded match block in EntityManager._deserialize_component()
## which silently returned null for any component type other than Transform and Velocity.
## This caused all other components (Health, IdleBehavior, Relation, etc.) to be
## silently dropped on save/load — data corruption with no error message.
##
## How it works:
##   Each component class registers a factory callable at engine boot.
##   EntityManager.deserialize_component() calls ComponentRegistry.create(type, data).
##   If the type is unknown, push_error fires — no silent null returns.
##
## Registration (call from GameBootstrap or Kernel._ready):
##   ComponentRegistry.register(&"Health", func(d): return HealthComponent.new().tap_deserialize(d))
##
## Or use the convenience helper:
##   ComponentRegistry.register_all_defaults()
##
## Adding a new component:
##   1. Create your XComponent class extending Component.
##   2. Implement serialize() → Dictionary and deserialize(data: Dictionary) → void.
##   3. Add one line to register_all_defaults() below.
extends Node

## StringName → Callable(data: Dictionary) → Component
var _factories : Dictionary = {}

# ── Registration ───────────────────────────────────────────────────────────────

func register(type: StringName, factory: Callable) -> void:
	if _factories.has(type):
		push_warning("[ComponentRegistry] Re-registering type: " + str(type))
	_factories[type] = factory
	Log.info("[ComponentRegistry] registered: " + str(type))

func unregister(type: StringName) -> void:
	_factories.erase(type)

func has_type(type: StringName) -> bool:
	return _factories.has(type)

func registered_types() -> Array[StringName]:
	var result : Array[StringName] = []
	for t in _factories.keys():
		result.append(t)
	return result

# ── Instantiation ──────────────────────────────────────────────────────────────

## Create and deserialize a component from saved data.
## Returns null ONLY if type is unknown — and always push_errors in that case.
## Never silently drops data.
func create(type: StringName, data: Dictionary) -> Component:
	if not _factories.has(type):
		push_error(
			"[ComponentRegistry] Unknown component type: '%s'. " % str(type) +
			"Register it in ComponentRegistry.register_all_defaults(). " +
			"Data will be LOST for this component."
		)
		return null
	var factory : Callable = _factories[type] as Callable
	if not factory.is_valid():
		push_error("[ComponentRegistry] Invalid factory for type: " + str(type))
		return null
	var comp : Variant = factory.call(data)
	if not comp is Component:
		push_error("[ComponentRegistry] Factory for '%s' did not return a Component." % str(type))
		return null
	return comp as Component

# ── Default registrations ──────────────────────────────────────────────────────

## Call once at boot (e.g. from GameBootstrap._ready or Kernel._ready).
## Add one line here per component class that needs save/load support.
func register_all_defaults() -> void:
	## Core movement
	register(&"Transform", func(d: Dictionary) -> Component:
		var c := TransformComponent.new()
		c.deserialize(d)
		return c)

	register(&"Velocity", func(d: Dictionary) -> Component:
		var c := VelocityComponent.new()
		c.deserialize(d)
		return c)

	## Gameplay
	register(&"Health", func(d: Dictionary) -> Component:
		var c := HealthComponent.new()
		c.deserialize(d)
		return c)

	## AI / behaviour
	register(&"IdleBehavior", func(d: Dictionary) -> Component:
		var c := IdleBehaviorComponent.new()
		c.deserialize(d)
		return c)

	register(&"Relation", func(d: Dictionary) -> Component:
		var c := RelationComponent.new()
		c.deserialize(d)
		return c)

	## Rendering / scene link
	## SceneNodeComponent holds a live Node3D reference — cannot be
	## meaningfully restored from JSON. Skip deserialization; the
	## SceneToEntityBridge re-creates it from the scene tree on load.
	## Registering it as a no-op prevents the unknown-type error.
	register(&"SceneNode", func(_d: Dictionary) -> Component:
		return null)   ## intentional null — bridge re-creates this

	## Rigidbody
	register(&"Rigidbody", func(d: Dictionary) -> Component:
		var c := RigidbodyComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## Animation
	register(&"Animation", func(d: Dictionary) -> Component:
		var c := AnimationComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## Audio
	register(&"Audio", func(d: Dictionary) -> Component:
		var c := AudioComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## Camera
	register(&"Camera", func(d: Dictionary) -> Component:
		var c := CameraComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## Light
	register(&"Light", func(d: Dictionary) -> Component:
		var c := LightComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## Mesh
	register(&"Mesh", func(d: Dictionary) -> Component:
		var c := MeshComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## Collider
	register(&"Collider", func(d: Dictionary) -> Component:
		var c := ColliderComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## Input
	register(&"Input", func(d: Dictionary) -> Component:
		var c := InputComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## Script
	register(&"Script", func(d: Dictionary) -> Component:
		var c := ScriptComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	## UI
	register(&"UI", func(d: Dictionary) -> Component:
		var c := UIComponent.new()
		if c.has_method("deserialize"):
			c.call("deserialize", d)
		return c)

	Log.info("[ComponentRegistry] %d types registered." % _factories.size())
