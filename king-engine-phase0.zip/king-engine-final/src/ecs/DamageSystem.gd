## DamageSystem — processes damage/heal events for ECS entities.
##
## To deal damage:
##   Bus.emit(&"ecs.damage", {"entity": id, "amount": 25.0, "source": attacker_id})
## To heal:
##   Bus.emit(&"ecs.heal",   {"entity": id, "amount": 10.0})
##
## Emits:
##   ecs.entity_damaged  -> { entity, data: { amount, hp, max_hp, pct, source } }
##   ecs.entity_healed   -> { entity, data: { amount, hp, max_hp, pct } }
##   ecs.entity_died     -> { entity, data: { source } }
##
## FIX: _tick_invincibility now accepts delta from TaskScheduler instead of
##   using a hardcoded dt = 0.05. The old value was only correct if the
##   scheduler fired exactly every 50ms — lag, jitter, or a rescheduled
##   interval would silently corrupt the i-frame timer. TaskScheduler passes
##   delta automatically when fn.get_argument_count() >= 1 (confirmed in v4).
extends SystemBase


const INVINCIBLE_SEC : float = 0.5   # i-frame window after taking damage

func _on_start() -> void:
	priority = 2500
	listen(&"ecs.damage",           _on_damage)
	listen(&"ecs.heal",             _on_heal)
	listen(&"ecs.component_added",  _on_comp_added)
	TaskScheduler.schedule(&"damage_system_tick", 0.05, _tick_invincibility)

func _on_stop() -> void:
	unlisten(&"ecs.damage",          _on_damage)
	unlisten(&"ecs.heal",            _on_heal)
	unlisten(&"ecs.component_added", _on_comp_added)
	TaskScheduler.unschedule(&"damage_system_tick")

# -- Damage -------------------------------------------------------------------

func _on_damage(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var id     : int   = int(d.get("entity", -1))
	var amount : float = float(d.get("amount", 0.0))
	var source : int   = int(d.get("source", -1))

	var hp := EntityManager.get_component(id, &"Health") as HealthComponent
	if hp == null or hp.dead or hp.invincible: return

	hp.hp = maxf(0.0, hp.hp - amount)
	hp.invincible       = true
	hp.invincible_timer = INVINCIBLE_SEC

	broadcast(&"ecs.entity_damaged", id, {
		"amount": amount, "hp": hp.hp,
		"max_hp": hp.max_hp, "pct": hp.pct(), "source": source
	})
	Log.debug("[DamageSystem] e%d took %.0f dmg -> %.0f/%.0f" % [id, amount, hp.hp, hp.max_hp])
	## Vibrate when the player takes a hit.
	if EntityManager.has_tag(id, &"player") and TouchInput.is_instance_valid(TouchInput):
		TouchInput.haptic_tap()

	if hp.hp <= 0.0:
		hp.dead = true
		broadcast(&"ecs.entity_died", id, {"source": source})
		Log.info("[DamageSystem] e%d died" % id)
		if EntityManager.has_tag(id, &"player") and TouchInput.is_instance_valid(TouchInput):
			TouchInput.haptic_confirm()

# -- Heal ---------------------------------------------------------------------

func _on_heal(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var id     : int   = int(d.get("entity", -1))
	var amount : float = float(d.get("amount", 0.0))

	var hp := EntityManager.get_component(id, &"Health") as HealthComponent
	if hp == null or hp.dead: return
	hp.heal(amount)

	broadcast(&"ecs.entity_healed", id, {
		"amount": amount, "hp": hp.hp,
		"max_hp": hp.max_hp, "pct": hp.pct()
	})

# -- I-frame tick -------------------------------------------------------------

## FIX: receives real delta from TaskScheduler (get_argument_count() == 1).
##   Replaces the hardcoded dt = 0.05 literal that was only correct at exactly
##   50ms tick rate with no jitter.
func _tick_invincibility(dt: float) -> void:
	for id: int in EntityManager.get_entities_with([&"Health"]):
		var hp := EntityManager.get_component(id, &"Health") as HealthComponent
		if hp == null or not hp.invincible: continue
		hp.invincible_timer -= dt
		if hp.invincible_timer <= 0.0:
			hp.invincible = false

# -- Auto-register ------------------------------------------------------------

func _on_comp_added(evt: Variant) -> void:
	if not evt is Dictionary: return
	var d := (evt as Dictionary).get("data", {}) as Dictionary
	if str(d.get("type", "")) == "Health":
		Log.debug("[DamageSystem] Health registered for e%d" % int((evt as Dictionary).get("entity", -1)))
