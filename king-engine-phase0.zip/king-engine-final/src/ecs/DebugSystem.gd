## DebugSystem — observes the full ECS event chain and logs it.
##
## Automatically disabled in release builds (OS.is_debug_build() == false).
## In editor/debug: logs entity lifecycle, component changes, moves, animations.
## Override log_moves = false to silence per-frame move spam in large worlds.
extends SystemBase

var log_moves      : bool = false   ## per-frame move events — noisy, off by default
var log_components : bool = true
var log_lifecycle  : bool = true
var log_animations : bool = true

func _on_start() -> void:
	priority = 8500
	## Auto-disable in release — no overhead in shipped builds.
	if not OS.is_debug_build():
		enabled = false
		return
	if log_lifecycle:
		listen(&"ecs.entity_created",    _on_created)
		listen(&"ecs.entity_destroyed",  _on_destroyed)
	if log_components:
		listen(&"ecs.component_added",   _on_comp_added)
		listen(&"ecs.component_removed", _on_comp_removed)
	if log_moves:
		listen(&"ecs.entity_moved",   _on_moved)
		listen(&"ecs.entity_stopped", _on_stopped)
	if log_animations:
		listen(&"ecs.animation_changed", _on_anim_changed)

func _on_stop() -> void:
	if log_lifecycle:
		unlisten(&"ecs.entity_created",    _on_created)
		unlisten(&"ecs.entity_destroyed",  _on_destroyed)
	if log_components:
		unlisten(&"ecs.component_added",   _on_comp_added)
		unlisten(&"ecs.component_removed", _on_comp_removed)
	if log_moves:
		unlisten(&"ecs.entity_moved",   _on_moved)
		unlisten(&"ecs.entity_stopped", _on_stopped)
	if log_animations:
		unlisten(&"ecs.animation_changed", _on_anim_changed)

func _on_created(evt: Variant) -> void:
	if not evt is Dictionary: return
	Log.debug("[ECS] e%d created" % int((evt as Dictionary).get("entity", -1)))

func _on_destroyed(evt: Variant) -> void:
	if not evt is Dictionary: return
	Log.debug("[ECS] e%d destroyed" % int((evt as Dictionary).get("entity", -1)))

func _on_comp_added(evt: Variant) -> void:
	if not evt is Dictionary: return
	var d := (evt as Dictionary).get("data", {}) as Dictionary
	Log.debug("[ECS] e%d += %s" % [
		int((evt as Dictionary).get("entity", -1)), d.get("type", "?")])

func _on_comp_removed(evt: Variant) -> void:
	if not evt is Dictionary: return
	var d := (evt as Dictionary).get("data", {}) as Dictionary
	Log.debug("[ECS] e%d -= %s" % [
		int((evt as Dictionary).get("entity", -1)), d.get("type", "?")])

func _on_moved(evt: Variant) -> void:
	if evt is BusEvents.EntityMoved:
		var e := evt as BusEvents.EntityMoved
		Log.debug("[ECS] e%d -> (%.1f,%.1f,%.1f)" % [
			e.entity, e.position.x, e.position.y, e.position.z])

func _on_stopped(evt: Variant) -> void:
	if evt is BusEvents.EntityStopped:
		Log.debug("[ECS] e%d stopped" % (evt as BusEvents.EntityStopped).entity)

func _on_anim_changed(evt: Variant) -> void:
	if not evt is Dictionary: return
	var d := (evt as Dictionary).get("data", {}) as Dictionary
	Log.debug("[ECS] e%d anim -> %s" % [
		int((evt as Dictionary).get("entity", -1)), d.get("animation", "?")])
