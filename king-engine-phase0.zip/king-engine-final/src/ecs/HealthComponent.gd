## HealthComponent — hit points with regen, invincibility frames, serialization.
class_name HealthComponent
extends Component

var hp               : float = 100.0
var max_hp           : float = 100.0
var dead             : bool  = false
var invincible       : bool  = false
var invincible_timer : float = 0.0
var regen_rate       : float = 0.0   ## hp per second when not dead

func _init(max_health: float = 100.0) -> void:
	max_hp = max_health
	hp     = max_health

func component_type() -> StringName:
	return &"Health"

func heal(amount: float) -> void:
	hp = minf(hp + amount, max_hp)

func is_full() -> bool:
	return hp >= max_hp

func pct() -> float:
	return hp / max_hp if max_hp > 0.0 else 0.0

## Full state snapshot — used by EntityManager and SaveManager.
func serialize() -> Dictionary:
	return {
		"hp":     hp,
		"max_hp": max_hp,
		"dead":   dead,
		"regen":  regen_rate,
	}

## Health is critical — always replicate, no delta skip.
func serialize_delta() -> Variant:
	return serialize()

func deserialize(data: Dictionary) -> void:
	hp         = float(data.get("hp",     max_hp))
	max_hp     = float(data.get("max_hp", 100.0))
	dead       = bool(data.get("dead",    false))
	regen_rate = float(data.get("regen",  0.0))
