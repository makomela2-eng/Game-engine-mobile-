## IdleBehaviorSystem — drives autonomous entity motion each tick.
##
## Reads IdleBehaviorComponent.mode and writes into:
##   • VelocityComponent.linear  (ORBIT, DRIFT, PATROL)
##   • TransformComponent.rotation.y  (SPIN)
##   • TransformComponent.position.y  (BOB)
##
## Velocity ownership:
##   Claims VelocityComponent as &"idle" before writing.
##   If the velocity is already claimed by another system, this system
##   skips that entity silently — it never force-overwrites another owner.
##
## Priority 800 — runs after input (500) but before physics (5000), so
## physics can apply gravity / move_and_slide on top of the idle velocity.
##
## Emits:
##   ecs.idle_behavior_changed  { entity, mode } — on first activation only,
##     so the Dashboard can flash the entity row in the viewport.
##
## Dashboard integration:
##   _affected_count is public — the Systems tab reads it for the per-system
##   entity count column (instead of the global entity count).
extends SystemBase

## Number of entities this system is actively driving this frame.
## Exposed so the Dashboard systems tab can display a real per-system count.
var _affected_count : int = 0

## Tracks the previous mode per entity for smooth transition detection.
## Dictionary[int, IdleBehaviorComponent.Mode]
var _prev_mode : Dictionary = {}

## Blend factor per entity during a mode transition. 0.0 = new mode, 1.0 = old.
## Dictionary[int, float]
var _blend     : Dictionary = {}

## Seconds over which velocity blends to the new mode target.
const TRANSITION_BLEND_TIME : float = 0.35

const REQUIRED : Array[StringName] = [&"IdleBehavior", &"Transform"]

func _on_start() -> void:
	priority = 800
	listen(&"ecs.component_added",   _on_component_changed)
	listen(&"ecs.component_removed", _on_component_changed)
	listen(&"ecs.entity_destroyed",  _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"ecs.component_added",   _on_component_changed)
	unlisten(&"ecs.component_removed", _on_component_changed)
	unlisten(&"ecs.entity_destroyed",  _on_entity_destroyed)

# ── Cache ──────────────────────────────────────────────────────────────────────

var _cache : Array[int] = []

func _on_component_changed(evt: Variant) -> void:
	if not evt is Dictionary: return
	_revalidate(int((evt as Dictionary).get("entity", -1)))

func _on_entity_destroyed(evt: Variant) -> void:
	if not evt is Dictionary: return
	var id := int((evt as Dictionary).get("entity", -1))
	_cache.erase(id)
	_prev_mode.erase(id)
	_blend.erase(id)

func _revalidate(id: int) -> void:
	var ok : bool = _qualify(id)
	if ok and not _cache.has(id):
		_cache.append(id)
	elif not ok:
		_cache.erase(id)

func _qualify(id: int) -> bool:
	for r : StringName in REQUIRED:
		if not EntityManager.has_component(id, r):
			return false
	return true

# ── Tick ───────────────────────────────────────────────────────────────────────

func tick(delta: float) -> void:
	_affected_count = 0
	for id : int in _cache:
		var ib := EntityManager.get_component(id, &"IdleBehavior") as IdleBehaviorComponent
		var tc := EntityManager.get_component(id, &"Transform")    as TransformComponent
		if ib == null or tc == null or ib.mode == IdleBehaviorComponent.Mode.NONE:
			_prev_mode.erase(id)
			_blend.erase(id)
			## PHASE 0 FIX: Release velocity ownership when this system is no
			## longer driving the entity. Without this, claim() persists and
			## blocks PhysicsSystem / Pathfinding from writing velocity.
			var vel_idle := EntityManager.get_component(id, &"Velocity") as VelocityComponent
			if vel_idle != null and vel_idle.is_owned_by(&"idle"):
				vel_idle.release_ownership()
			continue

		## Detect mode change — start a blend and apply smart defaults.
		var prev : int = _prev_mode.get(id, -1)
		if prev != int(ib.mode):
			if prev != -1:
				_blend[id] = 1.0   ## start blend from 1.0 (old) → 0.0 (new)
			_prev_mode[id] = int(ib.mode)

		_affected_count += 1

		## Compute new-mode desired velocity/transform into a scratch copy.
		var saved_linear := Vector3.ZERO
		var vel_comp := EntityManager.get_component(id, &"Velocity") as VelocityComponent
		if vel_comp != null:
			saved_linear = vel_comp.linear

		match ib.mode:
			IdleBehaviorComponent.Mode.ORBIT:   _tick_orbit(id, ib, tc, delta)
			IdleBehaviorComponent.Mode.DRIFT:   _tick_drift(id, ib, tc, delta)
			IdleBehaviorComponent.Mode.BOB:     _tick_bob(ib, tc, delta)
			IdleBehaviorComponent.Mode.SPIN:    _tick_spin(ib, tc, delta)
			IdleBehaviorComponent.Mode.PATROL:  _tick_patrol(id, ib, tc, delta)

		## Apply blend — lerp between old velocity and new-mode velocity.
		if _blend.has(id) and vel_comp != null:
			var blend_t : float = _blend[id]
			vel_comp.linear = vel_comp.linear.lerp(saved_linear, blend_t)
			_blend[id] = maxf(blend_t - delta / TRANSITION_BLEND_TIME, 0.0)
			if _blend[id] <= 0.0:
				_blend.erase(id)

# ── Mode implementations ───────────────────────────────────────────────────────

func _tick_orbit(id: int, ib: IdleBehaviorComponent,
		tc: TransformComponent, delta: float) -> void:
	ib.orbit_angle = fmod(ib.orbit_angle + ib.orbit_speed * delta, TAU)
	var target := ib.orbit_origin + Vector3(
		cos(ib.orbit_angle) * ib.orbit_radius,
		0.0,
		sin(ib.orbit_angle) * ib.orbit_radius)
	var vel_comp := EntityManager.get_component(id, &"Velocity") as VelocityComponent
	if vel_comp != null:
		if vel_comp.claim(&"idle", SystemScheduler.frame_index):
			vel_comp.linear = (target - tc.position) / maxf(delta, 0.00001)
			vel_comp.linear.y = 0.0
	else:
		## No velocity component — write position directly.
		tc.position = target

func _tick_drift(id: int, ib: IdleBehaviorComponent,
		_tc: TransformComponent, delta: float) -> void:
	ib._drift_timer -= delta
	if ib._drift_timer <= 0.0 or ib._drift_dir == Vector2.ZERO:
		ib._drift_timer = ib.drift_change_interval
		var angle := randf() * TAU
		ib._drift_dir = Vector2(cos(angle), sin(angle))
	var vel_comp := EntityManager.get_component(id, &"Velocity") as VelocityComponent
	if vel_comp != null and vel_comp.claim(&"idle", SystemScheduler.frame_index):
		vel_comp.linear.x = ib._drift_dir.x * ib.drift_speed
		vel_comp.linear.z = ib._drift_dir.y * ib.drift_speed

func _tick_bob(ib: IdleBehaviorComponent,
		tc: TransformComponent, delta: float) -> void:
	if not ib._bob_init:
		ib._bob_base_y = tc.position.y
		ib._bob_init   = true
	ib._bob_phase = fmod(ib._bob_phase + ib.bob_frequency * delta * TAU, TAU)
	tc.position.y = ib._bob_base_y + sin(ib._bob_phase) * ib.bob_amplitude

func _tick_spin(ib: IdleBehaviorComponent,
		tc: TransformComponent, delta: float) -> void:
	tc.rotation.y = fmod(tc.rotation.y + ib.spin_speed * delta, 360.0)

func _tick_patrol(id: int, ib: IdleBehaviorComponent,
		tc: TransformComponent, delta: float) -> void:
	var target : Vector3 = ib.patrol_b if ib._patrol_target == 1 else ib.patrol_a
	var to_target := target - tc.position
	to_target.y = 0.0
	var dist := to_target.length()
	if dist < 0.15:
		## Flip target.
		ib._patrol_target = 1 - ib._patrol_target
		return
	var vel_comp := EntityManager.get_component(id, &"Velocity") as VelocityComponent
	if vel_comp != null and vel_comp.claim(&"idle", SystemScheduler.frame_index):
		vel_comp.linear = (to_target.normalized() * ib.patrol_speed)
		vel_comp.linear.y = 0.0
