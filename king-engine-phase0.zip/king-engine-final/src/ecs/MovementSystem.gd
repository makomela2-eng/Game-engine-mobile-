## MovementSystem — applies Velocity to TransformComponent each frame.
##
## Single source of truth: TransformComponent.position is the canonical
## world position. PositionComponent has been removed — do not re-add it.
##
## Reactive cache: updated by component events, never full-scanned.
##
## _stopped is a Dictionary (entity_id -> true) for O(1) has/erase.
##
## Delta source:
##   SystemScheduler calls tick(delta) directly — delta is always valid.
##
## Emits:
##   ecs.entity_moved   -> BusEvents.EntityMoved  (entity, position, delta)
##   ecs.entity_stopped -> BusEvents.EntityStopped (state-change only)
extends SystemBase


var _cache   : Array[int] = []
## Dictionary[int, bool] — present means entity is currently at zero velocity.
var _stopped : Dictionary = {}
## Entities actively moving this frame. Read by Dashboard systems tab.
var _affected_count : int = 0

const REQUIRED: Array[StringName] = [&"Transform", &"Velocity"]

func _on_start() -> void:
	priority = 1000
	listen(&"ecs.component_added",   _on_component_changed)
	listen(&"ecs.component_removed", _on_component_changed)
	listen(&"ecs.entity_destroyed",  _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"ecs.component_added",   _on_component_changed)
	unlisten(&"ecs.component_removed", _on_component_changed)
	unlisten(&"ecs.entity_destroyed",  _on_entity_destroyed)

# -- Cache maintenance ---------------------------------------------------------

func _on_component_changed(evt: Variant) -> void:
	if not evt is Dictionary: return
	var id: int = (evt as Dictionary).get("entity", -1)
	_revalidate(id)

func _on_entity_destroyed(evt: Variant) -> void:
	if not evt is Dictionary: return
	var id: int = (evt as Dictionary).get("entity", -1)
	_cache.erase(id)
	_stopped.erase(id)

func _revalidate(id: int) -> void:
	var qualifies : bool = _qualify(id)
	var in_cache  : bool = _cache.has(id)
	if qualifies and not in_cache:
		_cache.append(id)
	elif not qualifies and in_cache:
		_cache.erase(id)
		_stopped.erase(id)

func _qualify(id: int) -> bool:
	for r: StringName in REQUIRED:
		if not EntityManager.has_component(id, r):
			return false
	return true

# -- Tick ----------------------------------------------------------------------

func tick(delta: float) -> void:
	_affected_count = 0
	for id: int in _cache:
		var transform := EntityManager.get_component(id, &"Transform") as TransformComponent
		var vel       := EntityManager.get_component(id, &"Velocity")  as VelocityComponent
		if transform == null or vel == null: continue

		if vel.linear.is_zero_approx():
			# O(1) lookup — emit only on the transition into stopped.
			if not _stopped.has(id):
				_stopped[id] = true
				Bus.emit(&"ecs.entity_stopped", BusEvents.EntityStopped.new(id))
			continue

		# Moving — clear stopped flag (O(1) erase).
		if _stopped.has(id):
			_stopped.erase(id)

		_affected_count += 1
		transform.position += vel.linear * delta
		Bus.emit(&"ecs.entity_moved",
			BusEvents.EntityMoved.new(id, transform.position, delta))
