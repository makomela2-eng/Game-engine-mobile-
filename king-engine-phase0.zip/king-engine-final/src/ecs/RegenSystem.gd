## RegenSystem — ticks HealthComponent.regen_rate each frame.
##
## PHASE 0 FIX: regen_rate was declared and serialized but never applied.
## This system is the single writer of health values due to passive regen.
##
## Priority: 150 — runs after input (10–99) and before DamageSystem (2500).
## This ordering guarantees: regen is applied → DamageSystem sees updated hp
## in the same frame. No buffering, no stale reads.
##
## Single-writer contract:
##   RegenSystem is the only system that writes hp via regen. DamageSystem
##   writes hp via damage/heal events. These are temporally separated by
##   priority order, not by locking — regen at 150, damage at 2500.
##   The debug write guard on Component will catch any future violation.
##
## Skips:
##   - Dead entities (hp.dead == true)
##   - Full entities (hp.is_full())
##   - Zero regen rate (no-op tick avoided)
##
## Future extension point:
##   When GAS is implemented, regen becomes a GameplayEffect with
##   modifier type REGEN applied to the Health attribute. This system
##   will either be replaced by EffectSystem or kept as a fallback
##   for entities without an AbilityComponent.
extends SystemBase

var _cache : Array[int] = []

func _on_start() -> void:
	priority = 150
	listen(&"ecs.component_added",   _on_component_changed)
	listen(&"ecs.component_removed", _on_component_changed)
	listen(&"ecs.entity_destroyed",  _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"ecs.component_added",   _on_component_changed)
	unlisten(&"ecs.component_removed", _on_component_changed)
	unlisten(&"ecs.entity_destroyed",  _on_entity_destroyed)

# ── Cache maintenance ──────────────────────────────────────────────────────────

func _on_component_changed(evt: Variant) -> void:
	if not evt is Dictionary: return
	_revalidate(int((evt as Dictionary).get("entity", -1)))

func _on_entity_destroyed(evt: Variant) -> void:
	if not evt is Dictionary: return
	_cache.erase(int((evt as Dictionary).get("entity", -1)))

func _revalidate(id: int) -> void:
	var qualifies := EntityManager.has_component(id, &"Health")
	var in_cache  := _cache.has(id)
	if qualifies and not in_cache:
		_cache.append(id)
	elif not qualifies and in_cache:
		_cache.erase(id)

# ── Tick ───────────────────────────────────────────────────────────────────────

func tick(delta: float) -> void:
	for id : int in _cache:
		var hp := EntityManager.get_component(id, &"Health") as HealthComponent
		if hp == null or hp.dead or hp.regen_rate <= 0.0 or hp.is_full():
			continue
		## Debug write guard: enforce single-writer invariant.
		hp._debug_write_guard(SystemScheduler.frame_index, &"RegenSystem")
		hp.heal(hp.regen_rate * delta)
		## Only broadcast if regen actually changed hp (avoids event spam
		## when entity was already full and is_full() just became true).
		if not hp.is_full():
			broadcast(&"ecs.entity_healed", id, {
				"amount": hp.regen_rate * delta,
				"hp":     hp.hp,
				"max_hp": hp.max_hp,
				"pct":    hp.pct(),
				"source": &"regen"
			})
