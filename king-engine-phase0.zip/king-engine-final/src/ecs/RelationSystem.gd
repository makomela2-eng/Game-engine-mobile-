## RelationSystem — inter-entity emergence forces.
##
## Runs AFTER IdleBehaviorSystem (priority 850) so that base intent is already
## written into VelocityComponent before we nudge it.
##
## Applies three additive forces to entities that have both IdleBehavior and
## Relation components:
##
##   1. SEPARATION  — repels entities that are too close together.
##   2. ALIGNMENT   — steers velocity toward the local neighbourhood average.
##   3. ORBIT PULL  — pulls orbit entities' orbit_origin toward each other,
##                    causing clusters to drift together organically.
##
## Critically:
##   • Never calls VelocityComponent.claim(). It writes vel.linear directly
##     as an additive nudge. This is intentional — it layers on top of
##     whatever system owns the velocity, not instead of it.
##   • Forces are scaled by delta so framerate independence is preserved.
##   • Spatial scan is O(n²) but capped per entity at RelationComponent.max_neighbours.
##
## Emits: nothing. Silent force application only.
##
## Dashboard: exposes _affected_count (entities with at least one neighbour
## interaction this frame) and _cache for system→entity highlight.
extends SystemBase

const REQUIRED : Array[StringName] = [&"IdleBehavior", &"Transform", &"Relation"]

var _cache          : Array[int] = []
var _affected_count : int        = 0

func _on_start() -> void:
	priority = 850   ## after IdleBehaviorSystem (800), before PhysicsSystem (5000)
	listen(&"ecs.component_added",   _on_component_changed)
	listen(&"ecs.component_removed", _on_component_changed)
	listen(&"ecs.entity_destroyed",  _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"ecs.component_added",   _on_component_changed)
	unlisten(&"ecs.component_removed", _on_component_changed)
	unlisten(&"ecs.entity_destroyed",  _on_entity_destroyed)

# ── Cache ──────────────────────────────────────────────────────────────────────

func _on_component_changed(evt: Variant) -> void:
	if not evt is Dictionary: return
	_revalidate(int((evt as Dictionary).get("entity", -1)))

func _on_entity_destroyed(evt: Variant) -> void:
	if not evt is Dictionary: return
	_cache.erase(int((evt as Dictionary).get("entity", -1)))

func _revalidate(id: int) -> void:
	var ok := _qualify(id)
	if ok and not _cache.has(id):
		_cache.append(id)
	elif not ok:
		_cache.erase(id)

func _qualify(id: int) -> bool:
	for r : StringName in REQUIRED:
		if not EntityManager.has_component(id, r):
			return false
	return true

# ── Tick ───────────────────────────────────────────────────────────────────────

func tick(delta: float) -> void:
	_affected_count = 0
	if _cache.is_empty(): return

	## Snapshot positions and velocities once — avoids redundant get_component
	## calls and prevents order-dependent reads within the same tick.
	var positions : Dictionary = {}    ## id → Vector3
	var velocities : Dictionary = {}   ## id → Vector3 (may be missing)
	var ibs : Dictionary = {}          ## id → IdleBehaviorComponent

	for id : int in _cache:
		var tc := EntityManager.get_component(id, &"Transform") as TransformComponent
		if tc == null: continue
		positions[id] = tc.position
		var vc := EntityManager.get_component(id, &"Velocity") as VelocityComponent
		if vc != null:
			velocities[id] = vc.linear
		var ib := EntityManager.get_component(id, &"IdleBehavior") as IdleBehaviorComponent
		if ib != null:
			ibs[id] = ib

	## Gather ALL entity positions for neighbour comparisons, not just the
	## relation-enabled subset — non-relation entities still block movement.
	var all_positions : Dictionary = {}
	for any_id : int in EntityManager.get_all_entities():
		var atc := EntityManager.get_component(any_id, &"Transform") as TransformComponent
		if atc != null:
			all_positions[any_id] = atc.position

	## Apply forces per relation entity.
	for id : int in _cache:
		if not positions.has(id): continue
		var rc := EntityManager.get_component(id, &"Relation") as RelationComponent
		if rc == null: continue

		var my_pos : Vector3 = positions[id]
		var sep_force   := Vector3.ZERO
		var align_sum   := Vector3.ZERO
		var align_count : int = 0
		var neighbour_checked : int = 0
		var had_interaction : bool = false

		## Scan all other entities for neighbour interactions.
		for other_id : int in all_positions:
			if other_id == id: continue
			if neighbour_checked >= rc.max_neighbours: break

			var other_pos : Vector3 = all_positions[other_id]
			var offset := my_pos - other_pos
			offset.y = 0.0   ## XZ plane interactions only
			var dist := offset.length()

			## ── Separation ──────────────────────────────────────────────────
			if dist < rc.sep_radius and dist > 0.001:
				var push_mag := rc.sep_strength * (1.0 - dist / rc.sep_radius)
				sep_force += offset.normalized() * push_mag
				had_interaction = true

			## ── Alignment — only with other relation entities that have vel ──
			if rc.align_strength > 0.0 and dist < rc.align_radius \
					and velocities.has(other_id):
				align_sum   += velocities[other_id]
				align_count += 1
				had_interaction = true

			neighbour_checked += 1

		## ── Orbit pull — only between ORBIT entities in _cache ──────────────
		if rc.orbit_pull_strength > 0.0 and ibs.has(id):
			var my_ib := ibs[id] as IdleBehaviorComponent
			if my_ib.mode == IdleBehaviorComponent.Mode.ORBIT:
				for other_id : int in ibs:
					if other_id == id: continue
					var other_ib := ibs[other_id] as IdleBehaviorComponent
					if other_ib.mode != IdleBehaviorComponent.Mode.ORBIT: continue
					var origin_offset := other_ib.orbit_origin - my_ib.orbit_origin
					origin_offset.y = 0.0
					var origin_dist := origin_offset.length()
					if origin_dist < rc.orbit_pull_radius and origin_dist > 0.01:
						var pull_mag := rc.orbit_pull_strength \
							* (1.0 - origin_dist / rc.orbit_pull_radius) * delta
						my_ib.orbit_origin += origin_offset.normalized() * pull_mag
					had_interaction = true

		if had_interaction:
			_affected_count += 1

		## ── Write forces back ────────────────────────────────────────────────
		var vc := EntityManager.get_component(id, &"Velocity") as VelocityComponent
		if vc != null:
			## Separation — hard additive push, scaled by delta.
			if sep_force.length_squared() > 0.0001:
				vc.linear += sep_force * delta

			## Alignment — gentle steer toward neighbour average velocity.
			if align_count > 0 and rc.align_strength > 0.0:
				var avg_vel := align_sum / float(align_count)
				var steer   := (avg_vel - vc.linear) * rc.align_strength
				steer.y = 0.0
				vc.linear += steer * delta
