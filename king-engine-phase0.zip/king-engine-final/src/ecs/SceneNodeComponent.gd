## SceneNodeComponent — links an ECS entity to a Godot Node3D.
## This is the bridge between pure-data ECS and the scene tree.
## LODManager, VisibilitySystem, etc. read this to find the renderable node.
class_name SceneNodeComponent
extends Component

var node: Node3D

func _init(n: Node3D = null) -> void:
	node = n

func component_type() -> StringName:
	return &"SceneNode"
