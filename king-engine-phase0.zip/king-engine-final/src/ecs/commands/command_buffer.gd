## CommandBuffer — deferred ECS mutations.
## Queue structural changes during a system tick, apply after all systems run.
## Prevents iterator invalidation when adding/removing entities mid-frame.
##
## Usage:
##   Commands.spawn().add(&"Transform", TransformComponent.new())
##   Commands.destroy(entity_id)
##   Commands.add_component(id, &"Tag", TagComponent.new())
##   # GameLoop calls Commands.flush() at end of each tick.
extends Node

enum CmdType { SPAWN, DESTROY, ADD_COMPONENT, REMOVE_COMPONENT, ADD_TAG, REMOVE_TAG }

var _queue : Array[Dictionary] = []

# ── Command builders ───────────────────────────────────────────────────────────

class SpawnBuilder extends RefCounted:
	var _cmds       : Array[Dictionary]
	var _components : Array[Dictionary] = []
	var _tags       : Array[StringName] = []

	func _init(queue: Array[Dictionary]) -> void:
		_cmds = queue

	func add(type: StringName, component: Component) -> SpawnBuilder:
		_components.append({"type": type, "component": component})
		return self

	func tag(t: StringName) -> SpawnBuilder:
		_tags.append(t)
		return self

	func commit() -> void:
		_cmds.append({
			"cmd": CmdType.SPAWN,
			"components": _components,
			"tags": _tags
		})

func spawn() -> SpawnBuilder:
	return SpawnBuilder.new(_queue)

func destroy(entity: int) -> void:
	_queue.append({"cmd": CmdType.DESTROY, "entity": entity})

func add_component(entity: int, type: StringName, component: Component) -> void:
	_queue.append({"cmd": CmdType.ADD_COMPONENT, "entity": entity, "type": type, "component": component})

func remove_component(entity: int, type: StringName) -> void:
	_queue.append({"cmd": CmdType.REMOVE_COMPONENT, "entity": entity, "type": type})

func add_tag(entity: int, tag: StringName) -> void:
	_queue.append({"cmd": CmdType.ADD_TAG, "entity": entity, "tag": tag})

func remove_tag(entity: int, tag: StringName) -> void:
	_queue.append({"cmd": CmdType.REMOVE_TAG, "entity": entity, "tag": tag})

# ── Flush ──────────────────────────────────────────────────────────────────────

func flush() -> void:
	var batch : Array[Dictionary] = _queue.duplicate()
	_queue.clear()
	for cmd : Dictionary in batch:
		match cmd.cmd:
			CmdType.SPAWN:
				var id := EntityManager.create_entity()
				for comp_data in (cmd.components as Array):
					var d := comp_data as Dictionary
					EntityManager.add_component(id, d.type, d.component)
				for t in (cmd.tags as Array):
					EntityManager.add_tag(id, t)
			CmdType.DESTROY:
				EntityManager.destroy_entity(cmd.entity)
			CmdType.ADD_COMPONENT:
				EntityManager.add_component(cmd.entity, cmd.type, cmd.component)
			CmdType.REMOVE_COMPONENT:
				EntityManager.remove_component(cmd.entity, cmd.type)
			CmdType.ADD_TAG:
				EntityManager.add_tag(cmd.entity, cmd.tag)
			CmdType.REMOVE_TAG:
				EntityManager.remove_tag(cmd.entity, cmd.tag)

func pending_count() -> int:
	return _queue.size()

func clear() -> void:
	_queue.clear()
