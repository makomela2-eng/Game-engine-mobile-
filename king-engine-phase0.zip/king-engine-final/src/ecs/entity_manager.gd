## EntityManager — core ECS registry.
## Stores entities and typed Component instances.
## Systems query via get_entities_with() — never iterate raw.
##
## Events (Bus, "ecs.*" namespace):
##   ecs.entity_created    → { entity, data: {} }
##   ecs.entity_destroyed  → { entity, data: {} }
##   ecs.component_added   → { entity, data: { type: StringName } }
##   ecs.component_removed → { entity, data: { type: StringName } }
extends Node

var _store      : Dictionary = {}  ## entity_id → { StringName → Component }
var _node_index : Dictionary = {}  ## node instance_id → entity_id
var _tags       : Dictionary = {}  ## entity_id → Array[StringName]
var _groups     : Dictionary = {}  ## StringName → Array[int]
var _next_id    : int = 0

# ── Helpers ────────────────────────────────────────────────────────────────────

func _evt(entity: int, data: Dictionary = {}) -> Dictionary:
	return {"entity": entity, "data": data}

func _index_node(entity_id: int, component: Component) -> void:
	if component is SceneNodeComponent:
		var sn := component as SceneNodeComponent
		if is_instance_valid(sn.node):
			_node_index[sn.node.get_instance_id()] = entity_id

func _unindex_entity(id: int) -> void:
	for node_id in _node_index.keys().duplicate():
		if _node_index[node_id] == id:
			_node_index.erase(node_id)

# ── Entity lifecycle ───────────────────────────────────────────────────────────

func create_entity() -> int:
	var id := _next_id
	_next_id += 1
	_store[id] = {}
	_tags[id]  = []
	Bus.emit(&"ecs.entity_created", _evt(id))
	return id

func create_entity_with_id(id: int) -> int:
	if id < 0:
		return create_entity()
	if _store.has(id):
		return id
	_store[id] = {}
	_tags[id]  = []
	if id >= _next_id:
		_next_id = id + 1
	Bus.emit(&"ecs.entity_created", _evt(id))
	return id

func destroy_entity(id: int) -> void:
	if not _store.has(id):
		return
	for type: StringName in (_store[id] as Dictionary).keys():
		Bus.emit(&"ecs.component_removed", _evt(id, {"type": type}))
	for tag: StringName in _tags.get(id, []):
		if _groups.has(tag):
			_groups[tag].erase(id)
	_unindex_entity(id)
	_store.erase(id)
	_tags.erase(id)
	Bus.emit(&"ecs.entity_destroyed", _evt(id))

func entity_exists(id: int) -> bool:
	return _store.has(id)

func entity_count() -> int:
	return _store.size()

func clear_all() -> void:
	_store.clear()
	_node_index.clear()
	_tags.clear()
	_groups.clear()
	_next_id = 0

# ── Component access ───────────────────────────────────────────────────────────

func add_component(id: int, type: StringName, component: Component) -> void:
	if not _store.has(id):
		Log.warn("[EntityManager] add_component on unknown entity %d" % id)
		return
	var comps: Dictionary = _store[id]
	if comps.has(type):
		var old_component: Variant = comps.get(type, null)
		if old_component is SceneNodeComponent:
			var old_sn := old_component as SceneNodeComponent
			if is_instance_valid(old_sn.node):
				_node_index.erase(old_sn.node.get_instance_id())
	comps[type] = component
	_index_node(id, component)
	Bus.emit(&"ecs.component_added", _evt(id, {"type": type}))

func get_component(id: int, type: StringName) -> Variant:
	if not _store.has(id):
		return null
	return _store[id].get(type, null)

func has_component(id: int, type: StringName) -> bool:
	if not _store.has(id):
		return false
	return _store[id].has(type)

func remove_component(id: int, type: StringName) -> void:
	if not _store.has(id) or not _store[id].has(type):
		return
	var component: Variant = _store[id].get(type, null)
	if component is SceneNodeComponent:
		var sn := component as SceneNodeComponent
		if is_instance_valid(sn.node):
			_node_index.erase(sn.node.get_instance_id())
	_store[id].erase(type)
	Bus.emit(&"ecs.component_removed", _evt(id, {"type": type}))

func get_components(id: int) -> Array[Component]:
	var result : Array[Component] = []
	if not _store.has(id):
		return result
	for comp in (_store[id] as Dictionary).values():
		result.append(comp)
	return result

func get_component_types(id: int) -> Array[StringName]:
	var result : Array[StringName] = []
	if not _store.has(id):
		return result
	for type in (_store[id] as Dictionary).keys():
		result.append(type)
	return result

# ── Queries ────────────────────────────────────────────────────────────────────

func get_entities_with(required: Array[StringName]) -> Array[int]:
	var result : Array[int] = []
	if required.is_empty():
		return get_all_entities()
	for id: int in _store:
		var comps : Dictionary = _store[id]
		var valid := true
		for r: StringName in required:
			if not comps.has(r):
				valid = false
				break
		if valid:
			result.append(id)
	return result

func get_entities_without(excluded: Array[StringName]) -> Array[int]:
	var result : Array[int] = []
	for id: int in _store:
		var comps : Dictionary = _store[id]
		var valid := true
		for e: StringName in excluded:
			if comps.has(e):
				valid = false
				break
		if valid:
			result.append(id)
	return result

func get_all_entities() -> Array[int]:
	var result : Array[int] = []
	for id: int in _store:
		result.append(id)
	return result

# ── Tags / Groups ──────────────────────────────────────────────────────────────

func add_tag(id: int, tag: StringName) -> void:
	if not _store.has(id):
		return
	if not (_tags[id] as Array).has(tag):
		(_tags[id] as Array).append(tag)
		if not _groups.has(tag):
			_groups[tag] = []
		(_groups[tag] as Array).append(id)

func remove_tag(id: int, tag: StringName) -> void:
	if _tags.has(id):
		(_tags[id] as Array).erase(tag)
	if _groups.has(tag):
		(_groups[tag] as Array).erase(id)

func has_tag(id: int, tag: StringName) -> bool:
	return _tags.has(id) and (_tags[id] as Array).has(tag)

func get_entities_by_tag(tag: StringName) -> Array[int]:
	var result : Array[int] = []
	if _groups.has(tag):
		for id in (_groups[tag] as Array):
			result.append(id)
	return result

func get_tags(id: int) -> Array[StringName]:
	var result : Array[StringName] = []
	if not _tags.has(id):
		return result
	for t in (_tags[id] as Array):
		result.append(t)
	return result

# ── Node index ─────────────────────────────────────────────────────────────────

func get_entity_id(node: Node) -> int:
	if not is_instance_valid(node):
		return -1
	return int(_node_index.get(node.get_instance_id(), -1))

# ── Snapshot / Restore ─────────────────────────────────────────────────────────

func snapshot(scene_root: Node = null) -> Dictionary:
	var entities : Array[Dictionary] = []
	for id: int in get_all_entities():
		var comps : Array[Dictionary] = []
		for type: StringName in get_component_types(id):
			var comp: Variant = get_component(id, type)
			if comp != null:
				comps.append(_serialize_component(type, comp, scene_root))
		entities.append({"id": id, "tags": get_tags(id), "components": comps})
	return {"version": 2, "entities": entities}

func snapshot_under(scene_root: Node = null) -> Dictionary:
	return snapshot(scene_root)

func restore_snapshot(data: Dictionary, scene_root: Node = null, clear_existing: bool = true) -> void:
	if data.is_empty():
		return
	if clear_existing:
		clear_all()
	var entities_var: Variant = data.get("entities", [])
	if not entities_var is Array:
		Log.warn("[EntityManager] restore_snapshot: missing entities array")
		return
	for entity_data in (entities_var as Array):
		if not entity_data is Dictionary:
			continue
		var d    := entity_data as Dictionary
		var id   := int(d.get("id", -1))
		if id < 0:
			continue
		create_entity_with_id(id)
		for tag in (d.get("tags", []) as Array):
			add_tag(id, StringName(str(tag)))
		for comp_data in (d.get("components", []) as Array):
			if not comp_data is Dictionary:
				continue
			var comp_dict  := comp_data as Dictionary
			var type_name  := StringName(str(comp_dict.get("type", "")))
			var comp       := _deserialize_component(comp_dict, scene_root)
			if comp != null:
				add_component(id, type_name, comp)

# ── Serialization ──────────────────────────────────────────────────────────────

func _serialize_component(type: StringName, component: Component, _scene_root: Node = null) -> Dictionary:
	var payload : Dictionary = {"type": str(type)}
	if component.has_method("serialize"):
		var result: Variant = component.call("serialize")
		if result is Dictionary:
			payload.merge(result)
	elif component is TransformComponent:
		var t := component as TransformComponent
		payload["position"] = var_to_str(t.position)
		payload["rotation"] = var_to_str(t.rotation)
		payload["scale"]    = var_to_str(t.scale)
	elif component is VelocityComponent:
		var v := component as VelocityComponent
		payload["linear"]  = var_to_str(v.linear)
		payload["angular"] = var_to_str(v.angular)
	return payload

func _deserialize_component(data: Dictionary, _scene_root: Node = null) -> Component:
	## PHASE 0 FIX: Replaced silent match block with ComponentRegistry.
	## Old code returned null for any type other than Transform and Velocity,
	## silently dropping Health, IdleBehavior, Relation, etc. on every load.
	## ComponentRegistry.create() push_errors on unknown types — no silent loss.
	var type_name := StringName(str(data.get("type", "")))
	if type_name == &"":
		push_error("[EntityManager] _deserialize_component: missing 'type' field in data: " + str(data))
		return null
	return ComponentRegistry.create(type_name, data)

func _as_vec3(value: Variant) -> Vector3:
	if value is Vector3:
		return value as Vector3
	if value is String:
		var parsed : Variant = str_to_var(value as String)
		if parsed is Vector3:
			return parsed as Vector3
	if value is Array and (value as Array).size() >= 3:
		var a := value as Array
		return Vector3(float(a[0]), float(a[1]), float(a[2]))
	return Vector3.ZERO

# ── Debug ──────────────────────────────────────────────────────────────────────

func debug_dump() -> void:
	Log.info("[EntityManager] %d entities:" % _store.size())
	for id: int in _store:
		var tags := get_tags(id)
		Log.info("  e%d  comps=%s  tags=%s" % [id, _store[id].keys(), tags])
