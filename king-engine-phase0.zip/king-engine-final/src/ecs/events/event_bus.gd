## EventBus — typed event queue for ECS events.
## Wraps the global Bus with typed dispatch and deferred flushing.
## Use for events that should process end-of-frame (e.g. death, collision).
##
## Usage:
##   EventBus.enqueue(&"entity.died", { entity = id, data = {} })
##   EventBus.flush()   ← called by GameLoop at end of tick
extends Node

var _queue : Array[Dictionary] = []  ## { event, payload }

func enqueue(event: StringName, payload: Dictionary = {}) -> void:
	_queue.append({"event": event, "payload": payload})

## Flush all queued events through Bus. Called once per frame by GameLoop.
func flush() -> void:
	var snapshot : Array[Dictionary] = _queue.duplicate()
	_queue.clear()
	for item : Dictionary in snapshot:
		Bus.emit(item.event, item.payload)

## Immediate dispatch — bypasses queue.
func dispatch(event: StringName, payload: Dictionary = {}) -> void:
	Bus.emit(event, payload)

func pending_count() -> int:
	return _queue.size()

func clear() -> void:
	_queue.clear()
