## EventTypes — canonical StringName constants for all engine events.
## Import this anywhere — avoids magic string typos.
##
## Convention: domain.verb  e.g. ecs.entity_created, audio.play
class_name EventTypes

# ECS
const ENTITY_CREATED    := &"ecs.entity_created"
const ENTITY_DESTROYED  := &"ecs.entity_destroyed"
const COMPONENT_ADDED   := &"ecs.component_added"
const COMPONENT_REMOVED := &"ecs.component_removed"

# Lifecycle
const GAME_STARTED   := &"game.started"
const GAME_PAUSED    := &"game.paused"
const GAME_RESUMED   := &"game.resumed"
const GAME_STOPPED   := &"game.stopped"
const SCENE_LOADED   := &"scene_loaded"
const SCENE_UNLOADED := &"scene_unloaded"

# Gameplay
const ENTITY_DAMAGED  := &"gameplay.entity_damaged"
const ENTITY_DIED     := &"gameplay.entity_died"
const ENTITY_HEALED   := &"gameplay.entity_healed"
const ABILITY_USED    := &"gameplay.ability_used"
const ITEM_PICKED_UP  := &"gameplay.item_picked_up"
const QUEST_UPDATED   := &"gameplay.quest_updated"
const INTERACTION     := &"gameplay.interaction"

# Input
const INPUT_ACTION    := &"input.action"
const INPUT_MOVE      := &"input.move"

# Audio
const AUDIO_PLAY      := &"audio.play"
const AUDIO_STOP      := &"audio.stop"

# UI
const UI_OPEN         := &"ui.open"
const UI_CLOSE        := &"ui.close"
const UI_DATA_CHANGED := &"ui.data_changed"

# Save
const SAVE_REQUESTED  := &"save.requested"
const LOAD_REQUESTED  := &"save.load_requested"
const SAVE_COMPLETED  := &"save.completed"
const LOAD_COMPLETED  := &"save.load_completed"

# Network
const NET_CONNECTED     := &"net.connected"
const NET_DISCONNECTED  := &"net.disconnected"
const NET_STATE_CHANGED := &"net.state_changed"

# Scheduler
const SCHEDULER_PAUSED  := &"scheduler.paused"
const SCHEDULER_RESUMED := &"scheduler.resumed"
