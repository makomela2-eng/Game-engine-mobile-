## EntityQuery — fluent result set returned by QueryBuilder.
## Iterate with for_each() or get results() directly.
class_name EntityQuery
extends RefCounted

var _results  : Array[int] = []
var _manager  : Node       = null  ## EntityManager ref

func _init(results: Array[int], manager: Node) -> void:
	_results = results.duplicate()
	_manager = manager

func results() -> Array[int]:
	return _results.duplicate()

func to_array() -> Array[int]:
	return results()

func count() -> int:
	return _results.size()

func is_empty() -> bool:
	return _results.is_empty()

func first() -> int:
	if _results.is_empty():
		return -1
	return _results[0]

## Call fn(entity_id: int) for each matching entity.
func for_each(fn: Callable) -> void:
	if not fn.is_valid():
		return
	for id in _results:
		fn.call(id)

## Call fn(entity_id: int, comp: Component) for each match.
func for_each_with(type: StringName, fn: Callable) -> void:
	if _manager == null or not fn.is_valid():
		return
	for id in _results:
		var c : Variant = _manager.get_component(id, type)
		if c != null:
			fn.call(id, c)

## Filter further — returns new EntityQuery.
func where(predicate: Callable) -> EntityQuery:
	if not predicate.is_valid():
		return EntityQuery.new(_results, _manager)
	var filtered : Array[int] = []
	for id in _results:
		if predicate.call(id):
			filtered.append(id)
	return EntityQuery.new(filtered, _manager)

func map(fn: Callable) -> Array:
	var out: Array = []
	if not fn.is_valid():
		return out
	for id in _results:
		out.append(fn.call(id))
	return out
