## QueryBuilder — fluent API for building ECS queries.
##
## Usage:
##   var q := QueryBuilder.new(EntityManager)##       .with(&"Transform").with(&"Velocity")##       .without(&"Dead")##       .tag(&"enemy")##       .build()
##   q.for_each(func(e): ...)
class_name QueryBuilder
extends RefCounted

var _manager  : Node
var _required : Array[StringName] = []
var _excluded : Array[StringName] = []
var _tags     : Array[StringName] = []

func _init(manager: Node) -> void:
	_manager = manager

func with(type: StringName) -> QueryBuilder:
	if not _required.has(type):
		_required.append(type)
	return self

func without(type: StringName) -> QueryBuilder:
	if not _excluded.has(type):
		_excluded.append(type)
	return self

func tag(t: StringName) -> QueryBuilder:
	if not _tags.has(t):
		_tags.append(t)
	return self

func build() -> EntityQuery:
	if _manager == null:
		return EntityQuery.new([], null)
	var candidates : Array = _manager.get_entities_with(_required)

	if not _excluded.is_empty():
		candidates = candidates.filter(func(id):
			for ex in _excluded:
				if _manager.has_component(id, ex):
					return false
			return true
		)

	if not _tags.is_empty():
		candidates = candidates.filter(func(id):
			for t in _tags:
				if not _manager.has_tag(id, t):
					return false
			return true
		)

	return EntityQuery.new(candidates, _manager)
