## QuerySystem — cached archetype queries for hot paths.
##
## PHASE 0 FIX: Per-component-type dirty invalidation via bitmask.
##
## Old behaviour (broken):
##   Any ecs.component_added/removed/entity event → ALL cached queries dirtied.
##   With 8 active queries, adding a Velocity component rebuilds every query
##   next frame including unrelated ones like [SceneNode, Mesh].
##
## New behaviour (correct):
##   ecs.component_added{type:"Velocity"} → only queries that REQUIRE "Velocity"
##   are dirtied. Queries with no overlap are untouched.
##
##   Entity create/destroy still dirties all queries because entity count
##   changes can affect any result set.
##
## Bitmask model:
##   _type_to_bit assigns each first-seen StringName component type a unique
##   power-of-two int. Each registered query stores the OR of its required
##   types' bits in _query_mask. Dirty check = single bitwise AND, O(1),
##   zero allocations.
##
##   Supports up to 62 distinct component types (64-bit int, bit 0 unused).
##   Overflow falls back to mark-all with a warning (safe, not silent).
##
## API is identical — no call sites change.
extends Node

## sorted-key → Array[int]
var _cache       : Dictionary = {}
## sorted-key → bool
var _dirty       : Dictionary = {}
## sorted-key → int (OR of required type bits)
var _query_mask  : Dictionary = {}
## StringName → power-of-two int
var _type_to_bit : Dictionary = {}
var _next_bit    : int        = 1

func _ready() -> void:
	Bus.on(&"ecs.entity_created",    _on_entity_structural)
	Bus.on(&"ecs.entity_destroyed",  _on_entity_structural)
	Bus.on(&"ecs.component_added",   _on_component_event)
	Bus.on(&"ecs.component_removed", _on_component_event)

func _exit_tree() -> void:
	Bus.off(&"ecs.entity_created",    _on_entity_structural)
	Bus.off(&"ecs.entity_destroyed",  _on_entity_structural)
	Bus.off(&"ecs.component_added",   _on_component_event)
	Bus.off(&"ecs.component_removed", _on_component_event)

# ── Dirty propagation ──────────────────────────────────────────────────────────

func _on_entity_structural(_data: Variant) -> void:
	for key in _dirty.keys():
		_dirty[key] = true

func _on_component_event(data: Variant) -> void:
	if not data is Dictionary:
		_mark_all_dirty()
		return
	var payload  := data as Dictionary
	var data_var : Variant = payload.get("data", null)
	if not data_var is Dictionary:
		_mark_all_dirty()
		return
	var type_var : Variant = (data_var as Dictionary).get("type", null)
	if type_var == null:
		_mark_all_dirty()
		return
	var changed_bit := _bit_for(StringName(str(type_var)))
	for key in _dirty.keys():
		if int(_query_mask.get(key, 0)) & changed_bit != 0:
			_dirty[key] = true

func _mark_all_dirty() -> void:
	for key in _dirty.keys():
		_dirty[key] = true

# ── Query API ──────────────────────────────────────────────────────────────────

func query(required: Array[StringName]) -> Array[int]:
	var key := _make_key(required)
	_ensure_registered(key, required)
	if _dirty.get(key, true):
		_cache[key] = EntityManager.get_entities_with(required)
		_dirty[key] = false
	var cached : Variant = _cache.get(key, [])
	if cached is Array:
		return (cached as Array).duplicate()
	return []

func query_without(required: Array[StringName],
		excluded: Array[StringName]) -> Array[int]:
	var result : Array[int] = []
	for id in query(required):
		var ok := true
		for ex : StringName in excluded:
			if EntityManager.has_component(id, ex):
				ok = false
				break
		if ok:
			result.append(id)
	return result

func query_tagged(required: Array[StringName],
		tag: StringName) -> Array[int]:
	var result : Array[int] = []
	for id in query(required):
		if EntityManager.has_tag(id, tag):
			result.append(id)
	return result

func build(required: Array[StringName]) -> EntityQuery:
	return QueryBuilder.new(EntityManager).with_all(required).build()

func invalidate() -> void:
	for key in _cache.keys():
		_dirty[key] = true

func invalidate_key(required: Array[StringName]) -> void:
	var key := _make_key(required)
	if _dirty.has(key):
		_dirty[key] = true

func cache_size() -> int:
	return _cache.size()

func type_count() -> int:
	return _type_to_bit.size()

# ── Internal ───────────────────────────────────────────────────────────────────

func _make_key(types: Array[StringName]) -> String:
	var sorted : Array[StringName] = types.duplicate()
	sorted.sort()
	return ",".join(sorted)

func _ensure_registered(key: String, required: Array[StringName]) -> void:
	if _query_mask.has(key):
		return
	var mask := 0
	for t : StringName in required:
		mask |= _bit_for(t)
	_query_mask[key] = mask
	_dirty[key]      = true

func _bit_for(type: StringName) -> int:
	if _type_to_bit.has(type):
		return int(_type_to_bit[type])
	if _next_bit <= 0:
		push_warning("[QuerySystem] Bitmask overflow (>62 component types). Falling back to mark-all for: " + str(type))
		return -1   ## -1 & anything != 0 → safe: marks dirty
	var bit := _next_bit
	_next_bit          = _next_bit << 1
	_type_to_bit[type] = bit
	return bit
