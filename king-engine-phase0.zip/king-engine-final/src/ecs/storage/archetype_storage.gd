## ArchetypeStorage — groups entities that share the exact same component set.
## Enables O(1) archetype lookup and tight iteration for matching systems.
class_name ArchetypeStorage
extends RefCounted

## Key: sorted comma-joined StringName list  →  Value: Array[int] entity ids
var _archetypes : Dictionary = {}
var _entity_arch : Dictionary = {}  ## entity_id → archetype key

func get_archetype_key(types: Array[StringName]) -> String:
	var sorted : Array[StringName] = types.duplicate()
	sorted.sort()
	return ",".join(sorted)

func register_entity(entity: int, types: Array[StringName]) -> void:
	var key := get_archetype_key(types)
	if not _archetypes.has(key):
		_archetypes[key] = []
	if not (_archetypes[key] as Array).has(entity):
		(_archetypes[key] as Array).append(entity)
	_entity_arch[entity] = key

func unregister_entity(entity: int) -> void:
	var key : String = _entity_arch.get(entity, "")
	if key != "" and _archetypes.has(key):
		(_archetypes[key] as Array).erase(entity)
	_entity_arch.erase(entity)

func query_matching(required: Array[StringName]) -> Array[int]:
	var result : Array[int] = []
	for key in _archetypes.keys():
		if _key_contains_all(key, required):
			for id in (_archetypes[key] as Array):
				result.append(id)
	return result

func _key_contains_all(arch_key: String, required: Array[StringName]) -> bool:
	var parts := arch_key.split(",")
	for r: StringName in required:
		if not parts.has(str(r)):
			return false
	return true

func archetype_count() -> int:
	return _archetypes.size()

func entity_count() -> int:
	return _entity_arch.size()
