## ComponentStorage — dense array storage for a single component type.
## More cache-friendly than EntityManager's Dictionary-of-Dictionaries
## for systems that iterate thousands of entities of the same archetype.
class_name ComponentStorage
extends RefCounted

var _type       : StringName
var _entity_ids : Array[int]       = []
var _components : Array[Component] = []
var _index      : Dictionary       = {}  ## entity_id → array index

func _init(type: StringName) -> void:
	_type = type

func add(entity: int, component: Component) -> void:
	if _index.has(entity):
		_components[_index[entity]] = component
		return
	_index[entity] = _entity_ids.size()
	_entity_ids.append(entity)
	_components.append(component)

func remove(entity: int) -> void:
	if not _index.has(entity):
		return
	var idx  : int = _index[entity]
	var last : int = _entity_ids.size() - 1
	if idx != last:
		# Swap with last to keep dense
		var last_entity : int = _entity_ids[last]
		_entity_ids[idx]  = last_entity
		_components[idx]  = _components[last]
		_index[last_entity] = idx
	_entity_ids.resize(last)
	_components.resize(last)
	_index.erase(entity)

func get_component(entity: int) -> Component:
	if not _index.has(entity):
		return null
	return _components[_index[entity]]

func has(entity: int) -> bool:
	return _index.has(entity)

func count() -> int:
	return _entity_ids.size()

func entities() -> Array[int]:
	return _entity_ids

func components() -> Array[Component]:
	return _components

func clear() -> void:
	_entity_ids.clear()
	_components.clear()
	_index.clear()
