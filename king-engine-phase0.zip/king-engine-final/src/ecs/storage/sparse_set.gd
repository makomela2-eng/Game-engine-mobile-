## SparseSet — O(1) add/remove/has, cache-friendly dense iteration.
## Used internally by ComponentStorage for entity membership.
class_name SparseSet
extends RefCounted

const INVALID := -1

var _dense  : Array[int] = []  ## Dense packed ids
var _sparse : Dictionary = {}  ## id → index into _dense

func add(id: int) -> void:
	if has(id):
		return
	_sparse[id] = _dense.size()
	_dense.append(id)

func remove(id: int) -> void:
	if not has(id):
		return
	var idx  : int = _sparse[id]
	var last : int = _dense.size() - 1
	if idx != last:
		var last_id : int = _dense[last]
		_dense[idx]       = last_id
		_sparse[last_id]  = idx
	_dense.resize(last)
	_sparse.erase(id)

func has(id: int) -> bool:
	return _sparse.has(id)

func size() -> int:
	return _dense.size()

func is_empty() -> bool:
	return _dense.is_empty()

func get_dense() -> Array[int]:
	return _dense

func clear() -> void:
	_dense.clear()
	_sparse.clear()

func index_of(id: int) -> int:
	return _sparse.get(id, INVALID)
