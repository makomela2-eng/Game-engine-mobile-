## SystemBase — base class for all KING ECS systems.
##
## Lifecycle:
##   _on_start()   → called on _ready(). Subscribe to Bus events here.
##   tick(delta)   → called each frame by SystemScheduler (not _process).
##   _on_stop()    → called on _exit_tree(). Unsubscribe everything here.
##
## Event convention:
##   listen / unlisten via helpers below.
##   Payload: { "entity": int, "data": Dictionary }
##   broadcast uses "ecs.*" namespace.
##
## Priority: lower number = ticks first. Set in subclass.
class_name SystemBase
extends Node

## Override in subclass to control tick order (lower = earlier).
var priority   : int  = 100
var enabled    : bool = true

var _subs : Array = []  ## [{ event, fn }] — for bulk cleanup

# ── Lifecycle ──────────────────────────────────────────────────────────────────

func _ready() -> void:
	# Let subclasses set priority / flags before the registry snapshots them.
	_on_start()
	SystemRegistry.register(self)

func _exit_tree() -> void:
	SystemRegistry.unregister(self)
	_on_stop()
	_cleanup_subs()

func _on_start() -> void:
	pass

func _on_stop() -> void:
	pass

func tick(_delta: float) -> void:
	pass

# ── Bus helpers ────────────────────────────────────────────────────────────────

func listen(event: StringName, fn: Callable) -> void:
	Bus.on(event, fn)
	_subs.append({"event": event, "fn": fn})

func unlisten(event: StringName, fn: Callable) -> void:
	Bus.off(event, fn)
	_subs = _subs.filter(func(s): return not (s.event == event and s.fn == fn))

func broadcast(event: StringName, entity: int, data: Dictionary = {}) -> void:
	Bus.emit(event, {"entity": entity, "data": data})

func _cleanup_subs() -> void:
	for s in _subs:
		Bus.off(s.event, s.fn)
	_subs.clear()

# ── Query shorthand ────────────────────────────────────────────────────────────

func query(required: Array[StringName]) -> Array[int]:
	return EntityManager.get_entities_with(required)

func get_c(entity: int, type: StringName) -> Component:
	return EntityManager.get_component(entity, type)
