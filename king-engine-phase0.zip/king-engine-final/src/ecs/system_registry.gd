## SystemRegistry — tracks all active systems by name.
## Used by SystemScheduler and editor tooling.
## Emits system_registry_changed on Bus when the registry changes so
## SystemScheduler can invalidate its sorted cache.
extends Node

var _systems : Dictionary = {}   ## StringName → SystemBase

func register(system: SystemBase) -> void:
	var key := StringName(system.name)
	if _systems.has(key):
		Log.warn("[SystemRegistry] Duplicate system name: %s — unregistering old" % key)
		_systems.erase(key)
	_systems[key] = system
	Bus.emit(&"system_registry_changed", {"action": "register", "name": key})
	Log.info("[SystemRegistry] + %s (priority %d)" % [key, system.priority])

func unregister(system: SystemBase) -> void:
	var key := StringName(system.name)
	if _systems.erase(key):
		Bus.emit(&"system_registry_changed", {"action": "unregister", "name": key})

func get_system(svc_name: StringName) -> SystemBase:
	return _systems.get(svc_name, null)

func has_system(svc_name: StringName) -> bool:
	return _systems.has(svc_name)

func all_systems() -> Array[SystemBase]:
	var result : Array[SystemBase] = []
	for s in _systems.values():
		if is_instance_valid(s):
			result.append(s)
	return result

func sorted_systems() -> Array[SystemBase]:
	var list := all_systems()
	list.sort_custom(func(a: SystemBase, b: SystemBase) -> bool:
		if a.priority == b.priority:
			return String(a.name) < String(b.name)
		return a.priority < b.priority)
	return list

func enabled_systems() -> Array[SystemBase]:
	return all_systems().filter(func(s: SystemBase) -> bool: return s.enabled)

func system_count() -> int:
	return _systems.size()

func debug_dump() -> void:
	Log.info("[SystemRegistry] %d systems:" % _systems.size())
	for s in sorted_systems():
		Log.info("  [%04d] %-40s enabled=%s" % [s.priority, s.name, s.enabled])
