## SystemScheduler — drives tick() on all registered systems in priority order.
##
## Sorted cache: only re-sorts when SystemRegistry signals a change,
## not every frame. With 80+ systems this cuts O(n log n) to O(1) per frame.
##
## Per-system profiling: wraps each tick in Profiler.begin/end so Dashboard
## and DebugOverlay can show hotspots without separate instrumentation.
##
## Frame budget guard: if a single system takes > budget_warn_ms, logs a warning
## once per second per system (rate-limited to avoid log floods).
extends Node

var paused          : bool  = false
var frame_index     : int   = 0
var budget_warn_ms  : float = 8.0   ## warn if one system takes longer than this

var _sorted_cache   : Array[SystemBase] = []
var _cache_dirty    : bool              = true
var _warn_timers    : Dictionary        = {}   ## system name → last warn time

func _ready() -> void:
	set_process(true)
	add_to_group("system_scheduler")
	Bus.on(&"system_registry_changed", _on_registry_changed)

func _exit_tree() -> void:
	Bus.off(&"system_registry_changed", _on_registry_changed)

func _on_registry_changed(_data: Variant) -> void:
	_cache_dirty = true

func _get_sorted() -> Array[SystemBase]:
	if _cache_dirty:
		_sorted_cache = SystemRegistry.sorted_systems()
		_cache_dirty  = false
	return _sorted_cache

func _process(delta: float) -> void:
	if paused:
		return
	frame_index += 1
	var systems := _get_sorted()
	for system : SystemBase in systems:
		if system == null or not is_instance_valid(system):
			continue
		if not system.enabled:
			continue
		if not system.is_inside_tree():
			continue
		## Profile each system tick.
		var scope := StringName(system.name)
		Profiler.begin(scope)
		system.tick(delta)
		Profiler.end(scope)
		## Warn on budget overrun (rate-limited to once per second per system).
		var tick_ms := Profiler.get_ms(scope)
		if tick_ms > budget_warn_ms:
			var now := Time.get_ticks_msec() * 0.001
			if float(_warn_timers.get(scope, 0.0)) + 1.0 < now:
				_warn_timers[scope] = now
				Log.warn("[SystemScheduler] %s took %.1f ms (budget %.0f ms)" \
					% [system.name, tick_ms, budget_warn_ms])
	if Commands != null and Commands.has_method("flush"):
		Commands.flush()
	if EventBus != null and EventBus.has_method("flush"):
		EventBus.flush()

func pause() -> void:
	paused = true
	Bus.emit(&"scheduler.paused", {})

func resume() -> void:
	paused = false
	Bus.emit(&"scheduler.resumed", {})

func set_system_enabled(svc_name: StringName, enabled: bool) -> void:
	var s := SystemRegistry.get_system(svc_name)
	if s:
		s.enabled = enabled
		_cache_dirty = true

func is_paused() -> bool:
	return paused

func invalidate_cache() -> void:
	_cache_dirty = true
