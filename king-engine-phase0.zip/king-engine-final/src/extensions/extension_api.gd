## ExtensionAPI — stable public surface for mods and plugins.
##
## Mods should ONLY use this — never access engine autoloads directly.
## This surface provides version negotiation, capability checks, and a
## sandboxed event scope so mods can't silently wire to internal events.
##
## Lifecycle:
##   1. Mod calls ExtensionAPI.negotiate(mod_id, required_api_version)
##   2. If version is compatible, mod receives an ApiHandle scoped to its id.
##   3. Mod uses handle.on() / handle.emit() — scoped to its namespace.
##   4. On mod unload, handle.dispose() cleans up all listeners.
extends Node

const API_VERSION := 2   ## Increment when breaking changes are made.

## mod_id → ApiHandle
var _handles : Dictionary = {}

func _ready() -> void:
	Log.info("[ExtensionAPI] v%d ready" % API_VERSION)

# ── Version negotiation ────────────────────────────────────────────────────────

## Returns an ApiHandle if version is compatible, null otherwise.
func negotiate(mod_id: StringName, required_version: int) -> RefCounted:
	if required_version > API_VERSION:
		Log.error("[ExtensionAPI] mod '%s' requires API v%d, engine has v%d" \
			% [mod_id, required_version, API_VERSION])
		return null
	if _handles.has(mod_id):
		return _handles[mod_id]
	var handle := ApiHandle.new(mod_id)
	_handles[mod_id] = handle
	Log.info("[ExtensionAPI] '%s' registered (requested v%d)" % [mod_id, required_version])
	return handle

func revoke(mod_id: StringName) -> void:
	if _handles.has(mod_id):
		(_handles[mod_id] as ApiHandle).dispose()
		_handles.erase(mod_id)
		Log.info("[ExtensionAPI] '%s' revoked" % mod_id)

func has_mod(mod_id: StringName) -> bool:
	return _handles.has(mod_id)

func loaded_mods() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _handles.keys(): result.append(k)
	return result

# ── Direct API (no handle — for trusted code only) ─────────────────────────────

func create_entity() -> int:
	return EntityManager.create_entity()

func destroy_entity(id: int) -> void:
	Commands.destroy(id)

func add_component(entity: int, type: StringName, component: Component) -> void:
	Commands.add_component(entity, type, component)

func get_component(entity: int, type: StringName) -> Component:
	return EntityManager.get_component(entity, type)

func query(required: Array[StringName]) -> Array[int]:
	return EntityManager.get_entities_with(required)

func tag(entity: int, t: StringName) -> void:
	Commands.add_tag(entity, t)

func on(event: StringName, fn: Callable) -> void:
	Bus.on(event, fn)

func off(event: StringName, fn: Callable) -> void:
	Bus.off(event, fn)

func emit(event: StringName, data: Dictionary = {}) -> void:
	Bus.emit(event, data)

func get_resource(id: StringName) -> Resource:
	return ResourceManager.get_resource(id)

func register_asset(id: StringName, path: String) -> void:
	ResourceManager.register(id, path)

func get_data(table: StringName, id: StringName) -> Dictionary:
	return DataRegistry.get_entry(table, id)

func load_data_table(name: StringName, path: String) -> void:
	DataRegistry.load_table(name, path)

func play_sound(id: StringName, bus: StringName = &"SFX") -> void:
	AudioManager.play_once(id, bus)

func log_info(msg: String)  -> void: Log.info("[MOD] "  + msg)
func log_warn(msg: String)  -> void: Log.warn("[MOD] "  + msg)
func log_error(msg: String) -> void: Log.error("[MOD] " + msg)

func api_version() -> int: return API_VERSION

# ── ApiHandle — scoped handle per mod ─────────────────────────────────────────

class ApiHandle extends RefCounted:
	var mod_id    : StringName
	var _subs     : Array[Dictionary] = []   ## { event, fn }
	var _disposed : bool = false

	func _init(id: StringName) -> void:
		mod_id = id

	## Subscribe to a Bus event. Automatically cleaned up on dispose().
	func on(event: StringName, fn: Callable) -> void:
		if _disposed or not fn.is_valid(): return
		Bus.on(event, fn)
		_subs.append({"event": event, "fn": fn})

	func off(event: StringName, fn: Callable) -> void:
		Bus.off(event, fn)
		_subs = _subs.filter(func(s): return not (s.event == event and s.fn == fn))

	## Emit an event namespaced to this mod: "mod.<mod_id>.<event>"
	func emit(event: StringName, data: Dictionary = {}) -> void:
		var namespaced := StringName("mod.%s.%s" % [mod_id, event])
		Bus.emit(namespaced, data)

	## Emit a global event (use sparingly — prefer namespaced).
	func emit_global(event: StringName, data: Dictionary = {}) -> void:
		Bus.emit(event, data)

	func create_entity() -> int: return EntityManager.create_entity()
	func destroy_entity(id: int) -> void: Commands.destroy(id)
	func add_component(entity: int, type: StringName, comp: Component) -> void:
		Commands.add_component(entity, type, comp)
	func get_component(entity: int, type: StringName) -> Component:
		return EntityManager.get_component(entity, type)
	func query(required: Array[StringName]) -> Array[int]:
		return EntityManager.get_entities_with(required)
	func get_data(table: StringName, id: StringName) -> Dictionary:
		return DataRegistry.get_entry(table, id)
	func get_resource(id: StringName) -> Resource:
		return ResourceManager.get_resource(id)
	func log_info(msg: String) -> void:
		Log.info("[%s] %s" % [mod_id, msg])
	func log_warn(msg: String) -> void:
		Log.warn("[%s] %s" % [mod_id, msg])
	func log_error(msg: String) -> void:
		Log.error("[%s] %s" % [mod_id, msg])

	## Release all Bus subscriptions and mark handle dead.
	func dispose() -> void:
		if _disposed: return
		_disposed = true
		for s : Dictionary in _subs:
			Bus.off(s.event as StringName, s.fn as Callable)
		_subs.clear()
		Log.info("[ExtensionAPI] '%s' disposed" % mod_id)

	func is_valid() -> bool: return not _disposed
