## ModuleLoader — loads, enables, disables, and hot-reloads engine modules.
##
## Manifest format (res://mods/manifest.json):
##   {
##     "modules": [
##       { "id": "my_mod", "path": "res://mods/my_mod/init.gd",
##         "api_version": 2, "enabled": true }
##     ]
##   }
##
## Each module's init.gd must export:
##   func on_load(handle: ExtensionAPI.ApiHandle) -> void
##   func on_unload() -> void   (optional)
extends Node

const MANIFEST := "res://mods/manifest.json"

## mod_id → { path, instance, handle, enabled }
var _modules : Dictionary = {}

func _ready() -> void:
	Bus.on(&"mods.reload",   _on_reload)
	Bus.on(&"mods.disable",  _on_disable)
	Bus.on(&"mods.enable",   _on_enable)

func _exit_tree() -> void:
	Bus.off(&"mods.reload",  _on_reload)
	Bus.off(&"mods.disable", _on_disable)
	Bus.off(&"mods.enable",  _on_enable)
	## Unload all on exit.
	for id in _modules.keys().duplicate():
		_unload_module(StringName(str(id)))

# ── Load all ───────────────────────────────────────────────────────────────────

func load_all() -> void:
	var data := JSONLoader.load_dict(MANIFEST)
	if data.is_empty():
		Log.info("[ModuleLoader] No mod manifest at %s" % MANIFEST)
		return
	for entry in (data.get("modules", []) as Array):
		if not entry is Dictionary: continue
		var d := entry as Dictionary
		if not bool(d.get("enabled", true)): continue
		_load_module(
			StringName(str(d.get("id", ""))),
			str(d.get("path", "")),
			int(d.get("api_version", 1)))

func _load_module(id: StringName, path: String, api_ver: int) -> bool:
	if id == &"" or path == "":
		Log.warn("[ModuleLoader] Invalid manifest entry: id='%s' path='%s'" % [id, path])
		return false
	if _modules.has(id):
		Log.warn("[ModuleLoader] '%s' already loaded — skipping" % id)
		return false
	if not ResourceLoader.exists(path):
		Log.error("[ModuleLoader] Path not found: %s" % path)
		return false
	var scr := load(path) as Script
	if scr == null:
		Log.error("[ModuleLoader] Not a Script: %s" % path)
		return false
	var instance : Object = scr.new()
	var handle   := ExtensionApi.negotiate(id, api_ver)
	if handle == null:
		Log.error("[ModuleLoader] API version rejected for '%s'" % id)
		return false
	if instance.has_method("on_load"):
		instance.call("on_load", handle)
	_modules[id] = {"path": path, "instance": instance,
		"handle": handle, "enabled": true}
	Log.info("[ModuleLoader] Loaded: %s" % id)
	Bus.emit(&"mod.loaded", {"id": id})
	return true

func _unload_module(id: StringName) -> void:
	if not _modules.has(id): return
	var entry := _modules[id] as Dictionary
	var inst  : Variant = entry.get("instance")
	if inst != null and inst.has_method("on_unload"):
		inst.call("on_unload")
	ExtensionApi.revoke(id)
	_modules.erase(id)
	Log.info("[ModuleLoader] Unloaded: %s" % id)
	Bus.emit(&"mod.unloaded", {"id": id})

func reload_module(id: StringName) -> bool:
	if not _modules.has(id): return false
	var path : String = str((_modules[id] as Dictionary).get("path", ""))
	_unload_module(id)
	return _load_module(id, path, 1)

func enable_module(id: StringName) -> void:
	if _modules.has(id):
		(_modules[id] as Dictionary)["enabled"] = true
		Bus.emit(&"mod.enabled", {"id": id})

func disable_module(id: StringName) -> void:
	if _modules.has(id):
		(_modules[id] as Dictionary)["enabled"] = false
		Bus.emit(&"mod.disabled", {"id": id})

func loaded_modules() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _modules.keys(): result.append(k)
	return result

func is_loaded(id: StringName) -> bool:
	return _modules.has(id)

func _on_reload(data: Variant) -> void:
	if not data is Dictionary: return
	reload_module(StringName(str((data as Dictionary).get("id", ""))))

func _on_disable(data: Variant) -> void:
	if not data is Dictionary: return
	disable_module(StringName(str((data as Dictionary).get("id", ""))))

func _on_enable(data: Variant) -> void:
	if not data is Dictionary: return
	enable_module(StringName(str((data as Dictionary).get("id", ""))))
