## KingUndoRedo — editor undo/redo with named action history.
## Usage:
##   UndoRedo.push("Move Cube", func(): node.pos = new, func(): node.pos = old)
## Ctrl+Z / Ctrl+Y triggers undo/redo. Shake gesture can call undo() directly.
##
## Typing notes:
##   • _history is Array[Action] — no bare Array.
##   • History trimming uses typed slice.
##   • Recursive-push caution: push() executes do_fn() after appending, so a
##     do_fn that calls push() again will nest. Guard against this if needed
##     by wrapping push() in a deferred call.
extends Node

const MAX_HISTORY := 64

signal history_changed(actions: Array[String], index: int)

class Action:
	var label   : String
	var do_fn   : Callable
	var undo_fn : Callable

var _history : Array[Action] = []
var _index   : int           = -1

func _ready() -> void:
	set_process_input(true)

# ── Public API ────────────────────────────────────────────────────────────────

func push(label: String, do_fn: Callable, undo_fn: Callable) -> void:
	# Discard redo future.
	if _index < _history.size() - 1:
		_history = _history.slice(0, _index + 1) as Array[Action]
	# Trim oldest when at limit.
	if _history.size() >= MAX_HISTORY:
		_history.pop_front()
		_index = _history.size() - 1
	var a := Action.new()
	a.label   = label
	a.do_fn   = do_fn
	a.undo_fn = undo_fn
	_history.append(a)
	_index = _history.size() - 1
	if do_fn.is_valid():
		do_fn.call()
	Log.debug("[UndoRedo] push: %s  (history: %d)" % [label, _history.size()])
	_notify()

func undo() -> void:
	if _index < 0: return
	var a: Action = _history[_index]
	if a.undo_fn.is_valid():
		a.undo_fn.call()
	Log.info("[UndoRedo] undo: %s" % a.label)
	_index -= 1
	_notify()
	Bus.emit(&"editor_undo", BusEvents.EditorAction.new(a.label))

func redo() -> void:
	if _index >= _history.size() - 1: return
	_index += 1
	var a: Action = _history[_index]
	if a.do_fn.is_valid():
		a.do_fn.call()
	Log.info("[UndoRedo] redo: %s" % a.label)
	_notify()
	Bus.emit(&"editor_redo", BusEvents.EditorAction.new(a.label))

func clear() -> void:
	_history.clear()
	_index = -1
	_notify()

func can_undo() -> bool: return _index >= 0
func can_redo() -> bool: return _index < _history.size() - 1

func history_labels() -> Array[String]:
	var out: Array[String] = []
	for a: Action in _history:
		out.append(a.label)
	return out

func current_index() -> int: return _index

# ── Keyboard shortcut ─────────────────────────────────────────────────────────

func _input(event: InputEvent) -> void:
	if not event is InputEventKey: return
	var e: InputEventKey = event as InputEventKey
	if not e.pressed: return
	if e.ctrl_pressed and e.keycode == KEY_Z:
		undo()
		get_viewport().set_input_as_handled()
	elif e.ctrl_pressed and e.keycode == KEY_Y:
		redo()
		get_viewport().set_input_as_handled()

func _notify() -> void:
	history_changed.emit(history_labels(), _index)
	Bus.emit(&"undo_history_changed", BusEvents.UndoHistoryChanged.new(_index, _history.size()))
