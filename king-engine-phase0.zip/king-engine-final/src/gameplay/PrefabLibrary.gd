## PrefabLibrary — mobile-friendly prefab capture and spawn.
##
## Typing notes:
##   • _serialize_node / _restore_node return typed Dictionary.
##   • _as_vec3 / _as_vec2 accept Variant but cast defensively.
##   • load_prefab validates version before returning data.
##   • _restore_node rejects untrusted class strings via the allowlist in
##     _create_node rather than calling ClassDB.instantiate() arbitrarily.
extends Node

const PREFAB_DIR     := "user://save/prefabs/"
const PREFAB_VERSION := 1

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(PREFAB_DIR)

func list_prefabs() -> Array[String]:
	var out: Array[String] = []
	var dir: DirAccess = DirAccess.open(PREFAB_DIR)
	if not dir: return out
	dir.list_dir_begin()
	var entry: String = dir.get_next()
	while entry != "":
		if not entry.begins_with(".") and entry.get_extension().to_lower() == "json":
			out.append(entry.get_basename())
		entry = dir.get_next()
	dir.list_dir_end()
	out.sort()
	return out

func prefab_path(prefab_name: String) -> String:
	return PREFAB_DIR + _sanitize_name(prefab_name) + ".json"

func save_prefab_from_node(prefab_name: String, source: Node) -> bool:
	if not is_instance_valid(source): return false
	var clean: String = _sanitize_name(prefab_name)
	if clean.is_empty():
		clean = _sanitize_name(str(source.name))
	if clean.is_empty(): clean = "Prefab"
	var data: Dictionary = {
		"version":  PREFAB_VERSION,
		"name":     clean,
		"root":     _serialize_node(source),
		"entities": EntityManager.snapshot_under(source)
	}
	var f: FileAccess = FileAccess.open(prefab_path(clean), FileAccess.WRITE)
	if not f:
		Log.error("[PrefabLibrary] cannot write prefab %s" % clean)
		return false
	f.store_string(JSON.stringify(data, "\t"))
	f.close()
	Log.info("[PrefabLibrary] saved prefab %s" % clean)
	Bus.emit(&"prefab_saved", BusEvents.PrefabSaved.new(clean, prefab_path(clean)))
	return true

## Returns an empty Dictionary if the file is missing, malformed, or has an
## incompatible version. Callers must check is_empty() before use.
func load_prefab(prefab_name: String) -> Dictionary:
	var path: String = prefab_path(prefab_name)
	if not FileAccess.file_exists(path): return {}
	var txt: String = FileAccess.get_file_as_string(path)
	if txt.is_empty(): return {}
	var parsed: Variant = JSON.parse_string(txt)
	if not parsed is Dictionary: return {}
	var d: Dictionary = parsed as Dictionary
	# Reject incompatible versions rather than silently misreading fields.
	var ver: int = int(d.get("version", 0))
	if ver != PREFAB_VERSION:
		Log.warn("[PrefabLibrary] prefab '%s' version %d != expected %d" % [
			prefab_name, ver, PREFAB_VERSION])
		return {}
	return d

func delete_prefab(prefab_name: String) -> bool:
	var path: String = prefab_path(prefab_name)
	if not FileAccess.file_exists(path): return false
	if DirAccess.remove_absolute(path) == OK:
		Bus.emit(&"prefab_deleted", BusEvents.PrefabDeleted.new(prefab_name))
		return true
	return false

func spawn_prefab(prefab_name: String, parent: Node = null) -> Node:
	var data: Dictionary = load_prefab(prefab_name)
	if data.is_empty(): return null
	var root_var: Variant = data.get("root", {})
	if not root_var is Dictionary: return null
	var node: Node = _restore_node(root_var as Dictionary)
	if node == null: return null
	if is_instance_valid(parent):
		parent.add_child(node)
	var ecs_var: Variant = data.get("entities", {})
	if ecs_var is Dictionary:
		EntityManager.restore_snapshot(ecs_var as Dictionary, node, true)
	Bus.emit(&"prefab_spawned", BusEvents.PrefabSpawned.new(prefab_name))
	Log.info("[PrefabLibrary] spawned prefab %s" % prefab_name)
	return node

# ── Serialization ─────────────────────────────────────────────────────────────

func _serialize_node(node: Node) -> Dictionary:
	var data: Dictionary = {
		"name":        str(node.name),
		"class":       node.get_class(),
		"script_path": str(node.get_script().resource_path) if node.get_script() else "",
		"children":    [] as Array
	}
	if node is Node3D:
		var n3: Node3D = node as Node3D
		## Save global_position — world-space, consistent with TransformComponent.position.
		## Prefab root nodes are always reparented on spawn, so global_position is the
		## reliable anchor. Children use local coords relative to root (correct for trees).
		var is_root: bool = node.get_parent() == null or not (node.get_parent() is Node3D)
		if is_root:
			data["position"] = var_to_str(n3.global_position)
		else:
			data["position"] = var_to_str(n3.position)  ## local — relative to parent root
		data["rotation_degrees"]  = var_to_str(n3.rotation_degrees)
		data["scale"]             = var_to_str(n3.scale)
		data["visible"]           = n3.visible
	if node is Node2D:
		var n2: Node2D = node as Node2D
		data["position_2d"] = var_to_str(n2.position)
		data["rotation_2d"] = n2.rotation
		data["scale_2d"]    = var_to_str(n2.scale)
	for child: Node in node.get_children():
		(data["children"] as Array).append(_serialize_node(child))
	return data

func _restore_node(data: Dictionary) -> Node:
	var node: Node = _create_node(str(data.get("class", "Node3D")))
	if node == null: return null
	node.name = str(data.get("name", "Prefab"))
	var script_path: String = str(data.get("script_path", ""))
	if not script_path.is_empty():
		var scr: Variant = load(script_path)
		if scr is Script:
			node.set_script(scr as Script)
	if node is Node3D:
		var n3: Node3D = node as Node3D
		## Root nodes were saved as global_position; children as local position.
		## On restore, root is not yet in tree so global==local — safe to use position.
		n3.position         = _as_vec3(data.get("position",         "Vector3(0,0,0)"))
		n3.rotation_degrees = _as_vec3(data.get("rotation_degrees", "Vector3(0,0,0)"))
		n3.scale            = _as_vec3(data.get("scale",            "Vector3(1,1,1)"))
		n3.visible          = bool(data.get("visible", true))
	if node is Node2D:
		var n2: Node2D = node as Node2D
		n2.position = _as_vec2(data.get("position_2d", "Vector2(0,0)"))
		n2.rotation = float(data.get("rotation_2d", 0.0))
		n2.scale    = _as_vec2(data.get("scale_2d",   "Vector2(1,1)"))
	var children_var: Variant = data.get("children", [])
	if children_var is Array:
		for child_data: Variant in (children_var as Array):
			if child_data is Dictionary:
				var child: Node = _restore_node(child_data as Dictionary)
				if child != null:
					node.add_child(child)
	return node

# ── Node factory (allowlist) ──────────────────────────────────────────────────

func _create_node(node_class: String) -> Node:
	match node_class:
		"Node":               return Node.new()
		"Node3D":             return Node3D.new()
		"Node2D":             return Node2D.new()
		"MeshInstance3D":     return MeshInstance3D.new()
		"OmniLight3D":        return OmniLight3D.new()
		"DirectionalLight3D": return DirectionalLight3D.new()
		"SpotLight3D":        return SpotLight3D.new()
		"StaticBody3D":       return StaticBody3D.new()
		"CharacterBody3D":    return CharacterBody3D.new()
		"CollisionShape3D":   return CollisionShape3D.new()
		"Camera3D":           return Camera3D.new()
		"WorldEnvironment":   return WorldEnvironment.new()
		"Control":            return Control.new()
		"Panel":              return Panel.new()
		"PanelContainer":     return PanelContainer.new()
		"VBoxContainer":      return VBoxContainer.new()
		"HBoxContainer":      return HBoxContainer.new()
		_:
			Log.warn("[PrefabLibrary] unknown node class '%s', defaulting to Node3D" % node_class)
			return Node3D.new()

# ── Helpers ───────────────────────────────────────────────────────────────────

func _as_vec3(value: Variant) -> Vector3:
	if value is Vector3: return value as Vector3
	if value is String:
		var parsed: Variant = str_to_var(value as String)
		if parsed is Vector3: return parsed as Vector3
	if value is Array:
		var a: Array = value as Array
		if a.size() >= 3:
			return Vector3(float(a[0]), float(a[1]), float(a[2]))
	return Vector3.ZERO

func _as_vec2(value: Variant) -> Vector2:
	if value is Vector2: return value as Vector2
	if value is String:
		var parsed: Variant = str_to_var(value as String)
		if parsed is Vector2: return parsed as Vector2
	if value is Array:
		var a: Array = value as Array
		if a.size() >= 2:
			return Vector2(float(a[0]), float(a[1]))
	return Vector2.ZERO

func _sanitize_name(raw: String) -> String:
	var out: String = raw.strip_edges()
	for ch: String in ["/", "\\", ":", "*", "?", "\"", "<", ">", "|"]:
		out = out.replace(ch, "_")
	return out
