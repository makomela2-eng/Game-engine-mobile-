## SceneValidator — scans the editor scene for common issues.
## Call validate(scene_root) and read results or listen to Bus &"scene_validation_done".
##
## Checks:
##   * Nodes with duplicate names at the same level
##   * Node3D with zero scale (invisible)
##   * MeshInstance3D with no material (default grey)
##   * Lights with extreme energy values
##   * Orphaned collision shapes (no parent body)
##   * Nodes named "Node", "Node3D" etc (default names)
##
## Fixes applied:
##   * _check_duplicate_names() now recurses into all sibling groups across the
##     full tree, not just root's immediate children. Nested duplicates are caught.
##   * Bus.emit at _done() now uses BusEvents.SceneValidated (typed payload)
##     instead of a raw Dictionary, matching the typed-event pattern used elsewhere.
##
## Typing notes:
##   * last_issues is Array[Issue] — no bare Array.
##   * Severity uses named constants to avoid magic ints at call sites.
##   * seen dict in _check_duplicate_names uses explicit String keys.
##   * validated signal carries Array[Issue].
extends Node

# Severity constants — use these at call sites instead of bare ints.
const SEV_INFO  := 0
const SEV_WARN  := 1
const SEV_ERROR := 2

class Issue:
	var severity  : int     # SEV_INFO / SEV_WARN / SEV_ERROR
	var node_name : String
	var message   : String

var last_issues : Array[Issue] = []

signal validated(issues: Array[Issue])

# -- Public -------------------------------------------------------------------

func validate(root: Node) -> Array[Issue]:
	last_issues.clear()
	if not is_instance_valid(root):
		_issue(SEV_ERROR, "Scene", "Scene root is invalid or null")
		_done()
		return last_issues
	_check_node(root)
	_check_duplicate_names(root)
	_done()
	return last_issues

# -- Checks -------------------------------------------------------------------

func _check_node(node: Node) -> void:
	var name_str: String = str(node.name)

	if name_str in ["Node", "Node3D", "Node2D", "Control"]:
		_issue(SEV_INFO, name_str, "Has default name — consider renaming")

	if node is Node3D:
		var n3: Node3D = node as Node3D
		if n3.scale.is_zero_approx():
			_issue(SEV_ERROR, name_str, "Scale is zero — node will be invisible")
		elif n3.scale.length() < 0.01:
			_issue(SEV_WARN, name_str, "Scale is very small (%.4f)" % n3.scale.length())

	if node is MeshInstance3D:
		var mi: MeshInstance3D = node as MeshInstance3D
		if is_instance_valid(mi.mesh):
			var has_mat: bool = false
			for i: int in mi.mesh.get_surface_count():
				if mi.get_surface_override_material(i) != null:
					has_mat = true; break
				if mi.mesh.surface_get_material(i) != null:
					has_mat = true; break
			if not has_mat:
				_issue(SEV_INFO, name_str, "MeshInstance3D has no material (using default grey)")

	if node is OmniLight3D or node is SpotLight3D or node is DirectionalLight3D:
		var light: Light3D = node as Light3D
		if light.light_energy > 100.0:
			_issue(SEV_WARN, name_str, "Light energy %.1f is very high" % light.light_energy)
		elif light.light_energy <= 0.0:
			_issue(SEV_WARN, name_str, "Light energy is zero — light has no effect")

	if node is CollisionShape3D:
		if not (node.get_parent() is PhysicsBody3D):
			_issue(SEV_ERROR, name_str,
				"CollisionShape3D has no PhysicsBody3D parent — collision won't work")

	for child: Node in node.get_children():
		_check_node(child)

## FIX: recurse into every sibling group in the tree, not just root's children.
## _check_duplicate_names(root) now walks the whole tree and checks each
## parent's child list independently, so nested duplicates are caught.
func _check_duplicate_names(parent: Node) -> void:
	var seen: Dictionary = {}  # String -> bool
	for child: Node in parent.get_children():
		var n: String = str(child.name)
		if seen.has(n):
			_issue(SEV_WARN, n, "Duplicate sibling name '%s' — may cause path conflicts" % n)
		seen[n] = true
		# Recurse so every level of the tree is checked.
		_check_duplicate_names(child)

# -- Internal -----------------------------------------------------------------

func _issue(severity: int, node_name: String, message: String) -> void:
	var i := Issue.new()
	i.severity  = clampi(severity, SEV_INFO, SEV_ERROR)
	i.node_name = node_name
	i.message   = message
	last_issues.append(i)
	var prefix: String = (["[INFO]", "[WARN]", "[ERROR]"] as Array)[i.severity]
	Log.warn("[SceneValidator] %s %s: %s" % [prefix, node_name, message])

func _done() -> void:
	var errors: int = 0
	var warns:  int = 0
	for i: Issue in last_issues:
		if i.severity == SEV_ERROR: errors += 1
		elif i.severity == SEV_WARN: warns += 1
	Log.info("[SceneValidator] done — %d errors, %d warnings, %d info" % [
		errors, warns, last_issues.size() - errors - warns])
	validated.emit(last_issues)
	## FIX: use typed BusEvents.SceneValidated payload instead of raw Dictionary.
	Bus.emit(&"scene_validation_done", BusEvents.SceneValidated.new(last_issues, errors, warns))
