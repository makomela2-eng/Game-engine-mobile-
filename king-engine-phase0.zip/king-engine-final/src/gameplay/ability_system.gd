## AbilitySystem — manages cooldowns and triggers abilities on entities.
## Entities need an ability data entry in DataRegistry table "abilities".
## Identity-safe: cooldown state is keyed by entity ID and cleaned up on
## ecs.entity_destroyed so no stale entries accumulate across respawns.
extends SystemBase

var _cooldowns : Dictionary = {}  ## entity_id → { ability_id → remaining_sec }

func _on_start() -> void:
	priority = 1500
	listen(&"gameplay.ability_used",  _on_ability_used)
	listen(&"ecs.entity_destroyed",   _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"gameplay.ability_used",  _on_ability_used)
	unlisten(&"ecs.entity_destroyed",   _on_entity_destroyed)

func tick(delta: float) -> void:
	for entity in _cooldowns.keys():
		var cds := _cooldowns[entity] as Dictionary
		for ab in cds.keys().duplicate():
			cds[ab] = maxf(float(cds[ab]) - delta, 0.0)
			if float(cds[ab]) <= 0.0:
				cds.erase(ab)

func use_ability(entity: int, ability_id: StringName) -> bool:
	if is_on_cooldown(entity, ability_id):
		return false
	var data := DataRegistry.get_entry(&"abilities", ability_id)
	if data.is_empty():
		Log.warn("[AbilitySystem] Unknown ability: %s" % ability_id)
		return false
	var cooldown := float(data.get("cooldown", 1.0))
	_set_cooldown(entity, ability_id, cooldown)
	broadcast(&"gameplay.ability_used", entity, {"ability": ability_id, "data": data})
	return true

func is_on_cooldown(entity: int, ability_id: StringName) -> bool:
	return _cooldowns.has(entity) and float((_cooldowns[entity] as Dictionary).get(ability_id, 0.0)) > 0.0

func get_cooldown(entity: int, ability_id: StringName) -> float:
	if not _cooldowns.has(entity):
		return 0.0
	return float((_cooldowns[entity] as Dictionary).get(ability_id, 0.0))

func _set_cooldown(entity: int, ability_id: StringName, seconds: float) -> void:
	if not _cooldowns.has(entity):
		_cooldowns[entity] = {}
	(_cooldowns[entity] as Dictionary)[ability_id] = seconds

func _on_ability_used(_data: Variant) -> void:
	pass  ## Hook for derived systems

## Clean up cooldown state when an entity is destroyed.
## Without this, a respawned entity gets a fresh entity ID anyway, but
## the old ID's entry would leak memory indefinitely.
func _on_entity_destroyed(data: Variant) -> void:
	if not data is Dictionary:
		return
	var entity := int((data as Dictionary).get("entity", -1))
	_cooldowns.erase(entity)
