## AISystem — high-level AI orchestrator. Bridges entity tags to BehaviorTrees.
## Automatically assigns default trees to entities tagged "ai".
## Override _build_tree() in a subclass to provide custom trees per entity type.
##
## BehaviorTree node lambdas use the new 3-arg signature:
##   ActionNode:    func(entity, blackboard, delta) -> BehaviorTree.Status
##   ConditionNode: func(entity, blackboard) -> bool
extends SystemBase

var _initialized : Dictionary = {}   ## entity_id → bool

func _on_start() -> void:
	priority = 4100
	listen(&"ecs.entity_created",  _on_entity_created)
	listen(&"ecs.entity_destroyed", _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"ecs.entity_created",  _on_entity_created)
	unlisten(&"ecs.entity_destroyed", _on_entity_destroyed)

func tick(_delta: float) -> void:
	## Lazy init for entities that gain the "ai" tag after creation.
	for id : int in EntityManager.get_entities_by_tag(&"ai"):
		if not _initialized.get(id, false):
			_init_ai(id)

func _init_ai(entity: int) -> void:
	_initialized[entity] = true
	if not Pathfinding.is_registered(entity):
		Pathfinding.register_entity(entity)
	var tree := _build_tree(entity)
	if tree != null:
		DecisionSystem.register_tree(entity, tree)

## Override in a subclass to assign entity-specific trees.
## Tag-based dispatch: check entity tags to decide which tree to build.
func _build_tree(entity: int) -> BehaviorTree:
	var bb   := BehaviorTree.Blackboard.new()
	var tree := BehaviorTree.new(entity, bb)

	## Default: sense for player → chase; otherwise wander.
	## Uses new 3-arg signatures throughout.
	tree.root = BehaviorTree.Selector.new([
		## Branch 1: if dead, do nothing.
		BehaviorTree.ConditionNode.new(
			func(e: int, _bb: BehaviorTree.Blackboard) -> bool:
				return EntityManager.has_tag(e, &"dead")),
		## Branch 2: sense → chase.
		BehaviorTree.Sequence.new([
			BehaviorTree.SenseTarget.new(12.0, &"player"),
			BehaviorTree.FaceTarget.new(5.0),
			BehaviorTree.MoveToTarget.new(3.5, 1.5),
		]),
		## Branch 3: idle wander.
		BehaviorTree.ActionNode.new(
			func(_e: int, _bb: BehaviorTree.Blackboard, _d: float) -> int:
				return BehaviorTree.Status.RUNNING),
	])
	return tree

func _on_entity_created(data: Variant) -> void:
	if not data is Dictionary: return
	var id := int((data as Dictionary).get("entity", -1))
	if id >= 0 and EntityManager.has_tag(id, &"ai"):
		_init_ai(id)

func _on_entity_destroyed(data: Variant) -> void:
	if not data is Dictionary: return
	var id := int((data as Dictionary).get("entity", -1))
	_initialized.erase(id)
	DecisionSystem.unregister(id)
	Pathfinding.unregister(id)
