## CombatSystem — resolves attack actions into damage events.
##
## Attack flow:
##   input.action "attack"  →  combat.attack_requested
##   combat.attack_requested →  hit detection (range + team check)  →  ecs.damage
##
## Features:
##   • Melee range check via TransformComponent distance.
##   • Team-friendly fire prevention (entities tagged "team_X" don't hit each other).
##   • Knockback: applies velocity impulse to hit target.
##   • Combo window: rapid attacks within combo_window_sec escalate damage.
##   • Ranged: emit combat.projectile_requested for ranged entities.
extends SystemBase

var melee_range      : float = 2.0
var knockback_force  : float = 5.0
var combo_window_sec : float = 0.8
var combo_multiplier : float = 1.25   ## damage multiplier per combo hit

## entity_id → { count: int, last_hit_time: float }
var _combos : Dictionary = {}

func _on_start() -> void:
	priority = 2200
	listen(&"combat.attack_requested", _on_attack_requested)
	listen(&"input.action",            _on_input_action)
	listen(&"ecs.entity_destroyed",    _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"combat.attack_requested", _on_attack_requested)
	unlisten(&"input.action",            _on_input_action)
	unlisten(&"ecs.entity_destroyed",    _on_entity_destroyed)

func tick(_delta: float) -> void:
	pass

# ── Input → request ───────────────────────────────────────────────────────────

func _on_input_action(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	if StringName(str(d.get("action", ""))) != &"attack": return
	var entity := int(d.get("entity", -1))
	if entity < 0: return
	Bus.emit(&"combat.attack_requested", {
		"entity": entity,
		"data":   {"damage": _base_damage(entity), "range": melee_range}
	})

func _base_damage(entity: int) -> float:
	## Check DataRegistry for entity-specific damage stat.
	var tags : Array[StringName] = EntityManager.get_tags(entity)
	for tag : StringName in tags:
		var data := DataRegistry.get_entry(&"entities", tag)
		if data.has("damage"):
			return float(data.get("damage", 10.0))
	return 10.0

# ── Attack resolution ─────────────────────────────────────────────────────────

func _on_attack_requested(data: Variant) -> void:
	if not data is Dictionary: return
	var d         := data as Dictionary
	var attacker  := int(d.get("entity", -1))
	if attacker < 0: return
	var inner     := d.get("data", {}) as Dictionary
	var damage    := float(inner.get("damage",  _base_damage(attacker)))
	var range_val := float(inner.get("range",   melee_range))
	## Apply combo multiplier.
	damage *= _get_combo_multiplier(attacker)
	for target : int in _find_targets(attacker, range_val):
		apply_hit(attacker, target, damage, inner)

func apply_hit(attacker: int, target: int, damage: float,
		params: Dictionary = {}) -> void:
	if not EntityManager.entity_exists(target): return
	if EntityManager.has_tag(target, &"dead"):  return
	if _same_team(attacker, target):            return
	## Apply knockback via VelocityComponent.
	_apply_knockback(attacker, target, float(params.get("knockback", knockback_force)))
	Bus.emit(&"ecs.damage", {"entity": target, "amount": damage, "source": attacker})
	Bus.emit(&"gameplay.entity_damaged", {
		"entity": target, "data": {"amount": damage, "source": attacker}
	})
	_record_combo_hit(attacker)

func _apply_knockback(attacker: int, target: int, force: float) -> void:
	if force <= 0.0: return
	var att_t := EntityManager.get_component(attacker, &"Transform") as TransformComponent
	var tgt_t := EntityManager.get_component(target,   &"Transform") as TransformComponent
	var tgt_v := EntityManager.get_component(target,   &"Velocity")  as VelocityComponent
	if att_t == null or tgt_t == null or tgt_v == null: return
	var dir := (tgt_t.position - att_t.position).normalized()
	dir.y    = 0.3   ## slight upward arc
	tgt_v.linear += dir * force

# ── Target finding ────────────────────────────────────────────────────────────

func _find_targets(attacker: int, range_val: float) -> Array[int]:
	var result : Array[int] = []
	var att_t  := EntityManager.get_component(attacker, &"Transform") as TransformComponent
	if att_t == null: return result
	for id : int in EntityManager.get_entities_with([&"Health", &"Transform"]):
		if id == attacker: continue
		var t := EntityManager.get_component(id, &"Transform") as TransformComponent
		if t == null: continue
		if att_t.position.distance_to(t.position) <= range_val:
			result.append(id)
	return result

# ── Team check ────────────────────────────────────────────────────────────────

func _same_team(a: int, b: int) -> bool:
	var ta : Array = EntityManager.get_tags(a).filter(
		func(t: StringName) -> bool: return str(t).begins_with("team_"))
	var tb : Array = EntityManager.get_tags(b).filter(
		func(t: StringName) -> bool: return str(t).begins_with("team_"))
	if ta.is_empty() or tb.is_empty(): return false
	return ta[0] == tb[0]

# ── Combo system ──────────────────────────────────────────────────────────────

func _record_combo_hit(attacker: int) -> void:
	var now := Time.get_ticks_msec() * 0.001
	if _combos.has(attacker):
		var c := _combos[attacker] as Dictionary
		if float(c.get("last_hit_time", 0.0)) + combo_window_sec > now:
			c["count"] = int(c.get("count", 1)) + 1
			c["last_hit_time"] = now
			if int(c.get("count", 1)) > 1:
				Bus.emit(&"combat.combo", {"entity": attacker, "count": c["count"]})
			return
	_combos[attacker] = {"count": 1, "last_hit_time": now}

func _get_combo_multiplier(attacker: int) -> float:
	if not _combos.has(attacker): return 1.0
	var c := _combos[attacker] as Dictionary
	var now := Time.get_ticks_msec() * 0.001
	if float(c.get("last_hit_time", 0.0)) + combo_window_sec < now:
		_combos.erase(attacker)
		return 1.0
	var count := int(c.get("count", 1))
	return pow(combo_multiplier, count - 1)

func get_combo_count(entity: int) -> int:
	if not _combos.has(entity): return 0
	return int((_combos[entity] as Dictionary).get("count", 0))

func _on_entity_destroyed(data: Variant) -> void:
	if not data is Dictionary: return
	_combos.erase(int((data as Dictionary).get("entity", -1)))
