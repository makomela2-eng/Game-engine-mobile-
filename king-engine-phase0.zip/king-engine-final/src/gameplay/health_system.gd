## HealthSystem — manages HealthComponent regen, death, and invincibility frames.
##
## Audio routing: uses AudioManager cue table (set via AudioManager.set_cue())
## instead of calling AudioDSPSystem.get_sfx() directly.
extends SystemBase

func _on_start() -> void:
	priority = 2100
	listen(&"ecs.entity_damaged", _on_ecs_damaged)
	listen(&"ecs.entity_healed",  _on_ecs_healed)
	listen(&"ecs.entity_died",    _on_ecs_died)

func _on_stop() -> void:
	unlisten(&"ecs.entity_damaged", _on_ecs_damaged)
	unlisten(&"ecs.entity_healed",  _on_ecs_healed)
	unlisten(&"ecs.entity_died",    _on_ecs_died)

func tick(delta: float) -> void:
	for id : int in QuerySystem.query([&"Health"]):
		var hc := EntityManager.get_component(id, &"Health") as HealthComponent
		if hc == null or hc.dead: continue
		## Tick i-frames.
		if hc.invincible_timer > 0.0:
			hc.invincible_timer = maxf(hc.invincible_timer - delta, 0.0)
			if hc.invincible_timer <= 0.0:
				hc.invincible = false
		## Health regen.
		if hc.regen_rate > 0.0 and hc.hp < hc.max_hp:
			hc.hp = minf(hc.hp + hc.regen_rate * delta, hc.max_hp)
			Bus.emit(&"gameplay.health_changed", {
				"entity": id, "hp": hc.hp, "max_hp": hc.max_hp
			})

func _on_ecs_damaged(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	var inner  := d.get("data", {}) as Dictionary
	if entity < 0: return
	Bus.emit(&"gameplay.health_changed", {
		"entity": entity,
		"hp":     float(inner.get("hp",     0.0)),
		"max_hp": float(inner.get("max_hp", 1.0))
	})
	## Route through AudioManager cue table — never call AudioDSPSystem directly.
	Bus.emit(&"audio.play_once", {"id": AudioManager.get_cue(&"entity_damaged")})

func _on_ecs_healed(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	var inner  := d.get("data", {}) as Dictionary
	if entity < 0: return
	Bus.emit(&"gameplay.health_changed", {
		"entity": entity,
		"hp":     float(inner.get("hp",     0.0)),
		"max_hp": float(inner.get("max_hp", 1.0))
	})

func _on_ecs_died(data: Variant) -> void:
	if not data is Dictionary: return
	var entity := int((data as Dictionary).get("entity", -1))
	if entity < 0: return
	EntityManager.add_tag(entity, &"dead")
	Bus.emit(&"gameplay.entity_died", {"entity": entity, "data": {}})
	Bus.emit(&"audio.play_once", {"id": AudioManager.get_cue(&"entity_died")})

## Public helpers for game code.
func apply_damage(entity: int, amount: float, source: int = -1) -> void:
	Bus.emit(&"ecs.damage", {"entity": entity, "amount": amount, "source": source})

func apply_heal(entity: int, amount: float) -> void:
	Bus.emit(&"ecs.heal", {"entity": entity, "amount": amount})

func revive(entity: int, hp_fraction: float = 1.0) -> void:
	var hc := EntityManager.get_component(entity, &"Health") as HealthComponent
	if hc == null: return
	hc.dead    = false
	hc.hp      = hc.max_hp * clampf(hp_fraction, 0.01, 1.0)
	hc.invincible = false
	hc.invincible_timer = 0.0
	EntityManager.remove_tag(entity, &"dead")
	Bus.emit(&"gameplay.entity_revived", {"entity": entity, "data": {}})

func get_hp_pct(entity: int) -> float:
	var hc := EntityManager.get_component(entity, &"Health") as HealthComponent
	return hc.pct() if hc else 0.0

func is_dead(entity: int) -> bool:
	var hc := EntityManager.get_component(entity, &"Health") as HealthComponent
	return hc == null or hc.dead
