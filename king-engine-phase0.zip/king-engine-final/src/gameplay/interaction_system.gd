## InteractionSystem — detects and resolves interactions between entities.
## Player presses interact → nearest interactable entity receives the event.
extends SystemBase

var interact_range   : float = 2.5

func _on_start() -> void:
	priority = 3100
	listen(&"input.action", _on_input_action)

func _on_stop() -> void:
	unlisten(&"input.action", _on_input_action)

func tick(_delta: float) -> void:
	pass

func _on_input_action(data: Variant) -> void:
	if not data is Dictionary:
		return
	var d := data as Dictionary
	if StringName(str(d.get("action", ""))) != &"interact":
		return
	var actor := int(d.get("entity", -1))
	if actor < 0:
		return
	try_interact(actor)

func try_interact(actor: int) -> bool:
	var target := find_nearest_interactable(actor)
	if target < 0:
		return false
	Bus.emit(&"gameplay.interaction", {
		"entity": actor,
		"data":   {"target": target}
	})
	Bus.emit(&"interaction.triggered", {"actor": actor, "target": target})
	return true

func find_nearest_interactable(actor: int) -> int:
	var actor_t := EntityManager.get_component(actor, &"Transform") as TransformComponent
	if actor_t == null:
		return -1
	var candidates := EntityManager.get_entities_by_tag(&"interactable")
	var best_dist  := interact_range + 0.01
	var best_id    := -1
	for id : int in candidates:
		if id == actor:
			continue
		var t := EntityManager.get_component(id, &"Transform") as TransformComponent
		if t == null:
			continue
		var dist := actor_t.position.distance_to(t.position)
		if dist < best_dist:
			best_dist = dist
			best_id   = id
	return best_id

func get_interactables_in_range(actor: int) -> Array[int]:
	var actor_t := EntityManager.get_component(actor, &"Transform") as TransformComponent
	if actor_t == null:
		return []
	var result    : Array[int] = []
	var candidates := EntityManager.get_entities_by_tag(&"interactable")
	for id : int in candidates:
		var t := EntityManager.get_component(id, &"Transform") as TransformComponent
		if t and actor_t.position.distance_to(t.position) <= interact_range:
			result.append(id)
	return result
