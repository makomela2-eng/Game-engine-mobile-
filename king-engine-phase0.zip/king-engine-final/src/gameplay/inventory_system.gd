## InventorySystem — manages item inventories for entities.
## Items are DataRegistry entries from the "items" table.
## Inventory data lives on entity tags + a side-table here.
extends SystemBase


## entity_id → { slot_index → { item_id, quantity, data } }
var _inventories : Dictionary = {}

func _on_start() -> void:
	priority = 3000
	listen(&"gameplay.item_picked_up", _on_item_picked_up)
	listen(&"gameplay.item_dropped",   _on_item_dropped)
	listen(&"gameplay.item_used",      _on_item_used)
	listen(&"ecs.entity_destroyed",   _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"gameplay.item_picked_up", _on_item_picked_up)
	unlisten(&"gameplay.item_dropped",   _on_item_dropped)
	unlisten(&"gameplay.item_used",      _on_item_used)
	unlisten(&"ecs.entity_destroyed",   _on_entity_destroyed)

func tick(_delta: float) -> void:
	pass

func init_inventory(entity: int, slots: int = 20) -> void:
	_inventories[entity] = {}
	for i in range(slots):
		(_inventories[entity] as Dictionary)[i] = null

func add_item(entity: int, item_id: StringName, quantity: int = 1) -> bool:
	if not _inventories.has(entity):
		init_inventory(entity)
	var inv := _inventories[entity] as Dictionary
	## Find existing stack
	for slot in inv.keys():
		var s = inv[slot]
		if s != null and (s as Dictionary).get("item_id") == item_id:
			var entry := s as Dictionary
			entry.quantity = int(entry.quantity) + quantity
			Bus.emit(&"inventory.changed", {"entity": entity, "slot": slot, "item": item_id, "quantity": entry.quantity})
			return true
	## Find empty slot
	for slot in inv.keys():
		if inv[slot] == null:
			var item_data := DataRegistry.get_entry(&"items", item_id)
			inv[slot] = {"item_id": item_id, "quantity": quantity, "data": item_data}
			Bus.emit(&"inventory.changed", {"entity": entity, "slot": slot, "item": item_id, "quantity": quantity})
			return true
	Log.warn("[InventorySystem] Inventory full for e%d" % entity)
	return false

func remove_item(entity: int, item_id: StringName, quantity: int = 1) -> bool:
	if not _inventories.has(entity):
		return false
	var inv := _inventories[entity] as Dictionary
	for slot in inv.keys():
		var s = inv[slot]
		if s != null and (s as Dictionary).get("item_id") == item_id:
			var entry := s as Dictionary
			entry.quantity = int(entry.quantity) - quantity
			if int(entry.quantity) <= 0:
				inv[slot] = null
			Bus.emit(&"inventory.changed", {"entity": entity, "slot": slot, "item": item_id, "quantity": maxi(int(entry.quantity), 0)})
			return true
	return false

func has_item(entity: int, item_id: StringName) -> bool:
	return get_item_count(entity, item_id) > 0

func get_item_count(entity: int, item_id: StringName) -> int:
	if not _inventories.has(entity):
		return 0
	var inv := _inventories[entity] as Dictionary
	for s in inv.values():
		if s != null and (s as Dictionary).get("item_id") == item_id:
			return int((s as Dictionary).quantity)
	return 0

func get_inventory(entity: int) -> Dictionary:
	return _inventories.get(entity, {})

func clear_inventory(entity: int) -> void:
	if _inventories.has(entity):
		_inventories.erase(entity)

func _on_item_picked_up(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	var item   := StringName(str(d.get("data", {}).get("item_id", "")))
	var qty    := int(d.get("data", {}).get("quantity", 1))
	if entity >= 0 and item != &"": add_item(entity, item, qty)

func _on_item_dropped(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	var item   := StringName(str(d.get("data", {}).get("item_id", "")))
	var qty    := int(d.get("data", {}).get("quantity", 1))
	if entity >= 0 and item != &"": remove_item(entity, item, qty)

func _on_item_used(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	var item   := StringName(str(d.get("data", {}).get("item_id", "")))
	if entity >= 0 and item != &"": remove_item(entity, item, 1)

func _on_entity_destroyed(data: Variant) -> void:
	if not data is Dictionary: return
	clear_inventory(int((data as Dictionary).get("entity", -1)))
