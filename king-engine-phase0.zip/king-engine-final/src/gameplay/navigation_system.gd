## NavigationSystem — manages navigation targets for ECS entities.
##
## Responsibilities:
##   • Set navigation targets via navigate_to(entity, target).
##   • Track arrival and emit navigation.arrived when done.
##   • For CharacterBody3D entities NOT using Pathfinding's auto-avoidance,
##     drives velocity directly. Entities registered with Pathfinding.register_entity()
##     are driven by PhysicsSystem via velocity_computed — NavigationSystem
##     does NOT call move_and_slide() on them to avoid double-movement.
extends SystemBase

var default_speed : float = 5.0

func _on_start() -> void:
	priority = 4200
	listen(&"navigation.request", _on_nav_request)
	listen(&"navigation.stop",    _on_nav_stop)

func _on_stop() -> void:
	unlisten(&"navigation.request", _on_nav_request)
	unlisten(&"navigation.stop",    _on_nav_stop)

func tick(_delta: float) -> void:
	for id : int in EntityManager.get_entities_by_tag(&"navigating"):
		if EntityManager.has_tag(id, &"dead"):
			EntityManager.remove_tag(id, &"navigating")
			continue
		if Pathfinding.is_navigation_finished(id):
			EntityManager.remove_tag(id, &"navigating")
			var t := EntityManager.get_component(id, &"Transform") as TransformComponent
			Bus.emit(&"navigation.arrived", {
				"entity":   id,
				"position": t.position if t else Vector3.ZERO
			})
			continue
		## Only drive velocity for entities NOT using Pathfinding's velocity_computed.
		## If Pathfinding is registered, it handles movement via CharacterBody.velocity_computed.
		if not Pathfinding.is_registered(id):
			_drive_velocity(id)

func navigate_to(entity: int, target: Vector3,
		speed: float = -1.0) -> void:
	if speed > 0.0:
		Pathfinding.set_speed(entity, speed)
	Pathfinding.set_target(entity, target)
	EntityManager.add_tag(entity, &"navigating")
	Bus.emit(&"navigation.started", {"entity": entity, "target": target})

func stop(entity: int) -> void:
	EntityManager.remove_tag(entity, &"navigating")
	var vel := EntityManager.get_component(entity, &"Velocity") as VelocityComponent
	if vel:
		vel.linear = Vector3.ZERO

func _drive_velocity(entity: int) -> void:
	var desired := Pathfinding.get_desired_velocity(entity) * default_speed
	var vel     := EntityManager.get_component(entity, &"Velocity") as VelocityComponent
	if vel:
		vel.linear.x = desired.x
		vel.linear.z = desired.z
		## Y is managed by PhysicsSystem gravity.

func _on_nav_request(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	var pos_v  : Variant = d.get("target", null)
	if entity < 0 or not pos_v is Vector3: return
	navigate_to(entity, pos_v as Vector3, float(d.get("speed", -1.0)))

func _on_nav_stop(data: Variant) -> void:
	if not data is Dictionary: return
	stop(int((data as Dictionary).get("entity", -1)))
