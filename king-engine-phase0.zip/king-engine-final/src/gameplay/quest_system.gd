## QuestSystem — tracks quest state: available, active, completed, failed.
## Listens to gameplay interactions and entity deaths via Bus.
## Also listens to gameplay.item_picked_up for collection objectives.
extends SystemBase

enum QuestState { AVAILABLE, ACTIVE, COMPLETED, FAILED }

var _quests : Dictionary = {}

func _on_start() -> void:
	priority = 3200
	listen(&"gameplay.interaction",    _on_interaction)
	listen(&"gameplay.entity_died",    _on_entity_died)
	listen(&"gameplay.item_picked_up", _on_item_picked_up)
	listen(&"input.action",            _on_input_action)

func _on_stop() -> void:
	unlisten(&"gameplay.interaction",    _on_interaction)
	unlisten(&"gameplay.entity_died",    _on_entity_died)
	unlisten(&"gameplay.item_picked_up", _on_item_picked_up)
	unlisten(&"input.action",            _on_input_action)

func tick(_delta: float) -> void:
	pass

## input.action "map" → show quest log
func _on_input_action(data: Variant) -> void:
	if not data is Dictionary: return
	if StringName(str((data as Dictionary).get("action", ""))) == &"map":
		Bus.emit(&"ui.open", {"id": "quest_log"})

func start_quest(quest_id: StringName) -> bool:
	if not DataRegistry.has_entry(&"quests", quest_id):
		Log.warn("[QuestSystem] Unknown quest: %s" % quest_id)
		return false
	if _quests.has(quest_id): return false
	_quests[quest_id] = {"state": QuestState.ACTIVE, "progress": {}}
	var def := DataRegistry.get_entry(&"quests", quest_id)
	for obj in (def.get("objectives", []) as Array):
		var obj_d := obj as Dictionary
		(_quests[quest_id] as Dictionary).progress[obj_d.get("id", "")] = 0
	Bus.emit(&"gameplay.quest_updated", {"quest": quest_id, "state": QuestState.ACTIVE})
	Log.info("[QuestSystem] Started: %s" % quest_id)
	return true

func advance_objective(quest_id: StringName, objective_id: StringName, amount: int = 1) -> void:
	if not _quests.has(quest_id): return
	var q := _quests[quest_id] as Dictionary
	if q.state != QuestState.ACTIVE: return
	var progress := q.progress as Dictionary
	progress[str(objective_id)] = int(progress.get(str(objective_id), 0)) + amount
	Bus.emit(&"gameplay.quest_updated", {
		"quest": quest_id, "objective": objective_id,
		"progress": progress[str(objective_id)]
	})
	_check_completion(quest_id)

func _check_completion(quest_id: StringName) -> void:
	var def      := DataRegistry.get_entry(&"quests", quest_id)
	var q        := _quests[quest_id] as Dictionary
	var progress := q.progress as Dictionary
	for obj in (def.get("objectives", []) as Array):
		var obj_d    := obj as Dictionary
		var obj_id   := str(obj_d.get("id", ""))
		var required := int(obj_d.get("required_count", 1))
		if int(progress.get(obj_id, 0)) < required: return
	q.state = QuestState.COMPLETED
	Bus.emit(&"gameplay.quest_updated", {"quest": quest_id, "state": QuestState.COMPLETED})
	Log.info("[QuestSystem] Completed: %s" % quest_id)

func fail_quest(quest_id: StringName) -> void:
	if not _quests.has(quest_id): return
	(_quests[quest_id] as Dictionary).state = QuestState.FAILED
	Bus.emit(&"gameplay.quest_updated", {"quest": quest_id, "state": QuestState.FAILED})

func get_state(quest_id: StringName) -> QuestState:
	return (_quests.get(quest_id, {}) as Dictionary).get("state", QuestState.AVAILABLE)

func get_progress(quest_id: StringName) -> Dictionary:
	return (_quests.get(quest_id, {}) as Dictionary).get("progress", {})

func active_quests() -> Array[StringName]:
	var result : Array[StringName] = []
	for id in _quests.keys():
		if (_quests[id] as Dictionary).state == QuestState.ACTIVE:
			result.append(id)
	return result

func _on_interaction(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var actor  := int(d.get("entity", -1))
	var target := int((d.get("data", {}) as Dictionary).get("target", -1))
	if actor < 0: return
	_advance_matching_objectives(&"interact", {"actor": actor, "target": target})

func _on_entity_died(data: Variant) -> void:
	if not data is Dictionary: return
	var entity := int((data as Dictionary).get("entity", -1))
	if entity < 0: return
	_advance_matching_objectives(&"kill", {"target": entity})

func _on_item_picked_up(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	var item   := StringName(str((d.get("data", {}) as Dictionary).get("item_id", "")))
	if entity < 0 or item == &"": return
	_advance_matching_objectives(&"collect", {"actor": entity, "item": item})

func _advance_matching_objectives(kind: StringName, context: Dictionary) -> void:
	for quest_id in _quests.keys():
		var q := _quests[quest_id] as Dictionary
		if q.get("state", QuestState.AVAILABLE) != QuestState.ACTIVE: continue
		var def := DataRegistry.get_entry(&"quests", quest_id)
		if def.is_empty(): continue
		for obj in (def.get("objectives", []) as Array):
			var obj_d  := obj as Dictionary
			if StringName(str(obj_d.get("kind", ""))) != kind: continue
			if not _objective_matches(obj_d, context): continue
			var obj_id := str(obj_d.get("id", ""))
			if obj_id == "": continue
			advance_objective(quest_id, StringName(obj_id), 1)

func _objective_matches(obj: Dictionary, context: Dictionary) -> bool:
	var target := str(obj.get("target", ""))
	if target == "": return true
	if context.has("item")   and str(context.get("item", ""))   == target: return true
	if context.has("target") and str(context.get("target", "")) == target: return true
	return false
