## StateMachine — general-purpose hierarchical state machine for gameplay logic.
## Use for player state (idle/run/jump/attack), enemy state, game flow, etc.
## Each state is a Dictionary: { enter, exit, tick, transitions: [{to, when}] }
##
## Usage:
##   var sm := StateMachine.new()
##   sm.add_state(&"idle",   { "enter": func(): ..., "tick": func(d): ... })
##   sm.add_state(&"run",    { "tick": func(d): ... })
##   sm.add_transition(&"idle", &"run",  func(): return speed > 0.1)
##   sm.add_transition(&"run",  &"idle", func(): return speed <= 0.1)
##   sm.start(&"idle")
##   ## In tick: sm.tick(delta)
class_name GameplayStateMachine
extends RefCounted

var _states       : Dictionary = {}  ## StringName → { enter, exit, tick, transitions }
var _current      : StringName = &""
var _previous     : StringName = &""
var _transitions  : Dictionary = {}  ## StringName → Array[{ to, when }]
var entity        : int        = -1  ## Optional entity context

signal state_changed(from: StringName, to: StringName)

func add_state(name: StringName, config: Dictionary = {}) -> GameplayStateMachine:
	_states[name]      = config
	_transitions[name] = []
	return self

func add_transition(from: StringName, to: StringName, condition: Callable) -> GameplayStateMachine:
	if not _transitions.has(from):
		_transitions[from] = []
	(_transitions[from] as Array).append({"to": to, "when": condition})
	return self

func start(initial: StringName) -> void:
	_current = initial
	_call_enter(initial)

func tick(delta: float) -> void:
	if _current == &"":
		return
	## Check transitions first
	for t : Dictionary in (_transitions.get(_current, []) as Array):
		if (t.when as Callable).call():
			transition(t.to)
			return
	## Tick current state
	var state := _states.get(_current, {}) as Dictionary
	if state.has("tick") and (state.tick as Callable).is_valid():
		(state.tick as Callable).call(delta)

func transition(to: StringName) -> void:
	if not _states.has(to):
		Log.warn("[StateMachine] Unknown state: %s" % to)
		return
	_call_exit(_current)
	_previous = _current
	_current  = to
	_call_enter(to)
	state_changed.emit(_previous, _current)

func force(state: StringName) -> void:
	transition(state)

func current() -> StringName:
	return _current

func previous() -> StringName:
	return _previous

func is_in(state: StringName) -> bool:
	return _current == state

func _call_enter(state: StringName) -> void:
	var s := _states.get(state, {}) as Dictionary
	if s.has("enter") and (s.enter as Callable).is_valid():
		(s.enter as Callable).call()

func _call_exit(state: StringName) -> void:
	var s := _states.get(state, {}) as Dictionary
	if s.has("exit") and (s.exit as Callable).is_valid():
		(s.exit as Callable).call()
