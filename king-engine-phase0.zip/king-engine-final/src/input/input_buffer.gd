## InputBuffer — ring buffer for recent inputs.
##
## Stores the last MAX_BUFFER input events so systems can ask
## "was X pressed within the last N frames?" — critical for responsive
## mobile/gamepad feel (coyote time, combo inputs, etc.).
##
## Uses a fixed-size ring buffer (no per-frame allocation) instead of
## rebuilding via filter() each frame.
extends Node

const MAX_BUFFER : int = 32

## Circular buffer entries: { action, frame, time_ms }
var _buffer   : Array = []
var _head     : int   = 0   ## next write index
var _size     : int   = 0   ## number of valid entries
var _frame    : int   = 0

func _ready() -> void:
	_buffer.resize(MAX_BUFFER)
	for i in MAX_BUFFER:
		_buffer[i] = {"action": &"", "frame": 0, "time_ms": 0}
	set_process(true)
	Bus.on(&"input.action", _on_input_action)

func _exit_tree() -> void:
	Bus.off(&"input.action", _on_input_action)

func _process(_delta: float) -> void:
	_frame += 1

func _on_input_action(data: Variant) -> void:
	if not data is Dictionary: return
	var action := StringName(str((data as Dictionary).get("action", "")))
	if action != &"": record(action)

# ── Public API ─────────────────────────────────────────────────────────────────

func record(action: StringName) -> void:
	_buffer[_head] = {
		"action":  action,
		"frame":   _frame,
		"time_ms": Time.get_ticks_msec()
	}
	_head = (_head + 1) % MAX_BUFFER
	_size = mini(_size + 1, MAX_BUFFER)

## True if action was pressed within the last `frames` frames.
func was_pressed(action: StringName, frames: int = 6) -> bool:
	var cutoff := _frame - frames
	for i in range(_size):
		var idx  := (_head - 1 - i + MAX_BUFFER) % MAX_BUFFER
		var entry := _buffer[idx] as Dictionary
		if int(entry.get("frame", 0)) < cutoff:
			break   ## Ring is newest-first from head; stop at first stale entry.
		if entry.get("action") == action:
			return true
	return false

## True if action was pressed within the last `ms` milliseconds.
func was_pressed_ms(action: StringName, ms: int = 100) -> bool:
	var cutoff := Time.get_ticks_msec() - ms
	for i in range(_size):
		var idx   := (_head - 1 - i + MAX_BUFFER) % MAX_BUFFER
		var entry := _buffer[idx] as Dictionary
		if int(entry.get("time_ms", 0)) < cutoff:
			break
		if entry.get("action") == action:
			return true
	return false

## Consume the buffered input (prevents double-triggering).
func consume(action: StringName) -> bool:
	for i in range(_size):
		var idx   := (_head - 1 - i + MAX_BUFFER) % MAX_BUFFER
		var entry := _buffer[idx] as Dictionary
		if entry.get("action") == action:
			(_buffer[idx] as Dictionary)["action"] = &""
			return true
	return false

## Number of times action appears in the current window.
func count_in_window(action: StringName, frames: int = 6) -> int:
	var cutoff := _frame - frames
	var n := 0
	for i in range(_size):
		var idx   := (_head - 1 - i + MAX_BUFFER) % MAX_BUFFER
		var entry := _buffer[idx] as Dictionary
		if int(entry.get("frame", 0)) < cutoff: break
		if entry.get("action") == action: n += 1
	return n

func clear() -> void:
	_head = 0
	_size = 0
	for i in MAX_BUFFER:
		(_buffer[i] as Dictionary)["action"] = &""

func current_frame() -> int:
	return _frame
