## InputManager — polls hardware input (keyboard / gamepad) each frame.
##
## Mobile vs desktop split:
##   On mobile, TouchInput owns move_dir for the player entity — it writes
##   directly into InputComponent.move_dir every frame. InputManager must NOT
##   overwrite that with Input.get_axis() (which returns 0 on phone).
##
##   On desktop/gamepad, InputManager owns move_dir and look_dir as before.
##   On any platform, InputManager still owns action buttons and held timers,
##   because touch buttons (when added) will emit input.action via Bus and
##   consume() from InputBuffer — they don't need InputManager to poll them.
##
## Rule: if Kernel.is_mobile and not PlatformManager.is_desktop → skip move/look poll.
extends SystemBase

const ACTION_NAMES : Array[StringName] = [
	&"jump", &"attack", &"dodge", &"interact", &"sprint",
	&"ability_1", &"ability_2", &"ability_3", &"ability_4",
	&"pause", &"map"
]

func _on_start() -> void:
	priority = 10

func tick(delta: float) -> void:
	var entities := query([&"Input"])
	for id : int in entities:
		var ic := get_c(id, &"Input") as InputComponent
		if ic == null or not ic.enabled:
			continue
		_poll(id, ic, delta)

func _poll(entity: int, ic: InputComponent, delta: float) -> void:
	## Hardware move/look: only on non-mobile (TouchInput handles mobile).
	if not Kernel.is_mobile:
		var move := Vector2.ZERO
		move.x = Input.get_axis(&"move_left",  &"move_right")
		move.y = Input.get_axis(&"move_forward", &"move_back")
		ic.move_dir = move
		if move != Vector2.ZERO:
			Bus.emit(&"input.move", {"entity": entity, "data": {"move": move}})

		var look := Vector2.ZERO
		look.x = Input.get_axis(&"look_left", &"look_right")
		look.y = Input.get_axis(&"look_up",   &"look_down")
		ic.look_dir = look

	## Gamepad right-stick look applies on all platforms
	## (a physical gamepad connected to a phone should still work).
	elif Input.get_connected_joypads().size() > 0:
		var look := Vector2.ZERO
		look.x = Input.get_axis(&"look_left", &"look_right")
		look.y = Input.get_axis(&"look_up",   &"look_down")
		if look.length_squared() > 0.01:
			ic.look_dir = look

	## Action buttons — platform-agnostic (hardware keys / gamepad buttons).
	ic.actions.clear()
	for action : StringName in ACTION_NAMES:
		if not InputMap.has_action(action):
			continue
		var pressed := Input.is_action_just_pressed(action)
		ic.actions[action] = pressed
		if pressed:
			Bus.emit(&"input.action", {
				"entity":  entity,
				"action":  action,
				"pressed": true
			})
		if Input.is_action_pressed(action):
			ic.held[action] = ic.held.get(action, 0.0) + delta
		else:
			ic.held.erase(action)
