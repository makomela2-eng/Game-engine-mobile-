## InputMap — custom action → binding registry (wraps Godot InputMap).
## Use to register actions at runtime rather than hardcoding in project settings.
extends Node

## Register a keyboard action at runtime.
func register_key(action: StringName, key: Key, modifiers: int = 0) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev       := InputEventKey.new()
	ev.keycode   = key
	ev.ctrl_pressed  = bool(modifiers & KEY_MASK_CTRL)
	ev.shift_pressed = bool(modifiers & KEY_MASK_SHIFT)
	InputMap.action_add_event(action, ev)

## Register a gamepad button action.
func register_pad_button(action: StringName, button: JoyButton) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev    := InputEventJoypadButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)

## Register a gamepad axis action.
func register_pad_axis(action: StringName, axis: JoyAxis, positive: bool = true) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev        := InputEventJoypadMotion.new()
	ev.axis        = axis
	ev.axis_value  = 1.0 if positive else -1.0
	InputMap.action_add_event(action, ev)

func load_defaults() -> void:
	register_key(&"move_right",   KEY_D)
	register_key(&"move_left",    KEY_A)
	register_key(&"move_forward", KEY_W)
	register_key(&"move_back",    KEY_S)
	register_key(&"jump",         KEY_SPACE)
	register_key(&"interact",     KEY_E)
	register_key(&"sprint",       KEY_SHIFT)
	register_key(&"pause",        KEY_ESCAPE)
	register_pad_button(&"jump",     JOY_BUTTON_A)
	register_pad_button(&"attack",   JOY_BUTTON_X)
	register_pad_button(&"dodge",    JOY_BUTTON_B)
	register_pad_button(&"interact", JOY_BUTTON_Y)
	register_pad_axis(&"move_right",   JOY_AXIS_LEFT_X, true)
	register_pad_axis(&"move_left",    JOY_AXIS_LEFT_X, false)
	register_pad_axis(&"move_forward", JOY_AXIS_LEFT_Y, false)
	register_pad_axis(&"move_back",    JOY_AXIS_LEFT_Y, true)
	Log.info("[InputMap] Default bindings loaded")
