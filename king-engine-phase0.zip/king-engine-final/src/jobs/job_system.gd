## JobSystem — budgeted deferred work queue with priority heap.
##
## Enqueuing inserts into a sorted heap in O(log n) rather than sorting the
## entire queue on every push. Budget tracking uses a real timer so it adapts
## to actual frame time rather than a hardcoded 2ms constant.
##
## Labels: jobs can be cancelled by label before they execute.
## Callbacks: optional on_complete(result) called after fn() returns.
extends Node

class Job extends RefCounted:
	var fn          : Callable
	var priority    : int        = 0
	var label       : StringName = &""
	var on_complete : Callable   = Callable()
	func _init(callable: Callable, prio: int = 0,
			lbl: StringName = &"",
			cb: Callable = Callable()) -> void:
		fn = callable; priority = prio; label = lbl; on_complete = cb

var _queue      : Array[Job] = []   ## min-heap by priority (higher = sooner)
var _budget_ms  : float      = 2.0
var _completed  : int        = 0
var _cancelled  : int        = 0

func _ready() -> void:
	set_process(true)

func _process(_delta: float) -> void:
	if _queue.is_empty():
		return
	var start_us := Time.get_ticks_usec()
	var budget_us := _budget_ms * 1000.0
	while not _queue.is_empty():
		if float(Time.get_ticks_usec() - start_us) >= budget_us:
			break
		var job := _heap_pop()
		if job.fn.is_valid():
			var result : Variant = job.fn.call()
			_completed += 1
			if job.on_complete.is_valid():
				job.on_complete.call(result)

# ── Enqueue ────────────────────────────────────────────────────────────────────

func enqueue(fn: Callable, priority: int = 0,
		label: StringName = &"",
		on_complete: Callable = Callable()) -> void:
	var job := Job.new(fn, priority, label, on_complete)
	_heap_push(job)

func enqueue_batch(fns: Array[Callable], priority: int = 0) -> void:
	for fn : Callable in fns:
		enqueue(fn, priority)

## Cancel all pending jobs with the given label.
func cancel_by_label(label: StringName) -> int:
	var before := _queue.size()
	_queue = _queue.filter(func(j: Job) -> bool: return j.label != label)
	var count := before - _queue.size()
	_cancelled += count
	return count

func cancel_all() -> void:
	_cancelled += _queue.size()
	_queue.clear()

func set_budget(ms: float) -> void:
	_budget_ms = maxf(ms, 0.1)

func pending_count() -> int:
	return _queue.size()

func completed_count() -> int:
	return _completed

func cancelled_count() -> int:
	return _cancelled

func stats() -> Dictionary:
	return {
		"pending":   _queue.size(),
		"completed": _completed,
		"cancelled": _cancelled,
		"budget_ms": _budget_ms,
	}

# ── Binary heap (max-heap by priority) ────────────────────────────────────────

func _heap_push(job: Job) -> void:
	_queue.append(job)
	_sift_up(_queue.size() - 1)

func _heap_pop() -> Job:
	var top : Job = _queue[0] as Job
	var last : Job = _queue.pop_back() as Job
	if not _queue.is_empty():
		_queue[0] = last
		_sift_down(0)
	return top

func _sift_up(i: int) -> void:
	while i > 0:
		var parent := (i - 1) / 2
		if (_queue[i] as Job).priority > (_queue[parent] as Job).priority:
			var tmp : Job = _queue[i] as Job
			_queue[i] = _queue[parent]
			_queue[parent] = tmp
			i = parent
		else:
			break

func _sift_down(i: int) -> void:
	var n := _queue.size()
	while true:
		var largest := i
		var l := 2 * i + 1
		var r := 2 * i + 2
		if l < n and (_queue[l] as Job).priority > (_queue[largest] as Job).priority:
			largest = l
		if r < n and (_queue[r] as Job).priority > (_queue[largest] as Job).priority:
			largest = r
		if largest == i: break
		var tmp : Job = _queue[i] as Job
		_queue[i] = _queue[largest]
		_queue[largest] = tmp
		i = largest
