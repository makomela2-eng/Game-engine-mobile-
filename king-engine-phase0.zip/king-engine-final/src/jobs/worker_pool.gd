## WorkerPool — manages a pool of WorkerThreads for CPU-bound tasks.
## Use for heavy operations: mesh baking, pathfinding, large data transforms.
## IMPORTANT: Godot resources are NOT thread-safe. Only pass plain data.
extends Node

var _threads   : Array[Thread] = []
var _queue     : Array[Dictionary] = []   ## { fn, args, callback }
var _mutex     : Mutex  = Mutex.new()
var _semaphore : Semaphore = Semaphore.new()
var _stop      : bool   = false
var _running   : bool   = false
var pool_size  : int    = 2
var max_queue  : int    = 1024

func _ready() -> void:
	_start_pool(pool_size)

func _start_pool(size: int) -> void:
	if _running:
		return
	_running = true
	for i in range(maxi(size, 1)):
		var t := Thread.new()
		t.start(Callable(self, "_worker_loop"))
		_threads.append(t)
	Log.info("[WorkerPool] Started %d threads" % size)

func submit(fn: Callable, args: Array = [], callback: Callable = Callable()) -> bool:
	if not fn.is_valid():
		return false
	_mutex.lock()
	if _queue.size() >= max_queue:
		_mutex.unlock()
		Log.warn("[WorkerPool] queue full")
		return false
	_queue.append({"fn": fn, "args": args, "callback": callback})
	_mutex.unlock()
	_semaphore.post()
	return true

func _worker_loop() -> void:
	while true:
		_semaphore.wait()
		if _stop:
			break
		var item : Dictionary = {}
		_mutex.lock()
		if not _queue.is_empty():
			item = _queue.pop_front()
		_mutex.unlock()
		if item.is_empty():
			continue
		var result = (item.get("fn") as Callable).callv(item.get("args", []))
		var cb : Callable = item.get("callback", Callable())
		if cb.is_valid():
			call_deferred("_dispatch_callback", cb, result)

func _dispatch_callback(cb: Callable, result: Variant) -> void:
	if cb.is_valid():
		cb.call(result)

func _exit_tree() -> void:
	_stop = true
	for i in range(_threads.size()):
		_semaphore.post()
	for t : Thread in _threads:
		if t.is_started():
			t.wait_to_finish()
	_threads.clear()
	_running = false

func shutdown() -> void:
	_exit_tree()

func active_count() -> int:
	return _threads.size()

func pending_count() -> int:
	return _queue.size()
