## NetworkState — connection state, quality, reconnect, and packet validation.
##
## Canonical version. The src/services/ duplicate has been removed.
##
## State machine:
##   OFFLINE → CONNECTING → CONNECTED / HOSTING
##   CONNECTED / HOSTING → OFFLINE (on disconnect)
##
## Reconnect discipline:
##   Exponential backoff, named TaskScheduler slot + session_id guard.
##   Emits network_reconnect_attempt (BusEvents.NetworkReconnectAttempt) so
##   callers can show UI feedback without polling.
##
## Quality scoring (0=poor, 1=fair, 2=good):
##   Driven by ping_ms and packet_loss set externally via set_ping / set_packet_loss.
extends Node

enum State { OFFLINE, CONNECTING, CONNECTED, HOSTING }

signal state_changed(state: State)
signal quality_changed(ping: int, loss: float)
signal connection_quality_changed(quality: int)  ## legacy alias

var current_state       : State = State.OFFLINE
var ping_ms             : int   = 0
var packet_loss         : float = 0.0
var quality             : int   = 2   ## 0=poor 1=fair 2=good
var _reconnect_attempts : int   = 0
var _session_id         : int   = 0

const MAX_RECONNECT  : int        = 5
const RECONNECT_KEY  : StringName = &"network_reconnect"

func _ready() -> void:
	Bus.on(&"net.hosting",       _on_hosting)
	Bus.on(&"net.connected",     _on_connected)
	Bus.on(&"net.disconnected",  _on_disconnected)
	Bus.on(&"net.state_changed", _on_net_state_changed)
	## Legacy signals from NetworkManager.
	Bus.on(&"connected_to_server", func(_d: Variant) -> void: _on_connect())
	Bus.on(&"connection_failed",   func(_d: Variant) -> void: _try_reconnect())
	TaskScheduler.schedule(&"network_health", 2.0, _check_health)

func _exit_tree() -> void:
	Bus.off(&"net.hosting",       _on_hosting)
	Bus.off(&"net.connected",     _on_connected)
	Bus.off(&"net.disconnected",  _on_disconnected)
	Bus.off(&"net.state_changed", _on_net_state_changed)
	TaskScheduler.unschedule(&"network_health")
	_cancel_reconnect()

# ── Net events ────────────────────────────────────────────────────────────────

func _on_hosting(_d: Variant) -> void:
	current_state = State.HOSTING
	_on_connect()
	state_changed.emit(current_state)

func _on_connected(_d: Variant) -> void:
	current_state = State.CONNECTED
	_on_connect()
	state_changed.emit(current_state)

func _on_disconnected(_d: Variant) -> void:
	current_state = State.OFFLINE
	_on_disconnect()
	state_changed.emit(current_state)

func _on_net_state_changed(_data: Variant) -> void:
	state_changed.emit(current_state)

# ── Connect / disconnect ──────────────────────────────────────────────────────

func _on_connect() -> void:
	_reconnect_attempts = 0
	packet_loss         = 0.0
	_update_quality()
	_cancel_reconnect()
	Log.info("[NetworkState] connected (%s)" % State.keys()[current_state])
	Bus.emit(&"network_connected", {"state": current_state})

func _on_disconnect() -> void:
	Log.warn("[NetworkState] disconnected")
	Bus.emit(&"network_disconnected", {"state": current_state})
	_try_reconnect()

# ── Reconnect ─────────────────────────────────────────────────────────────────

func _try_reconnect() -> void:
	if _reconnect_attempts >= MAX_RECONNECT:
		Log.error("[NetworkState] max reconnect attempts reached")
		Bus.emit(&"network_failed", null)
		return
	_reconnect_attempts += 1
	_session_id         += 1
	var delay   : float = 2.0 * _reconnect_attempts
	var attempt : int   = _reconnect_attempts
	var session : int   = _session_id
	Log.info("[NetworkState] reconnect attempt %d in %.0fs" % [attempt, delay])
	TaskScheduler.unschedule(RECONNECT_KEY)
	TaskScheduler.schedule(RECONNECT_KEY, delay, func() -> void:
		if session != _session_id or is_online(): return
		TaskScheduler.unschedule(RECONNECT_KEY)
		Bus.emit(&"network_reconnect_attempt",
			BusEvents.NetworkReconnectAttempt.new(attempt, session)))

func _cancel_reconnect() -> void:
	_session_id += 1
	TaskScheduler.unschedule(RECONNECT_KEY)

# ── Health / quality ──────────────────────────────────────────────────────────

func _check_health() -> void:
	if not is_online(): return
	_update_quality()

func _update_quality() -> void:
	var new_quality : int = 2
	if packet_loss > 0.15 or ping_ms >= 200:
		new_quality = 0
	elif packet_loss > 0.05 or ping_ms >= 80:
		new_quality = 1
	if new_quality != quality:
		quality = new_quality
		connection_quality_changed.emit(quality)  ## legacy
		quality_changed.emit(ping_ms, packet_loss)
		Bus.emit(&"network_quality", BusEvents.NetworkQuality.new(quality, ping_ms))

func set_ping(ms: int) -> void:
	ping_ms = maxi(ms, 0)
	_update_quality()

func set_packet_loss(loss: float) -> void:
	packet_loss = clampf(loss, 0.0, 1.0)
	_update_quality()

# ── Packet validation ─────────────────────────────────────────────────────────

func validate_packet(data: Dictionary, required_keys: Array) -> bool:
	for key : Variant in required_keys:
		if not data.has(key):
			Log.warn("[NetworkState] invalid packet: missing key '%s'" % str(key))
			return false
	return true

# ── Queries ───────────────────────────────────────────────────────────────────

func is_online() -> bool:
	return current_state != State.OFFLINE

func is_server() -> bool:
	return current_state == State.HOSTING

func get_status() -> Dictionary:
	return {
		"state":               State.keys()[current_state],
		"quality":             quality,
		"ping_ms":             ping_ms,
		"packet_loss":         packet_loss,
		"reconnect_attempts":  _reconnect_attempts,
	}
