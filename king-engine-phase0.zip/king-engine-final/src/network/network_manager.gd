## NetworkManager — manages peer connections via Godot's multiplayer API.
extends Node

enum NetState { OFFLINE, CONNECTING, CONNECTED, HOSTING, DISCONNECTING }

var state       : NetState = NetState.OFFLINE
var peer_id     : int      = 0
var max_players : int      = 16
var port        : int      = 7777

signal peer_connected(id: int)
signal peer_disconnected(id: int)
signal connection_failed
signal connected_to_server

func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_connection_failed)

func _exit_tree() -> void:
	if multiplayer.peer_connected.is_connected(_on_peer_connected):
		multiplayer.peer_connected.disconnect(_on_peer_connected)
	if multiplayer.peer_disconnected.is_connected(_on_peer_disconnected):
		multiplayer.peer_disconnected.disconnect(_on_peer_disconnected)
	if multiplayer.connected_to_server.is_connected(_on_connected):
		multiplayer.connected_to_server.disconnect(_on_connected)
	if multiplayer.connection_failed.is_connected(_on_connection_failed):
		multiplayer.connection_failed.disconnect(_on_connection_failed)

func host(p: int = 7777, max_peers: int = 16) -> bool:
	port = p
	max_players = max_peers
	var mp_peer := ENetMultiplayerPeer.new()
	var err := mp_peer.create_server(port, max_players)
	if err != OK:
		Log.error("[NetworkManager] Host failed: %s" % error_string(err))
		return false
	multiplayer.multiplayer_peer = mp_peer
	state = NetState.HOSTING
	peer_id = multiplayer.get_unique_id()
	Bus.emit(&"net.state_changed", {"state": state})
	Bus.emit(&"net.hosting", {"port": port})
	Log.info("[NetworkManager] Hosting on port %d" % port)
	return true

func join(address: String, p: int = 7777) -> bool:
	port = p
	state = NetState.CONNECTING
	Bus.emit(&"net.state_changed", {"state": state})
	var mp_peer := ENetMultiplayerPeer.new()
	var err := mp_peer.create_client(address, port)
	if err != OK:
		Log.error("[NetworkManager] Join failed: %s" % error_string(err))
		state = NetState.OFFLINE
		Bus.emit(&"net.state_changed", {"state": state})
		return false
	multiplayer.multiplayer_peer = mp_peer
	Log.info("[NetworkManager] Connecting to %s:%d" % [address, port])
	return true

func disconnect_all() -> void:
	state = NetState.DISCONNECTING
	Bus.emit(&"net.state_changed", {"state": state})
	multiplayer.multiplayer_peer = null
	peer_id = 0
	state = NetState.OFFLINE
	Bus.emit(&"net.state_changed", {"state": state})
	Bus.emit(&"net.disconnected", {})

func is_server() -> bool:
	return multiplayer.is_server()

func get_peers() -> Array[int]:
	var result : Array[int] = []
	for id in multiplayer.get_peers():
		result.append(id)
	return result

func get_state_name() -> StringName:
	return StringName(NetState.keys()[state])

func _on_peer_connected(id: int) -> void:
	Log.info("[NetworkManager] Peer connected: %d" % id)
	Bus.emit(&"net.connected", {"peer": id})
	peer_connected.emit(id)

func _on_peer_disconnected(id: int) -> void:
	Log.info("[NetworkManager] Peer disconnected: %d" % id)
	Bus.emit(&"net.disconnected", {"peer": id})
	peer_disconnected.emit(id)

func _on_connected() -> void:
	peer_id = multiplayer.get_unique_id()
	state   = NetState.CONNECTED
	Bus.emit(&"net.state_changed", {"state": state})
	connected_to_server.emit()

func _on_connection_failed() -> void:
	state = NetState.OFFLINE
	Bus.emit(&"net.state_changed", {"state": state})
	connection_failed.emit()
