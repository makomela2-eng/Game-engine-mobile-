## ReplicationSystem — entity replication registry with dirty-flag delta tracking.
##
## Only components flagged dirty since last snapshot are included in delta
## snapshots, drastically reducing bandwidth at scale (80–150 entities).
##
## Authority model: server owns all entities unless explicitly assigned to a peer.
## Clients apply incoming snapshots; server collects and distributes them.
##
## Component serialization contract:
##   Component.serialize() → Dictionary   (full state)
##   Component.serialize_delta() → Dictionary | null  (nil = unchanged)
##   Component.deserialize(data: Dictionary) → void
extends Node

## entity_id → { owner: int, types: Array[StringName], dirty: bool }
var _replicated  : Dictionary = {}
## entity_id → { type_str → last_serialized_hash: int }
var _last_hashes : Dictionary = {}

func _ready() -> void:
	Bus.on(&"ecs.entity_destroyed",  _on_entity_destroyed)
	Bus.on(&"ecs.component_added",   _on_component_changed)
	Bus.on(&"ecs.component_removed", _on_component_changed)

func _exit_tree() -> void:
	Bus.off(&"ecs.entity_destroyed",  _on_entity_destroyed)
	Bus.off(&"ecs.component_added",   _on_component_changed)
	Bus.off(&"ecs.component_removed", _on_component_changed)

# ── Registration ───────────────────────────────────────────────────────────────

func register(entity: int, peer_owner: int = 1,
		types: Array[StringName] = []) -> void:
	_replicated[entity] = {
		"owner": peer_owner,
		"types": types.duplicate(),
		"dirty": true   ## force full snapshot on first sync
	}
	_last_hashes[entity] = {}

func unregister(entity: int) -> void:
	_replicated.erase(entity)
	_last_hashes.erase(entity)

func clear() -> void:
	_replicated.clear()
	_last_hashes.clear()

func is_replicated(entity: int) -> bool:
	return _replicated.has(entity)

func get_entity_owner(entity: int) -> int:
	return int((_replicated.get(entity, {}) as Dictionary).get("owner", -1))

func is_local_authority(entity: int) -> bool:
	var peer_owner := get_entity_owner(entity)
	return peer_owner == multiplayer.get_unique_id() or multiplayer.is_server()

func mark_dirty(entity: int) -> void:
	if _replicated.has(entity):
		(_replicated[entity] as Dictionary)["dirty"] = true

# ── Snapshots ─────────────────────────────────────────────────────────────────

## Full snapshot for one entity (ignores dirty flag).
func snapshot_entity(entity: int) -> Dictionary:
	if not _replicated.has(entity): return {}
	var entry := _replicated[entity] as Dictionary
	var types  : Array[StringName] = entry.get("types", [])
	var comps  : Dictionary = {}
	for type : StringName in types:
		var comp: Variant = EntityManager.get_component(entity, type)
		if comp == null: continue
		var data : Variant = null
		if comp.has_method("serialize"):
			data = comp.call("serialize")
		elif comp.has_method("snapshot"):
			data = comp.call("snapshot")
		if data is Dictionary:
			comps[str(type)] = data
	return {"entity": entity, "components": comps, "full": true}

## Delta snapshot: only components whose serialized hash changed since last call.
func delta_snapshot_entity(entity: int) -> Dictionary:
	if not _replicated.has(entity): return {}
	var entry  := _replicated[entity] as Dictionary
	var types   : Array[StringName] = entry.get("types", [])
	var hashes  : Dictionary = _last_hashes.get(entity, {}) as Dictionary
	var comps   : Dictionary = {}
	var is_full : bool       = bool(entry.get("dirty", true))
	for type : StringName in types:
		var comp: Variant = EntityManager.get_component(entity, type)
		if comp == null: continue
		var data : Variant = null
		if is_full:
			if comp.has_method("serialize"):
				data = comp.call("serialize")
		else:
			if comp.has_method("serialize_delta"):
				data = comp.call("serialize_delta")
			elif comp.has_method("serialize"):
				## Fallback: compare hash to detect changes.
				var full_data : Variant = comp.call("serialize")
				var h : int = JSON.stringify(full_data).hash()
				var last_h : int = int(hashes.get(str(type), -1))
				if h != last_h:
					data = full_data
					hashes[str(type)] = h
		if data is Dictionary:
			comps[str(type)] = data
	if not comps.is_empty():
		entry["dirty"] = false
	return {"entity": entity, "components": comps, "full": is_full} if not comps.is_empty() else {}

## Full world snapshot (server only).
func full_snapshot() -> Array[Dictionary]:
	var result : Array[Dictionary] = []
	for entity in _replicated.keys():
		var snap := snapshot_entity(int(entity))
		if not snap.is_empty():
			result.append(snap)
	return result

## Delta world snapshot — only dirty/changed entities.
func delta_snapshot() -> Array[Dictionary]:
	var result : Array[Dictionary] = []
	for entity in _replicated.keys():
		var snap := delta_snapshot_entity(int(entity))
		if not snap.is_empty():
			result.append(snap)
	return result

func apply_snapshot(snapshot: Array[Dictionary]) -> void:
	for item in snapshot:
		if not item is Dictionary: continue
		var d      := item as Dictionary
		var entity := int(d.get("entity", -1))
		if entity < 0: continue
		## Auto-create entity on client if missing.
		if not EntityManager.entity_exists(entity):
			EntityManager.create_entity_with_id(entity)
		var comps : Variant = d.get("components", {})
		if not comps is Dictionary: continue
		for key in (comps as Dictionary).keys():
			var type := StringName(str(key))
			var comp: Variant = EntityManager.get_component(entity, type)
			if comp != null and comp.has_method("deserialize"):
				comp.call("deserialize", (comps as Dictionary)[key])

func replicated_count() -> int:
	return _replicated.size()

func dirty_count() -> int:
	var n := 0
	for entry in _replicated.values():
		if bool((entry as Dictionary).get("dirty", false)): n += 1
	return n

# ── Event handlers ────────────────────────────────────────────────────────────

func _on_entity_destroyed(data: Variant) -> void:
	if data is Dictionary:
		unregister(int((data as Dictionary).get("entity", -1)))

func _on_component_changed(data: Variant) -> void:
	if not data is Dictionary: return
	var entity := int((data as Dictionary).get("entity", -1))
	if entity >= 0: mark_dirty(entity)
