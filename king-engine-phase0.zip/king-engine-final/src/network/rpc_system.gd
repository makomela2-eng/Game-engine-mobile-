## RPCSystem — typed RPC dispatcher with reliability modes, call ID tracking,
## and request-response support.
##
## Reliability:
##   call_reliable()   → guaranteed delivery (Godot reliable channel)
##   call_unreliable() → best-effort, lower latency (good for position updates)
##
## Request-response:
##   request_response(peer, name, args, callback, timeout_sec)
##   Server calls callback(result) or callback(null) on timeout.
##
## Registration:
##   RPCSystem.register(&"my_method", my_callable)
##   Handlers receive (args: Array) → Variant
extends Node

var _handlers  : Dictionary = {}   ## StringName → Callable
## call_id → { callback: Callable, timeout: float, elapsed: float }
var _pending   : Dictionary = {}
var _next_id   : int        = 0

func _ready() -> void:
	set_process(true)

func _process(delta: float) -> void:
	if _pending.is_empty(): return
	for id in _pending.keys().duplicate():
		var entry := _pending[id] as Dictionary
		entry["elapsed"] = float(entry.get("elapsed", 0.0)) + delta
		if float(entry.get("elapsed", 0.0)) >= float(entry.get("timeout", 5.0)):
			var cb := entry.get("callback") as Callable
			if cb.is_valid(): cb.call(null)
			_pending.erase(id)

# ── Registration ───────────────────────────────────────────────────────────────

func register(name: StringName, fn: Callable) -> void:
	_handlers[name] = fn

func unregister(name: StringName) -> void:
	_handlers.erase(name)

# ── Remote calls ───────────────────────────────────────────────────────────────

## Reliable ordered delivery.
func call_remote(peer_id: int, name: StringName, args: Array = []) -> void:
	if peer_id == 0:
		rpc(&"_receive_reliable", str(name), args, -1)
	else:
		rpc_id(peer_id, &"_receive_reliable", str(name), args, -1)

## Unreliable (use for high-frequency updates like positions).
func call_unreliable(peer_id: int, name: StringName, args: Array = []) -> void:
	if peer_id == 0:
		rpc(&"_receive_unreliable", str(name), args, -1)
	else:
		rpc_id(peer_id, &"_receive_unreliable", str(name), args, -1)

## Call server only.
func call_server(name: StringName, args: Array = []) -> void:
	if multiplayer.is_server():
		_dispatch(name, args, -1)
	else:
		rpc_id(1, &"_receive_reliable", str(name), args, -1)

## Broadcast to all including self.
func broadcast(name: StringName, args: Array = []) -> void:
	_dispatch(name, args, -1)
	rpc(&"_receive_reliable", str(name), args, -1)

## Request-response: callback(result) called when handler returns, or callback(null) on timeout.
func request_response(peer_id: int, name: StringName, args: Array = [],
		callback: Callable = Callable(), timeout_sec: float = 5.0) -> int:
	var call_id := _next_id
	_next_id   += 1
	if callback.is_valid():
		_pending[call_id] = {
			"callback": callback,
			"timeout":  timeout_sec,
			"elapsed":  0.0
		}
	if peer_id == multiplayer.get_unique_id() or multiplayer.is_server() and peer_id == 1:
		var result : Variant = _dispatch(name, args, call_id)
		_resolve(call_id, result)
	else:
		rpc_id(peer_id, &"_receive_reliable", str(name), args, call_id)
	return call_id

# ── Receive ────────────────────────────────────────────────────────────────────

@rpc("any_peer", "reliable")
func _receive_reliable(name: String, args: Array, call_id: int) -> void:
	var result : Variant = _dispatch(StringName(name), args, call_id)
	if call_id >= 0 and multiplayer.get_remote_sender_id() > 0:
		rpc_id(multiplayer.get_remote_sender_id(),
			&"_on_response", call_id, result)

@rpc("any_peer", "unreliable")
func _receive_unreliable(name: String, args: Array, _call_id: int) -> void:
	_dispatch(StringName(name), args, -1)

@rpc("any_peer", "reliable")
func _on_response(call_id: int, result: Variant) -> void:
	_resolve(call_id, result)

# ── Internal ───────────────────────────────────────────────────────────────────

func _dispatch(_name: StringName, args: Array, _call_id: int) -> Variant:
	if not _handlers.has(_name):
		Log.warn("[RPCSystem] No handler: %s" % _name)
		return null
	return (_handlers[_name] as Callable).callv(args)

func _resolve(call_id: int, result: Variant) -> void:
	if not _pending.has(call_id): return
	var cb := (_pending[call_id] as Dictionary).get("callback") as Callable
	_pending.erase(call_id)
	if cb.is_valid(): cb.call(result)

func pending_count() -> int: return _pending.size()
func handler_count() -> int: return _handlers.size()
