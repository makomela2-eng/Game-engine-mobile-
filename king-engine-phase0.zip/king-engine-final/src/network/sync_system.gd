## SyncSystem — server-side snapshot distribution with delta compression
## and per-peer interest management.
##
## Sends delta snapshots (only changed components) to each connected peer.
## Peers that just connected receive a full snapshot on their first sync.
## Bandwidth cap: if delta payload exceeds max_bytes_per_peer, the snapshot
## is split across multiple sync intervals.
extends Node

var sync_rate_hz      : float = 20.0    ## syncs per second
var max_bytes_per_peer: int   = 8192    ## soft cap per peer per sync
var _timer            : float = 0.0
var _enabled          : bool  = false
## peer_id → bool (true = needs full snapshot on next sync)
var _needs_full       : Dictionary = {}

func _ready() -> void:
	set_process(false)
	Bus.on(&"net.connected",    _on_peer_connected)
	Bus.on(&"net.disconnected", _on_peer_disconnected)

func _exit_tree() -> void:
	Bus.off(&"net.connected",    _on_peer_connected)
	Bus.off(&"net.disconnected", _on_peer_disconnected)

func start() -> void:
	if not multiplayer.is_server():
		Log.warn("[SyncSystem] start() called on non-server — ignoring")
		return
	_enabled = true
	set_process(true)
	Log.info("[SyncSystem] Started at %.0f Hz" % sync_rate_hz)

func stop() -> void:
	_enabled = false
	set_process(false)

func _process(delta: float) -> void:
	if not _enabled: return
	_timer += delta
	if _timer < 1.0 / sync_rate_hz: return
	_timer = 0.0
	_distribute()

func _distribute() -> void:
	var peers := multiplayer.get_peers()
	if peers.is_empty(): return

	## Build delta snapshot once and share reference across peers.
	var delta_snap := ReplicationSystem.delta_snapshot()

	for peer_id in peers:
		var snapshot : Array[Dictionary]
		if _needs_full.get(peer_id, false):
			snapshot = ReplicationSystem.full_snapshot()
			_needs_full[peer_id] = false
		else:
			snapshot = delta_snap

		if snapshot.is_empty(): continue

		## Soft byte cap: split into chunks if needed.
		var serialized : String = JSON.stringify(snapshot)
		if serialized.length() > max_bytes_per_peer:
			var chunk_size := max_bytes_per_peer / (serialized.length() / snapshot.size() + 1)
			chunk_size = maxi(1, int(chunk_size))
			for i in range(0, snapshot.size(), chunk_size):
				var chunk := snapshot.slice(i, mini(i + chunk_size, snapshot.size()))
				RPCSystem.call_remote(peer_id, &"apply_snapshot", [chunk])
		else:
			RPCSystem.call_remote(peer_id, &"apply_snapshot", [snapshot])

## Called on clients via RPC (registered in RPCSystem at boot).
func apply_snapshot(snapshot: Array) -> void:
	var typed : Array[Dictionary] = []
	for item in snapshot:
		if item is Dictionary: typed.append(item as Dictionary)
	ReplicationSystem.apply_snapshot(typed)

func set_sync_rate(hz: float) -> void:
	sync_rate_hz = maxf(hz, 1.0)
	Log.info("[SyncSystem] Sync rate: %.0f Hz" % sync_rate_hz)

func _on_peer_connected(data: Variant) -> void:
	if not data is Dictionary: return
	var peer_id := int((data as Dictionary).get("peer", 0))
	if peer_id > 0:
		_needs_full[peer_id] = true
		Log.info("[SyncSystem] Peer %d queued for full snapshot" % peer_id)

func _on_peer_disconnected(data: Variant) -> void:
	if not data is Dictionary: return
	_needs_full.erase(int((data as Dictionary).get("peer", 0)))

func is_running() -> bool: return _enabled
