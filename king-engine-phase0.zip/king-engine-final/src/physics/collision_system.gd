## CollisionSystem — handles collision events from Godot physics bodies
## and translates them into Bus events with entity context.
extends SystemBase

var _recent : Dictionary = {}  ## pair_key -> frame
var _frame   : int = 0
const DUP_WINDOW : int = 2

func _on_start() -> void:
	priority = 5100
	listen(&"physics.body_entered", _on_body_entered)
	listen(&"physics.body_exited",  _on_body_exited)

func _on_stop() -> void:
	unlisten(&"physics.body_entered", _on_body_entered)
	unlisten(&"physics.body_exited",  _on_body_exited)
	_recent.clear()

func tick(_delta: float) -> void:
	_frame += 1
	_prune()

func _on_body_entered(data: Variant) -> void:
	var payload := _extract_payload(data)
	if payload.is_empty():
		return
	var ent_a: int = int(payload.get("entity_a", -1))
	var ent_b: int = int(payload.get("entity_b", -1))
	if ent_a < 0 and ent_b < 0:
		return
	var key := _pair_key(ent_a, ent_b)
	if _recent.get(key, -999) > _frame - DUP_WINDOW:
		return
	_recent[key] = _frame
	Bus.emit(&"ecs.collision_entered", {
		"entity_a": ent_a,
		"entity_b": ent_b,
		"node_a":   payload.node_a,
		"node_b":   payload.node_b
	})

func _on_body_exited(data: Variant) -> void:
	var payload := _extract_payload(data)
	if payload.is_empty():
		return
	Bus.emit(&"ecs.collision_exited", {
		"entity_a": int(payload.get("entity_a", -1)),
		"entity_b": int(payload.get("entity_b", -1)),
		"node_a":   payload.get("node_a", null),
		"node_b":   payload.get("node_b", null)
	})

func _extract_payload(data: Variant) -> Dictionary:
	if not data is Dictionary:
		return {}
	var d := data as Dictionary
	var node_a  := d.get("self") as Node
	var node_b  := d.get("other") as Node
	if node_b == null:
		node_b = d.get("body") as Node
	var ent_a: int = EntityManager.get_entity_id(node_a)
	var ent_b: int = EntityManager.get_entity_id(node_b)
	return {"entity_a": ent_a, "entity_b": ent_b, "node_a": node_a, "node_b": node_b}

func _pair_key(a: int, b: int) -> String:
	var x := mini(a, b)
	var y := maxi(a, b)
	return "%d:%d" % [x, y]

func _prune() -> void:
	for key in _recent.keys().duplicate():
		if int(_recent[key]) < _frame - 30:
			_recent.erase(key)
