## PhysicsSystem — syncs RigidbodyComponent settings → Godot physics bodies,
## and drives CharacterBody3D movement from VelocityComponent.
##
## CharacterBody3D flow:
##   1. MovementSystem writes VelocityComponent.linear (input-driven)
##   2. This system applies gravity, calls move_and_slide, writes result back
##   3. CollisionSystem reads body_entered signals for hit detection
extends SystemBase

const GRAVITY : float = -9.8

func _on_start() -> void:
	priority = 5000

func tick(delta: float) -> void:
	var entities := query([&"Rigidbody", &"SceneNode"])
	for id : int in entities:
		var rb := get_c(id, &"Rigidbody") as RigidbodyComponent
		var sn := get_c(id, &"SceneNode") as SceneNodeComponent
		if rb == null or sn == null or not is_instance_valid(sn.node):
			continue
		if sn.node is RigidBody3D:
			_sync_rigidbody(rb, sn.node as RigidBody3D)
		elif sn.node is CharacterBody3D:
			_drive_character(id, rb, sn.node as CharacterBody3D, delta)

# ── RigidBody3D ───────────────────────────────────────────────────────────────

func _sync_rigidbody(rb: RigidbodyComponent, body: RigidBody3D) -> void:
	body.mass               = maxf(rb.mass, 0.001)
	body.gravity_scale      = rb.gravity_scale
	body.linear_damp        = rb.linear_damp
	body.angular_damp       = rb.angular_damp
	body.continuous_cd      = rb.continuous_cd
	body.freeze             = rb.mode != RigidbodyComponent.BodyMode.DYNAMIC
	body.freeze_mode        = RigidBody3D.FREEZE_MODE_KINEMATIC \
		if rb.mode == RigidbodyComponent.BodyMode.KINEMATIC \
		else RigidBody3D.FREEZE_MODE_STATIC
	body.axis_lock_angular_x = rb.freeze_rot_x
	body.axis_lock_angular_y = rb.freeze_rot_y
	body.axis_lock_angular_z = rb.freeze_rot_z

## Apply an impulse to a RigidBody3D entity.
func apply_impulse(entity: int, impulse: Vector3, at_pos: Vector3 = Vector3.ZERO) -> void:
	var sn := EntityManager.get_component(entity, &"SceneNode") as SceneNodeComponent
	if sn == null or not is_instance_valid(sn.node): return
	if sn.node is RigidBody3D:
		var body := sn.node as RigidBody3D
		if at_pos == Vector3.ZERO:
			body.apply_central_impulse(impulse)
		else:
			body.apply_impulse(impulse, at_pos)

# ── CharacterBody3D ───────────────────────────────────────────────────────────

func _drive_character(entity: int, rb: RigidbodyComponent,
		body: CharacterBody3D, delta: float) -> void:
	## Do not drive entities whose navigation agent owns velocity (Pathfinding handles them).
	if Pathfinding.is_registered(entity):
		return
	var vel_comp := EntityManager.get_component(entity, &"Velocity") as VelocityComponent
	if vel_comp == null:
		return
	## Apply gravity when airborne.
	if not body.is_on_floor():
		vel_comp.linear.y += GRAVITY * rb.gravity_scale * delta
	else:
		if vel_comp.linear.y < 0.0:
			vel_comp.linear.y = 0.0
	## Apply linear damping on horizontal axes.
	if rb.linear_damp > 0.0:
		vel_comp.linear.x = move_toward(vel_comp.linear.x, 0.0, rb.linear_damp * delta * 10.0)
		vel_comp.linear.z = move_toward(vel_comp.linear.z, 0.0, rb.linear_damp * delta * 10.0)
	body.velocity = vel_comp.linear
	body.move_and_slide()
	## Write result back so systems see post-collision velocity.
	vel_comp.linear = body.velocity
	## Sync transform back to TransformComponent.
	var tc := EntityManager.get_component(entity, &"Transform") as TransformComponent
	if tc:
		tc.position = body.global_position
		tc.rotation = body.rotation_degrees
