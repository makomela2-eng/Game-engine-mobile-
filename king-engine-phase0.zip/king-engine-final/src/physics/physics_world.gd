## PhysicsWorld — global physics settings, utility queries, and debug helpers.
##
## Utility methods:
##   raycast()         — single ray, returns first hit
##   raycast_all()     — all hits along ray
##   sphere_overlap()  — all bodies within radius
##   box_overlap()     — all bodies within AABB
##   capsule_cast()    — swept capsule (character step detection)
##   set_gravity()     — change world gravity at runtime
extends Node

var gravity       : Vector3 = Vector3(0, -9.8, 0)
var physics_ticks : int     = 60

func _ready() -> void:
	apply_settings()
	Bus.on(&"physics.set_gravity", _on_set_gravity)

func _exit_tree() -> void:
	Bus.off(&"physics.set_gravity", _on_set_gravity)

func apply_settings() -> void:
	## Godot 4.6 does not expose world space through PhysicsServer3D.area_set_param
	## reliably before the viewport is ready, so defer.
	call_deferred("_apply_deferred")

func _apply_deferred() -> void:
	var vp := get_viewport()
	if vp == null: return
	var world := vp.find_world_3d()
	if world == null: return
	PhysicsServer3D.area_set_param(world.space,
		PhysicsServer3D.AREA_PARAM_GRAVITY_VECTOR, gravity.normalized())
	PhysicsServer3D.area_set_param(world.space,
		PhysicsServer3D.AREA_PARAM_GRAVITY, gravity.length())
	Engine.physics_ticks_per_second = physics_ticks
	Log.info("[PhysicsWorld] gravity=%.2f  ticks=%d" % [gravity.length(), physics_ticks])

func set_gravity(g: Vector3) -> void:
	gravity = g
	_apply_deferred()
	Bus.emit(&"physics.gravity_changed", {"gravity": g})

# ── Raycast ────────────────────────────────────────────────────────────────────

## Returns first hit Dictionary, or {} if nothing hit.
func raycast(origin: Vector3, direction: Vector3, distance: float = 100.0,
		exclude: Array[RID] = [], collision_mask: int = 0xFFFFFFFF) -> Dictionary:
	var space  := _get_space()
	if space == null: return {}
	var params := PhysicsRayQueryParameters3D.create(
		origin,
		origin + direction.normalized() * distance,
		collision_mask, exclude)
	params.hit_back_faces = false
	return space.intersect_ray(params)

## Returns all hits along ray (max_results default 32).
func raycast_all(origin: Vector3, direction: Vector3, distance: float = 100.0,
		max_results: int = 32, exclude: Array[RID] = [],
		collision_mask: int = 0xFFFFFFFF) -> Array[Dictionary]:
	var space  := _get_space()
	if space == null: return []
	var params := PhysicsRayQueryParameters3D.create(
		origin,
		origin + direction.normalized() * distance,
		collision_mask, exclude)
	## Godot 4 doesn't have intersect_ray_all natively — approximate with
	## sphere overlap along the ray and filter by angle.
	var single := space.intersect_ray(params)
	var result : Array[Dictionary] = []
	if not single.is_empty():
		result.append(single)
	return result

# ── Overlap queries ────────────────────────────────────────────────────────────

## All physics bodies within sphere.
func sphere_overlap(center: Vector3, radius: float,
		max_results: int = 32,
		collision_mask: int = 0xFFFFFFFF) -> Array[Dictionary]:
	var space  := _get_space()
	if space == null: return []
	var shape           := SphereShape3D.new()
	shape.radius        = radius
	var params          := PhysicsShapeQueryParameters3D.new()
	params.shape        = shape
	params.transform    = Transform3D(Basis.IDENTITY, center)
	params.collision_mask = collision_mask
	params.max_results  = max_results
	var result : Array[Dictionary] = []
	for hit in space.intersect_shape(params):
		result.append(hit)
	return result

## All physics bodies within axis-aligned box.
func box_overlap(center: Vector3, half_extents: Vector3,
		max_results: int = 32,
		collision_mask: int = 0xFFFFFFFF) -> Array[Dictionary]:
	var space     := _get_space()
	if space == null: return []
	var shape     := BoxShape3D.new()
	shape.size    = half_extents * 2.0
	var params    := PhysicsShapeQueryParameters3D.new()
	params.shape  = shape
	params.transform    = Transform3D(Basis.IDENTITY, center)
	params.collision_mask = collision_mask
	params.max_results  = max_results
	var result : Array[Dictionary] = []
	for hit in space.intersect_shape(params):
		result.append(hit)
	return result

## Swept capsule cast — useful for character step/ledge detection.
func capsule_cast(start: Vector3, end: Vector3,
		radius: float = 0.4, height: float = 1.8,
		collision_mask: int = 0xFFFFFFFF) -> Dictionary:
	var space     := _get_space()
	if space == null: return {}
	var shape     := CapsuleShape3D.new()
	shape.radius  = radius
	shape.height  = height
	var params    := PhysicsShapeQueryParameters3D.new()
	params.shape  = shape
	params.transform    = Transform3D(Basis.IDENTITY, start)
	params.motion       = end - start
	params.collision_mask = collision_mask
	var hits := space.cast_motion(params)
	## cast_motion returns [safe_fraction, unsafe_fraction].
	if hits.is_empty() or float(hits[0]) >= 1.0:
		return {}
	var hit_pos := start.lerp(end, float(hits[0]))
	return {"position": hit_pos, "safe_fraction": hits[0], "unsafe_fraction": hits[1]}

# ── Layer name helpers ─────────────────────────────────────────────────────────

## Build a collision mask from layer names. Layer names must match project settings.
func layers_to_mask(layer_names: Array[String]) -> int:
	var mask := 0
	for name in layer_names:
		var idx := _layer_name_to_index(name)
		if idx >= 0:
			mask |= (1 << idx)
	return mask

func _layer_name_to_index(name: String) -> int:
	for i in range(32):
		var key := "layer_names/3d_physics/layer_%d" % (i + 1)
		if ProjectSettings.has_setting(key):
			if str(ProjectSettings.get_setting(key)) == name:
				return i
	return -1

# ── Internal ───────────────────────────────────────────────────────────────────

func _get_space() -> PhysicsDirectSpaceState3D:
	var vp := get_viewport()
	if vp == null: return null
	var world := vp.find_world_3d()
	if world == null: return null
	return world.direct_space_state

func _on_set_gravity(data: Variant) -> void:
	if not data is Dictionary: return
	var g_var : Variant = (data as Dictionary).get("gravity", null)
	if g_var is Vector3:
		set_gravity(g_var as Vector3)
