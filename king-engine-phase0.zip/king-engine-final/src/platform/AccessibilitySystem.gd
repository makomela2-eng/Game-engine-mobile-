## AccessibilitySystem — high contrast, text scale, reduced motion, screen reader.
##
## High contrast: swaps to a high-contrast theme if one is registered, or
## applies a color modulate to CanvasLayer layer 0.
## Text scale: sets theme default font sizes via ThemeDB.
## Reduce motion: emits a Bus event so animation systems can skip tweens.
extends Node

var high_contrast : bool  = false
var text_scale    : float = 1.0
var reduce_motion : bool  = false

## Set this to your high-contrast Theme resource at boot.
var high_contrast_theme : Theme = null
var default_theme        : Theme = null

func _ready() -> void:
	Bus.on(&"a11y_set_high_contrast", _on_set_contrast)
	Bus.on(&"a11y_set_text_scale",    _on_set_text_scale)
	Bus.on(&"a11y_set_reduce_motion", _on_reduce_motion)
	## Restore saved prefs
	high_contrast = Cfg.get_bool("a11y", "high_contrast", false)
	text_scale    = Cfg.get_float("a11y", "text_scale",   1.0)
	reduce_motion = Cfg.get_bool("a11y", "reduce_motion", false)
	call_deferred("_apply_all")

func _exit_tree() -> void:
	Bus.off(&"a11y_set_high_contrast", _on_set_contrast)
	Bus.off(&"a11y_set_text_scale",    _on_set_text_scale)
	Bus.off(&"a11y_set_reduce_motion", _on_reduce_motion)

func _on_set_contrast(data: Variant) -> void:
	high_contrast = bool(data)
	Cfg.set_val("a11y", "high_contrast", high_contrast)
	_apply_contrast()
	Bus.emit(&"high_contrast_changed", {"enabled": high_contrast})

func _on_set_text_scale(data: Variant) -> void:
	text_scale = clampf(float(data), 0.5, 2.5)
	Cfg.set_val("a11y", "text_scale", text_scale)
	_apply_text_scale()
	Bus.emit(&"text_scale_changed", {"scale": text_scale})

func _on_reduce_motion(data: Variant) -> void:
	reduce_motion = bool(data)
	Cfg.set_val("a11y", "reduce_motion", reduce_motion)
	Bus.emit(&"reduce_motion_changed", {"enabled": reduce_motion})

func _apply_all() -> void:
	_apply_contrast()
	_apply_text_scale()

func _apply_contrast() -> void:
	var root : Window = get_tree().root
	if high_contrast:
		if high_contrast_theme != null:
			## Apply high-contrast theme engine-wide.
			get_tree().root.theme = high_contrast_theme
		else:
			## Fallback: tint all UI with high-contrast colors using a CanvasLayer.
			_set_ui_modulate(Color(1.0, 1.0, 0.9))
	else:
		if default_theme != null:
			get_tree().root.theme = default_theme
		else:
			_set_ui_modulate(Color.WHITE)

func _set_ui_modulate(color: Color) -> void:
	## CanvasLayer is not a CanvasItem — it has no modulate property.
	## Apply modulate to each CanvasItem child of every CanvasLayer in the scene root.
	if not get_tree(): return
	for child in get_tree().root.get_children():
		if child is CanvasLayer:
			for item in (child as CanvasLayer).get_children():
				if item is CanvasItem:
					(item as CanvasItem).modulate = color

func _apply_text_scale() -> void:
	## Scale font sizes on the root theme.
	## Theme.set_font_size(prop: StringName, type: StringName, size: int)
	var theme : Theme = get_tree().root.theme if get_tree() else null
	if theme == null: return
	## Scale each type's font_size property if it exists.
	for type : StringName in theme.get_type_list():
		for prop : StringName in theme.get_font_size_list(type):
			## Avoid compounding: base scale from a reference of 16pt.
			theme.set_font_size(prop, type, int(16.0 * text_scale))

func is_reduced_motion() -> bool: return reduce_motion
func is_high_contrast()  -> bool: return high_contrast
func get_text_scale()    -> float: return text_scale
