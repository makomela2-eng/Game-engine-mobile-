## AppLifecycle — handles OS foreground/background/quit notifications.
## Emits app_background, app_foreground, app_quit on Bus.
## These are the master lifecycle signals all other systems react to.
extends Node

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_FOCUS_OUT:
			Log.info("[AppLifecycle] background")
			Bus.emit(&"app_background", null)
			Cfg.force_save()
		NOTIFICATION_APPLICATION_FOCUS_IN:
			Log.info("[AppLifecycle] foreground")
			Bus.emit(&"app_foreground", null)
		NOTIFICATION_WM_CLOSE_REQUEST:
			Log.info("[AppLifecycle] quit requested")
			Bus.emit(&"app_quit", null)
			Cfg.force_save()
			## Give systems one frame to handle app_quit (save, flush logs, etc.)
			await get_tree().process_frame
			get_tree().quit()
		NOTIFICATION_CRASH:
			Log.error("[AppLifecycle] crash notification received")
			Cfg.force_save()
