## BatteryMonitor — battery-aware performance scaling.
## Emits battery_level and battery_low on the Bus.
## Responds to app_background to skip polling while offscreen.
##
## Battery API availability in Godot 4.6:
##   Android: GodotAndroid plugin (if bundled) or assume full.
##   iOS:     No native API exposed yet in 4.6 — assume full.
##   Desktop: No battery management needed.
##   All platforms: graceful fallback to 100% / charging.
extends Node

signal level_changed(pct: int)
signal charging_changed(charging: bool)

var battery_pct : int  = 100
var is_charging : bool = true
var _bg         : bool = false
var _cb_bg      : Callable
var _cb_fg      : Callable

func _ready() -> void:
	TaskScheduler.schedule(&"battery_poll", 30.0, _poll)
	_cb_bg = func(_d: Variant) -> void: _bg = true
	_cb_fg = func(_d: Variant) -> void:
		_bg = false
		_poll()
	Bus.on(&"app_background", _cb_bg)
	Bus.on(&"app_foreground", _cb_fg)
	_poll()

func _exit_tree() -> void:
	TaskScheduler.unschedule(&"battery_poll")
	if _cb_bg.is_valid(): Bus.off(&"app_background", _cb_bg)
	if _cb_fg.is_valid(): Bus.off(&"app_foreground", _cb_fg)

func _poll() -> void:
	if _bg: return
	var new_pct      : int  = 100
	var new_charging : bool = true

	## Android: try GodotAndroid plugin first.
	if Engine.has_singleton("GodotAndroid"):
		var info : Dictionary = Engine.get_singleton("GodotAndroid").get_battery_info()
		new_pct      = int(info.get("level",  100))
		new_charging = bool(info.get("plugged", true))
	## Desktop/other: no battery info available — stay at defaults.

	if new_pct != battery_pct:
		battery_pct = new_pct
		level_changed.emit(battery_pct)
		Bus.emit(&"battery_level", {"pct": battery_pct})
		if battery_pct <= 15 and not is_charging:
			Log.warn("[Battery] low: %d%%" % battery_pct)
			Bus.emit(&"battery_low", {"pct": battery_pct})
			_apply_battery_saver()
	if new_charging != is_charging:
		is_charging = new_charging
		charging_changed.emit(is_charging)

func _apply_battery_saver() -> void:
	Engine.max_fps = 30
	GraphicsScaler.set_scale(0.70)
	Log.info("[Battery] battery saver activated")
