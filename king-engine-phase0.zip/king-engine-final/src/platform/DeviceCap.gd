## DeviceCap — detects device capability tier and sets render targets.
## Emits device.quality_tier_set on Bus after detection.
## Other systems (GraphicsScaler, ThermalMonitor) read gpu_tier and target_fps.
extends Node

var gpu_tier   : int   = 1   ## 0=low 1=mid 2=high
var target_fps : int   = 60
var is_mobile  : bool  = false
var ram_mb     : int   = 0

func _ready() -> void:
	is_mobile = OS.get_name() in ["Android", "iOS"]
	ram_mb    = int(OS.get_static_memory_usage() / 1_048_576.0)
	## Detect GPU tier immediately from adapter name (safe at frame 0).
	## FPS-based confirmation is deferred until frame 90 so the engine has
	## time to reach its steady-state rate. At frame 0 get_frames_per_second()
	## always returns 0 and would incorrectly classify every device as low-end.
	_detect_tier_from_gpu_name()
	Bus.on(&"thermal_state_changed", _on_thermal)
	## Schedule FPS confirmation — 90 frames ≈ 1.5 s at 60 Hz.
	var t : SceneTreeTimer = get_tree().create_timer(1.5)
	t.timeout.connect(_confirm_tier_from_fps)

func _exit_tree() -> void:
	Bus.off(&"thermal_state_changed", _on_thermal)

func _detect_tier_from_gpu_name() -> void:
	var renderer : String = RenderingServer.get_video_adapter_name().to_lower()
	if renderer.contains("adreno 6") or renderer.contains("adreno 7") \
			or renderer.contains("mali-g7") or renderer.contains("mali-g9") \
			or renderer.contains("apple a1") or renderer.contains("apple m"):
		gpu_tier = 2
	elif renderer.contains("adreno 5") or renderer.contains("adreno 61") \
			or renderer.contains("mali-g5") or renderer.contains("mali-g6"):
		gpu_tier = 1
	else:
		gpu_tier = 0
	target_fps = 60 if gpu_tier >= 1 else 30
	Engine.max_fps = target_fps
	Log.info("[DeviceCap] GPU: %s  tier: %d  target_fps: %d" % [renderer, gpu_tier, target_fps])
	Bus.emit(&"device.quality_tier_set", {"tier": gpu_tier, "fps": target_fps})

## Called 1.5 s after boot. Downgrades tier if measured FPS is well below target.
## Never upgrades — we trust the GPU name for upward classification.
func _confirm_tier_from_fps() -> void:
	var measured : float = Engine.get_frames_per_second()
	if measured < 1.0:
		return  ## still too early (editor pause, etc.)
	var original := gpu_tier
	if gpu_tier >= 2 and measured < 40.0:
		gpu_tier = 1
	elif gpu_tier >= 1 and measured < 22.0:
		gpu_tier = 0
	if gpu_tier != original:
		target_fps = 60 if gpu_tier >= 1 else 30
		Engine.max_fps = target_fps
		Log.warn("[DeviceCap] FPS confirmation downgraded tier %d→%d (measured %.0f fps)" \
			% [original, gpu_tier, measured])
		Bus.emit(&"device.quality_tier_set", {"tier": gpu_tier, "fps": target_fps})

func _on_thermal(data: Variant) -> void:
	if not data is Dictionary: return
	var state := int((data as Dictionary).get("state", 0))
	if state >= 2:
		target_fps = 30
	else:
		target_fps = 60 if gpu_tier >= 1 else 30
