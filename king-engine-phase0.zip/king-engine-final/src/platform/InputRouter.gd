## InputRouter — unified gesture detection for touch screens.
##
## Detects: tap, long_press, swipe, double_tap.
## Records all touch actions into InputBuffer for buffered-input queries.
## Emits both typed signals and Bus events.
##
## Complements TouchInput (which handles joystick/camera).
## InputRouter handles discrete gestures; TouchInput handles continuous input.
extends Node

signal tap(pos: Vector2)
signal double_tap(pos: Vector2)
signal swipe(delta: Vector2, direction: StringName)
signal long_press(pos: Vector2)

const LONG_PRESS_SEC  : float = 0.5
const SWIPE_MIN_PX    : float = 40.0
const DOUBLE_TAP_MS   : int   = 300
const TAP_MAX_DIST_PX : float = 20.0

var _touch_start  : Vector2 = Vector2.ZERO
var _touch_time   : float   = 0.0
var _touching     : bool    = false
var _last_tap_ms  : int     = 0
var _last_tap_pos : Vector2 = Vector2.ZERO

func _ready() -> void:
	set_process(true)
	set_process_input(true)

func _input(event: InputEvent) -> void:
	if not Kernel.is_mobile and not OS.is_debug_build():
		return
	if event is InputEventScreenTouch:
		_on_touch(event as InputEventScreenTouch)

func _on_touch(e: InputEventScreenTouch) -> void:
	if e.pressed:
		_touch_start = e.position
		_touch_time  = 0.0
		_touching    = true
	else:
		_touching      = false
		var dist       := e.position.distance_to(_touch_start)
		var was_tap    := dist < TAP_MAX_DIST_PX and _touch_time < LONG_PRESS_SEC
		if was_tap:
			var now_ms := Time.get_ticks_msec()
			var gap    := now_ms - _last_tap_ms
			if gap < DOUBLE_TAP_MS and e.position.distance_to(_last_tap_pos) < TAP_MAX_DIST_PX * 2.0:
				double_tap.emit(e.position)
				Bus.emit(&"double_tap", {"pos": e.position})
				InputBuffer.record(&"double_tap")
				_last_tap_ms = 0
			else:
				tap.emit(e.position)
				Bus.emit(&"tap", {"pos": e.position})
				InputBuffer.record(&"tap")
				_last_tap_ms  = now_ms
				_last_tap_pos = e.position
		elif dist >= SWIPE_MIN_PX:
			var delta     := e.position - _touch_start
			var direction := _classify_swipe(delta)
			swipe.emit(delta, direction)
			Bus.emit(&"swipe", {"delta": delta, "direction": direction})
			InputBuffer.record(StringName("swipe_" + str(direction)))

func _process(delta: float) -> void:
	if not _touching: return
	_touch_time += delta
	if _touch_time >= LONG_PRESS_SEC:
		_touching = false
		long_press.emit(_touch_start)
		Bus.emit(&"long_press", {"pos": _touch_start})
		InputBuffer.record(&"long_press")
		TouchInput.haptic_tap()

func _classify_swipe(delta: Vector2) -> StringName:
	if absf(delta.x) > absf(delta.y):
		return &"right" if delta.x > 0 else &"left"
	else:
		return &"down" if delta.y > 0 else &"up"
