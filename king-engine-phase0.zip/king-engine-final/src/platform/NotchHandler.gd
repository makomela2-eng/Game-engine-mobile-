## NotchHandler — safe-area insets for notched/hole-punch displays.
extends Node

var safe_area    : Rect2 = Rect2()
var inset_top    : float = 0.0
var inset_bottom : float = 0.0
var inset_left   : float = 0.0
var inset_right  : float = 0.0

func _ready() -> void:
	_update()
	get_tree().root.size_changed.connect(_update)

func _exit_tree() -> void:
	if get_tree() and is_instance_valid(get_tree().root):
		if get_tree().root.size_changed.is_connected(_update):
			get_tree().root.size_changed.disconnect(_update)

func _update() -> void:
	var screen_size := DisplayServer.screen_get_size()
	var rect        := DisplayServer.get_display_safe_area()
	safe_area    = Rect2(rect)
	inset_top    = float(rect.position.y)
	inset_left   = float(rect.position.x)
	inset_bottom = float(screen_size.y - rect.end.y)
	inset_right  = float(screen_size.x - rect.end.x)
	Bus.emit(&"safe_area_updated", {
		"top": inset_top, "bottom": inset_bottom,
		"left": inset_left, "right": inset_right})

## Apply safe-area margins to a Control node.
func apply_to(control: Control) -> void:
	if not is_instance_valid(control): return
	var mc := control as MarginContainer
	if mc:
		mc.add_theme_constant_override("margin_top",    int(inset_top))
		mc.add_theme_constant_override("margin_bottom", int(inset_bottom))
		mc.add_theme_constant_override("margin_left",   int(inset_left))
		mc.add_theme_constant_override("margin_right",  int(inset_right))
