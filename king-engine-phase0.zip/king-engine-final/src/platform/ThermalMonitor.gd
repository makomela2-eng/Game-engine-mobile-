## ThermalMonitor — monitors device thermal state and throttles engine.
## Emits thermal_state_changed and thermal_critical on the Bus.
## GraphicsScaler and BatteryMonitor listen and respond.
extends Node

signal state_changed(state: int)

var thermal_state : int = 0

func _ready() -> void:
	TaskScheduler.schedule(&"thermal_check", 5.0, _check)
	Bus.on(&"memory_warning", _on_memory_warning)

func _exit_tree() -> void:
	Bus.off(&"memory_warning", _on_memory_warning)

func _check() -> void:
	var new_state := _read_state()
	if new_state == thermal_state: return
	thermal_state = new_state
	state_changed.emit(thermal_state)
	Bus.emit(&"thermal_state_changed", {"state": thermal_state})
	Log.info("[Thermal] state: %d" % thermal_state)
	_apply_throttle()

func _on_memory_warning(_data: Variant) -> void:
	## Memory pressure → treat as thermal stress
	if thermal_state < 2:
		thermal_state = 2
		_apply_throttle()

func _read_state() -> int:
	var fps := Engine.get_frames_per_second()
	var mb  := OS.get_static_memory_usage() / 1_048_576.0
	if fps < 20 or mb > 400: return 3
	if fps < 30 or mb > 320: return 2
	if fps < 45 or mb > 250: return 1
	return 0

func _apply_throttle() -> void:
	match thermal_state:
		3:
			Engine.max_fps = 30
			GraphicsScaler.set_scale(0.55)
			Bus.emit(&"thermal_critical", null)
		2:
			Engine.max_fps = 45
			GraphicsScaler.set_scale(0.70)
		1:
			Engine.max_fps = DeviceCap.target_fps
			GraphicsScaler.set_scale(0.85)
		_:
			Engine.max_fps = DeviceCap.target_fps
			GraphicsScaler._apply_for_tier(DeviceCap.gpu_tier)

func is_throttled() -> bool: return thermal_state >= 2
