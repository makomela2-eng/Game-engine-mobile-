## TouchInput — virtual joystick, camera swipe, pinch zoom, and haptics.
##
## Architecture:
##   Left half of screen   → virtual joystick → writes InputComponent.move_dir
##   Right half of screen  → camera swipe     → emits input.look_delta
##   Two-finger pinch      → zoom             → emits input.pinch_zoom
##
## Systems read move_dir from the player's InputComponent as normal.
## Camera systems listen to input.look_delta.
## No polling required — all output is pushed each frame via Bus.
##
## Haptics: call TouchInput.vibrate(ms) — no-op on desktop.
##
## Enabling/disabling:
##   Autoloaded. Active whenever Kernel.is_mobile OR force_enabled = true.
##   Disable at runtime: TouchInput.enabled = false
extends CanvasLayer

# ── Config ─────────────────────────────────────────────────────────────────────

## Force touch controls on desktop (useful for testing in editor).
var force_enabled          : bool  = false
var enabled                : bool  = true

## Joystick visual
const JOY_OUTER_RADIUS     : float = 72.0
const JOY_INNER_RADIUS     : float = 32.0
const JOY_DEADZONE         : float = 0.12   ## normalised 0-1
const JOY_ALPHA_IDLE       : float = 0.35
const JOY_ALPHA_ACTIVE     : float = 0.75

## Camera swipe
var look_sensitivity       : float = 0.003  ## radians per pixel

## Pinch
const PINCH_ZOOM_SPEED     : float = 0.01

## Haptics
const HAPTIC_TAP_MS        : int   = 18
const HAPTIC_CONFIRM_MS    : int   = 40

# ── Internal state ─────────────────────────────────────────────────────────────

## Joystick finger tracking.
var _joy_finger    : int     = -1   ## active finger index, -1 = none
var _joy_origin    : Vector2 = Vector2.ZERO
var _joy_current   : Vector2 = Vector2.ZERO

## Camera swipe finger tracking.
var _cam_finger    : int     = -1
var _cam_last      : Vector2 = Vector2.ZERO

## Pinch tracking — two finger indices.
var _pinch_a       : int     = -1
var _pinch_b       : int     = -1
var _pinch_last_dist : float = 0.0

## Active touches: finger_index → Vector2 (current position).
var _touches       : Dictionary = {}

# ── Nodes ──────────────────────────────────────────────────────────────────────

var _joy_base      : Control     ## outer ring
var _joy_knob      : Control     ## inner dot
var _joy_visible   : bool = false

# ── Boot ───────────────────────────────────────────────────────────────────────

func _ready() -> void:
	layer = 50   ## above game, below Dashboard and DevUI
	set_process_input(true)
	set_process(true)
	_build_joystick_ui()
	## Hide on desktop unless force_enabled.
	if not Kernel.is_mobile and not force_enabled:
		visible = false

func _build_joystick_ui() -> void:
	## Outer ring.
	_joy_base = _make_circle(JOY_OUTER_RADIUS, Color(1, 1, 1, JOY_ALPHA_IDLE))
	_joy_base.visible = false
	add_child(_joy_base)
	## Inner knob.
	_joy_knob = _make_circle(JOY_INNER_RADIUS, Color(1, 1, 1, JOY_ALPHA_ACTIVE))
	_joy_knob.visible = false
	add_child(_joy_knob)

func _make_circle(radius: float, color: Color) -> Control:
	var c := ColorRect.new()
	## ColorRect is a filled square — we'll round it via StyleBox on Control,
	## or just use it as-is for a functional (not decorative) placeholder.
	## Games should override these with proper art. The code only tracks positions.
	c.size           = Vector2(radius * 2.0, radius * 2.0)
	c.color          = color
	c.mouse_filter   = Control.MOUSE_FILTER_IGNORE
	return c

# ── Active check ───────────────────────────────────────────────────────────────

func _is_active() -> bool:
	return enabled and (Kernel.is_mobile or force_enabled)

# ── Input ──────────────────────────────────────────────────────────────────────

func _input(event: InputEvent) -> void:
	if not _is_active():
		return
	if event is InputEventScreenTouch:
		_on_touch(event as InputEventScreenTouch)
	elif event is InputEventScreenDrag:
		_on_drag(event as InputEventScreenDrag)

func _on_touch(e: InputEventScreenTouch) -> void:
	if e.pressed:
		_touches[e.index] = e.position
		_assign_finger(e.index, e.position)
	else:
		_touches.erase(e.index)
		_release_finger(e.index)

func _on_drag(e: InputEventScreenDrag) -> void:
	_touches[e.index] = e.position
	## Joystick knob move.
	if e.index == _joy_finger:
		_joy_current = e.position
		_update_joy_visual()
	## Camera swipe.
	elif e.index == _cam_finger:
		var delta := e.position - _cam_last
		_cam_last = e.position
		Bus.emit(&"input.look_delta", {"delta": delta * look_sensitivity})
	## Pinch — update if either finger moved.
	if (_pinch_a >= 0 and e.index == _pinch_a) or \
	   (_pinch_b >= 0 and e.index == _pinch_b):
		_update_pinch()

func _assign_finger(index: int, pos: Vector2) -> void:
	var vp_size := get_viewport().get_visible_rect().size
	var left_half : bool = pos.x < vp_size.x * 0.5

	## Pinch logic: if two fingers already on screen from same half, promote to pinch.
	## Otherwise assign joystick (left) or camera (right).
	if left_half:
		if _joy_finger < 0:
			_joy_finger  = index
			_joy_origin  = pos
			_joy_current = pos
			_show_joy(pos)
		elif _pinch_a < 0 and _pinch_b < 0:
			## Second left-hand finger → begin pinch.
			_pinch_a = _joy_finger
			_pinch_b = index
			_pinch_last_dist = _pinch_distance()
	else:
		if _cam_finger < 0:
			_cam_finger = index
			_cam_last   = pos
		elif _pinch_a < 0 and _pinch_b < 0:
			## Second right-hand finger → begin pinch.
			_pinch_a = _cam_finger
			_pinch_b = index
			_pinch_last_dist = _pinch_distance()

func _release_finger(index: int) -> void:
	if index == _joy_finger:
		_joy_finger = -1
		_hide_joy()
		## Also cancel pinch if the joystick finger was a pinch participant.
	if index == _cam_finger:
		_cam_finger = -1
	if index == _pinch_a or index == _pinch_b:
		_pinch_a = -1
		_pinch_b = -1
		_pinch_last_dist = 0.0

# ── Joystick visual ────────────────────────────────────────────────────────────

func _show_joy(pos: Vector2) -> void:
	_joy_base.position = pos - Vector2(JOY_OUTER_RADIUS, JOY_OUTER_RADIUS)
	_joy_knob.position = pos - Vector2(JOY_INNER_RADIUS, JOY_INNER_RADIUS)
	_joy_base.visible  = true
	_joy_knob.visible  = true
	_joy_visible       = true

func _hide_joy() -> void:
	_joy_base.visible = false
	_joy_knob.visible = false
	_joy_visible      = false

func _update_joy_visual() -> void:
	if not _joy_visible: return
	var offset   := _joy_current - _joy_origin
	var clamped  := offset.limit_length(JOY_OUTER_RADIUS)
	var knob_pos := _joy_origin + clamped
	_joy_knob.position = knob_pos - Vector2(JOY_INNER_RADIUS, JOY_INNER_RADIUS)

# ── Per-frame output ───────────────────────────────────────────────────────────

func _process(_delta: float) -> void:
	if not _is_active():
		return
	_push_move()

func _push_move() -> void:
	var move := Vector2.ZERO
	if _joy_finger >= 0:
		var offset    := _joy_current - _joy_origin
		var magnitude := offset.length() / JOY_OUTER_RADIUS
		if magnitude > JOY_DEADZONE:
			move = offset.normalized() * clampf((magnitude - JOY_DEADZONE) / (1.0 - JOY_DEADZONE), 0.0, 1.0)
	## Write directly into the player entity's InputComponent.
	_write_to_input_component(move)

func _write_to_input_component(move: Vector2) -> void:
	## Find player entity — tagged "player" — and write move_dir.
	var players := EntityManager.get_entities_by_tag(&"player")
	for id : int in players:
		var ic := EntityManager.get_component(id, &"Input") as InputComponent
		if ic != null and ic.enabled:
			ic.move_dir = move

# ── Pinch ──────────────────────────────────────────────────────────────────────

func _pinch_distance() -> float:
	if _pinch_a < 0 or _pinch_b < 0: return 0.0
	var pa : Variant = _touches.get(_pinch_a)
	var pb : Variant = _touches.get(_pinch_b)
	if pa is Vector2 and pb is Vector2:
		return (pa as Vector2).distance_to(pb as Vector2)
	return 0.0

func _update_pinch() -> void:
	if _pinch_a < 0 or _pinch_b < 0: return
	var dist := _pinch_distance()
	if _pinch_last_dist > 0.0:
		var delta := dist - _pinch_last_dist
		Bus.emit(&"input.pinch_zoom", {"delta": delta * PINCH_ZOOM_SPEED})
	_pinch_last_dist = dist

# ── Haptics ────────────────────────────────────────────────────────────────────

## Vibrate for `ms` milliseconds. Safe to call on desktop (no-op).
func vibrate(ms: int = HAPTIC_TAP_MS) -> void:
	if not Kernel.is_mobile: return
	Input.vibrate_handheld(ms)

func haptic_tap()     -> void: vibrate(HAPTIC_TAP_MS)
func haptic_confirm() -> void: vibrate(HAPTIC_CONFIRM_MS)
