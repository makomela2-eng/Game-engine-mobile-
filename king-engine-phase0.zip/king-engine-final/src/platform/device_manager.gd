## DeviceManager — runtime device capability queries and adaptive quality.
extends Node

enum QualityTier { LOW, MEDIUM, HIGH, ULTRA }

var quality_tier    : QualityTier = QualityTier.MEDIUM
var ram_mb          : int         = 0
var cpu_cores       : int         = 0
var gpu_name        : String      = ""
var model_name      : String      = ""

func _ready() -> void:
	_detect()
	_auto_quality()
	Log.info("[DeviceManager] Tier=%s  RAM=%dMB  Cores=%d  GPU=%s" % [
		_tier_name(), ram_mb, cpu_cores, gpu_name])

func _detect() -> void:
	ram_mb     = _read_physical_ram_mb()
	cpu_cores  = OS.get_processor_count()
	gpu_name   = RenderingServer.get_video_adapter_name()
	model_name = OS.get_model_name()

func _auto_quality() -> void:
	if ram_mb <= 1024 or cpu_cores <= 2:
		quality_tier = QualityTier.LOW
	elif ram_mb <= 2048 or cpu_cores <= 4:
		quality_tier = QualityTier.MEDIUM
	elif ram_mb <= 4096:
		quality_tier = QualityTier.HIGH
	else:
		quality_tier = QualityTier.ULTRA
	_apply_quality()
	Bus.emit(&"device.quality_tier_set", {"tier": quality_tier})

func set_quality_tier(tier: QualityTier) -> void:
	quality_tier = tier
	Bus.emit(&"device.quality_tier_set", {"tier": tier})
	_apply_quality()

func _apply_quality() -> void:
	match quality_tier:
		QualityTier.LOW:
			RenderPipeline.set_msaa(0)
			RenderPipeline.set_shadow_quality(0)
		QualityTier.MEDIUM:
			RenderPipeline.set_msaa(0)
			RenderPipeline.set_shadow_quality(1)
		QualityTier.HIGH:
			RenderPipeline.set_msaa(2)
			RenderPipeline.set_shadow_quality(2)
		QualityTier.ULTRA:
			RenderPipeline.set_msaa(4)
			RenderPipeline.set_shadow_quality(3)

func _tier_name() -> String:
	return QualityTier.keys()[quality_tier]

func is_low_end() -> bool:
	return quality_tier == QualityTier.LOW

func _read_physical_ram_mb() -> int:
	var info: Dictionary = {}
	if OS.has_method("get_memory_info"):
		info = OS.get_memory_info()
	if info.has("physical"):
		var physical := float(info.get("physical", 0))
		if physical > 0.0:
			return int(physical / 1_048_576.0)
	var proc := _read_proc_meminfo_kb("MemTotal")
	if proc > 0:
		return int(proc / 1024.0)
	return 2048 if Kernel.is_mobile else 4096

func _read_proc_meminfo_kb(label: String) -> int:
	if not FileAccess.file_exists("/proc/meminfo"):
		return 2048 if Kernel.is_mobile else 4096
	var f := FileAccess.open("/proc/meminfo", FileAccess.READ)
	if f == null:
		return 2048 if Kernel.is_mobile else 4096
	while not f.eof_reached():
		var line := f.get_line()
		if line.begins_with(label + ":"):
			var parts := line.split(":", true, 1)
			if parts.size() < 2:
				return 2048 if Kernel.is_mobile else 4096
			var payload := parts[1].strip_edges()
			var tokens := payload.split(" ", false)
			for token in tokens:
				if token.is_valid_int():
					return int(token)
				elif token.is_valid_float():
					return int(float(token))
	return 2048 if Kernel.is_mobile else 4096
