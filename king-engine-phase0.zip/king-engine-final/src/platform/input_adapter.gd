## InputAdapter — normalizes input across touch, gamepad, and keyboard.
## Emits unified events so game systems don't need platform conditionals.
extends Node

var touch_sensitivity : float = 1.5
var _touch_start      : Dictionary = {}  ## finger index → Vector2

func _ready() -> void:
	set_process_unhandled_input(true)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		_handle_touch(event as InputEventScreenTouch)
	elif event is InputEventScreenDrag:
		_handle_drag(event as InputEventScreenDrag)
	elif event is InputEventMouseMotion:
		_handle_mouse(event as InputEventMouseMotion)
	elif event is InputEventJoypadMotion:
		_handle_joystick(event as InputEventJoypadMotion)

func _handle_touch(e: InputEventScreenTouch) -> void:
	if e.pressed:
		_touch_start[e.index] = e.position
		Bus.emit(&"input.touch_start", {"index": e.index, "position": e.position})
	else:
		_touch_start.erase(e.index)
		Bus.emit(&"input.touch_end", {"index": e.index, "position": e.position})

func _handle_drag(e: InputEventScreenDrag) -> void:
	Bus.emit(&"input.touch_drag", {
		"index":    e.index,
		"position": e.position,
		"relative": e.relative * touch_sensitivity,
		"velocity": e.velocity
	})

func _handle_mouse(e: InputEventMouseMotion) -> void:
	if not PlatformManager.is_mobile:
		Bus.emit(&"input.mouse_motion", {"relative": e.relative, "position": e.position})

func _handle_joystick(e: InputEventJoypadMotion) -> void:
	Bus.emit(&"input.joystick", {"axis": e.axis, "value": e.axis_value, "device": e.device})
