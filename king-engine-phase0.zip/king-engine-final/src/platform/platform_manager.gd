## PlatformManager — detects and exposes platform capabilities at runtime.
extends Node

enum Platform { UNKNOWN, ANDROID, IOS, WINDOWS, MACOS, LINUX, WEB }

var current      : Platform = Platform.UNKNOWN
var is_mobile    : bool     = false
var is_desktop   : bool     = false
var is_web       : bool     = false
var screen_dpi   : float    = 96.0
var safe_area    : Rect2    = Rect2()

func _ready() -> void:
	_detect()
	Log.info("[PlatformManager] Platform: %s  mobile=%s  dpi=%.0f" % [
		_platform_name(), is_mobile, screen_dpi])

func _detect() -> void:
	var os_name := OS.get_name()
	match os_name:
		"Android":
			current   = Platform.ANDROID
			is_mobile = true
		"iOS":
			current   = Platform.IOS
			is_mobile = true
		"Windows":
			current    = Platform.WINDOWS
			is_desktop = true
		"macOS":
			current    = Platform.MACOS
			is_desktop = true
		"Linux", "FreeBSD":
			current    = Platform.LINUX
			is_desktop = true
		"Web":
			current = Platform.WEB
			is_web  = true
		_:
			current = Platform.UNKNOWN
	screen_dpi = DisplayServer.screen_get_dpi()
	safe_area  = DisplayServer.get_display_safe_area()

func _platform_name() -> String:
	return Platform.keys()[current]

func supports_haptics() -> bool:
	return is_mobile

func supports_gyroscope() -> bool:
	return Input.get_gyroscope() != Vector3.ZERO or is_mobile

func vibrate(ms: int = 50) -> void:
	if is_mobile:
		Input.vibrate_handheld(ms)
