## PluginLoader — scans a directory for plugin scripts and loads them.
extends Node

const PLUGIN_DIR := "res://plugins/"

func load_all(dir_path: String = PLUGIN_DIR) -> void:
	var dir : DirAccess = DirAccess.open(dir_path)
	if dir == null:
		Log.info("[PluginLoader] No plugins directory at: %s" % dir_path)
		return
	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if not dir.current_is_dir() and entry.ends_with(".gd"):
			_load_script(dir_path + entry)
		entry = dir.get_next()

func load_from_path(path: String) -> bool:
	return _load_script(path)

func _load_script(path: String) -> bool:
	var script: Resource = load(path)
	if not script is GDScript:
		Log.warn("[PluginLoader] Not a GDScript: %s" % path)
		return false
	var instance = (script as GDScript).new()
	return PluginManager.load_plugin(instance)

func unload_all() -> void:
	PluginManager.unload_all()
