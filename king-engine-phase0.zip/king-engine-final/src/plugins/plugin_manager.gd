## PluginManager — loads and manages runtime KING plugins.
## A plugin is any GDScript Resource with a defined interface.
extends Node

## Plugin interface contract — plugins must implement these methods:
##   func plugin_name() -> StringName
##   func on_load()  → called when registered
##   func on_unload() → called before removal
var _plugins : Dictionary = {}  ## StringName → plugin object

signal plugin_loaded(svc_name: StringName)
signal plugin_unloaded(svc_name: StringName)

func load_plugin(plugin: Object) -> bool:
	if plugin == null or not is_instance_valid(plugin):
		return false
	if not plugin.has_method("plugin_name"):
		Log.warn("[PluginManager] Plugin missing plugin_name()")
		return false
	var svc_name : StringName = StringName(str(plugin.call("plugin_name")))
	if svc_name == &"":
		Log.warn("[PluginManager] Plugin returned empty name")
		return false
	if _plugins.has(svc_name):
		Log.warn("[PluginManager] Plugin already loaded: %s" % svc_name)
		return false
	_plugins[svc_name] = plugin
	if plugin.has_method("on_load"):
		plugin.call("on_load")
	Bus.emit(&"plugin.loaded", {"svc_name": svc_name})
	plugin_loaded.emit(svc_name)
	Log.info("[PluginManager] Loaded: %s" % svc_name)
	return true

func unload_plugin(svc_name: StringName) -> void:
	if not _plugins.has(svc_name):
		return
	var plugin: Object = _plugins[svc_name] as Object
	if plugin.has_method("on_unload"):
		plugin.call("on_unload")
	_plugins.erase(svc_name)
	Bus.emit(&"plugin.unloaded", {"svc_name": svc_name})
	plugin_unloaded.emit(svc_name)
	Log.info("[PluginManager] Unloaded: %s" % svc_name)

func get_plugin(svc_name: StringName) -> Object:
	return _plugins.get(svc_name, null)

func is_loaded(svc_name: StringName) -> bool:
	return _plugins.has(svc_name)

func all_plugins() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _plugins.keys():
		result.append(k)
	return result

func unload_all() -> void:
	for svc_name in _plugins.keys().duplicate():
		unload_plugin(svc_name)

func clear() -> void:
	unload_all()
