## Prefab — data definition for a reusable entity template.
class_name Prefab
extends Resource

@export var prefab_id   : StringName = &""
@export var tags        : Array[StringName] = []
@export var scene_path  : String = ""
@export var components  : Array[Dictionary] = []  ## [{ type, data }]

func is_valid() -> bool:
	return prefab_id != &""
