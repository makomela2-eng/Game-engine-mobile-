## PrefabInstance — spawns entities from Prefab definitions.
##
## Scene loading is async by default via AssetLoader to avoid blocking mobile.
## Component data from the Prefab resource is applied to the entity.
## Despawn cleans up both the entity and its scene node.
extends Node

## Spawn from a registered Prefab id. Returns entity id immediately;
## scene node is attached asynchronously if the prefab has a scene_path.
func spawn(prefab_id: StringName, position: Vector3 = Vector3.ZERO,
		parent: Node = null, on_ready: Callable = Callable()) -> int:
	var prefab := PrefabRegistry.get_prefab(prefab_id)
	if prefab == null:
		Log.error("[PrefabInstance] Unknown prefab: %s" % prefab_id)
		return -1

	var id := EntityManager.create_entity()

	## TransformComponent — world position.
	EntityManager.add_component(id, &"Transform", TransformComponent.new(position))

	## Tags from prefab definition.
	for tag : StringName in prefab.tags:
		EntityManager.add_tag(id, tag)
	## Also tag with the prefab id itself for easy lookup.
	EntityManager.add_tag(id, prefab_id)

	## Components defined in prefab resource.
	_apply_components(id, prefab)

	## Scene node — load async if path is set.
	if prefab.scene_path != "":
		var resolved_parent := _resolve_parent(parent)
		if ResourceManager.is_ready(StringName(prefab.scene_path)):
			_attach_scene(id, prefab.scene_path, position, resolved_parent, on_ready)
		else:
			ResourceManager.get_async(StringName(prefab.scene_path),
				func(_sid: StringName, _res: Resource) -> void:
					if EntityManager.entity_exists(id):
						_attach_scene(id, prefab.scene_path, position, resolved_parent, on_ready))
	elif on_ready.is_valid():
		on_ready.call(id)

	Bus.emit(&"prefab.spawned", {"entity": id, "prefab": prefab_id, "position": position})
	return id

## Synchronous spawn — blocks until scene is loaded. Avoid on mobile for large scenes.
func spawn_sync(prefab_id: StringName, position: Vector3 = Vector3.ZERO,
		parent: Node = null) -> int:
	var prefab := PrefabRegistry.get_prefab(prefab_id)
	if prefab == null:
		Log.error("[PrefabInstance] Unknown prefab: %s" % prefab_id)
		return -1
	var id := EntityManager.create_entity()
	EntityManager.add_component(id, &"Transform", TransformComponent.new(position))
	for tag : StringName in prefab.tags:
		EntityManager.add_tag(id, tag)
	EntityManager.add_tag(id, prefab_id)
	_apply_components(id, prefab)
	if prefab.scene_path != "":
		var res := ResourceManager.get_resource(StringName(prefab.scene_path))
		if res is PackedScene:
			_attach_scene_node(id, res as PackedScene, position, _resolve_parent(parent))
	Bus.emit(&"prefab.spawned", {"entity": id, "prefab": prefab_id, "position": position})
	return id

func despawn(entity: int) -> void:
	var sn := EntityManager.get_component(entity, &"SceneNode") as SceneNodeComponent
	if sn and is_instance_valid(sn.node):
		sn.node.queue_free()
	EntityManager.destroy_entity(entity)
	Bus.emit(&"prefab.despawned", {"entity": entity})

func despawn_tag(tag: StringName) -> int:
	var count := 0
	for id : int in EntityManager.get_entities_by_tag(tag).duplicate():
		despawn(id)
		count += 1
	return count

# ── Internal ───────────────────────────────────────────────────────────────────

func _apply_components(entity: int, prefab: Prefab) -> void:
	for comp_def : Dictionary in prefab.components:
		var type_name := StringName(str(comp_def.get("type", "")))
		if type_name == &"": continue
		## Component factory: look up class by StringName and instantiate.
		## Systems can override this by registering factories.
		var comp : Component = _make_component(type_name, comp_def.get("data", {}))
		if comp != null:
			EntityManager.add_component(entity, type_name, comp)

func _make_component(type: StringName, data: Dictionary) -> Component:
	## Built-in component types.
	match type:
		&"Transform":
			var c := TransformComponent.new()
			if data.has("position"): c.position = data.get("position") as Vector3
			return c
		&"Velocity":
			return VelocityComponent.new()
		&"Health":
			return HealthComponent.new(float(data.get("max_hp", 100.0)))
		&"Render":
			return RenderComponent.new(bool(data.get("visible", true)))
		&"Input":
			return InputComponent.new(int(data.get("player_index", 0)))
		_:
			## Unknown type — skip silently; game code registers custom factories.
			return null

func _attach_scene(entity: int, path: String, position: Vector3,
		parent: Node, on_ready: Callable) -> void:
	var res := ResourceManager.get_resource(StringName(path))
	if res is PackedScene:
		_attach_scene_node(entity, res as PackedScene, position, parent)
	if on_ready.is_valid(): on_ready.call(entity)

func _attach_scene_node(entity: int, packed: PackedScene,
		position: Vector3, parent: Node) -> void:
	var node := packed.instantiate() as Node3D
	if node == null: return
	node.position = position
	if is_instance_valid(parent):
		parent.add_child(node)
	EntityManager.add_component(entity, &"SceneNode", SceneNodeComponent.new(node))

func _resolve_parent(parent: Node) -> Node:
	if is_instance_valid(parent): return parent
	if is_instance_valid(WorldManager) and is_instance_valid(WorldManager.scene_root):
		return WorldManager.scene_root
	var tree := get_tree()
	return tree.current_scene if tree else null
