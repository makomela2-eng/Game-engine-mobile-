## PrefabLoader — loads Prefab .tres files from disk into PrefabRegistry.
extends Node

const PREFAB_DIR := "res://assets/prefabs/"

func load_all() -> void:
	_scan_dir(PREFAB_DIR)

func load_prefab(path: String) -> Prefab:
	var res: Resource = load(path)
	if res is Prefab:
		PrefabRegistry.register(res as Prefab)
		return res as Prefab
	Log.warn("[PrefabLoader] Not a Prefab resource: %s" % path)
	return null

func _scan_dir(dir_path: String) -> void:
	var dir : DirAccess = DirAccess.open(dir_path)
	if dir == null:
		return
	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if not dir.current_is_dir() and entry.ends_with(".tres"):
			load_prefab(dir_path + entry)
		entry = dir.get_next()
