## PrefabRegistry — indexed library of Prefab resources.
##
## Supports: register by resource, register_inline (code-defined),
## clone (modified copy), and group tagging for mass operations.
extends Node

var _registry : Dictionary = {}   ## StringName → Prefab
var _groups   : Dictionary = {}   ## StringName group → Array[StringName] ids

func register(prefab: Prefab) -> void:
	if prefab == null or not prefab.is_valid():
		Log.warn("[PrefabRegistry] Tried to register invalid prefab")
		return
	_registry[prefab.prefab_id] = prefab
	Log.info("[PrefabRegistry] Registered: %s" % prefab.prefab_id)
	Bus.emit(&"prefab.registered", {"id": prefab.prefab_id})

## Register a prefab defined entirely in code (no .tres file required).
func register_inline(id: StringName, scene_path: String = "",
		tags: Array[StringName] = [],
		components: Array[Dictionary] = [],
		group: StringName = &"") -> Prefab:
	var p          := Prefab.new()
	p.prefab_id    = id
	p.scene_path   = scene_path
	p.tags         = tags.duplicate()
	p.components   = components.duplicate()
	register(p)
	if group != &"":
		add_prefab_to_group(id, group)
	return p

func unregister(id: StringName) -> void:
	_registry.erase(id)
	for group in _groups.keys():
		(_groups[group] as Array).erase(id)

func get_prefab(id: StringName) -> Prefab:
	return _registry.get(id, null)

func has(id: StringName) -> bool:
	return _registry.has(id)

## Returns a duplicate Prefab with optional property overrides.
func clone(source_id: StringName, new_id: StringName,
		overrides: Dictionary = {}) -> Prefab:
	var source := get_prefab(source_id)
	if source == null:
		Log.error("[PrefabRegistry] Cannot clone unknown prefab: %s" % source_id)
		return null
	var cloned         := source.duplicate() as Prefab
	cloned.prefab_id   = new_id
	for key in overrides.keys():
		cloned.set(str(key), overrides[key])
	register(cloned)
	return cloned

## Group operations.
func add_prefab_to_group(id: StringName, group: StringName) -> void:
	if not _groups.has(group): _groups[group] = []
	if not (_groups[group] as Array).has(id):
		(_groups[group] as Array).append(id)

func get_group(group: StringName) -> Array[StringName]:
	var result : Array[StringName] = []
	if not _groups.has(group): return result
	for id in (_groups[group] as Array): result.append(id)
	return result

func all_ids() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _registry.keys(): result.append(k)
	return result

func count() -> int: return _registry.size()
