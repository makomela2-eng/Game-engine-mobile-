## GraphicsScaler — adjusts render scale based on GPU tier and thermals.
## Listens to thermal_critical and memory_critical from Bus.
## Listens to device.quality_tier_set to set initial scale.
extends Node

const SCALE_HIGH   := 1.0
const SCALE_MID    := 0.85
const SCALE_LOW    := 0.70
const SCALE_POTATO := 0.55

var current_scale : float = 1.0

var _cb_thermal : Callable
var _cb_memory  : Callable
var _cb_tier    : Callable
var _cb_battery : Callable

func _ready() -> void:
	_cb_thermal = func(_d: Variant) -> void: _downscale()
	_cb_memory  = func(_d: Variant) -> void: _downscale()
	_cb_tier    = func(d: Variant) -> void:
		if d is Dictionary:
			_apply_for_tier(int((d as Dictionary).get("tier", 1)))
	_cb_battery = func(_d: Variant) -> void: set_scale(SCALE_LOW)
	Bus.on(&"thermal_critical",        _cb_thermal)
	Bus.on(&"memory_critical",         _cb_memory)
	Bus.on(&"device.quality_tier_set", _cb_tier)
	Bus.on(&"battery_low",             _cb_battery)
	## Apply initial tier after DeviceCap has run
	call_deferred("_apply_for_tier", DeviceCap.gpu_tier)

func _exit_tree() -> void:
	if _cb_thermal.is_valid(): Bus.off(&"thermal_critical",        _cb_thermal)
	if _cb_memory.is_valid():  Bus.off(&"memory_critical",         _cb_memory)
	if _cb_tier.is_valid():    Bus.off(&"device.quality_tier_set", _cb_tier)
	if _cb_battery.is_valid(): Bus.off(&"battery_low",             _cb_battery)

func set_scale(scale: float) -> void:
	current_scale = clampf(scale, 0.5, 1.0)
	var vp := get_viewport()
	if not vp: return
	vp.scaling_3d_scale = current_scale
	Bus.emit(&"render_scale_changed", BusEvents.RenderScaleChanged.new(current_scale))

func _apply_for_tier(tier: int) -> void:
	match tier:
		2: set_scale(SCALE_HIGH)
		1: set_scale(SCALE_MID)
		_: set_scale(SCALE_LOW)

func _downscale() -> void:
	set_scale(maxf(SCALE_POTATO, current_scale - 0.1))
