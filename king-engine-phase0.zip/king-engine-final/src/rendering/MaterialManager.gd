## MaterialManager — dynamic material creation and runtime shader params.
##
## Typing notes:
##   • make_shader params loop uses explicit Variant key type.
##   • tween_method lambda annotates its argument as Variant.
##   • _materials Dictionary values accessed via is-checks before cast,
##     consistent with the rest of the codebase.
extends Node

## StringName → Material (ShaderMaterial or StandardMaterial3D).
var _materials : Dictionary = {}

func register(id: StringName, mat: Material) -> void:
	_materials[id] = mat

func get_mat(id: StringName) -> Material:
	var m: Variant = _materials.get(id)
	if m is Material: return m as Material
	return null

func set_param(id: StringName, param: StringName, value: Variant) -> void:
	var m: Material = get_mat(id)
	if m is ShaderMaterial:
		(m as ShaderMaterial).set_shader_parameter(param, value)
	elif m is StandardMaterial3D:
		(m as StandardMaterial3D).set(str(param), value)

func get_param(id: StringName, param: StringName) -> Variant:
	var m: Material = get_mat(id)
	if m is ShaderMaterial:
		return (m as ShaderMaterial).get_shader_parameter(param)
	return null

func make_standard(id: StringName, color: Color = Color.WHITE,
		metallic: float = 0.0, roughness: float = 0.8) -> StandardMaterial3D:
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic     = metallic
	mat.roughness    = roughness
	_materials[id]   = mat
	return mat

func make_shader(id: StringName, shader: Shader,
		params: Dictionary = {}) -> ShaderMaterial:
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = shader
	# Explicit Variant key so GDScript strict mode doesn't warn on iteration.
	for p: Variant in params:
		mat.set_shader_parameter(StringName(str(p)), params[p])
	_materials[id] = mat
	return mat

func tween_param(id: StringName, param: StringName,
		to_value: Variant, duration: float) -> void:
	var m: Material = get_mat(id)
	if not m is ShaderMaterial: return
	var sm: ShaderMaterial = m as ShaderMaterial
	var from_value: Variant = sm.get_shader_parameter(param)
	var tree := get_tree()
	if tree == null:
		sm.set_shader_parameter(param, to_value)
		return
	var t: Tween = tree.create_tween()
	# Lambda argument annotated as Variant - required for strict typing.
	t.tween_method(func(v: Variant) -> void: sm.set_shader_parameter(param, v),
		from_value, to_value, duration)
