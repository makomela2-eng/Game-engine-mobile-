## ParticleSystem — pooled particle emitters supporting CPU and GPU particles.
##
## Pool sizes:
##   CPU particles: POOL_SIZE (default 24) — safe on all devices
##   GPU particles: GPU_POOL_SIZE (default 16) — only on tier-1+ devices
##
## Usage:
##   ParticleSystem.burst(pos, color, count, speed)           → CPU one-shot
##   ParticleSystem.burst_gpu(pos, emitter_id, duration)      → GPU emitter
##   ParticleSystem.emit_entity(entity, emitter_id, duration) → follow entity
extends Node

const POOL_SIZE     := 24
const GPU_POOL_SIZE := 16

var _cpu_pool : Array[CPUParticles3D]  = []
var _gpu_pool : Array[GPUParticles3D]  = []
var _use_gpu  : bool                   = false

## Registered GPU particle presets: id → GPUParticles3D template node
var _gpu_templates : Dictionary = {}

func _ready() -> void:
	## CPU pool — always available.
	for i in POOL_SIZE:
		var p           := CPUParticles3D.new()
		p.emitting      = false
		p.one_shot      = true
		p.explosiveness = 0.9
		p.lifetime      = 1.2
		add_child(p)
		_cpu_pool.append(p)

	## GPU pool — tier 1+ only.
	_use_gpu = DeviceCap.gpu_tier >= 1
	if _use_gpu:
		for i in GPU_POOL_SIZE:
			var p      := GPUParticles3D.new()
			p.emitting  = false
			p.one_shot  = true
			add_child(p)
			_gpu_pool.append(p)

	Bus.on(&"particle.burst",       _on_burst)
	Bus.on(&"particle.burst_entity", _on_burst_entity)
	Bus.on(&"device.quality_tier_set", _on_tier_changed)

func _exit_tree() -> void:
	Bus.off(&"particle.burst",        _on_burst)
	Bus.off(&"particle.burst_entity",  _on_burst_entity)
	Bus.off(&"device.quality_tier_set", _on_tier_changed)

# ── CPU burst ──────────────────────────────────────────────────────────────────

func burst(pos: Vector3, color: Color = Color.WHITE,
		count: int = 20, speed: float = 4.0,
		lifetime: float = 1.2, size: float = 0.08) -> void:
	var p := _get_free_cpu()
	if p == null: return
	p.global_position      = pos
	p.amount               = count
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.color                = color
	p.lifetime             = lifetime
	p.scale                = Vector3.ONE * size
	p.emitting             = true

## Burst at an entity's current world position.
func burst_entity(entity: int, color: Color = Color.WHITE,
		count: int = 15, speed: float = 3.0) -> void:
	var t := EntityManager.get_component(entity, &"Transform") as TransformComponent
	if t: burst(t.position, color, count, speed)

# ── GPU emitter ────────────────────────────────────────────────────────────────

## Register a GPU particle template by id.
func register_gpu_template(id: StringName, template: GPUParticles3D) -> void:
	_gpu_templates[id] = template

## Play a named GPU emitter at a world position.
func burst_gpu(pos: Vector3, emitter_id: StringName,
		duration: float = 2.0) -> void:
	if not _use_gpu or not _gpu_templates.has(emitter_id): return
	var p := _get_free_gpu()
	if p == null: return
	var tmpl := _gpu_templates[emitter_id] as GPUParticles3D
	p.process_material   = tmpl.process_material
	p.draw_pass_1        = tmpl.draw_pass_1
	p.amount             = tmpl.amount
	p.lifetime           = tmpl.lifetime
	p.one_shot           = true
	p.global_position    = pos
	p.emitting           = true
	## Auto-stop after duration.
	TaskScheduler.schedule_once(func() -> void:
		if is_instance_valid(p): p.emitting = false,
		duration)

# ── Pool management ────────────────────────────────────────────────────────────

func _get_free_cpu() -> CPUParticles3D:
	for p : CPUParticles3D in _cpu_pool:
		if not p.emitting: return p
	## Pool exhausted — steal oldest (index 0, least-recently-started).
	_cpu_pool[0].emitting = false
	return _cpu_pool[0]

func _get_free_gpu() -> GPUParticles3D:
	for p : GPUParticles3D in _gpu_pool:
		if not p.emitting: return p
	return null

# ── Bus listeners ──────────────────────────────────────────────────────────────

func _on_burst(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	var pos_v : Variant = d.get("position", null)
	if not pos_v is Vector3: return
	burst(pos_v as Vector3,
		d.get("color",    Color.WHITE) as Color,
		int(d.get("count",  20)),
		float(d.get("speed", 4.0)),
		float(d.get("lifetime", 1.2)))

func _on_burst_entity(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	burst_entity(
		int(d.get("entity", -1)),
		d.get("color",  Color.WHITE) as Color,
		int(d.get("count",  15)),
		float(d.get("speed", 3.0)))

func _on_tier_changed(data: Variant) -> void:
	if not data is Dictionary: return
	_use_gpu = int((data as Dictionary).get("tier", 0)) >= 1

func active_count() -> int:
	var n := 0
	for p : CPUParticles3D in _cpu_pool:
		if p.emitting: n += 1
	for p : GPUParticles3D in _gpu_pool:
		if p.emitting: n += 1
	return n
