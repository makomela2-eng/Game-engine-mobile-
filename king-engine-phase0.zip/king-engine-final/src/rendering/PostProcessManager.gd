## PostProcessManager — manages WorldEnvironment and post-process effects.
##
## Finds the active WorldEnvironment on scene_loaded and scene_changed.
## Exposes brightness, saturation, contrast, glow, fog, DOF, and vignette.
## Mobile-safe: skips expensive effects when thermal state is critical.
extends Node

var _env_node : WorldEnvironment = null
var _env      : Environment      = null
var _throttled : bool            = false

func _ready() -> void:
	Bus.on(&"scene_loaded",         _on_scene_loaded)
	Bus.on(&"thermal_critical",     _on_thermal_critical)
	Bus.on(&"thermal_state_changed", _on_thermal_state)
	## Find environment in current scene if already loaded.
	call_deferred("_find_environment")

func _exit_tree() -> void:
	Bus.off(&"scene_loaded",          _on_scene_loaded)
	Bus.off(&"thermal_critical",      _on_thermal_critical)
	Bus.off(&"thermal_state_changed", _on_thermal_state)

func _on_scene_loaded(_d: Variant) -> void:
	_find_environment()

func _on_thermal_critical(_d: Variant) -> void:
	_throttled = true
	## Disable glow on thermal critical — significant GPU savings.
	if _env: _env.glow_enabled = false

func _on_thermal_state(data: Variant) -> void:
	if not data is Dictionary: return
	var state := int((data as Dictionary).get("state", 0))
	_throttled = state >= 2
	if not _throttled and _env:
		## Re-enable effects when thermal recovers.
		_env.glow_enabled = Cfg.get_bool("rendering", "glow", false)

func _find_environment() -> void:
	if not get_tree(): return
	var nodes : Array = get_tree().get_nodes_in_group("world_environment")
	if not nodes.is_empty() and nodes[0] is WorldEnvironment:
		_env_node = nodes[0] as WorldEnvironment
		_env      = _env_node.environment
		Log.info("[PostProcessManager] WorldEnvironment found")
		return
	## Fallback: scan scene root children.
	if get_tree().current_scene:
		for child in get_tree().current_scene.get_children():
			if child is WorldEnvironment:
				_env_node = child as WorldEnvironment
				_env      = _env_node.environment
				return

# ── Effect controls ────────────────────────────────────────────────────────────

func set_brightness(value: float) -> void:
	if not _env: return
	_env.adjustment_enabled    = true
	_env.adjustment_brightness = clampf(value, 0.0, 4.0)

func set_saturation(value: float) -> void:
	if not _env: return
	_env.adjustment_enabled    = true
	_env.adjustment_saturation = clampf(value, 0.0, 2.0)

func set_contrast(value: float) -> void:
	if not _env: return
	_env.adjustment_enabled  = true
	_env.adjustment_contrast = clampf(value, 0.0, 2.0)

func set_glow(enable: bool, intensity: float = 1.0,
		bloom: float = 0.1) -> void:
	if not _env or _throttled: return
	_env.glow_enabled   = enable
	_env.glow_intensity = clampf(intensity, 0.0, 8.0)
	_env.glow_bloom     = clampf(bloom, 0.0, 1.0)
	Cfg.set_val("rendering", "glow", enable)

func set_fog(enable: bool, density: float = 0.01,
		color: Color = Color(0.5, 0.6, 0.7)) -> void:
	if not _env: return
	_env.fog_enabled     = enable
	_env.fog_density     = clampf(density, 0.0, 1.0)
	_env.fog_light_color = color

func set_dof(enable: bool, focus_dist: float = 10.0,
		amount: float = 0.1) -> void:
	if not _env or _throttled: return
	_env.dof_blur_far_enabled   = enable
	_env.dof_blur_far_distance  = focus_dist
	_env.dof_blur_far_transition = amount

func fade_to_black(duration: float = 0.5) -> void:
	if not _env: return
	var tree := get_tree()
	if not tree: return
	var t : Tween = tree.create_tween()
	t.tween_method(
		func(v: float) -> void:
			if _env: _env.adjustment_brightness = v,
		_env.adjustment_brightness, 0.0, duration)

func fade_from_black(duration: float = 0.5) -> void:
	if not _env: return
	var tree := get_tree()
	if not tree: return
	_env.adjustment_brightness = 0.0
	var t : Tween = tree.create_tween()
	t.tween_method(
		func(v: float) -> void:
			if _env: _env.adjustment_brightness = v,
		0.0, 1.0, duration)

func has_environment() -> bool: return _env != null
