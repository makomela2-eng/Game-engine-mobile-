## ShaderManager — loads and caches shaders by id.
extends Node

var _shaders : Dictionary = {}  # StringName -> Shader

func register(id: StringName, shader: Shader) -> void:
	_shaders[id] = shader

func load_shader(id: StringName, path: String) -> Shader:
	if _shaders.has(id): return _shaders[id] as Shader
	var s := load(path) as Shader
	if s: _shaders[id] = s
	else: Log.error("[ShaderManager] failed to load: " + path)
	return s

func get_shader(id: StringName) -> Shader:
	var s : Variant = _shaders.get(id)
	if s is Shader: return s as Shader
	return null

func apply(mesh: MeshInstance3D, surface: int, mat_id: StringName) -> void:
	var mat := MaterialManager.get_mat(mat_id)
	if mat: mesh.set_surface_override_material(surface, mat)
