## CameraSystem — activates Camera3D nodes based on CameraComponent.
## Uses QuerySystem cache. Tracks active entity to avoid redundant make_current().
extends SystemBase

var _active_entity : int = -1

func _on_start() -> void:
	priority = 8050
	listen(&"camera.set_active",    _on_set_active)
	listen(&"ecs.entity_destroyed", _on_entity_destroyed)

func _on_stop() -> void:
	unlisten(&"camera.set_active",    _on_set_active)
	unlisten(&"ecs.entity_destroyed", _on_entity_destroyed)

func tick(_delta: float) -> void:
	for id : int in QuerySystem.query([&"Camera", &"SceneNode"]):
		var cc := get_c(id, &"Camera") as CameraComponent
		var sn := get_c(id, &"SceneNode") as SceneNodeComponent
		if cc == null or sn == null or not is_instance_valid(sn.node): continue
		if not sn.node is Camera3D: continue
		var cam := sn.node as Camera3D
		cam.fov  = cc.fov
		cam.near = cc.near_clip
		cam.far  = cc.far_clip
		if cc.is_active and id != _active_entity:
			cam.make_current()
			_active_entity = id
			Bus.emit(&"camera_changed", {"position": cam.global_position})

func _on_set_active(data: Variant) -> void:
	if not data is Dictionary: return
	var entity := int((data as Dictionary).get("entity", -1))
	if entity < 0: return
	if _active_entity >= 0 and _active_entity != entity:
		var cc := get_c(_active_entity, &"Camera") as CameraComponent
		if cc: cc.is_active = false
	var new_cc := get_c(entity, &"Camera") as CameraComponent
	if new_cc: new_cc.is_active = true
	_active_entity = entity

func _on_entity_destroyed(data: Variant) -> void:
	if not data is Dictionary: return
	if int((data as Dictionary).get("entity", -1)) == _active_entity:
		_active_entity = -1
