## MaterialInstance — a runtime copy of a material with overridable properties.
class_name MaterialInstance
extends RefCounted

var source_path : String           = ""
var material    : ShaderMaterial   = null
var overrides   : Dictionary       = {}  ## param_name → value

func _init(path: String = "") -> void:
	source_path = path

func load_from(path: String) -> bool:
	var res: Resource = load(path)
	if res is ShaderMaterial:
		material = (res as ShaderMaterial).duplicate() as ShaderMaterial
		source_path = path
		return true
	return false

func set_param(name: StringName, value: Variant) -> void:
	overrides[name] = value
	if material:
		material.set_shader_parameter(name, value)

func get_param(name: StringName) -> Variant:
	return overrides.get(name, null)

func apply_to(mesh_instance: MeshInstance3D, surface: int = 0) -> void:
	if material:
		mesh_instance.set_surface_override_material(surface, material)
