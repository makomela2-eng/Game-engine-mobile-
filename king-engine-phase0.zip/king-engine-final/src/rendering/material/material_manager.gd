## MaterialManager — caches and vends materials by path.
extends Node

var _cache : Dictionary = {}  ## path → ShaderMaterial

func get_material(path: String) -> ShaderMaterial:
	if path.is_empty():
		return null
	if _cache.has(path):
		return _cache[path]
	var res: Resource = load(path)
	if res is ShaderMaterial:
		_cache[path] = res as ShaderMaterial
		return _cache[path]
	Log.warn("[MaterialManager] Not a ShaderMaterial: %s" % path)
	return null

func has_cached(path: String) -> bool:
	return _cache.has(path)

func get_instance(path: String) -> MaterialInstance:
	var inst := MaterialInstance.new(path)
	inst.load_from(path)
	return inst

func preload_materials(paths: Array[String]) -> void:
	for p : String in paths:
		get_material(p)
	Log.info("[MaterialManager] Preloaded %d materials" % paths.size())

func release(path: String) -> void:
	_cache.erase(path)

func clear_cache() -> void:
	_cache.clear()

func cached_count() -> int:
	return _cache.size()
