## RenderPipeline — controls the active rendering path and global render settings.
## Wraps Godot's RenderingServer for engine-level control.
extends Node

enum Pipeline { MOBILE, FORWARD_PLUS, COMPATIBILITY }

var current_pipeline : Pipeline = Pipeline.MOBILE
var msaa             : int      = 0   ## 0=off 2=2x 4=4x 8=8x
var fxaa             : bool     = false
var shadow_quality   : int      = 1   ## 0=disabled 1=low 2=medium 3=high
var ambient_occlusion : bool    = false
var glow             : bool     = false

func _ready() -> void:
	_apply()
	Log.info("[RenderPipeline] Initialized: %s" % _pipeline_name())

func set_pipeline(p: Pipeline) -> void:
	current_pipeline = p
	_apply()
	Bus.emit(&"render.pipeline_changed", {"pipeline": p})

func set_msaa(level: int) -> void:
	msaa = level
	var vp := get_viewport()
	if vp:
		vp.msaa_3d = _msaa_enum(level)

func set_shadow_quality(level: int) -> void:
	shadow_quality = clamp(level, 0, 3)
	# Directional shadow filtering is global in Godot 4.6.
	RenderingServer.directional_soft_shadow_filter_set_quality(
		[
			RenderingServer.SHADOW_QUALITY_HARD,
			RenderingServer.SHADOW_QUALITY_SOFT_LOW,
			RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM,
			RenderingServer.SHADOW_QUALITY_SOFT_HIGH,
		][shadow_quality]
	)
func _apply() -> void:
	var vp := get_viewport()
	if vp == null:
		return
	vp.msaa_3d     = _msaa_enum(msaa)
	vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if fxaa else Viewport.SCREEN_SPACE_AA_DISABLED

func _msaa_enum(level: int) -> int:
	match level:
		2: return Viewport.MSAA_2X
		4: return Viewport.MSAA_4X
		8: return Viewport.MSAA_8X
		_: return Viewport.MSAA_DISABLED

func _pipeline_name() -> String:
	match current_pipeline:
		Pipeline.MOBILE:       return "Mobile"
		Pipeline.FORWARD_PLUS: return "Forward+"
		_:                     return "Compatibility"
