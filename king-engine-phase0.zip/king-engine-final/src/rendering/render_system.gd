## RenderSystem — syncs RenderComponent state to scene MeshInstance3D nodes.
## Uses QuerySystem cache to avoid iterating all entities every frame.
extends SystemBase

func _on_start() -> void:
	priority = 8100

func tick(_delta: float) -> void:
	## Use QuerySystem cached query instead of raw EntityManager call.
	for id : int in QuerySystem.query([&"Render", &"SceneNode"]):
		var rc := get_c(id, &"Render") as RenderComponent
		var sn := get_c(id, &"SceneNode") as SceneNodeComponent
		if rc == null or sn == null or not is_instance_valid(sn.node):
			continue
		sn.node.visible = rc.visible
		if sn.node is GeometryInstance3D:
			var gi := sn.node as GeometryInstance3D
			gi.layers      = rc.layer_mask
			gi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON \
				if rc.cast_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
