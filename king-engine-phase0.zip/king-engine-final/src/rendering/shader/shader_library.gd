## ShaderLibrary — named registry of compiled shaders.
extends Node

var _shaders : Dictionary = {}  ## StringName → Shader

func register(svc_name: StringName, shader: Shader) -> void:
	if shader == null:
		return
	_shaders[svc_name] = shader

func unregister(svc_name: StringName) -> void:
	_shaders.erase(svc_name)

func load_shader(svc_name: StringName, path: String) -> Shader:
	var res: Resource = load(path)
	if res is Shader:
		_shaders[svc_name] = res as Shader
		return _shaders[svc_name]
	Log.warn("[ShaderLibrary] Not a Shader: %s" % path)
	return null

func get_shader(svc_name: StringName) -> Shader:
	return _shaders.get(svc_name, null)

func has_shader(svc_name: StringName) -> bool:
	return _shaders.has(svc_name)

func make_material(shader_name: StringName) -> ShaderMaterial:
	var shader := get_shader(shader_name)
	if shader == null:
		Log.error("[ShaderLibrary] Shader not found: %s" % shader_name)
		return null
	var mat := ShaderMaterial.new()
	mat.shader = shader
	return mat

func all_names() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _shaders.keys():
		result.append(k)
	return result

func clear() -> void:
	_shaders.clear()
