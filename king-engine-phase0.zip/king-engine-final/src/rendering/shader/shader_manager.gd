## ShaderManager — loads, caches, and hot-reloads shaders.
extends Node

const SHADER_DIR := "res://assets/shaders/"
var _cache       : Dictionary = {}  ## path → Shader

func get_shader(path: String) -> Shader:
	if path.is_empty():
		return null
	if _cache.has(path):
		return _cache[path]
	var res: Resource = load(path)
	if res is Shader:
		_cache[path] = res as Shader
		ShaderLibrary.register(StringName(path.get_file().get_basename()), res)
		return _cache[path]
	Log.warn("[ShaderManager] Not a Shader: %s" % path)
	return null

func has_cached(path: String) -> bool:
	return _cache.has(path)

func preload_dir(dir_path: String = SHADER_DIR) -> void:
	var dir : DirAccess = DirAccess.open(dir_path)
	if dir == null:
		return
	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if entry.ends_with(".gdshader") or entry.ends_with(".shader"):
			get_shader(dir_path + entry)
		entry = dir.get_next()
	dir.list_dir_end()
	Log.info("[ShaderManager] Loaded %d shaders from %s" % [_cache.size(), dir_path])

func release(path: String) -> void:
	_cache.erase(path)

func clear_cache() -> void:
	_cache.clear()

func cached_count() -> int:
	return _cache.size()
