## FrameBudget — per-frame time budget with running average and tier-aware defaults.
##
## Reads from SystemScheduler's Profiler data for accurate per-system remaining time.
## Auto-configures budget_ms from DeviceCap.gpu_tier on first ready.
## Provides: is_over(), remaining_ms(), allocate_for(system), usage_pct().
extends Node

## Overridable. Auto-set from tier if not manually configured.
var budget_ms     : float = 6.0
var _history      : Array[float] = []
var _history_size : int   = 30
var _avg_frame_ms : float = 0.0
var _frame_start  : int   = 0

func _ready() -> void:
	set_process(true)
	## Set budget from device tier — lower tier gets more headroom (less work per frame).
	match DeviceCap.gpu_tier:
		2: budget_ms = 8.0    ## high-end: 8ms budget (targeting 60fps ~16ms frame)
		1: budget_ms = 6.0    ## mid: 6ms
		_: budget_ms = 4.0    ## low: 4ms — leave more headroom for rendering
	Log.info("[FrameBudget] budget=%.1fms (tier %d)" % [budget_ms, DeviceCap.gpu_tier])
	Bus.on(&"device.quality_tier_set", _on_tier_changed)

func _exit_tree() -> void:
	Bus.off(&"device.quality_tier_set", _on_tier_changed)

func _process(_delta: float) -> void:
	## Track actual frame time with a rolling average.
	var now := Time.get_ticks_usec()
	if _frame_start > 0:
		var frame_ms := float(now - _frame_start) / 1000.0
		_history.append(frame_ms)
		if _history.size() > _history_size:
			_history.pop_front()
		var total := 0.0
		for v : float in _history: total += v
		_avg_frame_ms = total / float(_history.size())
	_frame_start = now

## Milliseconds elapsed in the current frame (using process monitor).
func elapsed_ms() -> float:
	return Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0

## Remaining budget in this frame.
func remaining_ms() -> float:
	return maxf(budget_ms - elapsed_ms(), 0.0)

## True when the frame budget has been consumed.
func is_over() -> bool:
	return remaining_ms() <= 0.0

## Budget used as a fraction 0–1.
func usage_pct() -> float:
	return clampf(elapsed_ms() / budget_ms, 0.0, 1.0)

## Rolling average frame time over last N frames.
func avg_frame_ms() -> float:
	return _avg_frame_ms

## Proportional budget for a named system based on its average tick time.
## Use in systems that want to self-limit: `if not FrameBudget.has_budget_for(&"AISystem"): return`
func has_budget_for(system_name: StringName, min_ms: float = 0.5) -> bool:
	var avg := Profiler.get_avg_ms(system_name)
	return remaining_ms() >= maxf(avg, min_ms)

func set_budget(ms: float) -> void:
	budget_ms = maxf(ms, 1.0)

func _on_tier_changed(data: Variant) -> void:
	if not data is Dictionary: return
	match int((data as Dictionary).get("tier", 1)):
		2: set_budget(8.0)
		1: set_budget(6.0)
		_: set_budget(4.0)
