## MemoryBudget — tracks memory usage and emits warnings.
## Feeds into ThermalMonitor and GraphicsScaler via Bus.
extends Node

var budget_mb      : float = 512.0
var warning_pct    : float = 0.80
var critical_pct   : float = 0.92
var _warned        : bool  = false
var _critical      : bool  = false

func _ready() -> void:
	TaskScheduler.schedule(&"memory_check", 3.0, _check)

func _check() -> void:
	var used_mb : float = OS.get_static_memory_usage() / 1_048_576.0
	var pct     : float = used_mb / budget_mb

	if pct >= critical_pct and not _critical:
		_critical = true
		_warned   = true
		Log.warn("[MemoryBudget] critical: %.0f MB / %.0f MB" % [used_mb, budget_mb])
		Bus.emit(&"memory_critical", {"used_mb": used_mb, "budget_mb": budget_mb, "pct": pct})
		Bus.emit(&"memory_warning",  {"used_mb": used_mb, "budget_mb": budget_mb, "pct": pct})
	elif pct >= warning_pct and not _warned:
		_warned = true
		Log.warn("[MemoryBudget] warning: %.0f MB / %.0f MB" % [used_mb, budget_mb])
		Bus.emit(&"memory_warning", {"used_mb": used_mb, "budget_mb": budget_mb, "pct": pct})
	elif pct < warning_pct:
		_warned   = false
		_critical = false

func set_budget(mb: float) -> void:
	budget_mb = mb

func get_used_mb() -> float:
	return OS.get_static_memory_usage() / 1_048_576.0

func get_pct() -> float:
	return get_used_mb() / budget_mb
