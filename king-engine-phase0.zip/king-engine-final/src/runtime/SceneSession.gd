## SceneSession — editor save/load and snapshot persistence.
##
## Typing notes:
##   • load_slot() validates version before returning data.
##   • _serialize_children returns Array[Dictionary].
##   • children array from deserialized JSON guarded with is Array before
##     iterating — JSON arrays come back as untyped Array, not Array[Dictionary].
##   • All loop variables explicitly typed.
extends Node

const SAVE_VERSION := 2

func save_slot(slot: int, scene_root: Node) -> bool:
	var path: String = SaveDir.path("scene_%d.json" % slot)
	var data: Dictionary = snapshot(scene_root)
	var f: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if not f:
		Log.error("[SceneSession] cannot write slot %d" % slot)
		return false
	f.store_string(JSON.stringify(data, "\t"))
	f.close()
	Bus.emit(&"scene_saved", BusEvents.SceneSaved.new(slot, path, SAVE_VERSION))
	Log.info("[SceneSession] saved slot %d" % slot)
	return true

## Returns empty Dictionary on missing file, parse failure, or version mismatch.
func load_slot(slot: int) -> Dictionary:
	var path: String = SaveDir.path("scene_%d.json" % slot)
	if not FileAccess.file_exists(path): return {}
	var text: String = FileAccess.get_file_as_string(path)
	if text.is_empty(): return {}
	var parsed: Variant = JSON.parse_string(text)
	if not parsed is Dictionary: return {}
	var d: Dictionary = parsed as Dictionary
	var ver: int = int(d.get("version", 0))
	if ver != SAVE_VERSION:
		Log.warn("[SceneSession] slot %d version %d != expected %d — refusing load" % [
			slot, ver, SAVE_VERSION])
		return {}
	return d

func restore_slot(slot: int, scene_root: Node) -> bool:
	var data: Dictionary = load_slot(slot)
	if data.is_empty():
		return false
	if not is_instance_valid(scene_root):
		return false
	# Defer the destructive part so we do not mutate the tree from inside
	# a UI callback or during the same frame a system is iterating.
	call_deferred("_apply_snapshot_safe", scene_root, data)
	return true

func _apply_snapshot_safe(scene_root: Node, data: Dictionary) -> void:
	apply_snapshot(scene_root, data)

func snapshot(scene_root: Node) -> Dictionary:
	return {
		"version":     SAVE_VERSION,
		"timestamp":   Time.get_datetime_string_from_system(),
		"scene_nodes": _serialize_children(scene_root),
		"entities":    EntityManager.snapshot(scene_root)
	}

func apply_snapshot(scene_root: Node, data: Dictionary) -> void:
	if not is_instance_valid(scene_root):
		Log.warn("[SceneSession] restore skipped: invalid scene root")
		return
	_clear_children(scene_root)
	call_deferred("_finish_apply_snapshot", scene_root, data)

func _finish_apply_snapshot(scene_root: Node, data: Dictionary) -> void:
	if not is_instance_valid(scene_root):
		return
	var nodes_var: Variant = data.get("scene_nodes", [])
	if nodes_var is Array:
		for node_data: Variant in (nodes_var as Array):
			if not node_data is Dictionary:
				continue
			var restored: Node = _restore_node(node_data as Dictionary)
			if restored != null:
				scene_root.add_child(restored)
	var ecs_var: Variant = data.get("entities", {})
	EntityManager.restore_snapshot(
		ecs_var as Dictionary if ecs_var is Dictionary else {},
		scene_root, true)
	_post_restore_recovery()
	Bus.emit(&"scene_loaded", BusEvents.SceneLoaded.new(int(data.get("version", 0))))
	Log.info("[SceneSession] snapshot restored")

func snapshot_entities(scene_root: Node = null) -> Dictionary:
	return EntityManager.snapshot(scene_root)

func restore_entities(data: Dictionary, scene_root: Node = null,
		clear_existing: bool = true) -> void:
	EntityManager.restore_snapshot(data, scene_root, clear_existing)

func _post_restore_recovery() -> void:
	var tree: SceneTree = get_tree()
	if tree == null:
		return
	tree.paused = false

	## Do NOT call GameLoop or SystemScheduler directly.
	## GameLoop already listens for engine_play. SystemScheduler listens for engine_play too.
	## UISystem and anything else can listen for scene_restored independently.
	Bus.emit(&"scene_restored", {"reason": "snapshot"})
	Bus.emit(&"engine_play", null)

# ── Serialization ─────────────────────────────────────────────────────────────

func _serialize_children(root: Node) -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if not is_instance_valid(root): return out
	for child: Node in root.get_children():
		out.append(_serialize_node(child))
	return out

func _serialize_node(node: Node) -> Dictionary:
	var data: Dictionary = {
		"name":     str(node.name),
		"class":    node.get_class(),
		"children": [] as Array
	}
	if node is Node3D:
		var n3: Node3D = node as Node3D
		## Save global_position to match TransformComponent.position (world-space).
		## Node tree restore uses global_position so TransformComponent and node
		## are always in the same coordinate space. Do NOT use n3.position here.
		data["position"]         = var_to_str(n3.global_position)
		data["rotation_degrees"] = var_to_str(n3.rotation_degrees)
		data["scale"]            = var_to_str(n3.scale)
		data["visible"]          = n3.visible
	for child: Node in node.get_children():
		(data["children"] as Array).append(_serialize_node(child))
	return data

func _restore_node(data: Dictionary) -> Node:
	var node_class: String = str(data.get("class", "Node3D"))
	var node: Node = _create_node(node_class)
	if node == null: return null
	node.name = str(data.get("name", "Node"))
	if node is Node3D:
		var n3: Node3D = node as Node3D
		## Restore to global_position — matches what was saved above and what
		## EntityToSceneSync writes each frame via TransformComponent.position.
		n3.global_position  = _as_vec3(data.get("position",         "Vector3(0,0,0)"))
		n3.rotation_degrees = _as_vec3(data.get("rotation_degrees", "Vector3(0,0,0)"))
		n3.scale            = _as_vec3(data.get("scale",            "Vector3(1,1,1)"))
		n3.visible          = bool(data.get("visible", true))
	var children_var: Variant = data.get("children", [])
	if children_var is Array:
		for child_data: Variant in (children_var as Array):
			if not child_data is Dictionary: continue
			var child: Node = _restore_node(child_data as Dictionary)
			if child != null:
				node.add_child(child)
	return node

# ── Node factory (allowlist) ──────────────────────────────────────────────────

func _create_node(node_class: String) -> Node:
	match node_class:
		"Node":               return Node.new()
		"Node3D":             return Node3D.new()
		"MeshInstance3D":     return MeshInstance3D.new()
		"OmniLight3D":        return OmniLight3D.new()
		"DirectionalLight3D": return DirectionalLight3D.new()
		"SpotLight3D":        return SpotLight3D.new()
		"StaticBody3D":       return StaticBody3D.new()
		"CharacterBody3D":    return CharacterBody3D.new()
		"CollisionShape3D":   return CollisionShape3D.new()
		"Camera3D":           return Camera3D.new()
		"WorldEnvironment":   return WorldEnvironment.new()
		_:
			Log.warn("[SceneSession] unknown node class '%s', defaulting to Node3D" % node_class)
			return Node3D.new()

# ── Helpers ───────────────────────────────────────────────────────────────────

func _as_vec3(value: Variant) -> Vector3:
	if value is Vector3: return value as Vector3
	if value is String:
		var parsed: Variant = str_to_var(value as String)
		if parsed is Vector3: return parsed as Vector3
	if value is Array:
		var a: Array = value as Array
		if a.size() >= 3:
			return Vector3(float(a[0]), float(a[1]), float(a[2]))
	return Vector3.ZERO

func _clear_children(root: Node) -> void:
	for child: Node in root.get_children().duplicate():
		child.queue_free()
