## TaskScheduler — runs recurring tasks at specified intervals.
## Replaces per-system _process timers with one centralised scheduler.
##
## Delta passing (FIX): callbacks now receive (delta: float) as their first
## argument when fn.get_argument_count() >= 1. This lets systems like
## MovementSystem use the real engine frame time rather than polling
## get_process_delta_time() themselves (which returns 0 when the system is
## not inside a _process call). Zero-argument callbacks still work unchanged.
##
## Mutation safety: _process iterates a snapshot of the task list taken at
## the start of each frame. Any schedule/unschedule calls made from inside a
## callback take effect on the live array but do NOT affect the current frame's
## snapshot, preventing skipped work and ordering issues.
extends Node

func _ready() -> void:
	set_process(true)

class Task:
	var id          : StringName
	var interval    : float
	var elapsed     : float = 0.0
	var fn          : Callable
	## Cached at registration — true when fn expects a delta float argument.
	var wants_delta : bool  = false

var _tasks        : Array[Task] = []
var _pending_add  : Array[Task] = []   # queued from inside a callback
var _in_process   : bool        = false

func _process(delta: float) -> void:
	_in_process = true
	# Snapshot: iterate a copy so callbacks can call schedule/unschedule safely.
	var snapshot: Array[Task] = _tasks.duplicate()
	for task: Task in snapshot:
		# Skip tasks that were unscheduled mid-frame.
		if not _tasks.has(task): continue
		task.elapsed += delta
		if task.elapsed >= task.interval:
			task.elapsed = 0.0
			if task.fn.is_valid():
				if task.wants_delta:
					task.fn.call(delta)
				else:
					task.fn.call()
	_in_process = false
	# Flush any tasks that were scheduled from inside a callback.
	for t: Task in _pending_add:
		_tasks.append(t)
	_pending_add.clear()

## Schedule a recurring task. interval_sec 0.0 = every frame.
## If fn accepts one or more arguments, delta (float) is passed as the first.
func schedule(id: StringName, interval_sec: float, fn: Callable) -> void:
	unschedule(id)
	var t: Task = Task.new()
	t.id          = id
	t.interval    = interval_sec
	t.fn          = fn
	t.wants_delta = fn.get_argument_count() >= 1
	if _in_process:
		_pending_add.append(t)
	else:
		_tasks.append(t)

func unschedule(id: StringName) -> void:
	# Remove from live array.
	for i in range(_tasks.size()):
		if (_tasks[i] as Task).id == id:
			_tasks.remove_at(i)
			break
	# Also remove from the pending-add queue if it hasn't flushed yet.
	for i in range(_pending_add.size()):
		if (_pending_add[i] as Task).id == id:
			_pending_add.remove_at(i)
			break

func is_scheduled(id: StringName) -> bool:
	for task: Task in _tasks:
		if task.id == id: return true
	for task: Task in _pending_add:
		if task.id == id: return true
	return false

func get_tasks() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for task: Task in _tasks:
		out.append({
			"id":        str(task.id),
			"interval":  task.interval,
			"elapsed":   task.elapsed,
			"remaining": maxf(task.interval - task.elapsed, 0.0)
		})
	return out

func task_count() -> int:
	return _tasks.size()

func clear() -> void:
	_tasks.clear()
	_pending_add.clear()

func flush() -> void:
	var snapshot: Array[Task] = _tasks.duplicate()
	for task: Task in snapshot:
		if task.fn.is_valid():
			if task.wants_delta:
				task.fn.call(0.0)
			else:
				task.fn.call()
