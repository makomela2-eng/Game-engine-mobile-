## Watchdog — detects stalls and provides a ping() heartbeat.
## GameLoop calls ping() every frame. If too long passes without a ping,
## a stall is detected and frame_stall is emitted on the Bus.
extends Node

var stall_threshold_ms : float = 500.0
var _last_time         : int   = 0
var _active            : bool  = false

func _ready() -> void:
	set_process(true)
	var t : SceneTreeTimer = get_tree().create_timer(3.0)
	t.timeout.connect(_activate)

func _activate() -> void:
	_last_time = Time.get_ticks_msec()
	_active    = true

## Called by GameLoop every frame.
func ping() -> void:
	if not _active: return
	var now     : int   = Time.get_ticks_msec()
	var elapsed : float = float(now - _last_time)
	_last_time = now
	if elapsed > stall_threshold_ms:
		Log.warn("[Watchdog] stall: %.0f ms" % elapsed)
		Bus.emit(&"frame_stall", {"ms": elapsed})

func _process(_delta: float) -> void:
	pass  ## Heartbeat now driven by GameLoop.ping()
