## EntityToSceneSync — writes ECS state back to scene nodes every frame.
## Runs after all systems tick (priority 9000). Keeps Godot nodes in sync
## with ECS data.
##
## Mismatch guard: if a SceneNodeComponent's node pointer is invalid
## (freed outside the ECS), we emit a warning and skip — never crash.
## The guard runs every N frames to keep overhead negligible on mobile.
extends SystemBase

## How often to run the validity check (every N ticks). 0 = every frame.
const VALIDATE_INTERVAL : int = 30

var _validate_counter : int = 0

func _on_start() -> void:
	priority = 9000

func tick(delta: float) -> void:
	_validate_counter += 1
	var do_validate := (_validate_counter >= VALIDATE_INTERVAL)
	if do_validate:
		_validate_counter = 0
	_sync_transforms(do_validate)

func _sync_transforms(validate: bool) -> void:
	var entities := query([&"Transform", &"SceneNode"])
	for id : int in entities:
		var t  := get_c(id, &"Transform") as TransformComponent
		var sn := get_c(id, &"SceneNode") as SceneNodeComponent
		if t == null or sn == null:
			continue
		if not is_instance_valid(sn.node):
			## Node was freed without going through ECS destroy.
			## Warn once; a future cleanup pass (or level reload) will
			## remove the component properly.
			if validate:
				Log.warn("[EntityToSceneSync] e%d SceneNode is invalid — node freed outside ECS" % id)
			continue
		## Optional: detect large position divergence and log it.
		if validate and sn.node is Node3D:
			var scene_pos := (sn.node as Node3D).global_position
			if t.position.distance_squared_to(scene_pos) > 100.0:
				Log.warn("[EntityToSceneSync] e%d position mismatch ECS=%s node=%s" % [
					id, t.position, scene_pos])
		t.apply_to_node(sn.node)
