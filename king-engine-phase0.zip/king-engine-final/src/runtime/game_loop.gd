## GameLoop — master tick coordinator.
##
## Execution order per frame:
##   1. SystemScheduler._process()  → all systems tick in priority order
##   2. GameLoop._process()         → Commands.flush() → EventBus.flush()
##
## Also listens for engine_pause / engine_play / engine_stop from Dashboard.
extends Node

var paused       : bool  = false
var tick_count   : int   = 0
var elapsed_time : float = 0.0
var time_scale   : float = 1.0

signal tick_started(delta: float)
signal tick_ended(delta: float)

var _cb_pause : Callable
var _cb_play  : Callable
var _cb_stop  : Callable

func _ready() -> void:
	set_process(true)
	add_to_group("game_loop")
	_cb_pause = func(_d: Variant) -> void: pause()
	_cb_play  = func(_d: Variant) -> void: resume()
	_cb_stop  = func(_d: Variant) -> void: pause()
	Bus.on(&"engine_pause", _cb_pause)
	Bus.on(&"engine_play",  _cb_play)
	Bus.on(&"engine_stop",  _cb_stop)
	Bus.on(&"app_background", _cb_pause)
	Bus.on(&"app_foreground", _cb_play)
	Log.info("[GameLoop] Ready")

func _exit_tree() -> void:
	if _cb_pause.is_valid(): Bus.off(&"engine_pause",   _cb_pause)
	if _cb_play.is_valid():  Bus.off(&"engine_play",    _cb_play)
	if _cb_stop.is_valid():  Bus.off(&"engine_stop",    _cb_stop)
	Bus.off(&"app_background", _cb_pause)
	Bus.off(&"app_foreground", _cb_play)

func _process(delta: float) -> void:
	if paused or not is_inside_tree():
		return
	var scaled := delta * time_scale
	tick_started.emit(scaled)
	Commands.flush()
	EventBus.flush()
	if Watchdog.has_method("ping"):
		Watchdog.ping()
	tick_count   += 1
	elapsed_time += scaled
	tick_ended.emit(scaled)

func pause() -> void:
	paused = true
	SystemScheduler.pause()
	Bus.emit(&"game.paused", {})

func resume() -> void:
	paused = false
	SystemScheduler.resume()
	Bus.emit(&"game.resumed", {})

func set_time_scale(scale: float) -> void:
	time_scale = clampf(scale, 0.0, 10.0)

func reset() -> void:
	tick_count   = 0
	elapsed_time = 0.0
