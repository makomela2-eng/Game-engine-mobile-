## SceneToEntityBridge — walks a scene tree and creates entities from tagged nodes.
## Nodes with meta "king_entity" = true get auto-converted on scene load.
## Component data read from node meta: "king_components" → Array[Dictionary]
extends Node

const META_ENTITY     := "king_entity"
const META_COMPONENTS := "king_components"
const META_TAGS       := "king_tags"

## Walk root and create entities for all marked nodes. Returns map node→entity_id.
func import_scene(root: Node) -> Dictionary:
	var map : Dictionary = {}
	_walk(root, map)
	Log.info("[SceneBridge] Imported %d entities from scene" % map.size())
	return map

func _walk(node: Node, map: Dictionary) -> void:
	if node.has_meta(META_ENTITY) and bool(node.get_meta(META_ENTITY)):
		var id := _create_from_node(node)
		if id >= 0:
			map[node] = id
	for child in node.get_children():
		_walk(child, map)

func _create_from_node(node: Node) -> int:
	var id := EntityManager.create_entity()

	# Always add SceneNodeComponent if Node3D
	if node is Node3D:
		var sn := SceneNodeComponent.new(node as Node3D)
		EntityManager.add_component(id, &"SceneNode", sn)
		var t := TransformComponent.new()
		t.set_from_node(node as Node3D)
		EntityManager.add_component(id, &"Transform", t)

	# Tags
	if node.has_meta(META_TAGS):
		var tags = node.get_meta(META_TAGS)
		if tags is Array:
			for tag in (tags as Array):
				EntityManager.add_tag(id, StringName(str(tag)))

	# Extra components from meta
	if node.has_meta(META_COMPONENTS):
		var comps = node.get_meta(META_COMPONENTS)
		if comps is Array:
			for comp_def in (comps as Array):
				_apply_component(id, comp_def as Dictionary)

	Bus.emit(&"bridge.entity_imported", {"entity": id, "node": node})
	return id

func _apply_component(id: int, def: Dictionary) -> void:
	var type := StringName(str(def.get("type", "")))
	if type == &"":
		return
	match type:
		&"Render":
			EntityManager.add_component(id, type, RenderComponent.new())
		&"Velocity":
			EntityManager.add_component(id, type, VelocityComponent.new())
		# Extend: add more component factories here
		_:
			Log.warn("[SceneBridge] Unknown component type: %s" % type)
