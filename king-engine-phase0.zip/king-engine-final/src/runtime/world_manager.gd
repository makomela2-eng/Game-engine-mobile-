## WorldManager — owns the active world with async loading to avoid mobile stalls.
##
## Async flow:
##   load_world_async(path) → ResourceLoader.load_threaded_request
##   → TaskScheduler polls → instantiate + bridge → scene_loaded
##
## Sync fallback:
##   load_world(path) → synchronous, use only in editor / non-mobile
##
## Entity bridge: SceneToEntityBridge.import_scene() after instantiation.
extends Node

var current_world : String = ""
var scene_root    : Node   = null
var entity_map    : Dictionary = {}
var _loading      : bool   = false

signal world_loaded(world_path: String)
signal world_unloaded(world_path: String)
signal world_load_failed(world_path: String)

# ── Async load (preferred on mobile) ──────────────────────────────────────────

func load_world_async(path: String, clear_entities: bool = true) -> void:
	if _loading:
		Log.warn("[WorldManager] Already loading, queuing: %s" % path)
		return
	_loading = true
	Log.info("[WorldManager] Async loading: %s" % path)
	_unload_current(clear_entities)
	var err := ResourceLoader.load_threaded_request(path)
	if err != OK:
		Log.error("[WorldManager] load_threaded_request failed: %s (%s)" \
			% [path, error_string(err)])
		_loading = false
		world_load_failed.emit(path)
		return
	TaskScheduler.schedule(&"world_load_poll", 0.1,
		func() -> void: _poll_world_load(path, clear_entities))

func _poll_world_load(path: String, clear_entities: bool) -> void:
	var status := ResourceLoader.load_threaded_get_status(path)
	match status:
		ResourceLoader.THREAD_LOAD_LOADED:
			TaskScheduler.unschedule(&"world_load_poll")
			var packed := ResourceLoader.load_threaded_get(path) as PackedScene
			if packed == null:
				Log.error("[WorldManager] Not a PackedScene: %s" % path)
				_loading = false
				world_load_failed.emit(path)
				return
			_instantiate_world(path, packed, clear_entities)
		ResourceLoader.THREAD_LOAD_FAILED, ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			TaskScheduler.unschedule(&"world_load_poll")
			_loading = false
			Log.error("[WorldManager] Async load failed: %s" % path)
			world_load_failed.emit(path)

# ── Sync load (editor / non-mobile) ───────────────────────────────────────────

func load_world(path: String, clear_entities: bool = true) -> void:
	if _loading: return
	_loading = true
	_unload_current(clear_entities)
	var packed : PackedScene = load(path)
	if packed == null:
		Log.error("[WorldManager] Failed to load: %s" % path)
		_loading = false
		world_load_failed.emit(path)
		return
	_instantiate_world(path, packed, clear_entities)

# ── Instantiation ──────────────────────────────────────────────────────────────

func _instantiate_world(path: String, packed: PackedScene,
		_clear_entities: bool) -> void:
	scene_root    = packed.instantiate()
	current_world = path
	var tree := get_tree()
	if tree == null:
		Log.error("[WorldManager] No SceneTree for: %s" % path)
		_loading = false
		world_load_failed.emit(path)
		return
	tree.root.add_child(scene_root)
	if tree.current_scene != scene_root:
		tree.current_scene = scene_root
	entity_map = SceneToEntityBridge.import_scene(scene_root)
	_loading   = false
	Bus.emit(&"scene_loaded", {"path": path})
	world_loaded.emit(path)
	Log.info("[WorldManager] World ready: %s (%d entities)" \
		% [path, entity_map.size()])

# ── Unload ─────────────────────────────────────────────────────────────────────

func unload_world(clear_entities: bool = true) -> void:
	_unload_current(clear_entities)

func _unload_current(clear_entities: bool) -> void:
	if scene_root != null and is_instance_valid(scene_root):
		Bus.emit(&"scene_unloaded", {"path": current_world})
		world_unloaded.emit(current_world)
		var tree := get_tree()
		if tree != null and tree.current_scene == scene_root:
			tree.current_scene = null
		scene_root.queue_free()
		scene_root = null
	if clear_entities:
		EntityManager.clear_all()
	entity_map    = {}
	current_world = ""

func reload_world() -> void:
	if current_world != "":
		load_world_async(current_world)

func is_loading() -> bool: return _loading

func get_entity_for_node(node: Node) -> int:
	return int(entity_map.get(node, -1))
