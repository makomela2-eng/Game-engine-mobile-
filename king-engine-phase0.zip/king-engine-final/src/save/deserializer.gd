## Deserializer — converts bytes back to engine data.
extends Node

func from_bytes(bytes: PackedByteArray) -> Dictionary:
	if bytes.is_empty():
		return {}
	var decompressed: PackedByteArray = bytes.decompress_dynamic(-1, FileAccess.COMPRESSION_ZSTD)
	var text: String = decompressed.get_string_from_utf8()
	var parsed: Variant = JSON.parse_string(text)
	if parsed is Dictionary:
		return parsed as Dictionary
	Log.error("[Deserializer] Failed to parse save data")
	return {}

func from_dict(data: Dictionary) -> Dictionary:
	return data.duplicate(true)
