## SaveFormat — defines the canonical structure of a KING save file.
## Use to validate loaded data and migrate old versions.
class_name SaveFormat

const VERSION := 1

## Validate a loaded save dictionary.
static func is_valid(data: Dictionary) -> bool:
	return data.has("version") and data.has("entities")

## Migrate save data from an older version to current.
static func migrate(data: Dictionary) -> Dictionary:
	var ver := int(data.get("version", 0))
	if ver == VERSION:
		return data
	# v0 → v1: no entities key → add empty
	if ver == 0:
		if not data.has("entities"):
			data["entities"] = {"version": 2, "entities": []}
		data["version"] = 1
	return data

## Return a blank valid save skeleton.
static func empty_save(slot: int = 0) -> Dictionary:
	return {
		"version":   VERSION,
		"slot":      slot,
		"timestamp": 0,
		"entities":  {"version": 2, "entities": []},
		"cfg":       {}
	}
