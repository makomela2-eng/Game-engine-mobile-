## SaveManager — save/load with versioning, migration, checksum, and cfg embedding.
##
## Format:
##   Binary: ZSTD-compressed JSON (via Serializer/Deserializer).
##   JSON field: "_checksum" (Adler-32 of the body for tamper detection).
##   Cfg is embedded so settings survive across saves.
##   SaveFormat.migrate() runs on load when version < current.
extends Node

const SAVE_DIR     := "user://saves/"
const SAVE_EXT     := ".king"
const SAVE_VERSION := 1

signal save_completed(slot: int)
signal load_completed(slot: int)
signal save_failed(slot: int, reason: String)
signal load_failed(slot: int, reason: String)

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)
	Bus.on(&"save.requested",      _on_save_requested)
	Bus.on(&"save.load_requested", _on_load_requested)

func _exit_tree() -> void:
	Bus.off(&"save.requested",      _on_save_requested)
	Bus.off(&"save.load_requested", _on_load_requested)

# ── Save ───────────────────────────────────────────────────────────────────────

func save(slot: int = 0) -> bool:
	var data := _collect_save_data(slot)
	## Embed checksum before serialization.
	var body_str : String = JSON.stringify(data)
	data["_checksum"] = _checksum(body_str)
	var bytes := Serializer.to_bytes(data)
	if bytes.is_empty():
		save_failed.emit(slot, "Serialization failed")
		return false
	var path := _slot_path(slot)
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		save_failed.emit(slot, "Cannot open: %s" % path)
		return false
	file.store_buffer(bytes)
	file.close()
	Bus.emit(&"save.completed", {"slot": slot})
	Bus.emit(&"game_saved",     BusEvents.GameSaved.new(slot))
	save_completed.emit(slot)
	Log.info("[SaveManager] Saved slot %d" % slot)
	return true

# ── Load ───────────────────────────────────────────────────────────────────────

func load_save(slot: int = 0) -> bool:
	var path := _slot_path(slot)
	if not FileAccess.file_exists(path):
		load_failed.emit(slot, "No save at slot %d" % slot)
		return false
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		load_failed.emit(slot, "Cannot open: %s" % path)
		return false
	var bytes := file.get_buffer(file.get_length())
	file.close()
	var data : Dictionary = Deserializer.from_bytes(bytes)
	if data.is_empty():
		load_failed.emit(slot, "Deserialization failed")
		return false
	## Checksum validation.
	if not _verify_checksum(data):
		Log.warn("[SaveManager] Checksum mismatch for slot %d — save may be corrupt" % slot)
	## Version migration.
	if not SaveFormat.is_valid(data):
		Log.warn("[SaveManager] Invalid save format at slot %d" % slot)
		load_failed.emit(slot, "Invalid save format")
		return false
	data = SaveFormat.migrate(data)
	_apply_save_data(data)
	Bus.emit(&"save.load_completed", {"slot": slot})
	Bus.emit(&"game_loaded",          BusEvents.GameLoaded.new(slot))
	load_completed.emit(slot)
	Log.info("[SaveManager] Loaded slot %d" % slot)
	return true

# ── Slot management ────────────────────────────────────────────────────────────

func delete_save(slot: int) -> void:
	var path := _slot_path(slot)
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)
		Bus.emit(&"save_deleted", {"slot": slot})

func save_exists(slot: int) -> bool:
	return FileAccess.file_exists(_slot_path(slot))

func list_saves() -> Array[int]:
	var result : Array[int] = []
	var dir : DirAccess = DirAccess.open(SAVE_DIR)
	if dir == null: return result
	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if entry.ends_with(SAVE_EXT):
			result.append(entry.get_basename().to_int())
		entry = dir.get_next()
	return result

## Returns metadata (timestamp, version) without deserializing the full save.
func slot_info(slot: int) -> Dictionary:
	if not save_exists(slot):
		return {"slot": slot, "empty": true}
	var file := FileAccess.open(_slot_path(slot), FileAccess.READ)
	if file == null: return {"slot": slot, "empty": true}
	var bytes := file.get_buffer(file.get_length())
	file.close()
	var data : Dictionary = Deserializer.from_bytes(bytes)
	return {
		"slot":      slot,
		"empty":     false,
		"version":   int(data.get("version", 0)),
		"timestamp": int(data.get("timestamp", 0)),
		"valid":     SaveFormat.is_valid(data),
	}

# ── Internal ───────────────────────────────────────────────────────────────────

func _slot_path(slot: int) -> String:
	return SAVE_DIR + str(slot) + SAVE_EXT

func _collect_save_data(slot: int) -> Dictionary:
	return {
		"version":   SAVE_VERSION,
		"slot":      slot,
		"timestamp": Time.get_unix_time_from_system(),
		"entities":  EntityManager.snapshot(),
		"cfg":       Cfg.export_all(),
	}

func _apply_save_data(data: Dictionary) -> void:
	## Restore entities.
	var entities := data.get("entities", {}) as Dictionary
	if not entities.is_empty():
		EntityManager.restore_snapshot(entities)
	## Restore cfg settings embedded in save.
	var cfg_data := data.get("cfg", {}) as Dictionary
	if not cfg_data.is_empty():
		Cfg.import_all(cfg_data)

func _checksum(body: String) -> int:
	## Simple Adler-32 — fast, detects corruption without full hash.
	var a : int = 1
	var b : int = 0
	for i in body.length():
		a = (a + body.unicode_at(i)) % 65521
		b = (b + a) % 65521
	return (b << 16) | a

func _verify_checksum(data: Dictionary) -> bool:
	if not data.has("_checksum"): return true   ## Old saves without checksum pass.
	var saved := int(data.get("_checksum", 0))
	var copy  := data.duplicate()
	copy.erase("_checksum")
	return saved == _checksum(JSON.stringify(copy))

func _on_save_requested(data: Variant) -> void:
	save(int((data as Dictionary).get("slot", 0)) if data is Dictionary else 0)

func _on_load_requested(data: Variant) -> void:
	load_save(int((data as Dictionary).get("slot", 0)) if data is Dictionary else 0)
