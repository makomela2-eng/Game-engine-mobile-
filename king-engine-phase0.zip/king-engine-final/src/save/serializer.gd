## Serializer — converts engine data to bytes for save files.
extends Node

## Serialize a Dictionary to compressed JSON bytes.
func to_bytes(data: Dictionary) -> PackedByteArray:
	var json  := JSON.stringify(data)
	if json.is_empty():
		return PackedByteArray()
	return json.to_utf8_buffer().compress(FileAccess.COMPRESSION_ZSTD)

## Serialize to a plain Dictionary (for network or debug use).
func to_dict(data: Dictionary) -> Dictionary:
	return data.duplicate(true)

## Serialize a single component to a Dictionary.
func component_to_dict(type: StringName, comp: Component) -> Dictionary:
	var result : Dictionary = {"type": str(type)}
	if comp.has_method("serialize"):
		var s: Variant = comp.call("serialize")
		if s is Dictionary:
			result.merge(s)
	return result
