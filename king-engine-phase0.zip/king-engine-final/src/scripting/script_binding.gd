## ScriptBinding — exposes engine APIs to script instances safely.
## Script instances receive a binding object, not raw autoload access.
## Prevents mods from accessing restricted systems.
class_name ScriptBinding
extends RefCounted

var entity : int = -1

func _init(e: int) -> void:
	entity = e

# ── Safe entity API ────────────────────────────────────────────────────────────

func get_component(type: StringName) -> Component:
	return EntityManager.get_component(entity, type)

func has_component(type: StringName) -> bool:
	return EntityManager.has_component(entity, type)

func add_tag(tag: StringName) -> void:
	Commands.add_tag(entity, tag)

func remove_tag(tag: StringName) -> void:
	Commands.remove_tag(entity, tag)

func has_tag(tag: StringName) -> bool:
	return EntityManager.has_tag(entity, tag)

# ── Safe event API ─────────────────────────────────────────────────────────────

func emit(event: StringName, data: Dictionary = {}) -> void:
	data["entity"] = entity
	Bus.emit(event, data)

func listen(event: StringName, fn: Callable) -> void:
	Bus.on(event, fn)

func unlisten(event: StringName, fn: Callable) -> void:
	Bus.off(event, fn)

# ── Safe data API ──────────────────────────────────────────────────────────────

func get_data(table: StringName, id: StringName) -> Dictionary:
	return DataRegistry.get_entry(table, id)

func play_sound(id: StringName) -> void:
	AudioManager.play(id)

func log(msg: String) -> void:
	Log.info("[Script e%d] %s" % [entity, msg])
