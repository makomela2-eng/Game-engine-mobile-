## ScriptLoader — loads and caches GDScripts for ScriptRuntime.
extends Node

var _cache : Dictionary = {}  ## path → GDScript

func load_script(path: String) -> GDScript:
	if _cache.has(path):
		return _cache[path]
	var res: Resource = load(path)
	if not res is GDScript:
		Log.error("[ScriptLoader] Not a GDScript: %s" % path)
		return null
	_cache[path] = res as GDScript
	return _cache[path]

func reload_script(path: String) -> GDScript:
	_cache.erase(path)
	return load_script(path)

func instantiate(path: String) -> Object:
	var script := load_script(path)
	if script == null:
		return null
	return script.new()

func has_script(path: String) -> bool:
	return _cache.has(path)

func release(path: String) -> void:
	_cache.erase(path)

func cached_count() -> int:
	return _cache.size()
