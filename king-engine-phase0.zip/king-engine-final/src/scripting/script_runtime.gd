## ScriptRuntime — instantiates ScriptComponent scripts, feeds them a ScriptBinding,
## and drives their tick() lifecycle.
##
## Each script instance receives a ScriptBinding scoped to its entity, not
## raw autoload access. This sandboxes scripts and prevents unsafe cross-entity ops.
extends SystemBase

var _instances : Dictionary = {}   ## entity_id → Object

func _on_start() -> void:
	priority = 2900
	listen(&"ecs.entity_destroyed",  _on_entity_destroyed)
	listen(&"ecs.component_removed", _on_component_removed)

func _on_stop() -> void:
	unlisten(&"ecs.entity_destroyed",  _on_entity_destroyed)
	unlisten(&"ecs.component_removed", _on_component_removed)

func tick(delta: float) -> void:
	## Use QuerySystem cache instead of raw query.
	for id : int in QuerySystem.query([&"Script"]):
		var sc := EntityManager.get_component(id, &"Script") as ScriptComponent
		if sc == null: continue
		if sc.instance == null:
			_instantiate(id, sc)
		elif sc.instance.has_method("tick"):
			sc.instance.call("tick", delta)

func _instantiate(entity: int, sc: ScriptComponent) -> void:
	var script := ScriptLoader.load_script(sc.script_path)
	if script == null: return
	var instance : Object = script.new()
	## Pass a ScriptBinding so the script gets a safe entity-scoped API.
	var binding := ScriptBinding.new(entity)
	if instance.has_method("init_entity"):
		instance.call("init_entity", entity, sc.properties, binding)
	elif instance.has_method("_init_binding"):
		instance.call("_init_binding", binding)
	sc.instance = instance
	_instances[entity] = instance
	if instance.has_method("on_start"):
		instance.call("on_start")
	Log.debug("[ScriptRuntime] Instantiated script for e%d: %s" % [entity, sc.script_path])

func get_instance(entity: int) -> Object:
	return _instances.get(entity, null)

func send_message(entity: int, message: StringName, args: Array = []) -> Variant:
	var inst : Variant = get_instance(entity)
	if inst != null and inst.has_method(str(message)):
		return inst.callv(str(message), args)
	return null

func _destroy_instance(entity: int) -> void:
	if not _instances.has(entity): return
	var inst : Variant = _instances[entity]
	if inst.has_method("on_stop"):
		inst.call("on_stop")
	_instances.erase(entity)
	var sc := EntityManager.get_component(entity, &"Script") as ScriptComponent
	if sc: sc.instance = null

func _on_entity_destroyed(data: Variant) -> void:
	if data is Dictionary:
		_destroy_instance(int((data as Dictionary).get("entity", -1)))

func _on_component_removed(data: Variant) -> void:
	if not data is Dictionary: return
	var d := data as Dictionary
	if StringName(str((d.get("data", {}) as Dictionary).get("type", ""))) == &"Script":
		_destroy_instance(int(d.get("entity", -1)))
