## AudioDSPSystem — music states, SFX pool, reverb, and EQ via AudioServer.
##
## SFX pool: 16 slots. Steal policy: lowest-priority slot, not oldest.
## This guarantees high-priority sounds (UI feedback, gunshots) survive
## even when the pool is full of lower-priority ambient effects.
##
## 3D spatial params: every AudioStreamPlayer3D created by play_sfx_3d()
## explicitly sets unit_size, max_distance, and attenuation_model.
## Godot defaults are inconsistent across platforms — never rely on them.
extends Node

const SFX_POOL_SIZE := 16

var _music_player  : AudioStreamPlayer = null
var _music_state   : StringName = &""
var _sfx_pool      : Array[AudioStreamPlayer]  = []
var _sfx_library   : Dictionary = {}   ## StringName → AudioStream
## Per-slot priority (0=lowest, 10=highest).
var _sfx_priority  : Array[int]  = []
var _sfx_play_time : Array[int]  = []

## Default 3D audio settings — set these at boot to match your game's scale.
var default_unit_size        : float = 1.0
var default_max_distance     : float = 40.0
var default_attenuation_model: int   = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE

func _ready() -> void:
	_music_player     = AudioStreamPlayer.new()
	_music_player.bus = "Music"
	add_child(_music_player)
	for i in SFX_POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_sfx_pool.append(p)
		_sfx_priority.append(0)
		_sfx_play_time.append(0)
	Bus.on(&"audio_play_sfx",    _on_play_sfx)
	Bus.on(&"audio_music_state", _on_music_state)
	Bus.on(&"app_background",    _on_background)
	Bus.on(&"app_foreground",    _on_foreground)

func _exit_tree() -> void:
	Bus.off(&"audio_play_sfx",    _on_play_sfx)
	Bus.off(&"audio_music_state", _on_music_state)
	Bus.off(&"app_background",    _on_background)
	Bus.off(&"app_foreground",    _on_foreground)

# ── SFX library ────────────────────────────────────────────────────────────────

func register_sfx(id: StringName, stream: AudioStream) -> void:
	_sfx_library[id] = stream

func get_sfx(id: StringName) -> AudioStream:
	return _sfx_library.get(id, null)

# ── 2D SFX playback ───────────────────────────────────────────────────────────

## Play a 2D (non-spatial) sound. sound = AudioStream or StringName cue id.
func play_sfx(sound: Variant, volume_db: float = 0.0,
		pitch_scale: float = 1.0, priority: int = 5) -> void:
	var stream := _resolve_stream(sound)
	if stream == null: return
	var idx := _get_sfx_slot(priority)
	_sfx_pool[idx].stream      = stream
	_sfx_pool[idx].volume_db   = volume_db
	_sfx_pool[idx].pitch_scale = pitch_scale
	_sfx_pool[idx].play()
	_sfx_priority[idx]  = priority
	_sfx_play_time[idx] = Time.get_ticks_msec()

## Play a 3D spatial sound at a world position.
## Explicitly sets unit_size, max_distance, and attenuation_model —
## never relies on Godot defaults (inconsistent per platform).
func play_sfx_3d(sound: Variant, position: Vector3,
		volume_db: float = 0.0,
		priority: int = 5,
		max_dist: float = -1.0) -> void:
	var stream := _resolve_stream(sound)
	if stream == null: return
	var p3 := AudioStreamPlayer3D.new()
	p3.stream             = stream
	p3.volume_db          = volume_db
	p3.unit_size          = default_unit_size
	p3.max_distance       = max_dist if max_dist > 0.0 else default_max_distance
	p3.attenuation_model  = default_attenuation_model
	p3.global_position    = position
	p3.autoplay           = true
	add_child(p3)
	## Auto-free when done.
	p3.finished.connect(p3.queue_free)

func _resolve_stream(sound: Variant) -> AudioStream:
	if sound is AudioStream: return sound as AudioStream
	if sound is StringName:
		var s := _sfx_library.get(sound as StringName, null) as AudioStream
		if s: return s
		return ResourceManager.get_audio(sound as StringName)
	return null

## Get a free pool slot, or steal the LOWEST priority slot.
func _get_sfx_slot(incoming_priority: int) -> int:
	## Find first idle slot.
	for i in range(_sfx_pool.size()):
		if not _sfx_pool[i].playing:
			return i
	## All busy — steal lowest-priority playing slot.
	var steal_idx := 0
	var steal_pri : int = _sfx_priority[0]
	for i in range(1, _sfx_pool.size()):
		if _sfx_priority[i] < steal_pri:
			steal_pri = _sfx_priority[i]
			steal_idx = i
	## Only steal if the incoming sound is higher priority.
	if incoming_priority >= steal_pri:
		_sfx_pool[steal_idx].stop()
		return steal_idx
	## All playing sounds have equal or higher priority — return slot 0
	## (least harmful sacrifice).
	_sfx_pool[0].stop()
	return 0

# ── Music ──────────────────────────────────────────────────────────────────────

func play_music(stream: AudioStream, fade_in: float = 0.8) -> void:
	if stream == null: return
	_music_player.stream    = stream
	_music_player.volume_db = -80.0
	_music_player.play()
	var tree := get_tree()
	if tree:
		tree.create_tween().tween_property(_music_player, "volume_db", 0.0, fade_in)
	else:
		_music_player.volume_db = 0.0

func stop_music(fade_out: float = 0.8) -> void:
	var tree := get_tree()
	if tree == null: _music_player.stop(); return
	var t : Tween = tree.create_tween()
	t.tween_property(_music_player, "volume_db", -80.0, fade_out)
	t.tween_callback(_music_player.stop)

func set_music_state(state: StringName) -> void:
	if state == _music_state: return
	_music_state = state
	Bus.emit(&"music_state_changed", BusEvents.MusicStateChanged.new(state))

func get_music_state() -> StringName: return _music_state

func set_music_volume(db: float, tween_sec: float = 0.0) -> void:
	if tween_sec > 0.0 and get_tree():
		get_tree().create_tween().tween_property(_music_player, "volume_db", db, tween_sec)
	else:
		_music_player.volume_db = db

# ── Effects ────────────────────────────────────────────────────────────────────

func set_reverb(enable: bool, room_size: float = 0.5,
		damping: float = 0.5, bus: StringName = &"SFX") -> void:
	var idx := AudioServer.get_bus_index(str(bus))
	if idx < 0: return
	for i in AudioServer.get_bus_effect_count(idx):
		var fx : AudioEffect = AudioServer.get_bus_effect(idx, i)
		if fx is AudioEffectReverb:
			var r := fx as AudioEffectReverb
			r.room_size = room_size
			r.damping   = damping
			AudioServer.set_bus_effect_enabled(idx, i, enable)
			return
	if enable:
		var reverb      := AudioEffectReverb.new()
		reverb.room_size = room_size
		reverb.damping   = damping
		AudioServer.add_bus_effect(idx, reverb)

func set_eq_gain(band: int, gain_db: float,
		bus: StringName = &"Master") -> void:
	var idx := AudioServer.get_bus_index(str(bus))
	if idx < 0: return
	for i in AudioServer.get_bus_effect_count(idx):
		var fx : AudioEffect = AudioServer.get_bus_effect(idx, i)
		if fx is AudioEffectEQ:
			(fx as AudioEffectEQ).set_band_gain_db(band, gain_db)
			return

# ── Bus listeners ──────────────────────────────────────────────────────────────

func _on_play_sfx(d: Variant) -> void:
	if d is Dictionary:
		var dd := d as Dictionary
		play_sfx(dd.get("id", dd.get("stream", null)),
			float(dd.get("volume_db", 0.0)),
			float(dd.get("pitch",     1.0)),
			int(dd.get("priority",    5)))
	else:
		play_sfx(d)

func _on_music_state(d: Variant) -> void:
	set_music_state(StringName(str(d)))

func _on_background(_d: Variant) -> void:
	_music_player.stream_paused = true

func _on_foreground(_d: Variant) -> void:
	_music_player.stream_paused = false
