## Clock — frame-time and elapsed tracking, synchronized with GameLoop pause state.
extends Node

var elapsed   : float = 0.0
var delta     : float = 0.0
var real_elapsed : float = 0.0   ## wall-clock elapsed (never paused)
var time_scale : float = 1.0
var _paused   : bool  = false

func _ready() -> void:
	set_process(true)
	Bus.on(&"game.paused",  func(_d: Variant) -> void: pause())
	Bus.on(&"game.resumed", func(_d: Variant) -> void: resume())

func _exit_tree() -> void:
	Bus.off(&"game.paused",  func(_d: Variant) -> void: pause())
	Bus.off(&"game.resumed", func(_d: Variant) -> void: resume())

func _process(d: float) -> void:
	real_elapsed += d
	if _paused: return
	delta         = d * time_scale
	elapsed      += delta

func pause()  -> void: _paused = true
func resume() -> void: _paused = false
func is_paused() -> bool: return _paused

func set_time_scale(scale: float) -> void:
	time_scale = clampf(scale, 0.0, 10.0)

## Formatted elapsed time as MM:SS.
func elapsed_formatted() -> String:
	var total := int(elapsed)
	return "%02d:%02d" % [total / 60, total % 60]

## Time since epoch in seconds (real world clock, for timestamps).
func unix_time() -> float:
	return Time.get_unix_time_from_system()
