## IAPSystem — in-app purchase abstraction layer.
##
## Architecture: plugin-agnostic backend pattern.
##   IAPSystem owns the public API and state machine.
##   A backend object handles the actual store calls.
##   Register a backend at boot (e.g. from an Android/iOS autoload):
##
##     IAPSystem.register_backend(MyAndroidIAP.new())
##
##   Backend contract (duck-typed — no forced base class):
##     func purchase(sku: String) -> void
##     func restore()             -> void
##     func query_products(skus: Array[String]) -> void  ## optional
##
##   Backend calls IAPSystem back via:
##     IAPSystem.on_purchase_success(sku, payload)
##     IAPSystem.on_purchase_failed(sku, reason)
##     IAPSystem.on_restore_complete(skus)
##     IAPSystem.on_products_received(products)
##
## Bus events emitted:
##   iap_result      → { sku, success, reason?, payload? }
##   iap_restored    → { skus: Array[String] }
##   iap_products    → { products: Array[Dictionary] }
##
## Listens:
##   iap_purchase    → { sku: String }
##   iap_restore     → (any)
##   iap_query       → { skus: Array[String] }
extends Node

# ── State ──────────────────────────────────────────────────────────────────────

var _backend    : Variant  = null  ## registered backend object
var _pending    : Dictionary = {}  ## sku → { requested_at_ms }
var _products   : Dictionary = {}  ## sku → product Dictionary from store

## Owned skus confirmed purchased this session (not persisted — use SaveManager).
var owned_skus  : Array[String] = []

# ── Boot ───────────────────────────────────────────────────────────────────────

func _ready() -> void:
	Bus.on(&"iap_purchase", _on_purchase_request)
	Bus.on(&"iap_restore",  _on_restore_request)
	Bus.on(&"iap_query",    _on_query_request)
	Log.info("[IAPSystem] ready — backend: %s" % ("none" if _backend == null else str(_backend)))

func _exit_tree() -> void:
	Bus.off(&"iap_purchase", _on_purchase_request)
	Bus.off(&"iap_restore",  _on_restore_request)
	Bus.off(&"iap_query",    _on_query_request)
	_pending.clear()

# ── Backend registration ───────────────────────────────────────────────────────

## Call this once at boot from your platform-specific autoload.
## e.g. IAPSystem.register_backend(GodotGooglePlayBillingAdapter.new())
func register_backend(backend: Variant) -> void:
	_backend = backend
	Log.info("[IAPSystem] backend registered: %s" % str(backend))

func has_backend() -> bool:
	return _backend != null

# ── Public API ─────────────────────────────────────────────────────────────────

func can_purchase() -> bool:
	return _backend != null and (OS.has_feature("android") or OS.has_feature("ios"))

func purchase(sku: String) -> void:
	if sku.is_empty():
		_emit_result({"success": false, "reason": "missing_sku"})
		return
	if _pending.has(sku):
		Log.warn("[IAPSystem] Purchase already pending: %s" % sku)
		return
	if not can_purchase():
		Log.warn("[IAPSystem] No backend or unsupported platform: %s" % sku)
		_emit_result({"sku": sku, "success": false, "reason": "no_backend"})
		return
	_pending[sku] = {"requested_at_ms": Time.get_ticks_msec()}
	Log.info("[IAPSystem] Purchasing: %s" % sku)
	_backend.purchase(sku)

func restore() -> void:
	if not can_purchase():
		_emit_result({"restore": true, "success": false, "reason": "no_backend"})
		return
	Log.info("[IAPSystem] Restore requested")
	_backend.restore()

func query_products(skus: Array[String]) -> void:
	if _backend == null or not _backend.has_method("query_products"):
		return
	_backend.query_products(skus)

func is_owned(sku: String) -> bool:
	return owned_skus.has(sku)

func get_product(sku: String) -> Dictionary:
	return _products.get(sku, {})

# ── Backend callbacks ─────────────────────────────────────────────────────────

## Call from backend on successful purchase.
func on_purchase_success(sku: String, payload: Dictionary = {}) -> void:
	_pending.erase(sku)
	if not owned_skus.has(sku):
		owned_skus.append(sku)
	Log.info("[IAPSystem] Purchase success: %s" % sku)
	_emit_result({"sku": sku, "success": true, "payload": payload})

## Call from backend on failed or cancelled purchase.
func on_purchase_failed(sku: String, reason: String = "unknown") -> void:
	_pending.erase(sku)
	Log.warn("[IAPSystem] Purchase failed: %s — %s" % [sku, reason])
	_emit_result({"sku": sku, "success": false, "reason": reason})

## Call from backend after restore completes.
func on_restore_complete(skus: Array[String]) -> void:
	for sku in skus:
		if not owned_skus.has(sku):
			owned_skus.append(sku)
	Log.info("[IAPSystem] Restored %d SKUs" % skus.size())
	Bus.emit(&"iap_restored", {"skus": skus})

## Call from backend when product info arrives.
func on_products_received(products: Array[Dictionary]) -> void:
	for p : Dictionary in products:
		var sku := str(p.get("sku", ""))
		if not sku.is_empty():
			_products[sku] = p
	Bus.emit(&"iap_products", {"products": products})

# ── Bus listeners ──────────────────────────────────────────────────────────────

func _on_purchase_request(data: Variant) -> void:
	if not data is Dictionary: return
	purchase(str((data as Dictionary).get("sku", "")))

func _on_restore_request(_data: Variant) -> void:
	restore()

func _on_query_request(data: Variant) -> void:
	if not data is Dictionary: return
	var skus_var : Variant = (data as Dictionary).get("skus", [])
	if skus_var is Array:
		var skus : Array[String] = []
		for s in (skus_var as Array):
			skus.append(str(s))
		query_products(skus)

# ── Internal ───────────────────────────────────────────────────────────────────

func _emit_result(payload: Dictionary) -> void:
	Bus.emit(&"iap_result", payload)
