## Jobs — lightweight async job queue.
##
## Thin facade over JobSystem (which uses a binary heap).
## Use this autoload for fire-and-forget deferred work from anywhere.
## For callbacks and cancellation, use JobSystem directly.
extends Node

func push(id: StringName, fn: Callable, priority: int = 0) -> void:
	JobSystem.enqueue(fn, priority, id)

func push_batch(fns: Array[Callable], priority: int = 0) -> void:
	JobSystem.enqueue_batch(fns, priority)

func cancel(id: StringName) -> int:
	return JobSystem.cancel_by_label(id)

func set_budget(ms: float) -> void:
	JobSystem.set_budget(ms)

func pending_count() -> int:
	return JobSystem.pending_count()

func clear() -> void:
	JobSystem.cancel_all()
