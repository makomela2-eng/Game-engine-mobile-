## LocalizationSystem — CSV-based localization with fallback chain.
## Listens to set_locale on Bus. Emits locale_changed.
## Also listens to engine_ready to complete post-boot locale setup.
extends Node

signal locale_changed(locale: String)

const FALLBACK := "en"
var _locale  : String = "en"
var _strings : Dictionary = {}

var _cb_set_locale : Callable
var _cb_engine_ready : Callable

func _ready() -> void:
	var saved : Variant = Cfg.get_val("i18n", "locale", null)
	if saved is String:
		_locale = saved as String
	else:
		var os_locale: String = OS.get_locale().substr(0, 2)
		if os_locale.length() == 2:
			_locale = os_locale
	_scan("res://locales/")
	TranslationServer.set_locale(_locale)
	_cb_set_locale = func(d: Variant) -> void: set_locale(str(d))
	_cb_engine_ready = func(_d: Variant) -> void:
		Log.info("[i18n] locale: %s" % _locale)
	Bus.on(&"set_locale",    _cb_set_locale)
	Bus.on(&"engine_ready",  _cb_engine_ready)

func _exit_tree() -> void:
	if _cb_set_locale.is_valid():
		Bus.off(&"set_locale", _cb_set_locale)
	if _cb_engine_ready.is_valid():
		Bus.off(&"engine_ready", _cb_engine_ready)

func set_locale(locale: String) -> void:
	_locale = locale
	TranslationServer.set_locale(locale)
	Cfg.set_val("i18n", "locale", locale)
	locale_changed.emit(locale)
	Bus.emit(&"locale_changed", locale)

func translate(key: String, vars: Dictionary = {}) -> String:
	var text: String = _lookup(key, _locale)
	if text.is_empty() and _locale != FALLBACK:
		text = _lookup(key, FALLBACK)
	if text.is_empty():
		return key
	for k: Variant in vars:
		text = text.replace("{%s}" % str(k), str(vars[k]))
	return text

func _lookup(key: String, locale: String) -> String:
	var loc_var: Variant = _strings.get(locale)
	if not loc_var is Dictionary: return ""
	return str((loc_var as Dictionary).get(key, ""))

func load_csv(path: String) -> void:
	if not FileAccess.file_exists(path): return
	var f: FileAccess = FileAccess.open(path, FileAccess.READ)
	if not f: return
	var header: PackedStringArray = f.get_csv_line()
	if header.size() < 2: return
	var locale_cols: Array[String] = []
	for i: int in range(1, header.size()):
		locale_cols.append(header[i].strip_edges())
	while not f.eof_reached():
		var row: PackedStringArray = f.get_csv_line()
		if row.size() < 2 or row[0].is_empty(): continue
		var tr_key: String = row[0]
		for i: int in range(locale_cols.size()):
			if i + 1 >= row.size(): continue
			var loc: String = locale_cols[i]
			if loc.is_empty(): continue
			if not _strings.has(loc):
				_strings[loc] = {}
			(_strings[loc] as Dictionary)[tr_key] = row[i + 1]

func _scan(dir_path: String) -> void:
	var d: DirAccess = DirAccess.open(dir_path)
	if not d: return
	d.list_dir_begin()
	while true:
		var fname: String = d.get_next()
		if fname == "": break
		if fname.ends_with(".csv"):
			load_csv(dir_path + fname)
	d.list_dir_end()

func get_locale() -> String: return _locale
