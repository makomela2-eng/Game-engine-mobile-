## MultiplayerSystem — high-level multiplayer session management.
## Listens to net.* events from NetworkManager.
## Emits peer_connected, multiplayer_stopped on Bus.
##
## Identity mapping: peer_id (Godot network ID) ≠ entity_id (ECS ID).
## Use register_peer_entity / get_entity_for_peer / get_peer_for_entity
## to translate. Without this mapping, systems that receive a peer ID from
## the network layer have no safe way to find the correct ECS entity.
extends Node

var _peers: Array[int] = []
## peer_id -> entity_id  (populated by spawn logic after peer connects)
var _peer_to_entity: Dictionary = {}
## entity_id -> peer_id  (reverse lookup)
var _entity_to_peer: Dictionary = {}

func _ready() -> void:
	Bus.on(&"net.connected", _on_peer_connected)
	Bus.on(&"net.disconnected", _on_peer_disconnected)
	Bus.on(&"net.state_changed", _on_state_changed)
	Bus.on(&"app_quit", _on_quit)
	Bus.on(&"ecs.entity_destroyed", _on_entity_destroyed)

func _exit_tree() -> void:
	Bus.off(&"net.connected", _on_peer_connected)
	Bus.off(&"net.disconnected", _on_peer_disconnected)
	Bus.off(&"net.state_changed", _on_state_changed)
	Bus.off(&"app_quit", _on_quit)
	Bus.off(&"ecs.entity_destroyed", _on_entity_destroyed)

# ── Peer ↔ Entity mapping ─────────────────────────────────────────────────────

func register_peer_entity(peer_id: int, entity_id: int) -> void:
	if peer_id <= 0 or entity_id < 0:
		return
	_peer_to_entity[peer_id] = entity_id
	_entity_to_peer[entity_id] = peer_id

func unregister_peer(peer_id: int) -> void:
	if _peer_to_entity.has(peer_id):
		var entity := int(_peer_to_entity[peer_id])
		_entity_to_peer.erase(entity)
	_peer_to_entity.erase(peer_id)

func get_entity_for_peer(peer_id: int) -> int:
	return int(_peer_to_entity.get(peer_id, -1))

func get_peer_for_entity(entity_id: int) -> int:
	return int(_entity_to_peer.get(entity_id, -1))

func is_local_player(entity_id: int) -> bool:
	var peer := get_peer_for_entity(entity_id)
	return peer > 0 and peer == multiplayer.get_unique_id()

func get_peers() -> Array[int]:
	return _peers.duplicate()

func peer_count() -> int:
	return _peers.size()

# ── Net events ────────────────────────────────────────────────────────────────

func _on_peer_connected(data: Variant) -> void:
	if not data is Dictionary:
		return
	var id := int((data as Dictionary).get("peer", 0))
	if id > 0 and not _peers.has(id):
		_peers.append(id)
	Bus.emit(&"peer_connected", {"peer": id})

func _on_peer_disconnected(data: Variant) -> void:
	if not data is Dictionary:
		return
	var id := int((data as Dictionary).get("peer", 0))
	_peers.erase(id)
	unregister_peer(id)
	Bus.emit(&"peer_disconnected", {"peer": id})

func _on_state_changed(data: Variant) -> void:
	if not data is Dictionary:
		return
	var state := int((data as Dictionary).get("state", -1))
	match state:
		0:
			_peers.clear()
			_peer_to_entity.clear()
			_entity_to_peer.clear()
			Bus.emit(&"multiplayer_stopped", {})
		_:
			if NetworkManager.has_method("get_peers"):
				var fresh: Array[int] = NetworkManager.get_peers()
				_peers = fresh.duplicate()
			Bus.emit(&"multiplayer_state_changed", {"state": state})

func _on_quit(_data: Variant) -> void:
	if NetworkManager.has_method("disconnect_all"):
		NetworkManager.disconnect_all()
	Bus.emit(&"multiplayer_stopped", {})

func _on_entity_destroyed(data: Variant) -> void:
	if not data is Dictionary:
		return
	var entity := int((data as Dictionary).get("entity", -1))
	if _entity_to_peer.has(entity):
		var peer := int(_entity_to_peer[entity])
		_peer_to_entity.erase(peer)
		_entity_to_peer.erase(entity)
