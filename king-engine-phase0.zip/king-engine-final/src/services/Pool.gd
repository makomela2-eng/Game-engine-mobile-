## Pool — generic object pool. Reduces allocation pressure on mobile.
extends Node

var _pools : Dictionary = {}  # StringName -> Array

func acquire(pool_id: StringName, factory: Callable) -> Variant:
	if _pools.has(pool_id) and not (_pools[pool_id] as Array).is_empty():
		return (_pools[pool_id] as Array).pop_back()
	return factory.call() if factory.is_valid() else null

func release(pool_id: StringName, obj: Variant) -> void:
	if obj == null:
		return
	if not _pools.has(pool_id):
		_pools[pool_id] = []
	(_pools[pool_id] as Array).append(obj)

func clear(pool_id: StringName) -> void:
	_pools.erase(pool_id)

func clear_all() -> void:
	_pools.clear()

func has(pool_id: StringName) -> bool:
	return _pools.has(pool_id)

func count(pool_id: StringName) -> int:
	return (_pools.get(pool_id, []) as Array).size()
