## Registry — global named object store.
## Any system can register itself and others can find it by name.
extends Node

var _store : Dictionary = {}  # StringName -> Variant

func register(id: StringName, obj: Variant) -> void:
	_store[id] = obj
	Log.debug("[Registry] registered: " + str(id))

func unregister(id: StringName) -> void:
	_store.erase(id)

func get_obj(id: StringName) -> Variant:
	return _store.get(id, null)

func has(id: StringName) -> bool:
	return _store.has(id)

func all_ids() -> Array:
	return _store.keys()

func clear() -> void:
	_store.clear()

func count() -> int:
	return _store.size()
