## StateMachine — reusable hierarchical state machine.
## Create one per actor/system that needs state management.
## Usage:
##   var sm := StateMachine.create()
##   sm.add_state(&"idle",   _on_idle_enter,   _on_idle_exit,   _on_idle_update)
##   sm.transition(&"idle")
extends Node

class State:
	var id     : StringName
	var enter  : Callable  # fn() -> void
	var exit   : Callable  # fn() -> void
	var on_update : Callable  # fn(delta) -> void

class Instance:
	var _states  : Dictionary = {}  # StringName -> State
	var _current : StringName = &""
	var _prev    : StringName = &""

	func add_state(id: StringName,
			enter:  Callable = Callable(),
			exit:   Callable = Callable(),
			update: Callable = Callable()) -> void:
		var s: State = State.new()
		s.id     = id
		s.enter  = enter
		s.exit   = exit
		s.on_update = update
		_states[id] = s

	func transition(id: StringName) -> void:
		if not _states.has(id):
			Log.warn("[StateMachine] unknown state: " + str(id))
			return
		if _current != &"":
			var cur : State = _states[_current]
			if cur.exit.is_valid(): cur.exit.call()
		_prev    = _current
		_current = id
		var next : State = _states[id]
		if next.enter.is_valid(): next.enter.call()

	func tick(delta: float) -> void:
		if _current == &"": return
		var cur : State = _states.get(_current)
		if cur and cur.on_update.is_valid(): cur.on_update.call(delta)

	func current() -> StringName: return _current
	func previous() -> StringName: return _prev
	func is_in(id: StringName) -> bool: return _current == id

## Factory — call StateMachine.create() to get a new Instance.
## Return type omitted: GDScript 4.6 cannot name inner classes as static return types.
static func create():
	return Instance.new()
