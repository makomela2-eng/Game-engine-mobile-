## UIStack — manages screen/modal stack with push/pop transitions.
## Listens to ui_push, ui_pop, ui_clear on Bus.
## Emits ui_pushed, ui_popped on Bus.
## Also listens to gameplay.entity_died to show death screen.
## And app_background to pause/resume top screen.
extends CanvasLayer

signal screen_pushed(id: StringName)
signal screen_popped(id: StringName)

class UIStackEntry:
	var id   : StringName
	var node : Control
	func _init(i: StringName, n: Control) -> void:
		id = i; node = n

var _scenes : Dictionary = {}
var _stack  : Array[UIStackEntry] = []

var _cb_push  : Callable
var _cb_pop   : Callable
var _cb_clear : Callable
var _cb_died  : Callable

func _ready() -> void:
	layer = 10
	_cb_push = func(d: Variant) -> void:
		if d is BusEvents.UIPushed:
			push((d as BusEvents.UIPushed).id)
		elif d is StringName:
			push(d as StringName)
		elif d is String:
			push(StringName(d as String))
	_cb_pop   = func(_d: Variant) -> void: pop()
	_cb_clear = func(_d: Variant) -> void: clear()
	_cb_died  = func(data: Variant) -> void:
		if data is Dictionary:
			var entity := int((data as Dictionary).get("entity", -1))
			if EntityManager.has_tag(entity, &"player"):
				push(&"death_screen")
	Bus.on(&"ui_push",              _cb_push)
	Bus.on(&"ui_pop",               _cb_pop)
	Bus.on(&"ui_clear",             _cb_clear)
	Bus.on(&"gameplay.entity_died", _cb_died)

func _exit_tree() -> void:
	if _cb_push.is_valid():  Bus.off(&"ui_push",              _cb_push)
	if _cb_pop.is_valid():   Bus.off(&"ui_pop",               _cb_pop)
	if _cb_clear.is_valid(): Bus.off(&"ui_clear",             _cb_clear)
	if _cb_died.is_valid():  Bus.off(&"gameplay.entity_died", _cb_died)

func register(id: StringName, scene: PackedScene) -> void:
	_scenes[id] = scene

func has_screen(id: StringName) -> bool:
	return _scenes.has(id)

func push(id: StringName, data: Dictionary = {}) -> Control:
	var scene_var : Variant = _scenes.get(id)
	if not scene_var is PackedScene:
		Log.warn("[UIStack] unknown screen: " + str(id))
		return null
	var screen : Control = (scene_var as PackedScene).instantiate() as Control
	if screen == null:
		return null
	screen.set_anchors_preset(Control.PRESET_FULL_RECT)
	if screen.has_method("set_data"):
		screen.call("set_data", data)
	add_child(screen)
	_stack.append(UIStackEntry.new(id, screen))
	_animate_in(screen)
	if TouchInput.is_instance_valid(TouchInput):
		TouchInput.haptic_tap()
	screen_pushed.emit(id)
	Bus.emit(&"ui_pushed", BusEvents.UIPushed.new(id))
	return screen

func pop() -> void:
	if _stack.is_empty(): return
	var entry : UIStackEntry = _stack.pop_back()
	if is_instance_valid(entry.node):
		_animate_out(entry.node)
	screen_popped.emit(entry.id)
	Bus.emit(&"ui_popped", BusEvents.UIPopped.new(entry.id))

func pop_to(id: StringName) -> void:
	while not _stack.is_empty() and _stack.back().id != id:
		pop()

func replace(id: StringName, data: Dictionary = {}) -> Control:
	if not _stack.is_empty():
		pop()
	return push(id, data)

func push_unique(id: StringName, data: Dictionary = {}) -> Control:
	if current_id() == id:
		return current()
	return push(id, data)

func clear() -> void:
	for entry : UIStackEntry in _stack:
		if is_instance_valid(entry.node):
			entry.node.queue_free()
	_stack.clear()
	Bus.emit(&"ui_cleared", {})

func current() -> Control:
	if _stack.is_empty(): return null
	return _stack.back().node

func current_id() -> StringName:
	if _stack.is_empty(): return &""
	return _stack.back().id

func depth() -> int: return _stack.size()

func _animate_in(screen: Control) -> void:
	screen.modulate.a = 0.0
	var tree := get_tree()
	if tree == null:
		screen.modulate.a = 1.0
		return
	tree.create_tween().tween_property(screen, "modulate:a", 1.0, 0.18)

func _animate_out(screen: Control) -> void:
	var tree := get_tree()
	if tree == null:
		screen.queue_free()
		return
	var t : Tween = tree.create_tween()
	t.tween_property(screen, "modulate:a", 0.0, 0.18)
	t.tween_callback(screen.queue_free)
