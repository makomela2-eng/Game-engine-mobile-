## DependencyContainer — lightweight IoC container.
## Binds interface names to factory callables or singleton instances.
##
## Usage:
##   DI.bind(&"IHealthSystem", func(): return HealthSystem)
##   var hs := DI.resolve(&"IHealthSystem")
extends Node

var _bindings : Dictionary = {}  ## StringName → { factory: Callable, singleton: bool, instance: Object }

func bind(svc_name: StringName, factory: Callable, singleton: bool = true) -> void:
	if not factory.is_valid():
		Log.warn("[DI] Invalid factory for: %s" % svc_name)
		return
	_bindings[svc_name] = {"factory": factory, "singleton": singleton, "instance": null}

func bind_instance(svc_name: StringName, instance: Object) -> void:
	_bindings[svc_name] = {"factory": Callable(), "singleton": true, "instance": instance}

func resolve(svc_name: StringName) -> Object:
	if not _bindings.has(svc_name):
		Log.warn("[DI] No binding for: %s" % svc_name)
		return null
	var b : Dictionary = _bindings[svc_name]
	var inst : Variant = b.get("instance", null)
	if inst != null and is_instance_valid(inst):
		return inst
	var factory : Callable = b.get("factory", Callable())
	if not factory.is_valid():
		return null
	var instance : Object = factory.call()
	if instance == null:
		Log.warn("[DI] Factory returned null for: %s" % svc_name)
		return null
	if bool(b.get("singleton", true)):
		b["instance"] = instance
		_bindings[svc_name] = b
	return instance

func resolve_or(svc_name: StringName, fallback: Object) -> Object:
	var resolved := resolve(svc_name)
	return resolved if resolved != null else fallback

func clear_instance(svc_name: StringName) -> void:
	if _bindings.has(svc_name):
		(_bindings[svc_name] as Dictionary)["instance"] = null

func unbind(svc_name: StringName) -> void:
	_bindings.erase(svc_name)

func is_bound(svc_name: StringName) -> bool:
	return _bindings.has(svc_name)

func bindings() -> Array[StringName]:
	var result : Array[StringName] = []
	for key in _bindings.keys():
		result.append(key)
	return result

func reset() -> void:
	_bindings.clear()

func count() -> int:
	return _bindings.size()
