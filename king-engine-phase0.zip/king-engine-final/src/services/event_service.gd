## EventService — typed event subscription registry on top of Bus.
## Provides subscription handles for clean lifetime management.
##
## Usage:
##   var handle := EventService.subscribe(&"gameplay.entity_died", _on_died)
##   EventService.unsubscribe(handle)
extends Node

var _next_handle : int = 0
var _subs        : Dictionary = {}  ## handle → { event, fn }

func subscribe(event: StringName, fn: Callable) -> int:
	var handle  := _next_handle
	_next_handle += 1
	_subs[handle] = {"event": event, "fn": fn}
	Bus.on(event, fn)
	return handle

func unsubscribe(handle: int) -> void:
	if not _subs.has(handle):
		return
	var s := _subs[handle] as Dictionary
	Bus.off(s.event, s.fn)
	_subs.erase(handle)

## Unsubscribe all handles belonging to an owner object.
func unsubscribe_all(handles: Array[int]) -> void:
	for h : int in handles:
		unsubscribe(h)

func emit(event: StringName, data: Dictionary = {}) -> void:
	Bus.emit(event, data)

func active_count() -> int:
	return _subs.size()
