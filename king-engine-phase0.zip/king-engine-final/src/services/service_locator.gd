## ServiceLocator — named service registry for dependency injection.
## Systems register themselves; consumers look up by interface name.
## Prefer this over direct autoload references in library code.
extends Node

var _services : Dictionary = {}  ## StringName → Object

func register(svc_name: StringName, service: Object) -> void:
	if _services.has(svc_name):
		Log.warn("[ServiceLocator] Overwriting service: %s" % svc_name)
	_services[svc_name] = service
	Log.info("[ServiceLocator] Registered: %s" % svc_name)

func get_service(svc_name: StringName) -> Object:
	if not _services.has(svc_name):
		Log.warn("[ServiceLocator] Service not found: %s" % svc_name)
		return null
	return _services[svc_name]

func has_service(svc_name: StringName) -> bool:
	return _services.has(svc_name)

func unregister(svc_name: StringName) -> void:
	_services.erase(svc_name)

func all_services() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _services.keys():
		result.append(k)
	return result

func count() -> int:
	return _services.size()

func clear() -> void:
	_services.clear()
