## AssetStream — async asset loading with progress tracking.
## Emits asset_loaded / asset_load_failed on Bus.
## Listens to app_background to pause non-critical loads.
extends Node

var _queue: Array[Dictionary] = []
var _loading: Dictionary = {}  ## path -> true
var _bg: bool = false

var _bg_cb: Callable
var _fg_cb: Callable

func _ready() -> void:
	set_process(true)
	_bg_cb = func(_d: Variant) -> void:
		_bg = true
	_fg_cb = func(_d: Variant) -> void:
		_bg = false
		_start_next()
	Bus.on(&"app_background", _bg_cb)
	Bus.on(&"app_foreground", _fg_cb)

func _exit_tree() -> void:
	Bus.off(&"app_background", _bg_cb)
	Bus.off(&"app_foreground", _fg_cb)
	_queue.clear()
	_loading.clear()
	set_process(false)

func request(path: String, priority: int = 0) -> void:
	if path.is_empty():
		return
	if _loading.has(path) or _already_queued(path):
		return
	_queue.append({"path": path, "priority": priority})
	_queue.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return int(a.get("priority", 0)) > int(b.get("priority", 0))
	)
	_start_next()

func cancel(path: String) -> bool:
	if _loading.has(path):
		return false
	for i in range(_queue.size() - 1, -1, -1):
		if str(_queue[i].get("path", "")) == path:
			_queue.remove_at(i)
			return true
	return false

func _already_queued(path: String) -> bool:
	for item in _queue:
		if str(item.get("path", "")) == path:
			return true
	return false

func _start_next() -> void:
	if _queue.is_empty() or _bg:
		return
	if not _loading.is_empty():
		return
	var item: Dictionary = _queue.pop_front()
	var path: String = str(item.get("path", ""))
	if path.is_empty():
		return
	var err := ResourceLoader.load_threaded_request(path)
	if err != OK:
		Log.error("[AssetStream] request failed: %s (%s)" % [path, error_string(err)])
		Bus.emit(&"asset_load_failed", {"path": path, "error": err})
		return
	_loading[path] = true

func _process(_delta: float) -> void:
	if _loading.is_empty():
		_start_next()
		return
	for path in _loading.keys().duplicate():
		var status := ResourceLoader.load_threaded_get_status(path)
		match status:
			ResourceLoader.THREAD_LOAD_LOADED:
				var res := ResourceLoader.load_threaded_get(path)
				_loading.erase(path)
				Bus.emit(&"asset_loaded", {"path": path, "resource": res})
				_start_next()
			ResourceLoader.THREAD_LOAD_FAILED, ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
				_loading.erase(path)
				Log.error("[AssetStream] failed: %s" % path)
				Bus.emit(&"asset_load_failed", {"path": path})
				_start_next()

func pending_count() -> int:
	return _queue.size() + _loading.size()

func cancel_all() -> void:
	_queue.clear()
	_loading.clear()
