## SceneStream — async scene loading and transitions.
extends Node
signal load_started(path: String)
signal load_complete(path: String)
signal load_failed(path: String)

var current_path : String = ""
var _loading     : bool   = false

func go(path: String) -> void:
	if _loading: return
	_loading = true
	load_started.emit(path)
	Bus.emit(&"scene_load_started", {"path": path})
	var err := ResourceLoader.load_threaded_request(path)
	if err != OK:
		_loading = false
		load_failed.emit(path)
		Log.error("[SceneStream] failed to request: " + path)
		return
	TaskScheduler.schedule(&"scene_stream_poll", 0.1, func(): _poll(path))

func _poll(path: String) -> void:
	var status := ResourceLoader.load_threaded_get_status(path)
	if status == ResourceLoader.THREAD_LOAD_LOADED:
		TaskScheduler.unschedule(&"scene_stream_poll")
		var scene := ResourceLoader.load_threaded_get(path) as PackedScene
		if not scene:
			load_failed.emit(path); _loading = false; return
		current_path = path
		_loading = false
		get_tree().change_scene_to_packed(scene)
		call_deferred("_finish_load", path)
	elif status == ResourceLoader.THREAD_LOAD_FAILED:
		TaskScheduler.unschedule(&"scene_stream_poll")
		_loading = false
		load_failed.emit(path)
		Log.error("[SceneStream] thread failed: " + path)

func _finish_load(path: String) -> void:
	load_complete.emit(path)
	Bus.emit(&"scene_loaded", {"path": path})
	Log.info("[SceneStream] loaded: " + path)

func is_loading() -> bool: return _loading
