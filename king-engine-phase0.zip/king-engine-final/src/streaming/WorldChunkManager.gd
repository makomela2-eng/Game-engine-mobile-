## WorldChunkManager — loads/unloads world chunks around a focal point.
##
## Chunk scene resolution order:
##   1. ChunkManifest entry  →  path from manifest JSON
##   2. Pattern fallback     →  chunk_scene_pattern % key
##   3. If neither exists    →  chunk is tracked as empty (no node, no error spam)
##
## Loaded chunks live as children of _chunk_root (a Node3D added to this node).
## Emits chunk_loaded / chunk_unloaded on Bus.
## Listens to camera_changed (from Dashboard/CameraSystem) to update focal point.
extends Node

var chunk_size    : float  = 32.0
var load_radius   : float  = 96.0
## Set by the game layer before this node enters the tree (or via the inspector).
## Engine does not provide defaults — paths are game content.
@export var chunk_scene_pattern : String = ""
@export var manifest_path : String = ""

var _focal_point  : Vector3    = Vector3.ZERO
var _loaded       : Dictionary = {}  ## chunk_key → Node3D (or null if empty/no scene)
var _loading      : Dictionary = {}  ## chunk_key → bool (async in-flight)
var _manifest     : Dictionary = {}  ## chunk_key → String (scene path)
var _chunk_root   : Node3D

var _cb_engine_play  : Callable
var _cb_engine_pause : Callable

func _ready() -> void:
	if chunk_scene_pattern.is_empty() and manifest_path.is_empty():
		Log.warn("[WorldChunkManager] Disabled — no paths configured")
		set_process(false)
		return
	_chunk_root = Node3D.new()
	_chunk_root.name = "ChunkRoot"
	add_child(_chunk_root)
	_load_manifest()
	_cb_engine_play  = func(_d: Variant) -> void: set_process(true)
	_cb_engine_pause = func(_d: Variant) -> void: set_process(false)
	Bus.on(&"camera_changed",  _on_camera_changed)
	Bus.on(&"engine_play",     _cb_engine_play)
	Bus.on(&"engine_pause",    _cb_engine_pause)
	TaskScheduler.schedule(&"chunk_update", 1.0, _update_chunks)

func _exit_tree() -> void:
	Bus.off(&"camera_changed", _on_camera_changed)
	if _cb_engine_play.is_valid():  Bus.off(&"engine_play",  _cb_engine_play)
	if _cb_engine_pause.is_valid(): Bus.off(&"engine_pause", _cb_engine_pause)
	TaskScheduler.unschedule(&"chunk_update")

# ── Manifest ───────────────────────────────────────────────────────────────────

func _load_manifest() -> void:
	if not FileAccess.file_exists(manifest_path):
		return
	var f := FileAccess.open(manifest_path, FileAccess.READ)
	if f == null:
		Log.warn("[WorldChunkManager] Cannot open manifest: %s" % manifest_path)
		return
	var text   := f.get_as_text()
	var parsed : Variant = JSON.parse_string(text)
	if not parsed is Dictionary:
		Log.warn("[WorldChunkManager] Manifest is not a JSON object")
		return
	for key in (parsed as Dictionary).keys():
		var val : Variant = (parsed as Dictionary)[key]
		if val is String:
			_manifest[str(key)] = val as String
	Log.info("[WorldChunkManager] Manifest loaded: %d entries" % _manifest.size())

# ── Focal point ────────────────────────────────────────────────────────────────

func _on_camera_changed(data: Variant) -> void:
	if not data is Dictionary: return
	var pos : Variant = (data as Dictionary).get("position", null)
	if pos is Vector3:
		_focal_point = pos as Vector3

func set_focal_point(pos: Vector3) -> void:
	_focal_point = pos

# ── Update loop ────────────────────────────────────────────────────────────────

func _update_chunks() -> void:
	var needed := _get_needed_keys(_focal_point)
	## Unload chunks that are out of range.
	for key in _loaded.keys().duplicate():
		if key not in needed:
			_unload_chunk(str(key))
	## Load or start loading chunks that are needed.
	for key : String in needed:
		if not _loaded.has(key) and not _loading.has(key):
			_begin_load_chunk(key)

func _get_needed_keys(center: Vector3) -> Array[String]:
	var keys : Array[String] = []
	var r    : int           = int(ceil(load_radius / chunk_size))
	var cx   : int           = int(floor(center.x / chunk_size))
	var cz   : int           = int(floor(center.z / chunk_size))
	for dx in range(-r, r + 1):
		for dz in range(-r, r + 1):
			keys.append("%d_%d" % [cx + dx, cz + dz])
	return keys

# ── Load ───────────────────────────────────────────────────────────────────────

func _resolve_scene_path(key: String) -> String:
	## Manifest takes priority.
	if _manifest.has(key):
		return _manifest[key]
	## Fallback pattern.
	var path := chunk_scene_pattern % key
	if ResourceLoader.exists(path):
		return path
	return ""

func _begin_load_chunk(key: String) -> void:
	var path := _resolve_scene_path(key)
	if path.is_empty():
		## No scene for this chunk — mark loaded-but-empty so we don't retry.
		_loaded[key] = null
		return
	_loading[key] = true
	var err := ResourceLoader.load_threaded_request(path)
	if err != OK:
		Log.warn("[WorldChunkManager] load_threaded_request failed for '%s': %s" \
			% [path, error_string(err)])
		_loading.erase(key)
		_loaded[key] = null
		return
	## Poll completion — one named slot per in-flight chunk.
	var slot := StringName("chunk_poll_%s" % key)
	TaskScheduler.schedule(slot, 0.1, func() -> void: _poll_chunk(key, path, slot))

func _poll_chunk(key: String, path: String, slot: StringName) -> void:
	var status := ResourceLoader.load_threaded_get_status(path)
	match status:
		ResourceLoader.THREAD_LOAD_LOADED:
			TaskScheduler.unschedule(slot)
			_loading.erase(key)
			var packed := ResourceLoader.load_threaded_get(path) as PackedScene
			if packed == null:
				Log.error("[WorldChunkManager] Not a PackedScene: %s" % path)
				_loaded[key] = null
				return
			_instantiate_chunk(key, packed)
		ResourceLoader.THREAD_LOAD_FAILED, ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			TaskScheduler.unschedule(slot)
			_loading.erase(key)
			Log.error("[WorldChunkManager] Async load failed: %s" % path)
			_loaded[key] = null
			Bus.emit(&"chunk_load_failed", {"key": key, "path": path})
		## THREAD_LOAD_IN_PROGRESS — keep polling.

func _instantiate_chunk(key: String, packed: PackedScene) -> void:
	var node := packed.instantiate() as Node3D
	if node == null:
		Log.error("[WorldChunkManager] PackedScene root is not Node3D for chunk: %s" % key)
		_loaded[key] = null
		return
	## Position chunk at its grid cell origin.
	var parts := key.split("_")
	if parts.size() >= 2 and parts[0].is_valid_int() and parts[1].is_valid_int():
		node.position = Vector3(int(parts[0]) * chunk_size, 0.0, int(parts[1]) * chunk_size)
	node.name = "Chunk_%s" % key
	_chunk_root.add_child(node)
	_loaded[key] = node
	Bus.emit(&"chunk_loaded", {"key": key, "node": node})
	Log.info("[WorldChunkManager] Loaded chunk: %s" % key)

# ── Unload ─────────────────────────────────────────────────────────────────────

func _unload_chunk(key: String) -> void:
	## Cancel any in-flight poll for this chunk.
	var slot := StringName("chunk_poll_%s" % key)
	if TaskScheduler.is_scheduled(slot):
		TaskScheduler.unschedule(slot)
		_loading.erase(key)
	var node : Variant = _loaded.get(key, null)
	_loaded.erase(key)
	if node is Node3D and is_instance_valid(node as Node3D):
		(node as Node3D).queue_free()
	Bus.emit(&"chunk_unloaded", {"key": key})

# ── Queries ────────────────────────────────────────────────────────────────────

func get_chunk_node(key: String) -> Node3D:
	var v : Variant = _loaded.get(key, null)
	if v is Node3D: return v as Node3D
	return null

func loaded_count() -> int:
	return _loaded.size()

func is_chunk_loaded(key: String) -> bool:
	return _loaded.has(key)

func unload_all() -> void:
	for key in _loaded.keys().duplicate():
		_unload_chunk(str(key))
