## IntegrationTest — base for tests that require a running scene/ECS state.
## These run after the world is loaded. Override setup()/teardown().
class_name IntegrationTest
extends UnitTest

## Override to prepare state before tests in this suite run.
func setup() -> void:
	pass

## Override to clean up state after tests in this suite run.
func teardown() -> void:
	pass

## Register as integration type and wrap with setup/teardown.
func register_integration_tests(suite: StringName = &"") -> void:
	_suite_name = suite if suite != &"" else StringName(get_script().resource_path.get_file())
	setup()
	for method in get_method_list():
		var method_name : String = method.get("name", "")
		if method_name.begins_with("test_"):
			var full_name := StringName("%s::%s" % [_suite_name, method_name])
			TestRunner.register(full_name, Callable(self, method_name), &"integration")
	teardown()

## Spawn a test entity with given components and auto-destroy after test.
func spawn_test_entity(components: Dictionary = {}) -> int:
	var id := EntityManager.create_entity()
	for type : StringName in components.keys():
		EntityManager.add_component(id, type, components[type])
	return id

func cleanup_entity(id: int) -> void:
	EntityManager.destroy_entity(id)

## Wait N frames (for use with async patterns — call with await).
func wait_frames(n: int) -> void:
	for i in range(n):
		await Engine.get_main_loop().process_frame
