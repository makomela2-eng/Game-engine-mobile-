## TestRunner — discovers and runs all unit and integration tests.
## Run from editor via Console: "test run"
## Or call TestRunner.run_all() from Boot in debug builds.
extends Node

var _tests      : Array[Dictionary] = []  ## { svc_name, fn, type }
var _results    : Array[Dictionary] = []  ## { svc_name, passed, error, ms }
var _running    : bool = false

signal all_tests_complete(passed: int, failed: int, total: int)

func register(svc_name: StringName, fn: Callable, type: StringName = &"unit") -> void:
	_tests.append({"svc_name": svc_name, "fn": fn, "type": type})

func run_all() -> void:
	if _running:
		return
	_running = true
	_results.clear()
	Log.info("[TestRunner] Running %d tests..." % _tests.size())
	for test : Dictionary in _tests:
		_run_one(test)
	_print_summary()
	_running = false

func run_type(type: StringName) -> void:
	_running = true
	_results.clear()
	for test : Dictionary in _tests:
		if test.type == type:
			_run_one(test)
	_print_summary()
	_running = false

func _run_one(test: Dictionary) -> void:
	var start := Time.get_ticks_usec()
	var passed := true
	var error  := ""
	var fn     := test.fn as Callable
	if fn.is_valid():
		var result: Variant = fn.call()
		if result is String and not (result as String).is_empty():
			passed = false
			error  = result as String
		elif result == false:
			passed = false
			error  = "returned false"
	var ms := (Time.get_ticks_usec() - start) / 1000.0
	_results.append({"svc_name": test.svc_name, "passed": passed, "error": error, "ms": ms})
	var icon := "✓" if passed else "✗"
	var msg  := "%s %s (%.1fms)" % [icon, test.svc_name, ms]
	if passed:
		Log.info(msg)
	else:
		Log.error("%s — %s" % [msg, error])

func _print_summary() -> void:
	var passed : int = _results.filter(func(r): return r.passed).size()
	var failed := _results.size() - passed
	Log.info("[TestRunner] %d/%d passed  %d failed" % [passed, _results.size(), failed])
	all_tests_complete.emit(passed, failed, _results.size())

func last_results() -> Array[Dictionary]:
	return _results.duplicate()
