## UnitTest — base class for KING unit tests.
## Subclass and call register_tests() in _init().
##
## Example:
##   class TestEntityManager extends UnitTest:
##       func _init() -> void:
##           register_tests()
##       func test_create_entity() -> String:
##           var id := EntityManager.create_entity()
##           return assert_true(id >= 0, "entity id should be >= 0")
class_name UnitTest
extends RefCounted

var _suite_name : StringName = &""

func _init() -> void:
	pass

## Call in subclass _init() to auto-register all test_* methods.
func register_tests(suite: StringName = &"") -> void:
	_suite_name = suite if suite != &"" else StringName(get_script().resource_path.get_file())
	for method in get_method_list():
		var method_name : String = method.get("name", "")
		if method_name.begins_with("test_"):
			var full_name := StringName("%s::%s" % [_suite_name, method_name])
			TestRunner.register(full_name, Callable(self, method_name), &"unit")

# ── Assertion helpers — return "" on pass, error string on fail ───────────────

func assert_true(condition: bool, msg: String = "") -> String:
	if condition:
		return ""
	return "Expected true — %s" % msg

func assert_false(condition: bool, msg: String = "") -> String:
	if not condition:
		return ""
	return "Expected false — %s" % msg

func assert_eq(a: Variant, b: Variant, msg: String = "") -> String:
	if a == b:
		return ""
	return "Expected %s == %s — %s" % [str(a), str(b), msg]

func assert_ne(a: Variant, b: Variant, msg: String = "") -> String:
	if a != b:
		return ""
	return "Expected %s != %s — %s" % [str(a), str(b), msg]

func assert_null(v: Variant, msg: String = "") -> String:
	if v == null:
		return ""
	return "Expected null, got %s — %s" % [str(v), msg]

func assert_not_null(v: Variant, msg: String = "") -> String:
	if v != null:
		return ""
	return "Expected non-null — %s" % msg

func assert_approx(a: float, b: float, tolerance: float = 0.001, msg: String = "") -> String:
	if abs(a - b) <= tolerance:
		return ""
	return "Expected %.4f ≈ %.4f (±%.4f) — %s" % [a, b, tolerance, msg]
