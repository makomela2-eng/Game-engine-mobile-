## AnalyticsSystem — event tracking with batched dispatch.
extends Node

const BATCH_SIZE    := 20
const FLUSH_SEC     := 30.0
var _endpoint       : String = ""
var _events         : Array  = []
var _session_id     : String = ""
var _cb_analytics   : Callable

func _ready() -> void:
	_session_id = str(Time.get_unix_time_from_system())
	TaskScheduler.schedule(&"analytics_flush", FLUSH_SEC, flush)
	_cb_analytics = func(d: Variant) -> void:
		if d is Dictionary: track(str((d as Dictionary).get("name","")), d as Dictionary)
	Bus.on(&"analytics_event", _cb_analytics)

func _exit_tree() -> void:
	TaskScheduler.unschedule(&"analytics_flush")
	if _cb_analytics.is_valid(): Bus.off(&"analytics_event", _cb_analytics)

func set_endpoint(url: String) -> void:
	_endpoint = url

func track(event_name: String, props: Dictionary = {}) -> void:
	if Kernel.is_debug: return  # no analytics in debug
	var ev: Dictionary = props.duplicate() as Dictionary
	ev["event"]      = event_name
	ev["session"]    = _session_id
	ev["time"]       = Time.get_unix_time_from_system()
	_events.append(ev)
	if _events.size() >= BATCH_SIZE: flush()

func flush() -> void:
	if _events.is_empty() or _endpoint.is_empty(): return
	var payload: Array = _events.duplicate()
	_events.clear()
	# Fire-and-forget HTTP via HTTPRequest node (handles async connection internally)
	var http: HTTPRequest = HTTPRequest.new()
	add_child(http)
	# Auto-free the node once the request completes or fails
	http.request_completed.connect(func(_result, _code, _headers, _body):
		http.queue_free())
	var err: int = http.request(
		_endpoint,
		["Content-Type: application/json"],
		HTTPClient.METHOD_POST,
		JSON.stringify(payload))
	if err != OK:
		Log.warn("[Analytics] HTTP request failed: %d" % err)
		http.queue_free()
