## DevUI — full in-game visual debug overlay.
## Toggle: DevUI.toggle()  or  Bus.emit(&"devui_toggle")
## Backtick ` also toggles in-game.
##
## Typing notes:
##   • _refresh_systems names list is Array[String].
##   • All for-loop variables explicitly typed.
##   • _push_log_line receives Dictionary directly — the is-check and cast
##     are done once in _on_log before the call, not repeated inside.
##   • Stored Callables present and correct throughout.
extends CanvasLayer

# ── Colours ───────────────────────────────────────────────────────────────────
const C_BG      := Color(0.04, 0.04, 0.04, 0.82)
const C_HDR     := Color(0.36, 0.64, 1.00)
const C_OK      := Color(0.44, 0.80, 0.44)
const C_WARN    := Color(1.00, 0.75, 0.20)
const C_ERR     := Color(0.90, 0.28, 0.28)
const C_DIM     := Color(0.55, 0.55, 0.55)
const C_TEXT    := Color(0.90, 0.90, 0.90)
const C_BAR_BG  := Color(0.15, 0.15, 0.15)

const LOG_LINES  := 6
const BAR_W      := 160.0
const FPS_TARGET := 60.0

# ── Nodes ─────────────────────────────────────────────────────────────────────
var _visible    : bool = false
var _panel      : PanelContainer
var _fps_lbl    : Label
var _fps_bar    : ColorRect
var _fps_bar_bg : ColorRect
var _mem_lbl    : Label
var _draw_lbl   : Label
var _node_lbl   : Label
var _sys_list   : VBoxContainer
var _log_vbox   : VBoxContainer
var _log_scroll : ScrollContainer
var _cmd_input  : LineEdit

# ── Callables ─────────────────────────────────────────────────────────────────
var _cb_toggle : Callable
var _cb_perf   : Callable
var _cb_log    : Callable

# ── Boot ──────────────────────────────────────────────────────────────────────

func _ready() -> void:
	layer = 100
	set_process_input(true)
	_build()
	hide_ui()
	TaskScheduler.schedule(&"devui_refresh", 0.33, _refresh)
	_cb_toggle = func(_d: Variant) -> void: toggle()
	_cb_perf   = func(_d: Variant) -> void: pass
	_cb_log    = func(d: Variant) -> void: _on_log(d)
	Bus.on(&"devui_toggle", _cb_toggle)
	Bus.on(&"perf_snap",    _cb_perf)
	Bus.on(&"log_entry",    _cb_log)

func _exit_tree() -> void:
	TaskScheduler.unschedule(&"devui_refresh")
	if _cb_toggle.is_valid(): Bus.off(&"devui_toggle", _cb_toggle)
	if _cb_perf.is_valid():   Bus.off(&"perf_snap",    _cb_perf)
	if _cb_log.is_valid():    Bus.off(&"log_entry",    _cb_log)

# ── Build ─────────────────────────────────────────────────────────────────────

func _build() -> void:
	_panel = PanelContainer.new()
	_panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
	_panel.position = Vector2(8, 8)
	_panel.custom_minimum_size = Vector2(280, 0)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = C_BG
	style.set_corner_radius_all(8)
	style.border_width_left   = 1; style.border_width_right  = 1
	style.border_width_top    = 1; style.border_width_bottom = 1
	style.border_color = Color(0.22, 0.22, 0.22, 0.9)
	_panel.add_theme_stylebox_override("panel", style)
	add_child(_panel)

	var root: MarginContainer = MarginContainer.new()
	root.add_theme_constant_override("margin_left",   8)
	root.add_theme_constant_override("margin_right",  8)
	root.add_theme_constant_override("margin_top",    6)
	root.add_theme_constant_override("margin_bottom", 6)
	_panel.add_child(root)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	root.add_child(vbox)

	# Title row
	var title_row: HBoxContainer = HBoxContainer.new()
	var title_lbl: Label = _lbl("▶ KING ENGINE", 11, C_HDR)
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_row.add_child(title_lbl)
	var close_btn: Button = Button.new()
	close_btn.text = "✕"; close_btn.flat = true
	close_btn.add_theme_font_size_override("font_size", 10)
	close_btn.add_theme_color_override("font_color", C_DIM)
	close_btn.pressed.connect(hide_ui)
	title_row.add_child(close_btn)
	vbox.add_child(title_row)
	vbox.add_child(_hsep())

	# FPS row with colour bar
	var fps_row: HBoxContainer = HBoxContainer.new()
	fps_row.add_theme_constant_override("separation", 6)
	_fps_lbl = _lbl("FPS: --", 11, C_OK)
	_fps_lbl.custom_minimum_size.x = 72
	fps_row.add_child(_fps_lbl)
	var bar_wrap: Control = Control.new()
	bar_wrap.custom_minimum_size = Vector2(BAR_W, 10)
	bar_wrap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_fps_bar_bg = ColorRect.new()
	_fps_bar_bg.color = C_BAR_BG
	_fps_bar_bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bar_wrap.add_child(_fps_bar_bg)
	_fps_bar = ColorRect.new()
	_fps_bar.color = C_OK
	_fps_bar.anchor_top    = 0.0; _fps_bar.anchor_bottom = 1.0
	_fps_bar.anchor_left   = 0.0; _fps_bar.anchor_right  = 0.5
	bar_wrap.add_child(_fps_bar)
	fps_row.add_child(bar_wrap)
	vbox.add_child(fps_row)

	# Stats
	_mem_lbl  = _lbl("MEM: -- MB", 10, C_DIM)
	_draw_lbl = _lbl("DRAW: --",   10, C_DIM)
	_node_lbl = _lbl("NODES: --",  10, C_DIM)
	vbox.add_child(_mem_lbl)
	vbox.add_child(_draw_lbl)
	vbox.add_child(_node_lbl)
	vbox.add_child(_hsep())

	# Active systems
	vbox.add_child(_lbl("SYSTEMS", 9, C_HDR))
	_sys_list = VBoxContainer.new()
	_sys_list.add_theme_constant_override("separation", 1)
	vbox.add_child(_sys_list)
	_refresh_systems()
	vbox.add_child(_hsep())

	# Live log
	vbox.add_child(_lbl("LOG", 9, C_HDR))
	_log_scroll = ScrollContainer.new()
	_log_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_log_scroll.custom_minimum_size.y = 72
	_log_vbox = VBoxContainer.new()
	_log_vbox.add_theme_constant_override("separation", 1)
	_log_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_log_scroll.add_child(_log_vbox)
	vbox.add_child(_log_scroll)
	for entry: Dictionary in LogCapture.recent(LOG_LINES):
		_push_log_line(entry)
	vbox.add_child(_hsep())

	# Command input
	_cmd_input = LineEdit.new()
	_cmd_input.placeholder_text = "> command…"
	_cmd_input.add_theme_font_size_override("font_size", 10)
	_cmd_input.text_submitted.connect(_on_cmd)
	vbox.add_child(_cmd_input)

# ── Refresh ───────────────────────────────────────────────────────────────────

func _refresh() -> void:
	if not _visible: return
	var fps  : float = Engine.get_frames_per_second()
	var mem  : float = OS.get_static_memory_usage() / 1_048_576.0
	var draw : int   = int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME))
	var nodes: int   = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))

	_fps_lbl.text  = "FPS: %d" % int(fps)
	_mem_lbl.text  = "MEM: %.1f MB" % mem
	_draw_lbl.text = "DRAW: %d" % draw
	_node_lbl.text = "NODES: %d" % nodes

	var fps_col: Color = C_OK if fps >= 50 else (C_WARN if fps >= 30 else C_ERR)
	_fps_lbl.add_theme_color_override("font_color", fps_col)
	_fps_bar.color = fps_col
	_fps_bar.anchor_right = clampf(fps / FPS_TARGET, 0.0, 1.0)

	_mem_lbl.add_theme_color_override("font_color",
		C_ERR if mem > 400.0 else (C_WARN if mem > 200.0 else C_TEXT))
	_draw_lbl.add_theme_color_override("font_color",
		C_ERR if draw > 500 else (C_WARN if draw > 200 else C_TEXT))

func _refresh_systems() -> void:
	if not is_instance_valid(_sys_list): return
	for c: Node in _sys_list.get_children():
		c.queue_free()
	var names: Array[String] = []
	for sname: StringName in Engine.get_singleton_list():
		names.append(str(sname))
	if is_instance_valid(get_tree()):
		for child: Node in get_tree().root.get_children():
			var n: String = str(child.name)
			if not names.has(n):
				names.append(n)
	for sname: String in names:
		var row: HBoxContainer = HBoxContainer.new()
		var dot: Label = Label.new()
		dot.text = "● "
		dot.add_theme_font_size_override("font_size", 9)
		dot.add_theme_color_override("font_color", C_OK)
		row.add_child(dot)
		var lbl: Label = Label.new()
		lbl.text = sname
		lbl.add_theme_font_size_override("font_size", 9)
		lbl.add_theme_color_override("font_color", C_DIM)
		row.add_child(lbl)
		_sys_list.add_child(row)

# ── Log ───────────────────────────────────────────────────────────────────────

func _on_log(entry: Variant) -> void:
	# Cast once here; _push_log_line receives a typed Dictionary.
	if not entry is Dictionary: return
	_push_log_line(entry as Dictionary)

func _push_log_line(entry: Dictionary) -> void:
	if not is_instance_valid(_log_vbox): return
	var lvl : int    = int(entry.get("level", 0))
	var msg : String = str(entry.get("msg", ""))
	var lbl : Label  = Label.new()
	lbl.text = msg.left(60)
	lbl.add_theme_font_size_override("font_size", 9)
	lbl.add_theme_color_override("font_color",
		C_ERR if lvl == 3 else (C_WARN if lvl == 2 else C_DIM))
	lbl.autowrap_mode = TextServer.AUTOWRAP_OFF
	_log_vbox.add_child(lbl)
	while _log_vbox.get_child_count() > LOG_LINES:
		_log_vbox.get_child(0).queue_free()
	if is_instance_valid(_log_scroll):
		var vsb: ScrollBar = _log_scroll.get_v_scroll_bar()
		if vsb: _log_scroll.scroll_vertical = int(vsb.max_value)

# ── Commands ──────────────────────────────────────────────────────────────────

func _on_cmd(text: String) -> void:
	_cmd_input.clear()
	text = text.strip_edges()
	if text.is_empty(): return
	Log.info("[DevUI] " + text)
	match text:
		"clear": LogCapture.clear()
		"fps30": Engine.max_fps = 30
		"fps60": Engine.max_fps = 60
		"sys":   _refresh_systems()
		"gc":    Log.info("MEM %.0f MB" % (OS.get_static_memory_usage() / 1_048_576.0))
		_:       Bus.emit(&"devui_command", {"cmd": text})

# ── Public ────────────────────────────────────────────────────────────────────

func show_ui() -> void:
	_visible = true
	_panel.visible = true
	_refresh_systems()

func hide_ui() -> void:
	_visible = false
	_panel.visible = false

func toggle() -> void:
	if _visible:
		hide_ui()
	else:
		show_ui()

func _input(event: InputEvent) -> void:
	if not event is InputEventKey: return
	var e: InputEventKey = event as InputEventKey
	if e.pressed and e.keycode == KEY_QUOTELEFT:
		toggle()

# ── Helpers ───────────────────────────────────────────────────────────────────

func _lbl(text: String, fs: int, color: Color) -> Label:
	var l: Label = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_color", color)
	return l

func _hsep() -> HSeparator:
	var s: HSeparator = HSeparator.new()
	s.add_theme_constant_override("separation", 2)
	return s
