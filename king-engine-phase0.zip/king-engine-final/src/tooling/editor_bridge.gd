## EditorBridge — routes between the KING runtime and the king_editor plugin.
## In-game: relays selection and scene changes to Bus.
## In editor: relays entity/scene events to panels.
extends Node

var is_editor_context : bool = false

func _ready() -> void:
	is_editor_context = Engine.is_editor_hint()
	Bus.on(&"ecs.entity_created",       _relay)
	Bus.on(&"ecs.entity_destroyed",     _relay)
	Bus.on(&"ecs.component_added",      _relay)
	Bus.on(&"ecs.component_removed",    _relay)
	Bus.on(&"editor.selection_changed", _relay)
	Bus.on(&"scene_loaded",             _on_scene_loaded)

func _exit_tree() -> void:
	Bus.off(&"ecs.entity_created",       _relay)
	Bus.off(&"ecs.entity_destroyed",     _relay)
	Bus.off(&"ecs.component_added",      _relay)
	Bus.off(&"ecs.component_removed",    _relay)
	Bus.off(&"editor.selection_changed", _relay)
	Bus.off(&"scene_loaded",             _on_scene_loaded)

func _relay(_data: Variant) -> void:
	pass  ## King editor panels connect to Bus directly

func _on_scene_loaded(data: Variant) -> void:
	if not data is Dictionary: return
	var path := str((data as Dictionary).get("path", ""))
	notify_scene_changed(path)

func notify_scene_changed(scene_path: String) -> void:
	Bus.emit(&"editor.scene_changed", {"path": scene_path})

func notify_asset_imported(path: String) -> void:
	Bus.emit(&"editor.asset_imported", {"path": path})
