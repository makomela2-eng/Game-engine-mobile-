## GizmoSystem — draws 3D handles over selected entities using ImmediateMesh.
extends Node

var _mesh_instance : MeshInstance3D
var _im            : ImmediateMesh
var gizmo_color    : Color = Color(0.2, 0.8, 1.0)
var axis_size      : float = 0.5

func _ready() -> void:
	_im             = ImmediateMesh.new()
	_mesh_instance  = MeshInstance3D.new()
	_mesh_instance.mesh = _im
	var mat         := StandardMaterial3D.new()
	mat.shading_mode        = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	_mesh_instance.material_override = mat
	add_child(_mesh_instance)
	Bus.on(&"editor.selection_changed", _on_selection_changed)

func _exit_tree() -> void:
	Bus.off(&"editor.selection_changed", _on_selection_changed)

func _on_selection_changed(data: Variant) -> void:
	_redraw(data if data is Dictionary else {})

func _redraw(data: Dictionary) -> void:
	_im.clear_surfaces()
	var entities: Array = data.get("entities", []) as Array
	if entities.is_empty():
		return
	_im.surface_begin(Mesh.PRIMITIVE_LINES)
	for id in entities:
		var t := EntityManager.get_component(id, &"Transform") as TransformComponent
		if t == null:
			continue
		_draw_axes(t.position)
	_im.surface_end()

func _draw_axes(pos: Vector3) -> void:
	var s := axis_size
	# X axis — red
	_im.surface_set_color(Color.RED)
	_im.surface_add_vertex(pos)
	_im.surface_add_vertex(pos + Vector3(s, 0, 0))
	# Y axis — green
	_im.surface_set_color(Color.GREEN)
	_im.surface_add_vertex(pos)
	_im.surface_add_vertex(pos + Vector3(0, s, 0))
	# Z axis — blue
	_im.surface_set_color(Color.BLUE)
	_im.surface_add_vertex(pos)
	_im.surface_add_vertex(pos + Vector3(0, 0, s))
