## SelectionSystem — tracks selected entities in editor/runtime.
extends Node

var _selected : Array[int] = []
var multi_select : bool = false

signal selection_changed(entities: Array[int])

func select(entity: int) -> void:
	if not EntityManager.entity_exists(entity):
		return
	if not multi_select:
		_selected.clear()
	if not _selected.has(entity):
		_selected.append(entity)
	Bus.emit(&"editor.selection_changed", {"entities": _selected.duplicate()})
	selection_changed.emit(_selected.duplicate())

func deselect(entity: int) -> void:
	_selected.erase(entity)
	Bus.emit(&"editor.selection_changed", {"entities": _selected.duplicate()})
	selection_changed.emit(_selected.duplicate())

func clear() -> void:
	_selected.clear()
	Bus.emit(&"editor.selection_changed", {"entities": []})
	selection_changed.emit([])

func is_selected(entity: int) -> bool:
	return _selected.has(entity)

func get_selected() -> Array[int]:
	return _selected.duplicate()

func primary() -> int:
	return _selected[0] if not _selected.is_empty() else -1

func count() -> int:
	return _selected.size()
