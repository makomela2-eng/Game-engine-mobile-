## ToolManager — registers and activates editor tools by svc_name.
extends Node

var _tools      : Dictionary = {}   ## StringName → tool object
var _active     : StringName = &""

signal tool_activated(svc_name: StringName)
signal tool_deactivated(svc_name: StringName)

func register_tool(svc_name: StringName, tool_obj: Object) -> void:
	_tools[svc_name] = tool_obj
	Log.info("[ToolManager] Registered tool: %s" % svc_name)

func activate(svc_name: StringName) -> void:
	if _active != &"" and _tools.has(_active):
		var prev = _tools[_active]
		if prev.has_method("on_deactivate"):
			prev.on_deactivate()
		tool_deactivated.emit(_active)
	_active = svc_name
	if _tools.has(svc_name):
		var t = _tools[svc_name]
		if t.has_method("on_activate"):
			t.on_activate()
		tool_activated.emit(svc_name)

func deactivate() -> void:
	if _active != &"" and _tools.has(_active):
		var t = _tools[_active]
		if t.has_method("on_deactivate"):
			t.on_deactivate()
		tool_deactivated.emit(_active)
	_active = &""

func get_active() -> StringName:
	return _active

func get_tool(svc_name: StringName) -> Object:
	return _tools.get(svc_name, null)

func all_tools() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _tools.keys():
		result.append(k)
	return result
