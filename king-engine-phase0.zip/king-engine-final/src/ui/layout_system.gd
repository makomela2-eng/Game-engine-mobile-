## LayoutSystem — applies layout presets and builds UI layouts in code.
##
## stack_vertical / stack_horizontal: use get_combined_minimum_size() so
## child dimensions are correct before any layout pass has run.
## apply_safe_area: pads control with NotchHandler insets.
extends Node

enum Preset { FULL, TOP_BAR, BOTTOM_BAR, LEFT_PANEL, RIGHT_PANEL, CENTER, HUD }

func apply(control: Control, preset: Preset, margin: int = 0) -> void:
	match preset:
		Preset.FULL:
			control.set_anchors_and_offsets_preset(
				Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, margin)
		Preset.TOP_BAR:
			control.set_anchors_preset(Control.PRESET_TOP_WIDE)
			control.offset_bottom = 64 + margin
		Preset.BOTTOM_BAR:
			control.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
			control.offset_top = -(80 + margin)
		Preset.LEFT_PANEL:
			control.set_anchors_preset(Control.PRESET_LEFT_WIDE)
			control.offset_right = 320 + margin
		Preset.RIGHT_PANEL:
			control.set_anchors_preset(Control.PRESET_RIGHT_WIDE)
			control.offset_left = -(320 + margin)
		Preset.CENTER:
			control.set_anchors_and_offsets_preset(
				Control.PRESET_CENTER, Control.PRESET_MODE_KEEP_SIZE)
		Preset.HUD:
			control.set_anchors_and_offsets_preset(
				Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 0)
			control.mouse_filter = Control.MOUSE_FILTER_IGNORE

## Stack controls vertically inside parent.
## Uses get_combined_minimum_size() so this works before any layout pass.
func stack_vertical(parent: Control, controls: Array[Control],
		spacing: int = 8) -> void:
	var y := 0
	for c : Control in controls:
		c.position.y = float(y)
		if not c.get_parent():
			parent.add_child(c)
		y += int(c.get_combined_minimum_size().y) + spacing

## Stack controls horizontally inside parent.
func stack_horizontal(parent: Control, controls: Array[Control],
		spacing: int = 8) -> void:
	var x := 0
	for c : Control in controls:
		c.position.x = float(x)
		if not c.get_parent():
			parent.add_child(c)
		x += int(c.get_combined_minimum_size().x) + spacing

## Apply NotchHandler safe-area insets to a MarginContainer.
func apply_safe_area(container: MarginContainer) -> void:
	if not is_instance_valid(container): return
	container.add_theme_constant_override("margin_top",    int(NotchHandler.inset_top))
	container.add_theme_constant_override("margin_bottom", int(NotchHandler.inset_bottom))
	container.add_theme_constant_override("margin_left",   int(NotchHandler.inset_left))
	container.add_theme_constant_override("margin_right",  int(NotchHandler.inset_right))
	## Keep in sync when safe area changes (orientation change, etc.)
	Bus.on(&"safe_area_updated", func(_d: Variant) -> void: apply_safe_area(container))

## Center a control on screen at a given anchor fraction (0.5 = center).
func center_on_screen(control: Control,
		anchor_x: float = 0.5, anchor_y: float = 0.5) -> void:
	var vp_size := control.get_viewport_rect().size
	var ctrl_size := control.get_combined_minimum_size()
	control.position = Vector2(
		vp_size.x * anchor_x - ctrl_size.x * 0.5,
		vp_size.y * anchor_y - ctrl_size.y * 0.5)
