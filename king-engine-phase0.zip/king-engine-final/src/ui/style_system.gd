## StyleSystem — theme registry and runtime style application.
##
## Godot 4 Theme API used correctly:
##   set_default_base_scale() for global scale
##   set_font_size() on theme requires type + name + size
##   ThemeDB.set_project_theme() to apply engine-wide
extends Node

var _themes : Dictionary = {}   ## StringName → Theme
var _active : StringName = &"default"

func register_theme(name: StringName, theme: Theme) -> void:
	_themes[name] = theme
	Log.info("[StyleSystem] Registered theme: %s" % name)

func load_theme(name: StringName, path: String) -> void:
	var res : Resource = load(path)
	if res is Theme:
		register_theme(name, res as Theme)
	else:
		Log.warn("[StyleSystem] Not a Theme: %s" % path)

func apply_theme(name: StringName) -> void:
	var theme := _themes.get(name, null) as Theme
	if theme == null:
		Log.warn("[StyleSystem] Theme not found: %s" % name)
		return
	_active = name
	## Apply to all nodes in "ui_screens" group.
	if get_tree():
		for node in get_tree().get_nodes_in_group("ui_screens"):
			if node is Control:
				(node as Control).theme = theme
	## Also apply project-wide if it should be the default.
	if get_tree(): get_tree().root.theme = theme
	Bus.emit(&"ui.theme_changed", {"theme": name})

func get_active_theme() -> Theme:
	return _themes.get(_active, null)

func get_theme(name: StringName) -> Theme:
	return _themes.get(name, null)

## Set a specific font size for a Control type and property.
## Example: set_font_size(&"Label", &"font_size", 18)
func set_font_size(type: StringName, property: StringName, size: int) -> void:
	var theme := get_active_theme()
	if theme == null: return
	theme.set_font_size(property, type, size)

## Scale all font sizes in the active theme by a multiplier.
func scale_fonts(multiplier: float) -> void:
	var theme := get_active_theme()
	if theme == null: return
	var types := theme.get_type_list()
	for t : StringName in types:
		for prop in theme.get_font_size_list(t):
			var current := theme.get_font_size(prop, t)
			theme.set_font_size(prop, t, int(float(current) * multiplier))

## Apply a StyleBox to a type + state combo.
func set_stylebox(type: StringName, state: StringName,
		stylebox: StyleBox) -> void:
	var theme := get_active_theme()
	if theme: theme.set_stylebox(state, type, stylebox)

func is_registered(name: StringName) -> bool:
	return _themes.has(name)

func all_themes() -> Array[StringName]:
	var result : Array[StringName] = []
	for k in _themes.keys(): result.append(k)
	return result
