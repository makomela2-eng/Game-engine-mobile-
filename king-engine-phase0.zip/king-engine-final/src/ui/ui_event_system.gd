## UIEventSystem — routes UI input events through Bus so gameplay can react
## without hardcoding Control signal connections.
extends Node

## Call from any Control signal (button pressed, slider changed, etc.)
func emit_action(action: StringName, data: Dictionary = {}) -> void:
	data["action"] = action
	Bus.emit(&"ui.action", data)

## Route a button press from any widget.
func button_pressed(button_id: StringName, extra: Dictionary = {}) -> void:
	extra["button"] = button_id
	Bus.emit(&"ui.button_pressed", extra)

## Route a value change (sliders, spinboxes).
func value_changed(control_id: StringName, value: Variant) -> void:
	Bus.emit(&"ui.value_changed", {"control": control_id, "value": value})

## Route tab or page change.
func tab_changed(tab_id: StringName, index: int) -> void:
	Bus.emit(&"ui.tab_changed", {"tab": tab_id, "index": index})

## Generic data event from a widget.
func widget_event(widget: StringName, event: StringName, data: Dictionary = {}) -> void:
	data["widget"] = widget
	data["event"]  = event
	Bus.emit(&"ui.widget_event", data)
