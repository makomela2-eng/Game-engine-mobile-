## UISystem — manages UI screens, drives UIComponent entities.
## Listens to ui.open from Bus and forwards to UIStack.
## Also wires gameplay events to HUD updates.
##
## State-on-connect: _sync_initial_state() pulls current ECS state
## immediately after subscribing, so the HUD is correct even if events
## fired before this node was ready (scene load order, autoload gaps, etc).
##
## Load-order independence: if the player entity does not exist at _ready()
## time, we watch ecs.entity_created and sync as soon as an entity tagged
## "player" appears. This removes all timing dependency on scene load order.
##
## Respawn safety: state is keyed on the player *entity ID*, not a boolean.
## If the player dies and a new entity is spawned (new ID), sync runs again
## automatically. Idempotent for the same entity, correct across respawns,
## possession, and co-op player swaps.
extends Node

## The entity ID we last synced against. -1 = never synced.
## Reset to -1 in _exit_tree() so autoload instances don't carry stale IDs
## across scene changes.
var _synced_player_id : int = -1


func _ready() -> void:
	Bus.on(&"ui.open",                 _on_ui_open)
	Bus.on(&"gameplay.health_changed",  _on_health_changed)
	Bus.on(&"gameplay.quest_updated",   _on_quest_updated)
	Bus.on(&"inventory.changed",        _on_inventory_changed)
	Bus.on(&"gameplay.entity_died",     _on_entity_died)
	## Watch for late player spawn — covers the case where UISystem loads
	## before the player entity exists in EntityManager.
	Bus.on(&"ecs.entity_created",       _on_entity_created)
	## Pull current state immediately — if the player already exists this
	## handles it in one step and records _synced_player_id.
	_sync_initial_state()


func _exit_tree() -> void:
	Bus.off(&"ui.open",                 _on_ui_open)
	Bus.off(&"gameplay.health_changed",  _on_health_changed)
	Bus.off(&"gameplay.quest_updated",   _on_quest_updated)
	Bus.off(&"inventory.changed",        _on_inventory_changed)
	Bus.off(&"gameplay.entity_died",     _on_entity_died)
	Bus.off(&"ecs.entity_created",       _on_entity_created)
	_synced_player_id = -1


# ── Screen management ──────────────────────────────────────────────────────────

func register_screen(id: StringName, scene: PackedScene) -> void:
	UIStack.register(id, scene)

func show_screen(id: StringName, data: Dictionary = {}) -> void:
	UIStack.push(id, data)

func hide_screen() -> void:
	UIStack.pop()


# ── Initial state sync ────────────────────────────────────────────────────────
## Safe to call multiple times. Guards on entity ID so the same player entity
## never triggers a duplicate sync, but a new entity (respawn, possession,
## co-op swap) always does.

func _sync_initial_state() -> void:
	var player := _find_player()
	if player < 0:
		## Player not spawned yet — _on_entity_created will call us again
		## as soon as an entity tagged "player" appears.
		return
	if player == _synced_player_id:
		## Already synced this exact entity. Idempotent, skip.
		return

	_synced_player_id = player

	## Health
	var hc := EntityManager.get_component(player, &"Health") as HealthComponent
	if hc != null:
		_on_health_changed({"entity": player, "hp": hc.hp, "max_hp": hc.max_hp})

	## Inventory and quest state are owned by the game layer.
	## Request a sync via Bus — game systems respond if present.
	## UISystem never calls InventorySystem or QuestSystem directly.
	Bus.emit(&"ui.sync_request", {"entity": player})


func _find_player() -> int:
	var players := EntityManager.get_entities_by_tag(&"player")
	return players[0] if not players.is_empty() else -1


## Called for every ecs.entity_created event.
## Triggers a sync if the new entity turns out to be a player we haven't
## synced yet — handles both late spawn and respawn (new entity ID).
func _on_entity_created(data: Variant) -> void:
	if not data is Dictionary:
		return
	var entity := int((data as Dictionary).get("entity", -1))
	if entity < 0:
		return
	if entity == _synced_player_id:
		return
	## Tags are added after entity_created fires (add_tag is a separate call),
	## so we defer one frame to let SceneBridge/spawner finish tagging.
	if EntityManager.has_tag(entity, &"player"):
		_sync_initial_state()
	else:
		## Defer: the spawner may add the "player" tag on the same frame,
		## just after emitting entity_created.
		call_deferred(&"_deferred_check_player", entity)


## Deferred check: called one frame after ecs.entity_created if the entity
## did not yet carry the "player" tag at event time.
func _deferred_check_player(entity: int) -> void:
	if entity == _synced_player_id:
		return
	if EntityManager.has_tag(entity, &"player"):
		_sync_initial_state()


# ── Event handlers ─────────────────────────────────────────────────────────────

func _on_ui_open(data: Variant) -> void:
	if not data is Dictionary: return
	var d  := data as Dictionary
	var id := StringName(str(d.get("id", "")))
	if id == &"": return
	Bus.emit(&"ui_push", BusEvents.UIPushed.new(id))


func _on_health_changed(data: Variant) -> void:
	if not data is Dictionary: return
	var d      := data as Dictionary
	var entity := int(d.get("entity", -1))
	var hp     := float(d.get("hp", 0.0))
	var max_hp := float(d.get("max_hp", 1.0))
	if entity < 0: return
	## Only forward player health to the HUD.
	if not EntityManager.has_tag(entity, &"player"): return
	Bus.emit(&"hud.health_updated", {
		"hp":       hp,
		"max_hp":   max_hp,
		"fraction": hp / max_hp if max_hp > 0.0 else 0.0
	})


func _on_quest_updated(data: Variant) -> void:
	if not data is Dictionary: return
	## Re-broadcast with ui-facing event so quest widgets don't depend on gameplay namespace.
	Bus.emit(&"hud.quest_updated", data)


func _on_inventory_changed(data: Variant) -> void:
	if not data is Dictionary: return
	Bus.emit(&"hud.inventory_changed", data)


func _on_entity_died(data: Variant) -> void:
	if not data is Dictionary: return
	var entity := int((data as Dictionary).get("entity", -1))
	if EntityManager.has_tag(entity, &"player"):
		Bus.emit(&"ui_push", BusEvents.UIPushed.new(&"death_screen"))
