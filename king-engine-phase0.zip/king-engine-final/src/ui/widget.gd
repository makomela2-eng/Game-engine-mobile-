## Widget — base class for all KING UI widgets.
## Provides data binding, theming hooks, and open/close lifecycle.
class_name Widget
extends Control

var _data : Dictionary = {}

func on_open(data: Dictionary = {}) -> void:
	_data = data
	_on_data_ready()

func on_close() -> void:
	_on_will_close()

func bind(key: StringName, value: Variant) -> void:
	_data[key] = value
	_on_binding_changed(key, value)

func get_binding(key: StringName, default: Variant = null) -> Variant:
	return _data.get(key, default)

## Override in subclass to react to initial data.
func _on_data_ready() -> void:
	pass

## Override to react to individual binding updates.
func _on_binding_changed(_key: StringName, _value: Variant) -> void:
	pass

## Override for close animation or teardown logic.
func _on_will_close() -> void:
	pass

func close() -> void:
	_on_will_close()
	Bus.emit(&"ui.close", {})
