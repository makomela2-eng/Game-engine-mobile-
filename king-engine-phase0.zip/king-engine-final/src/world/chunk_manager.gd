## ChunkManager — spatial chunk registry with async loading.
##
## _do_load uses ResourceLoader.load_threaded_request to avoid blocking
## the main thread on mobile. Falls back to sync only for empty chunks.
extends Node

var chunk_size : float = 64.0
var _chunks    : Dictionary = {}   ## Vector2i → { state, node, path }

enum ChunkState { UNLOADED, LOADING, LOADED, UNLOADING }

signal chunk_loaded(coord: Vector2i)
signal chunk_unloaded(coord: Vector2i)

func update(focal: Vector3, load_r: float, unload_r: float) -> void:
	var focal_chunk  := world_to_chunk(focal)
	var load_dist    := int(ceil(load_r   / chunk_size))
	var unload_dist  := int(ceil(unload_r / chunk_size))
	for x in range(focal_chunk.x - load_dist, focal_chunk.x + load_dist + 1):
		for y in range(focal_chunk.y - load_dist, focal_chunk.y + load_dist + 1):
			var coord := Vector2i(x, y)
			var entry  : Dictionary = _chunks.get(coord, {})
			if entry.is_empty() or int(entry.get("state", ChunkState.UNLOADED)) == ChunkState.UNLOADED:
				_request_load(coord)
	for coord in _chunks.keys().duplicate():
		var c := coord as Vector2i
		if c.distance_to(focal_chunk) > unload_dist:
			_request_unload(c)

func world_to_chunk(pos: Vector3) -> Vector2i:
	return Vector2i(int(floor(pos.x / chunk_size)), int(floor(pos.z / chunk_size)))

func chunk_to_world(coord: Vector2i) -> Vector3:
	return Vector3(coord.x * chunk_size, 0.0, coord.y * chunk_size)

func register_chunk(coord: Vector2i, scene_path: String) -> void:
	_chunks[coord] = {"state": ChunkState.UNLOADED, "node": null, "path": scene_path}

func _request_load(coord: Vector2i) -> void:
	if not _chunks.has(coord):
		_chunks[coord] = {"state": ChunkState.UNLOADED, "node": null, "path": ""}
	var entry := _chunks[coord] as Dictionary
	if int(entry.get("state")) != ChunkState.UNLOADED: return
	entry["state"] = ChunkState.LOADING
	Bus.emit(&"chunk.load_requested", {"coord": coord})
	_do_load(coord)

func _do_load(coord: Vector2i) -> void:
	var data  : Dictionary = _chunks.get(coord, {})
	var path  : String = str(data.get("path", ""))
	if path.is_empty():
		## No scene — mark loaded immediately (empty chunk).
		(_chunks[coord] as Dictionary)["state"] = ChunkState.LOADED
		chunk_loaded.emit(coord)
		return
	var err := ResourceLoader.load_threaded_request(path)
	if err != OK:
		Log.warn("[ChunkManager] load_threaded_request failed for %s: %s" \
			% [str(coord), error_string(err)])
		(_chunks[coord] as Dictionary)["state"] = ChunkState.UNLOADED
		return
	## Poll via TaskScheduler slot per chunk.
	var slot := StringName("chunk_load_%d_%d" % [coord.x, coord.y])
	TaskScheduler.schedule(slot, 0.1,
		func() -> void: _poll_chunk(coord, path, slot))

func _poll_chunk(coord: Vector2i, path: String, slot: StringName) -> void:
	var status := ResourceLoader.load_threaded_get_status(path)
	match status:
		ResourceLoader.THREAD_LOAD_LOADED:
			TaskScheduler.unschedule(slot)
			var packed := ResourceLoader.load_threaded_get(path) as PackedScene
			if packed == null:
				(_chunks[coord] as Dictionary)["state"] = ChunkState.UNLOADED
				return
			var node := packed.instantiate()
			node.position = chunk_to_world(coord)
			get_tree().root.add_child(node)
			(_chunks[coord] as Dictionary)["node"]  = node
			(_chunks[coord] as Dictionary)["state"] = ChunkState.LOADED
			chunk_loaded.emit(coord)
			Bus.emit(&"chunk.loaded", {"coord": coord})
		ResourceLoader.THREAD_LOAD_FAILED, ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			TaskScheduler.unschedule(slot)
			(_chunks[coord] as Dictionary)["state"] = ChunkState.UNLOADED
			Log.error("[ChunkManager] Async load failed: %s" % path)

func _request_unload(coord: Vector2i) -> void:
	if not _chunks.has(coord): return
	var data := _chunks[coord] as Dictionary
	if int(data.get("state")) != ChunkState.LOADED: return
	data["state"] = ChunkState.UNLOADING
	var node := data.get("node") as Node
	if node and is_instance_valid(node):
		node.queue_free()
	_chunks.erase(coord)
	chunk_unloaded.emit(coord)
	Bus.emit(&"chunk.unloaded", {"coord": coord})

func loaded_count() -> int:
	var n := 0
	for coord in _chunks:
		if int((_chunks[coord] as Dictionary).get("state")) == ChunkState.LOADED:
			n += 1
	return n
