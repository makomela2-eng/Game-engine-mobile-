## LevelLoader — loads a named level by path, replaces current scene content.
extends Node

var _current_path : String = ""
var _current_node : Node   = null

signal level_loaded(path: String)
signal level_unloaded(path: String)

func load_level(path: String) -> void:
	unload()
	Log.info("[LevelLoader] Loading: %s" % path)
	var packed : PackedScene = load(path)
	if packed == null:
		Log.error("[LevelLoader] Not found: %s" % path)
		return
	_current_node = packed.instantiate()
	_current_path = path
	var tree := get_tree()
	if tree == null:
		Log.error("[LevelLoader] No SceneTree available for: %s" % path)
		_current_node = null
		_current_path = ""
		return
	var parent := tree.root
	if parent == null:
		Log.error("[LevelLoader] No valid parent for: %s" % path)
		_current_node = null
		_current_path = ""
		return
	parent.add_child(_current_node)
	if tree.current_scene != _current_node:
		tree.current_scene = _current_node
	Bus.emit(&"scene_loaded", {"path": path})
	level_loaded.emit(path)

func unload() -> void:
	if _current_node and is_instance_valid(_current_node):
		Bus.emit(&"scene_unloaded", {"path": _current_path})
		level_unloaded.emit(_current_path)
		var tree := get_tree()
		if tree != null and tree.current_scene == _current_node:
			tree.current_scene = null
		_current_node.queue_free()
		_current_node = null
		_current_path = ""

func current_level() -> String:
	return _current_path

func is_loaded() -> bool:
	return _current_node != null and is_instance_valid(_current_node)
