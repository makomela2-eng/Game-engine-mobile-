## LODSystem — adjusts LOD bias on MeshInstance3D nodes based on camera distance.
## Uses QuerySystem cache. Listens to camera_changed (not camera.moved).
extends SystemBase

var lod_distance_0 : float = 30.0
var lod_distance_1 : float = 80.0
var lod_distance_2 : float = 160.0
var _camera_pos    : Vector3 = Vector3.ZERO

func _on_start() -> void:
	priority = 8200
	## Correct event name: CameraSystem emits "camera_changed", not "camera.moved".
	listen(&"camera_changed", _on_camera_changed)

func _on_stop() -> void:
	unlisten(&"camera_changed", _on_camera_changed)

func _on_camera_changed(data: Variant) -> void:
	if data is Dictionary:
		var pos_v : Variant = (data as Dictionary).get("position", null)
		if pos_v is Vector3: _camera_pos = pos_v as Vector3

func tick(_delta: float) -> void:
	## QuerySystem cache instead of raw query.
	for id : int in QuerySystem.query([&"SceneNode", &"Mesh"]):
		var sn := get_c(id, &"SceneNode") as SceneNodeComponent
		var mc := get_c(id, &"Mesh")      as MeshComponent
		if sn == null or mc == null or not is_instance_valid(sn.node): continue
		if not sn.node is MeshInstance3D: continue
		var mi   := sn.node as MeshInstance3D
		var dist := _camera_pos.distance_to(sn.node.global_position)
		mi.lod_bias = _bias_for_distance(dist) * mc.lod_bias

func _bias_for_distance(dist: float) -> float:
	if dist < lod_distance_0: return 1.0
	if dist < lod_distance_1: return 0.6
	if dist < lod_distance_2: return 0.3
	return 0.1
