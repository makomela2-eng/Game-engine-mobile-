## WorldStreamer — loads/unloads world regions based on a focal point.
## Throttled to update_hz updates per second to avoid every-frame overhead.
extends Node

var stream_radius  : float = 200.0
var unload_radius  : float = 280.0
var focal_point    : Vector3 = Vector3.ZERO
var update_hz      : float = 2.0   ## chunk updates per second

func _ready() -> void:
	TaskScheduler.schedule(&"world_stream_update",
		1.0 / update_hz, _update)
	Bus.on(&"camera_changed", _on_camera_changed)

func _exit_tree() -> void:
	TaskScheduler.unschedule(&"world_stream_update")
	Bus.off(&"camera_changed", _on_camera_changed)

func _on_camera_changed(data: Variant) -> void:
	if not data is Dictionary: return
	var pos_v : Variant = (data as Dictionary).get("position", null)
	if pos_v is Vector3: focal_point = pos_v as Vector3

func set_focal_entity(entity: int) -> void:
	var t := EntityManager.get_component(entity, &"Transform") as TransformComponent
	if t: focal_point = t.position

func _update() -> void:
	ChunkManager.update(focal_point, stream_radius, unload_radius)

func get_focal_point() -> Vector3: return focal_point
