## Integration test: full ECS frame pipeline.
##
## Spawns 3 entities with distinct component sets, runs for 10 frames,
## validates that each system did its job:
##
##   Entity A — Transform + Velocity + Health + Animation
##     MovementSystem  → position moves
##     HealthSystem    → regen ticks
##     AnimationSystem → current_anim set on move/stop
##
##   Entity B — Health only (static, no movement)
##     HealthSystem    → regen ticks independently
##     MovementSystem  → ignores (no Velocity)
##
##   Entity C — Transform + Velocity, tagged "dead"
##     EntityManager query includes it
##     HealthSystem ignores it (no Health component)
##     Movement still runs (dead tag doesn't block Transform+Velocity)
##
## Bus event log validates the composition chain fires correctly.
extends Node

var _pass      : int  = 0
var _fail      : int  = 0
var _frame     : int  = 0
const FRAMES   : int  = 10

## Entity IDs
var _ea : int = -1
var _eb : int = -1
var _ec : int = -1

## Positions sampled at frame 0 and frame FRAMES
var _pos_a_start : Vector3 = Vector3.ZERO
var _pos_c_start : Vector3 = Vector3.ZERO

## Event log — populated by Bus listeners
var _moved_events    : Array[int] = []   ## entity ids that emitted ecs.entity_moved
var _stopped_events  : Array[int] = []
var _anim_events     : Array[int] = []   ## entity ids that emitted ecs.animation_changed
var _health_changed  : Array[int] = []   ## entity ids that emitted gameplay.health_changed

func _ready() -> void:
	print("[INTEGRATION] ECS pipeline — starting")
	_setup_entities()
	_subscribe_events()
	set_process(true)

func _setup_entities() -> void:
	## Entity A: mover + health + animation
	_ea = EntityManager.create_entity()
	EntityManager.add_component(_ea, &"Transform",  TransformComponent.new(Vector3.ZERO))
	EntityManager.add_component(_ea, &"Velocity",   VelocityComponent.new(Vector3(2, 0, 0)))
	EntityManager.add_component(_ea, &"Health",     HealthComponent.new(100.0))
	EntityManager.add_component(_ea, &"Animation",  AnimationComponent.new(&"idle"))
	## Give entity A some regen so HealthSystem does visible work
	var hc_a := EntityManager.get_component(_ea, &"Health") as HealthComponent
	hc_a.hp        = 50.0   ## start at half health
	hc_a.regen_rate = 5.0   ## 5 hp/s
	_pos_a_start = Vector3.ZERO

	## Entity B: static health only
	_eb = EntityManager.create_entity()
	EntityManager.add_component(_eb, &"Health", HealthComponent.new(80.0))
	var hc_b := EntityManager.get_component(_eb, &"Health") as HealthComponent
	hc_b.hp         = 40.0
	hc_b.regen_rate = 2.0

	## Entity C: mover, no health, tagged dead
	_ec = EntityManager.create_entity()
	EntityManager.add_component(_ec, &"Transform", TransformComponent.new(Vector3(10, 0, 0)))
	EntityManager.add_component(_ec, &"Velocity",  VelocityComponent.new(Vector3(0, 0, 1)))
	EntityManager.add_tag(_ec, &"dead")
	_pos_c_start = Vector3(10, 0, 0)

	Log.info("[INTEGRATION] Spawned entities %d %d %d" % [_ea, _eb, _ec])

func _subscribe_events() -> void:
	Bus.on(&"ecs.entity_moved",      _on_moved)
	Bus.on(&"ecs.entity_stopped",    _on_stopped)
	Bus.on(&"ecs.animation_changed", _on_anim_changed)
	Bus.on(&"gameplay.health_changed", _on_health_changed)

func _process(delta: float) -> void:
	_frame += 1
	if _frame < FRAMES:
		return

	## After FRAMES ticks — validate everything
	set_process(false)
	_unsubscribe_events()
	_validate(delta)
	_cleanup()

# ── Validation ─────────────────────────────────────────────────────────────────

func _validate(last_delta: float) -> void:
	print("[INTEGRATION] Validating after %d frames..." % FRAMES)

	## 1. MovementSystem: entity A should have moved along +X
	var tc_a := EntityManager.get_component(_ea, &"Transform") as TransformComponent
	_assert(tc_a != null,                          "Entity A has TransformComponent")
	if tc_a:
		_assert(tc_a.position.x > _pos_a_start.x,
			"Entity A moved in +X (%.3f > %.3f)" % [tc_a.position.x, _pos_a_start.x])

	## 2. MovementSystem: entity C (dead tag) also moved — tags don't block movement
	var tc_c := EntityManager.get_component(_ec, &"Transform") as TransformComponent
	_assert(tc_c != null, "Entity C has TransformComponent")
	if tc_c:
		_assert(tc_c.position.z > _pos_c_start.z,
			"Entity C moved in +Z (dead tag doesn't block movement)")

	## 3. HealthSystem: entity A regenerated (started 50, regen 5/s, 10 frames)
	var hc_a := EntityManager.get_component(_ea, &"Health") as HealthComponent
	_assert(hc_a != null,        "Entity A has HealthComponent")
	if hc_a:
		_assert(hc_a.hp > 50.0, "Entity A hp regenerated (%.1f > 50.0)" % hc_a.hp)

	## 4. HealthSystem: entity B regenerated independently
	var hc_b := EntityManager.get_component(_eb, &"Health") as HealthComponent
	_assert(hc_b != null,        "Entity B has HealthComponent")
	if hc_b:
		_assert(hc_b.hp > 40.0, "Entity B hp regenerated (%.1f > 40.0)" % hc_b.hp)

	## 5. MovementSystem emitted ecs.entity_moved for entity A
	_assert(_moved_events.has(_ea), "ecs.entity_moved fired for entity A")
	_assert(_moved_events.has(_ec), "ecs.entity_moved fired for entity C")

	## 6. AnimationSystem: entity A's animation set to walk (has Animation component + moved)
	var ac_a := EntityManager.get_component(_ea, &"Animation") as AnimationComponent
	_assert(ac_a != null, "Entity A has AnimationComponent")
	if ac_a:
		_assert(ac_a.current_anim == &"walk" or ac_a.playing,
			"Entity A animation updated (current=%s playing=%s)" % [ac_a.current_anim, ac_a.playing])

	## 7. Bus composition: animation_changed should have fired for entity A
	_assert(_anim_events.has(_ea), "ecs.animation_changed fired for entity A")

	## 8. Entity B has no Velocity — should NOT appear in moved events
	_assert(not _moved_events.has(_eb), "entity B (no Velocity) didn't emit entity_moved")

	## 9. Health events fired for regen (gameplay.health_changed from HealthSystem)
	_assert(_health_changed.has(_ea) or _health_changed.has(_eb),
		"gameplay.health_changed fired for at least one regenerating entity")

	## 10. EntityManager integrity — entities still exist
	_assert(EntityManager.entity_exists(_ea), "Entity A still exists after 10 frames")
	_assert(EntityManager.entity_exists(_eb), "Entity B still exists after 10 frames")
	_assert(EntityManager.entity_exists(_ec), "Entity C still exists after 10 frames")

	_summary()

# ── Event handlers ─────────────────────────────────────────────────────────────

func _on_moved(evt: Variant) -> void:
	if evt is BusEvents.EntityMoved:
		var e := evt as BusEvents.EntityMoved
		if not _moved_events.has(e.entity):
			_moved_events.append(e.entity)

func _on_stopped(evt: Variant) -> void:
	if evt is BusEvents.EntityStopped:
		var e := evt as BusEvents.EntityStopped
		if not _stopped_events.has(e.entity):
			_stopped_events.append(e.entity)

func _on_anim_changed(evt: Variant) -> void:
	if evt is Dictionary:
		var id := int((evt as Dictionary).get("entity", -1))
		if not _anim_events.has(id):
			_anim_events.append(id)

func _on_health_changed(evt: Variant) -> void:
	if evt is Dictionary:
		var id := int((evt as Dictionary).get("entity", -1))
		if not _health_changed.has(id):
			_health_changed.append(id)

# ── Cleanup ────────────────────────────────────────────────────────────────────

func _unsubscribe_events() -> void:
	Bus.off(&"ecs.entity_moved",       _on_moved)
	Bus.off(&"ecs.entity_stopped",     _on_stopped)
	Bus.off(&"ecs.animation_changed",  _on_anim_changed)
	Bus.off(&"gameplay.health_changed", _on_health_changed)

func _cleanup() -> void:
	EntityManager.destroy_entity(_ea)
	EntityManager.destroy_entity(_eb)
	EntityManager.destroy_entity(_ec)
	Log.info("[INTEGRATION] Entities cleaned up")

# ── Helpers ────────────────────────────────────────────────────────────────────

func _assert(condition: bool, msg: String) -> void:
	if condition:
		_pass += 1
		Log.debug("[INTEGRATION] PASS: " + msg)
	else:
		_fail += 1
		push_error("[INTEGRATION FAIL] " + msg)

func _summary() -> void:
	print("[INTEGRATION] ECS pipeline — %d passed, %d failed" % [_pass, _fail])
	if _fail == 0:
		print("[INTEGRATION] ✓ All systems are live and connected")
	else:
		push_error("[INTEGRATION] %d assertion(s) failed — check output above" % _fail)
