## Integration test: SceneStream loads and unloads a scene.
extends Node

func _ready() -> void:
	print("[INTEGRATION] SceneStream test starting...")
	var ss_scr : Script = load("res://src/streaming/SceneStream.gd")
	assert(ss_scr != null, "SceneStream script must exist")
	var ss : Node = ss_scr.new()
	add_child(ss)
	print("[INTEGRATION] SceneStream instantiated ✓")
	ss.queue_free()
	get_tree().quit(0)
