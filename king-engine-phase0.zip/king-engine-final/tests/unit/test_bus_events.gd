## Unit tests for Bus and BusEvents typed payload system.
extends Node

var _pass    : int  = 0
var _fail    : int  = 0
var _received : Array = []

func _ready() -> void:
	print("[TEST] Bus/BusEvents — starting")
	_test_on_off_emit()
	_test_typed_payload()
	_test_multiple_listeners()
	_test_unlisten_cleanup()
	_summary()

# ── Tests ──────────────────────────────────────────────────────────────────────

func _test_on_off_emit() -> void:
	_received.clear()
	Bus.on(&"test.basic", _collect)
	Bus.emit(&"test.basic", 42)
	_assert(_received.size() == 1, "received exactly one event")
	_assert(_received[0] == 42,    "payload value preserved")
	Bus.off(&"test.basic", _collect)
	Bus.emit(&"test.basic", 99)
	_assert(_received.size() == 1, "no event after off()")
	print("  ✓ on/off/emit")

func _test_typed_payload() -> void:
	_received.clear()
	Bus.on(&"test.typed", _collect)
	var evt := BusEvents.EntityMoved.new(7, Vector3(1, 2, 3), 0.016)
	Bus.emit(&"test.typed", evt)
	_assert(_received.size() == 1, "typed payload received")
	var got: Variant = _received[0]
	_assert(got is BusEvents.EntityMoved, "payload is BusEvents.EntityMoved")
	var moved := got as BusEvents.EntityMoved
	_assert(moved.entity == 7,            "entity id preserved")
	_assert(moved.position.is_equal_approx(Vector3(1,2,3)), "position preserved")
	Bus.off(&"test.typed", _collect)
	print("  ✓ typed BusEvents payload")

func _test_multiple_listeners() -> void:
	_received.clear()
	var count_a : int = 0
	var count_b : int = 0
	var fn_a := func(_d): count_a += 1
	var fn_b := func(_d): count_b += 1
	Bus.on(&"test.multi", fn_a)
	Bus.on(&"test.multi", fn_b)
	Bus.emit(&"test.multi", null)
	_assert(count_a == 1, "listener A fired")
	_assert(count_b == 1, "listener B fired")
	Bus.off(&"test.multi", fn_a)
	Bus.off(&"test.multi", fn_b)
	print("  ✓ multiple listeners")

func _test_unlisten_cleanup() -> void:
	## Verify off() during emit doesn't crash (Bus uses .duplicate() snapshot).
	var fired : int = 0
	var self_removing := func(_d):
		fired += 1
		Bus.off(&"test.self_remove", func(_x): pass)  # safe no-op removal mid-emit
	Bus.on(&"test.self_remove", self_removing)
	Bus.emit(&"test.self_remove", null)
	_assert(fired == 1, "listener ran before self-removal")
	Bus.off(&"test.self_remove", self_removing)
	print("  ✓ unlisten during emit is safe")

# ── Helpers ────────────────────────────────────────────────────────────────────

func _collect(data: Variant) -> void:
	_received.append(data)

func _assert(condition: bool, msg: String) -> void:
	if condition:
		_pass += 1
	else:
		_fail += 1
		push_error("[TEST FAIL] Bus: " + msg)

func _summary() -> void:
	print("[TEST] Bus/BusEvents — %d passed, %d failed" % [_pass, _fail])
	if _fail > 0:
		push_error("[TEST] Bus has %d failure(s)" % _fail)
