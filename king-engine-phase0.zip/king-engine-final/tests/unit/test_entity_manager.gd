## Unit tests for EntityManager (snake_case canonical version).
## Tests the real autoloaded API: create, destroy, components, tags, queries.
## Run via DebugScene or GUT.
extends Node

var _pass : int = 0
var _fail : int = 0

func _ready() -> void:
	print("[TEST] EntityManager — starting")
	_test_create_destroy()
	_test_component_add_get_remove()
	_test_component_type_key()
	_test_tags()
	_test_query()
	_test_snapshot()
	_summary()

# ── Tests ──────────────────────────────────────────────────────────────────────

func _test_create_destroy() -> void:
	var id := EntityManager.create_entity()
	_assert(id >= 0,                         "create returns non-negative id")
	_assert(EntityManager.entity_exists(id), "entity exists after create")
	EntityManager.destroy_entity(id)
	_assert(not EntityManager.entity_exists(id), "entity gone after destroy")
	print("  ✓ create/destroy")

func _test_component_add_get_remove() -> void:
	var id := EntityManager.create_entity()
	var hc := HealthComponent.new(50.0)
	EntityManager.add_component(id, &"Health", hc)
	_assert(EntityManager.has_component(id, &"Health"), "has_component after add")
	var got := EntityManager.get_component(id, &"Health") as HealthComponent
	_assert(got != null,        "get_component returns non-null")
	_assert(got.max_hp == 50.0, "HealthComponent max_hp preserved")
	EntityManager.remove_component(id, &"Health")
	_assert(not EntityManager.has_component(id, &"Health"), "component gone after remove")
	EntityManager.destroy_entity(id)
	print("  ✓ component add/get/remove")

func _test_component_type_key() -> void:
	var id := EntityManager.create_entity()
	EntityManager.add_component(id, &"Health",    HealthComponent.new(100.0))
	EntityManager.add_component(id, &"Transform", TransformComponent.new())
	var types := EntityManager.get_component_types(id)
	_assert(types.has(&"Health"),    "Health type present")
	_assert(types.has(&"Transform"), "Transform type present")
	_assert(types.size() == 2,       "exactly 2 component types")
	EntityManager.destroy_entity(id)
	print("  ✓ component type keys")

func _test_tags() -> void:
	var id := EntityManager.create_entity()
	EntityManager.add_tag(id, &"player")
	EntityManager.add_tag(id, &"team_a")
	_assert(EntityManager.has_tag(id, &"player"),  "has tag player")
	_assert(EntityManager.has_tag(id, &"team_a"),  "has tag team_a")
	_assert(not EntityManager.has_tag(id, &"ai"),  "no tag ai")
	var by_tag := EntityManager.get_entities_by_tag(&"player")
	_assert(by_tag.has(id),                        "get_entities_by_tag finds entity")
	EntityManager.remove_tag(id, &"player")
	_assert(not EntityManager.has_tag(id, &"player"), "tag removed")
	EntityManager.destroy_entity(id)
	print("  ✓ tags")

func _test_query() -> void:
	var a := EntityManager.create_entity()
	var b := EntityManager.create_entity()
	EntityManager.add_component(a, &"Health",    HealthComponent.new())
	EntityManager.add_component(a, &"Transform", TransformComponent.new())
	EntityManager.add_component(b, &"Transform", TransformComponent.new())
	var with_health := EntityManager.get_entities_with([&"Health"])
	_assert(with_health.has(a),     "a in Health query")
	_assert(not with_health.has(b), "b not in Health query")
	var with_both := EntityManager.get_entities_with([&"Health", &"Transform"])
	_assert(with_both.has(a),       "a in Health+Transform query")
	_assert(not with_both.has(b),   "b not in Health+Transform query")
	EntityManager.destroy_entity(a)
	EntityManager.destroy_entity(b)
	print("  ✓ queries")

func _test_snapshot() -> void:
	var id := EntityManager.create_entity()
	EntityManager.add_component(id, &"Transform", TransformComponent.new(Vector3(1,2,3)))
	EntityManager.add_component(id, &"Velocity",  VelocityComponent.new(Vector3(1,0,0)))
	EntityManager.add_tag(id, &"test_tag")
	var snap := EntityManager.snapshot()
	_assert(snap.has("entities"),       "snapshot has entities key")
	_assert(snap.get("version", 0) > 0, "snapshot has version")
	EntityManager.destroy_entity(id)
	print("  ✓ snapshot")

# ── Helpers ────────────────────────────────────────────────────────────────────

func _assert(condition: bool, msg: String) -> void:
	if condition:
		_pass += 1
	else:
		_fail += 1
		push_error("[TEST FAIL] EntityManager: " + msg)

func _summary() -> void:
	print("[TEST] EntityManager — %d passed, %d failed" % [_pass, _fail])
	if _fail > 0:
		push_error("[TEST] EntityManager has %d failure(s)" % _fail)
