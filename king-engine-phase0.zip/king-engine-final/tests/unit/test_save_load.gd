## Unit tests for SaveLoadManager.
## Tests the real autoloaded API: save(), load_slot(), slot_info(), delete_slot().
extends Node

var _pass : int = 0
var _fail : int = 0

func _ready() -> void:
	print("[TEST] SaveLoadManager — starting")
	_test_round_trip()
	_test_version_stamp()
	_test_slot_info()
	_test_delete()
	_test_missing_slot()
	_summary()

# ── Tests ──────────────────────────────────────────────────────────────────────

func _test_round_trip() -> void:
	var data := {"player_hp": 75.0, "level": 3, "name": "TestHero"}
	var ok := SaveLoadManager.save(0, data)
	_assert(ok, "save() returns true")
	var loaded := SaveLoadManager.load_slot(0)
	_assert(not loaded.is_empty(),              "load_slot returns non-empty dict")
	_assert(loaded.get("player_hp") == 75.0,    "player_hp round-trips")
	_assert(loaded.get("level")     == 3,       "level round-trips")
	_assert(loaded.get("name")      == "TestHero", "name round-trips")
	print("  ✓ round-trip")

func _test_version_stamp() -> void:
	SaveLoadManager.save(0, {"x": 1})
	var loaded := SaveLoadManager.load_slot(0)
	_assert(loaded.has("_version"),   "save stamps _version")
	_assert(loaded.has("_timestamp"), "save stamps _timestamp")
	print("  ✓ version/timestamp stamp")

func _test_slot_info() -> void:
	SaveLoadManager.save(0, {"y": 2})
	var info := SaveLoadManager.slot_info(0)
	_assert(not info.get("empty", true),    "slot 0 not empty")
	_assert(info.get("slot", -1) == 0,      "slot_info slot field correct")
	_assert(info.has("timestamp"),          "slot_info has timestamp")
	print("  ✓ slot_info")

func _test_delete() -> void:
	SaveLoadManager.save(1, {"temp": true})
	_assert(SaveLoadManager.slot_exists(1), "slot 1 exists before delete")
	SaveLoadManager.delete_slot(1)
	_assert(not SaveLoadManager.slot_exists(1), "slot 1 gone after delete")
	print("  ✓ delete_slot")

func _test_missing_slot() -> void:
	SaveLoadManager.delete_slot(2)
	var loaded := SaveLoadManager.load_slot(2)
	_assert(loaded.is_empty(), "missing slot returns empty dict")
	print("  ✓ missing slot returns empty")

# ── Helpers ────────────────────────────────────────────────────────────────────

func _assert(condition: bool, msg: String) -> void:
	if condition:
		_pass += 1
	else:
		_fail += 1
		push_error("[TEST FAIL] SaveLoad: " + msg)

func _summary() -> void:
	print("[TEST] SaveLoadManager — %d passed, %d failed" % [_pass, _fail])
	if _fail > 0:
		push_error("[TEST] SaveLoadManager has %d failure(s)" % _fail)
